import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusDays((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar12 = dateTime11.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getLeapAmount(36000052L);
        long long24 = dividedDateTimeField17.roundHalfEven(1560636573041L);
        long long27 = dividedDateTimeField17.addWrapField((long) (-79760), (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560636573048L + "'", long24 == 1560636573048L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-79736L) + "'", long27 == (-79736L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', 0, 9, 19, (int) '4', 7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Jun", 28, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for Jun must be in the range [-1,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        boolean boolean22 = unsupportedDateTimeField21.isLenient();
        boolean boolean23 = unsupportedDateTimeField21.isSupported();
        try {
            long long26 = unsupportedDateTimeField21.set(1560636587000L, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getLeapAmount(36000052L);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfMonth();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology27);
        boolean boolean31 = dateTime26.isAfter((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime.Property property32 = dateTime30.monthOfYear();
        org.joda.time.DateTime dateTime34 = dateTime30.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime38 = dateTime34.minusHours(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.dayOfMonth();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology43);
        boolean boolean47 = dateTime46.isEqualNow();
        org.joda.time.DateTime.Property property48 = dateTime46.hourOfDay();
        org.joda.time.DateTime.Property property49 = dateTime46.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder40.appendSignedDecimal(dateTimeFieldType50, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField59 = gregorianChronology58.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField60 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType50, durationField59);
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) (-10), (java.lang.Number) (byte) 0, (java.lang.Number) (-28800000));
        boolean boolean65 = dateTime38.isSupported(dateTimeFieldType50);
        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) 166L, (java.lang.Number) 9, (java.lang.Number) 1.0d);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, dateTimeFieldType50);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        org.joda.time.DateTime dateTime15 = dateTime11.minusSeconds(6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str17 = dateTime11.toString(dateTimeFormatter16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.weekOfWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime11.toMutableDateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime dateTime25 = dateTime11.minusMinutes((int) (byte) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T22:10:21.670Z" + "'", str17.equals("T22:10:21.670Z"));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.hourOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType7, 79807, 5, 79);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79807 for millisOfSecond must be in the range [5,79]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("79797", "79772");
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
//        org.joda.time.Interval interval11 = property10.toInterval();
//        int int12 = property10.getMinimumValue();
//        java.lang.String str13 = property10.getAsString();
//        java.util.Locale locale14 = null;
//        int int15 = property10.getMaximumShortTextLength(locale14);
//        long long16 = property10.remainder();
//        int int17 = property10.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "79822" + "'", str13.equals("79822"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 237L + "'", long16 == 237L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTime dateTime18 = property17.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime20 = dateTime18.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getLeapDurationField();
        try {
            int int23 = unsupportedDateTimeField21.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) '4');
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTime7.toString("79772", locale13);
        org.joda.time.DateTime dateTime16 = dateTime7.withWeekOfWeekyear((int) '#');
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime7.plus(readableDuration17);
        org.joda.time.DateTime.Property property19 = dateTime18.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "79772" + "'", str14.equals("79772"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(100);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder2.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNull(dateTimeZone7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        boolean boolean18 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = dateTime13.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate21 = dateTime13.toLocalDate();
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        boolean boolean27 = dateTime26.isEqualNow();
        org.joda.time.DateTime dateTime29 = dateTime26.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime31 = dateTime26.withWeekyear(0);
        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
        int int33 = property9.compareTo((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime.Property property34 = dateTime31.monthOfYear();
        org.joda.time.DateTime dateTime35 = dateTime31.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTimeISO();
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "79770", 770);
        try {
            org.joda.time.LocalDate localDate14 = dateTimeFormatter0.parseLocalDate("79810");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"79810\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-771) + "'", int12 == (-771));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long29 = cachedDateTimeZone27.previousTransition(10L);
        org.joda.time.DateTimeZone dateTimeZone30 = cachedDateTimeZone27.getUncachedZone();
        boolean boolean31 = cachedDateTimeZone27.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("79");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"79/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType14, 0, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendCenturyOfEra(44, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 0L, 100);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = dateTime10.plusDays((-1));
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTimeISO();
        org.joda.time.Instant instant12 = dateTime11.toInstant();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
        try {
            long long24 = unsupportedDateTimeField21.roundHalfEven(36000052L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(100);
        org.joda.time.DateTime dateTime11 = dateTime5.minusWeeks(1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getLeapAmount(36000052L);
        long long24 = dividedDateTimeField17.roundHalfEven(1560636573041L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560636573048L + "'", long24 == 1560636573048L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        java.util.Locale locale20 = null;
        int int21 = dividedDateTimeField17.getMaximumTextLength(locale20);
        int int23 = dividedDateTimeField17.get((long) 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "79784", 19, 44);
        long long6 = fixedDateTimeZone4.nextTransition(0L);
        long long8 = fixedDateTimeZone4.previousTransition(0L);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) 166);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 44 + "'", int10 == 44);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("70000000000000000000000000000000000010000000000000000000000000000000000000000000000000001");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"70000000000000000000000000000000000010000000000000000000000000000000000000000000000000001/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        long long4 = dateTimeZone1.convertLocalToUTC((long) 44, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-35999956L) + "'", long4 == (-35999956L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(36000000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
        boolean boolean12 = dateTime10.isAfter(1560636565813L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
//        boolean boolean25 = dividedDateTimeField17.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.dayOfMonth();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
//        boolean boolean34 = dateTime29.isAfter((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime37 = dateTime33.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime39 = dateTime37.withHourOfDay(0);
//        org.joda.time.TimeOfDay timeOfDay40 = dateTime37.toTimeOfDay();
//        int int41 = dividedDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay40);
//        long long44 = dividedDateTimeField17.set((long) (-10), 6);
//        java.lang.String str45 = dividedDateTimeField17.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(timeOfDay40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-850L) + "'", long44 == (-850L));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str45.equals("DateTimeField[millisOfSecond]"));
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
        org.joda.time.ReadableInstant readableInstant11 = null;
        long long12 = property10.getDifferenceAsLong(readableInstant11);
        org.joda.time.DateTime dateTime14 = property10.setCopy("1");
        org.joda.time.DurationField durationField15 = property10.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property10.getFieldType();
        org.joda.time.DateTime dateTime18 = property10.addWrapFieldToCopy(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour(0, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.dayOfMonth();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        boolean boolean13 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.monthOfYear();
        org.joda.time.DateTime.Property property15 = dateTime12.secondOfDay();
        org.joda.time.ReadableInstant readableInstant16 = null;
        long long17 = property15.getDifferenceAsLong(readableInstant16);
        org.joda.time.DateTime dateTime19 = property15.setCopy("1");
        org.joda.time.DurationField durationField20 = property15.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property15.getFieldType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType21, (-771), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType14, 0, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendFractionOfMinute(44, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long29 = cachedDateTimeZone27.previousTransition(10L);
        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
        boolean boolean32 = cachedDateTimeZone27.isFixed();
        long long34 = cachedDateTimeZone27.nextTransition((long) 79819);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 79819L + "'", long34 == 79819L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "dayOfMonth", "79770");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "79809", "Property[secondOfDay]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime5.minusWeeks(79760);
        int int10 = dateTime9.getWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 490 + "'", int10 == 490);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
//        org.joda.time.Interval interval11 = property10.toInterval();
//        org.joda.time.DurationField durationField12 = property10.getRangeDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property10.getAsText(locale13);
//        boolean boolean15 = property10.isLeap();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "79825" + "'", str14.equals("79825"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        org.joda.time.DurationField durationField23 = remainderDateTimeField20.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfMonth();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfMonth();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology28);
        boolean boolean32 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime.Property property33 = dateTime31.monthOfYear();
        org.joda.time.DateTime dateTime35 = dateTime31.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime37 = dateTime35.plusMonths((int) (byte) 0);
        int int38 = dateTime37.getYearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.dayOfMonth();
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology39);
        boolean boolean43 = dateTime42.isEqualNow();
        org.joda.time.DateTime dateTime45 = dateTime42.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime47 = dateTime42.withWeekyear(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.dayOfMonth();
        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology48);
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology52.dayOfMonth();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology52);
        boolean boolean56 = dateTime51.isAfter((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DateTime dateTime58 = dateTime51.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate59 = dateTime51.toLocalDate();
        java.lang.Class<?> wildcardClass60 = localDate59.getClass();
        org.joda.time.DateTime dateTime61 = dateTime42.withFields((org.joda.time.ReadablePartial) localDate59);
        org.joda.time.DateTime dateTime62 = dateTime37.withFields((org.joda.time.ReadablePartial) localDate59);
        int[] intArray68 = new int[] { 2552640, 79770, 79797, 3 };
        try {
            int[] intArray70 = remainderDateTimeField20.add((org.joda.time.ReadablePartial) localDate59, 79819, intArray68, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 79819");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        long long22 = dividedDateTimeField17.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(10, '4', (-79760), 3, 1, false, (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("hi!", (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder8.setStandardOffset(19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        boolean boolean3 = dateTimeFormatter1.isParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        int int13 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "79770", 770);
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "79", (int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withDefaultYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-771) + "'", int13 == (-771));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        java.util.Locale locale11 = null;
        int int12 = property9.getMaximumShortTextLength(locale11);
        java.lang.String str13 = property9.toString();
        java.lang.String str14 = property9.getAsString();
        org.joda.time.DateTime dateTime15 = property9.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "6" + "'", str14.equals("6"));
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
//        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
//        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
//        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long29 = cachedDateTimeZone27.previousTransition(10L);
//        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
//        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
//        int int35 = cachedDateTimeZone27.getOffset((-604799900L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.dayOfMonth();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
//        boolean boolean42 = dateTime41.isEqualNow();
//        org.joda.time.DateTime.Property property43 = dateTime41.hourOfDay();
//        org.joda.time.DateTime.Property property44 = dateTime41.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType45, 24);
//        java.lang.String str55 = dividedDateTimeField53.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField53, 4);
//        long long60 = dividedDateTimeField53.roundHalfCeiling((-18491L));
//        int int63 = dividedDateTimeField53.getDifference((long) 13, 0L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        boolean boolean65 = cachedDateTimeZone27.equals((java.lang.Object) dividedDateTimeField53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder66.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder67.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology70.dayOfMonth();
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology70);
//        boolean boolean74 = dateTime73.isEqualNow();
//        org.joda.time.DateTime.Property property75 = dateTime73.hourOfDay();
//        org.joda.time.DateTime.Property property76 = dateTime73.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = property76.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder67.appendSignedDecimal(dateTimeFieldType77, (int) (short) 0, 79);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, "79769");
//        java.lang.String str87 = illegalFieldValueException86.getFieldName();
//        java.lang.String str88 = illegalFieldValueException86.getIllegalValueAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType89 = illegalFieldValueException86.getDateTimeFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField90 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53, dateTimeFieldType89);
//        int int92 = remainderDateTimeField90.getLeapAmount((long) 770);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1" + "'", str55.equals("1"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-18496L) + "'", long60 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "millisOfSecond" + "'", str87.equals("millisOfSecond"));
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "79769" + "'", str88.equals("79769"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType89);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 0L, 100);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(79770);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfDay((int) (short) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder2.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        boolean boolean14 = dateTime13.isEqualNow();
        org.joda.time.DateTime.Property property15 = dateTime13.hourOfDay();
        org.joda.time.DateTime.Property property16 = dateTime13.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType17, (int) (short) 0, 79);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendHourOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendClockhourOfHalfday(100);
        org.joda.time.format.DateTimePrinter dateTimePrinter31 = dateTimeFormatterBuilder30.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter32.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter31, dateTimeParser33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.util.Locale locale36 = dateTimeFormatter35.getLocale();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter31, dateTimeParser37);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder24.appendOptional(dateTimeParser37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimePrinter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNull(locale36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime7.isEqualNow();
//        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
//        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getLeapDurationField();
//        try {
//            int int23 = unsupportedDateTimeField21.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertNull(durationField22);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(79770);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfDay(3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        int int17 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        boolean boolean27 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime.Property property28 = dateTime26.monthOfYear();
        org.joda.time.DateTime dateTime30 = dateTime26.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime34 = dateTime30.minusHours(3);
        org.joda.time.DateTime.Property property35 = dateTime34.yearOfEra();
        int int36 = dateTime34.getYear();
        org.joda.time.DateTime dateTime38 = dateTime34.plusMillis(4);
        boolean boolean39 = zonedChronology18.equals((java.lang.Object) dateTime38);
        try {
            long long44 = zonedChronology18.getDateTimeMillis(79819155, 0, 15, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36000000 + "'", int17 == 36000000);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(79770);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfDay((int) (short) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder2.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTwoDigitYear(7, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
//        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
//        org.joda.time.DurationField durationField28 = dividedDateTimeField17.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        int int17 = dateTime15.getYear();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime15.toYearMonthDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(yearMonthDay18);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        long long25 = offsetDateTimeField22.add((long) 13, (-771));
        long long27 = offsetDateTimeField22.roundHalfFloor((long) 44);
        int int29 = offsetDateTimeField22.get(1560636587000L);
        org.joda.time.DurationField durationField30 = offsetDateTimeField22.getDurationField();
        long long32 = offsetDateTimeField22.roundFloor((long) 600);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-18491L) + "'", long25 == (-18491L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 48L + "'", long27 == 48L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 600L + "'", long32 == 600L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withTime(6, 10, 36, 3324);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3324 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime20 = dateTime17.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime20.withMillis((long) 79);
        int int23 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime22);
        long long25 = dateTimeZone1.convertUTCToLocal((long) 23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 36000000 + "'", int23 == 36000000);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 36000023L + "'", long25 == 36000023L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 237L, number2, (java.lang.Number) (-18491L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfMonth();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.hourOfDay();
        org.joda.time.DateTime.Property property14 = dateTime11.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType15, 0, 4);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        int int24 = remainderDateTimeField20.get((-18376L));
        int int26 = remainderDateTimeField20.get(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        boolean boolean18 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime20 = dateTime13.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate21 = dateTime13.toLocalDate();
//        int int22 = property9.compareTo((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeField dateTimeField23 = property9.getField();
//        org.joda.time.DateTime dateTime24 = property9.roundFloorCopy();
//        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.dayOfMonth();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
//        boolean boolean34 = dateTime29.isAfter((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property35 = dateTime33.monthOfYear();
//        org.joda.time.DateTime.Property property36 = dateTime33.secondOfDay();
//        org.joda.time.DateTime dateTime38 = dateTime33.minusSeconds(2019);
//        org.joda.time.DateTime dateTime40 = dateTime33.withMonthOfYear(10);
//        int int41 = property25.getDifference((org.joda.time.ReadableInstant) dateTime40);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-197170) + "'", int41 == (-197170));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        org.joda.time.DateTimeField dateTimeField23 = dividedDateTimeField17.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMonthOfYear((int) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDayOfMonth((int) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder5.toFormatter();
//        java.lang.String str11 = dateTime1.toString(dateTimeFormatter10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime1.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "70000000000000000000000000000000000010000000000000000000000000000000000000000000000000001" + "'", str11.equals("70000000000000000000000000000000000010000000000000000000000000000000000000000000000000001"));
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        boolean boolean22 = unsupportedDateTimeField21.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
        try {
            int int25 = unsupportedDateTimeField21.getMinimumValue((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        int int12 = dateTime7.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 996 + "'", int12 == 996);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(1560600573041L, 490);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis((int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.DateTime dateTime11 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfEra((int) (byte) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        int int17 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        boolean boolean27 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime.Property property28 = dateTime26.monthOfYear();
        org.joda.time.DateTime dateTime30 = dateTime26.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime34 = dateTime30.minusHours(3);
        org.joda.time.DateTime.Property property35 = dateTime34.yearOfEra();
        int int36 = dateTime34.getYear();
        org.joda.time.DateTime dateTime38 = dateTime34.plusMillis(4);
        boolean boolean39 = zonedChronology18.equals((java.lang.Object) dateTime38);
        org.joda.time.DateTimeField dateTimeField40 = zonedChronology18.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36000000 + "'", int17 == 36000000);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMonthOfYear((int) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDayOfMonth((int) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder5.toFormatter();
//        java.lang.String str11 = dateTime1.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = dateTime1.minusWeeks(79797);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "70000000000000000000000000000000000010000000000000000000000000000000000000000000000000001" + "'", str11.equals("70000000000000000000000000000000000010000000000000000000000000000000000000000000000000001"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfMonth();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        boolean boolean10 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime5.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate13 = dateTime5.toLocalDate();
//        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate13);
//        boolean boolean15 = dateTimeFormatter0.isParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019166T������" + "'", str14.equals("2019166T������"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) '4');
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTime7.toString("79772", locale13);
        org.joda.time.DateTime.Property property15 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime16 = property15.withMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "79772" + "'", str14.equals("79772"));
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        int int17 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36000000 + "'", int17 == 36000000);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.dayOfMonth();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology20);
        boolean boolean24 = dateTime23.isEqualNow();
        org.joda.time.DateTime.Property property25 = dateTime23.hourOfDay();
        org.joda.time.DateTime.Property property26 = dateTime23.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType27, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField36 = gregorianChronology35.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField36);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) (-10), (java.lang.Number) (byte) 0, (java.lang.Number) (-28800000));
        boolean boolean42 = dateTime15.isSupported(dateTimeFieldType27);
        int int43 = dateTime15.getSecondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 75600 + "'", int43 == 75600);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
        boolean boolean7 = dateTime3.isBefore((long) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
//        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        java.lang.String str29 = dividedDateTimeField17.getName();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.dayOfMonth();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
//        boolean boolean37 = dateTime36.isEqualNow();
//        org.joda.time.DateTime.Property property38 = dateTime36.hourOfDay();
//        org.joda.time.DateTime.Property property39 = dateTime36.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField32, dateTimeFieldType40, 24);
//        java.lang.String str50 = dividedDateTimeField48.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField48);
//        int int53 = dividedDateTimeField48.getLeapAmount(36000052L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.dayOfMonth();
//        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology54);
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology58.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology58.dayOfMonth();
//        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology58);
//        boolean boolean62 = dateTime57.isAfter((org.joda.time.ReadableInstant) dateTime61);
//        org.joda.time.DateTime dateTime64 = dateTime57.minusMillis((int) (short) -1);
//        org.joda.time.DateTime dateTime66 = dateTime64.plusMillis((int) (byte) 100);
//        org.joda.time.DateTime.Property property67 = dateTime64.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology68.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology68.dayOfMonth();
//        org.joda.time.DateTime dateTime71 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology68);
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology72.dayOfMonth();
//        org.joda.time.DateTime dateTime75 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology72);
//        boolean boolean76 = dateTime71.isAfter((org.joda.time.ReadableInstant) dateTime75);
//        org.joda.time.DateTime dateTime78 = dateTime71.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate79 = dateTime71.toLocalDate();
//        java.lang.Class<?> wildcardClass80 = localDate79.getClass();
//        int int81 = property67.compareTo((org.joda.time.ReadablePartial) localDate79);
//        int int82 = dividedDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) localDate79);
//        long long84 = iSOChronology30.set((org.joda.time.ReadablePartial) localDate79, (long) 1969);
//        java.util.Locale locale85 = null;
//        try {
//            java.lang.String str86 = dividedDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate79, locale85);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "millisOfSecond" + "'", str29.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(localDate79);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 41 + "'", int82 == 41);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560556801969L + "'", long84 == 1560556801969L);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
        try {
            int int24 = unsupportedDateTimeField21.getLeapAmount((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate11 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
        java.lang.String str13 = property12.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfMonth" + "'", str13.equals("dayOfMonth"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long29 = cachedDateTimeZone27.previousTransition(10L);
        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
        int int35 = cachedDateTimeZone27.getOffset((-604799900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.dayOfMonth();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
        boolean boolean42 = dateTime41.isEqualNow();
        org.joda.time.DateTime.Property property43 = dateTime41.hourOfDay();
        org.joda.time.DateTime.Property property44 = dateTime41.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType45, 24);
        java.lang.String str55 = dividedDateTimeField53.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField53, 4);
        long long60 = dividedDateTimeField53.roundHalfCeiling((-18491L));
        int int63 = dividedDateTimeField53.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
        boolean boolean65 = cachedDateTimeZone27.equals((java.lang.Object) dividedDateTimeField53);
        long long68 = dividedDateTimeField53.add((long) (-79727), 23);
        long long70 = dividedDateTimeField53.remainder((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1" + "'", str55.equals("1"));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-18496L) + "'", long60 == (-18496L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-79175L) + "'", long68 == (-79175L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekyear(0);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField15 = gregorianChronology14.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTime((org.joda.time.Chronology) gregorianChronology14);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) property9, (org.joda.time.Chronology) gregorianChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendDayOfMonth((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, 75600, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75600 for yearOfEra must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 10);
        int int14 = dateTime11.getYearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendDayOfMonth((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.append(dateTimeFormatter10);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatterBuilder7.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(79807);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.dayOfMonth();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology5);
        boolean boolean9 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.monthOfYear();
        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
        java.util.Locale locale12 = null;
        int int13 = property10.getMaximumTextLength(locale12);
        boolean boolean14 = iSOChronology0.equals((java.lang.Object) property10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
        org.joda.time.ReadableInstant readableInstant11 = null;
        long long12 = property10.getDifferenceAsLong(readableInstant11);
        org.joda.time.DateTime dateTime14 = property10.setCopy("1");
        int int15 = property10.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        int int17 = dateTime15.getYear();
        int int18 = dateTime15.getYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType14, 0, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendCenturyOfEra(44, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYear(79807, 41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendTwoDigitYear(9);
        boolean boolean18 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatterBuilder15.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendClockhourOfHalfday(100);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatterBuilder22.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter23, dateTimeParser25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.util.Locale locale28 = dateTimeFormatter27.getLocale();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter27.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter23, dateTimeParser29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder5.append(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNull(locale28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getLeapDurationField();
        try {
            java.lang.String str24 = unsupportedDateTimeField21.getAsText((-144L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dividedDateTimeField17.getAsShortText(19, locale30);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "19" + "'", str31.equals("19"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (byte) 100);
        long long6 = dateTimeZone1.adjustOffset((long) 770, false);
        boolean boolean8 = dateTimeZone1.isStandardOffset((long) 21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 770L + "'", long6 == 770L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTimeISO();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime3.withPeriodAdded(readablePeriod12, 19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        java.lang.String str18 = property17.getAsShortText();
        org.joda.time.DurationField durationField19 = property17.getLeapDurationField();
        org.joda.time.DateTime dateTime20 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime22 = property17.setCopy("79805");
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        org.joda.time.DurationField durationField23 = remainderDateTimeField20.getRangeDurationField();
        long long25 = remainderDateTimeField20.roundHalfEven((long) 79779);
        java.util.Locale locale26 = null;
        int int27 = remainderDateTimeField20.getMaximumShortTextLength(locale26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = remainderDateTimeField20.getAsShortText(94, locale29);
        long long32 = remainderDateTimeField20.roundCeiling((long) 75600);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 79779L + "'", long25 == 79779L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "94" + "'", str30.equals("94"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 75600L + "'", long32 == 75600L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField17.getAsText((-9L), locale23);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "41" + "'", str24.equals("41"));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        int int22 = remainderDateTimeField20.getMaximumValue((long) 79770);
//        long long25 = remainderDateTimeField20.add(802L, 79779);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(100L, dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.DateTime dateTime31 = dateTime30.withEarlierOffsetAtOverlap();
//        org.joda.time.LocalDate localDate32 = dateTime31.toLocalDate();
//        int[] intArray34 = new int[] {};
//        try {
//            int[] intArray36 = remainderDateTimeField20.set((org.joda.time.ReadablePartial) localDate32, 15, intArray34, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 23 + "'", int22 == 23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 80581L + "'", long25 == 80581L);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 10);
//        int int14 = dateTime11.getSecondOfDay();
//        int int15 = dateTime11.getWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 79833 + "'", int14 == 79833);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        long long23 = remainderDateTimeField21.roundHalfFloor((long) 1970);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1970L + "'", long23 == 1970L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendClockhourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendPattern("1560636565813");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        long long22 = dividedDateTimeField17.getDifferenceAsLong(0L, (-18396L));
        long long24 = dividedDateTimeField17.roundFloor((long) 41);
        long long26 = dividedDateTimeField17.roundHalfEven((-18376L));
        int int28 = dividedDateTimeField17.getLeapAmount((long) (-10));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 766L + "'", long22 == 766L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24L + "'", long24 == 24L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-18376L) + "'", long26 == (-18376L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfMonth();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        boolean boolean10 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime13 = dateTime9.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay16 = dateTime13.toTimeOfDay();
        org.joda.time.DateTime dateTime18 = dateTime13.plusWeeks(2019);
        org.joda.time.DateTime.Property property19 = dateTime13.dayOfMonth();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(timeOfDay16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun", (java.lang.Number) 1560636565813L, (java.lang.Number) (-1.0d), (java.lang.Number) 1);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1560636565813" + "'", str6.equals("1560636565813"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DurationField durationField16 = gregorianChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.yearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime13.withChronology((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(36000000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        boolean boolean22 = unsupportedDateTimeField21.isSupported();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear(9);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime6 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) 79);
        org.joda.time.DateTime.Property property9 = dateTime6.weekyear();
        int int10 = dateTime6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 21 + "'", int10 == 21);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
//        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        int int30 = remainderDateTimeField28.get((long) 4);
//        boolean boolean31 = remainderDateTimeField28.isLenient();
//        try {
//            long long34 = remainderDateTimeField28.set((long) 79819155, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for millisOfSecond must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear(9);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(100);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.util.Locale locale19 = dateTimeFormatter18.getLocale();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.util.Locale locale24 = dateTimeFormatter23.getLocale();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNull(locale19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNull(locale24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        java.lang.String str13 = property12.getAsShortText();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[secondOfDay]", "", 770, (int) (byte) 0);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) 303);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 303L + "'", long8 == 303L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendHourOfHalfday(79819);
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatterBuilder19.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 'a', (int) ' ');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str8 = dateTimeZone7.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property18 = dateTime16.monthOfYear();
        int int19 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.dayOfMonth();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfMonth();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
        boolean boolean28 = dateTime23.isAfter((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime.Property property29 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime31 = dateTime27.withMillis((long) (short) 10);
        int int32 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long35 = cachedDateTimeZone33.previousTransition(10L);
        org.joda.time.DateTimeZone dateTimeZone36 = cachedDateTimeZone33.getUncachedZone();
        java.util.TimeZone timeZone37 = dateTimeZone36.toTimeZone();
        try {
            org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((int) (byte) 0, 1969, (int) (short) 0, 0, (-79760), 79802, dateTimeZone36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -79760 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+10:00" + "'", str8.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 36000000 + "'", int19 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 36000000 + "'", int32 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(timeZone37);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.hourOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "79773");
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 100.0d, (java.lang.Number) 1560636587000L, (java.lang.Number) 1560636565000L);
        java.lang.String str18 = illegalFieldValueException17.getFieldName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "millisOfSecond" + "'", str18.equals("millisOfSecond"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear(44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfDay(248);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendHourOfDay(1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun", (java.lang.Number) 1560636565813L, (java.lang.Number) (-1.0d), (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.toString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1560636565813 for Jun must be in the range [-1.0,1]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 1560636565813 for Jun must be in the range [-1.0,1]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1560636565813" + "'", str6.equals("1560636565813"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1560636565813" + "'", str7.equals("1560636565813"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long25 = offsetDateTimeField22.add((long) 13, (-771));
//        long long27 = offsetDateTimeField22.remainder((long) (-10));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-18491L) + "'", long25 == (-18491L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-994L) + "'", long27 == (-994L));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendClockhourOfDay((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendLiteral("79");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        org.joda.time.DurationField durationField23 = remainderDateTimeField20.getRangeDurationField();
        long long25 = remainderDateTimeField20.roundHalfEven((long) 79779);
        java.util.Locale locale26 = null;
        int int27 = remainderDateTimeField20.getMaximumShortTextLength(locale26);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfMonth();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology28);
        boolean boolean32 = dateTime31.isEqualNow();
        org.joda.time.DateTime.Property property33 = dateTime31.hourOfDay();
        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField20, dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 79779L + "'", long25 == 79779L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusWeeks(600);
        org.joda.time.DateTime.Property property4 = dateTime3.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone1.getName(24L, locale15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+10:00" + "'", str16.equals("+10:00"));
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
//        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
//        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
//        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long29 = cachedDateTimeZone27.previousTransition(10L);
//        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
//        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
//        int int35 = cachedDateTimeZone27.getOffset((-604799900L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.dayOfMonth();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
//        boolean boolean42 = dateTime41.isEqualNow();
//        org.joda.time.DateTime.Property property43 = dateTime41.hourOfDay();
//        org.joda.time.DateTime.Property property44 = dateTime41.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType45, 24);
//        java.lang.String str55 = dividedDateTimeField53.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField53, 4);
//        long long60 = dividedDateTimeField53.roundHalfCeiling((-18491L));
//        int int63 = dividedDateTimeField53.getDifference((long) 13, 0L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        boolean boolean65 = cachedDateTimeZone27.equals((java.lang.Object) dividedDateTimeField53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder66.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder67.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology70.dayOfMonth();
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology70);
//        boolean boolean74 = dateTime73.isEqualNow();
//        org.joda.time.DateTime.Property property75 = dateTime73.hourOfDay();
//        org.joda.time.DateTime.Property property76 = dateTime73.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = property76.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder67.appendSignedDecimal(dateTimeFieldType77, (int) (short) 0, 79);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, "79769");
//        java.lang.String str87 = illegalFieldValueException86.getFieldName();
//        java.lang.String str88 = illegalFieldValueException86.getIllegalValueAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType89 = illegalFieldValueException86.getDateTimeFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField90 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53, dateTimeFieldType89);
//        org.joda.time.DurationField durationField91 = dividedDateTimeField53.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1" + "'", str55.equals("1"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-18496L) + "'", long60 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "millisOfSecond" + "'", str87.equals("millisOfSecond"));
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "79769" + "'", str88.equals("79769"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType89);
//        org.junit.Assert.assertNotNull(durationField91);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfYear(770);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMinuteOfDay((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(10, '4', (-79760), 3, 1, false, (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("hi!", (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 1560636565813 for Jun must be in the range [-1.0,1]", 79802);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        java.util.Locale locale20 = null;
//        int int21 = dividedDateTimeField17.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.dayOfMonth();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
//        boolean boolean26 = dateTime25.isEqualNow();
//        org.joda.time.DateTime.Property property27 = dateTime25.hourOfDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, dateTimeFieldType29, 21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DurationField durationField40 = gregorianChronology38.hours();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.dayOfMonth();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology45);
//        boolean boolean49 = dateTime48.isEqualNow();
//        org.joda.time.DateTime.Property property50 = dateTime48.hourOfDay();
//        org.joda.time.DateTime.Property property51 = dateTime48.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder42.appendSignedDecimal(dateTimeFieldType52, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField61 = gregorianChronology60.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField61);
//        boolean boolean63 = unsupportedDateTimeField62.isLenient();
//        org.joda.time.DurationField durationField64 = unsupportedDateTimeField62.getDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField65 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType29, durationField40, durationField64);
//        int int66 = preciseDateTimeField65.getMaximumValue();
//        int int67 = preciseDateTimeField65.getMaximumValue();
//        long long69 = preciseDateTimeField65.roundCeiling((long) 996);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 23 + "'", int66 == 23);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 23 + "'", int67 == 23);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 3600000L + "'", long69 == 3600000L);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(1);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.DateTime dateTime15 = dateTime13.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime11.toDateTimeISO();
        boolean boolean15 = dateTime14.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
//        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime6.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate14 = dateTime6.toLocalDate();
//        java.lang.Class<?> wildcardClass15 = localDate14.getClass();
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate14);
//        java.io.Writer writer17 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.dayOfMonth();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
//        boolean boolean26 = dateTime21.isAfter((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime.Property property27 = dateTime25.monthOfYear();
//        org.joda.time.DateTime dateTime29 = dateTime25.plusMinutes((int) '4');
//        org.joda.time.DateTime dateTime31 = dateTime29.plusMonths((int) (byte) 0);
//        int int32 = dateTime31.getYearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.dayOfMonth();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
//        boolean boolean37 = dateTime36.isEqualNow();
//        org.joda.time.DateTime dateTime39 = dateTime36.minus((long) (byte) 0);
//        org.joda.time.DateTime dateTime41 = dateTime36.withWeekyear(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.dayOfMonth();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology42);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.dayOfMonth();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology46);
//        boolean boolean50 = dateTime45.isAfter((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTime dateTime52 = dateTime45.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate53 = dateTime45.toLocalDate();
//        java.lang.Class<?> wildcardClass54 = localDate53.getClass();
//        org.joda.time.DateTime dateTime55 = dateTime36.withFields((org.joda.time.ReadablePartial) localDate53);
//        org.joda.time.DateTime dateTime56 = dateTime31.withFields((org.joda.time.ReadablePartial) localDate53);
//        try {
//            dateTimeFormatter0.printTo(writer17, (org.joda.time.ReadableInstant) dateTime56);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNull(chronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019166T������" + "'", str16.equals("2019166T������"));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
        boolean boolean30 = dateTime29.isEqualNow();
        org.joda.time.DateTime.Property property31 = dateTime29.hourOfDay();
        org.joda.time.DateTime.Property property32 = dateTime29.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType33, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField42 = gregorianChronology41.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField42);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField21, dateTimeFieldType33, 79779, (-1), 2019);
        long long49 = offsetDateTimeField47.roundHalfEven(770L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 770L + "'", long49 == 770L);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long25 = offsetDateTimeField22.add((long) 13, (-771));
//        long long27 = offsetDateTimeField22.roundCeiling((-18396L));
//        long long29 = offsetDateTimeField22.roundHalfFloor((long) 79819);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-18491L) + "'", long25 == (-18491L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-18376L) + "'", long27 == (-18376L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 79816L + "'", long29 == 79816L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("6");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"6/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(79810, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79810 + "'", int2 == 79810);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(0);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy(75600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75600 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 0L, 100);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear(9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitYear(2552640);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfYear(770);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("PST");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfHour(79819, 248);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfMonth();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.hourOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime11.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType15, (int) (short) 0, 79);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendSecondOfDay(79770);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendSecondOfDay((int) (short) 1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter29 = dateTimeFormatterBuilder26.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendClockhourOfHalfday(100);
//        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatterBuilder32.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter33, dateTimeParser35);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        java.util.Locale locale38 = dateTimeFormatter37.getLocale();
//        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter37.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter33, dateTimeParser39);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder3.append(dateTimePrinter29, dateTimeParser39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimePrinter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimePrinter33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeParser35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNull(locale38);
//        org.junit.Assert.assertNotNull(dateTimeParser39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale5 = dateTimeFormatter4.getLocale();
        boolean boolean6 = dateTimeFormatter4.isParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTimeISO();
        int int16 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "79770", 770);
        int int19 = dateTimeFormatter3.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "79", (int) (short) 0);
        int int22 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "", (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(locale5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-771) + "'", int16 == (-771));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-98) + "'", int22 == (-98));
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
//        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
//        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
//        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long29 = cachedDateTimeZone27.previousTransition(10L);
//        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
//        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
//        int int35 = cachedDateTimeZone27.getOffset((-604799900L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.dayOfMonth();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
//        boolean boolean42 = dateTime41.isEqualNow();
//        org.joda.time.DateTime.Property property43 = dateTime41.hourOfDay();
//        org.joda.time.DateTime.Property property44 = dateTime41.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType45, 24);
//        java.lang.String str55 = dividedDateTimeField53.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField53, 4);
//        long long60 = dividedDateTimeField53.roundHalfCeiling((-18491L));
//        int int63 = dividedDateTimeField53.getDifference((long) 13, 0L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        boolean boolean65 = cachedDateTimeZone27.equals((java.lang.Object) dividedDateTimeField53);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder66.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder67.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology70.dayOfMonth();
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology70);
//        boolean boolean74 = dateTime73.isEqualNow();
//        org.joda.time.DateTime.Property property75 = dateTime73.hourOfDay();
//        org.joda.time.DateTime.Property property76 = dateTime73.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = property76.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder67.appendSignedDecimal(dateTimeFieldType77, (int) (short) 0, 79);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, "79769");
//        java.lang.String str87 = illegalFieldValueException86.getFieldName();
//        java.lang.String str88 = illegalFieldValueException86.getIllegalValueAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType89 = illegalFieldValueException86.getDateTimeFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField90 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53, dateTimeFieldType89);
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = dividedDateTimeField53.getAsText((long) 10, locale92);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1" + "'", str55.equals("1"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-18496L) + "'", long60 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "millisOfSecond" + "'", str87.equals("millisOfSecond"));
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "79769" + "'", str88.equals("79769"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType89);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "0" + "'", str93.equals("0"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.dayOfMonth();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
        boolean boolean21 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime16.minusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime25 = dateTime23.plusMillis((int) (byte) 100);
        org.joda.time.DateTime.Property property26 = dateTime23.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfMonth();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.dayOfMonth();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology31);
        boolean boolean35 = dateTime30.isAfter((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime37 = dateTime30.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate38 = dateTime30.toLocalDate();
        java.lang.Class<?> wildcardClass39 = localDate38.getClass();
        int int40 = property26.compareTo((org.joda.time.ReadablePartial) localDate38);
        org.joda.time.DateTime dateTime41 = dateTime10.withFields((org.joda.time.ReadablePartial) localDate38);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        java.util.Locale locale20 = null;
//        int int21 = dividedDateTimeField17.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.dayOfMonth();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
//        boolean boolean26 = dateTime25.isEqualNow();
//        org.joda.time.DateTime.Property property27 = dateTime25.hourOfDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, dateTimeFieldType29, 21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DurationField durationField40 = gregorianChronology38.hours();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.dayOfMonth();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology45);
//        boolean boolean49 = dateTime48.isEqualNow();
//        org.joda.time.DateTime.Property property50 = dateTime48.hourOfDay();
//        org.joda.time.DateTime.Property property51 = dateTime48.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder42.appendSignedDecimal(dateTimeFieldType52, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField61 = gregorianChronology60.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField61);
//        boolean boolean63 = unsupportedDateTimeField62.isLenient();
//        org.joda.time.DurationField durationField64 = unsupportedDateTimeField62.getDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField65 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType29, durationField40, durationField64);
//        long long66 = preciseDateTimeField65.getUnitMillis();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 3600000L + "'", long66 == 3600000L);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
//        org.joda.time.DateTime dateTime6 = dateTime3.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        long long11 = gregorianChronology7.add(readablePeriod8, 0L, 100);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.dayOfMonth();
//        org.joda.time.Chronology chronology13 = gregorianChronology7.withUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime6, (java.lang.Object) chronology13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.millisOfSecond();
//        org.joda.time.DurationField durationField17 = gregorianChronology15.hours();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology15.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.dayOfMonth();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
//        boolean boolean26 = dateTime25.isEqualNow();
//        org.joda.time.DateTime.Property property27 = dateTime25.hourOfDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, dateTimeFieldType29, 24);
//        java.lang.String str39 = dividedDateTimeField37.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField40 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder42.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.dayOfMonth();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology46);
//        boolean boolean50 = dateTime49.isEqualNow();
//        org.joda.time.DateTime.Property property51 = dateTime49.hourOfDay();
//        org.joda.time.DateTime.Property property52 = dateTime49.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property52.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder43.appendSignedDecimal(dateTimeFieldType53, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField62 = gregorianChronology61.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField62);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField41, dateTimeFieldType53, 79779, (-1), 2019);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType53, 79807);
//        try {
//            org.joda.time.DateTime dateTime71 = dateTime6.withField(dateTimeFieldType53, 79802);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79802 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        boolean boolean3 = dateTimeZone1.isStandardOffset(1560636591000L);
        long long5 = dateTimeZone1.convertUTCToLocal((long) 980);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-35999020L) + "'", long5 == (-35999020L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-01T00:00:00.000Z", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-01T00:00:00.000Z/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 79810);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun", (java.lang.Number) 1560636565813L, (java.lang.Number) (-1.0d), (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.toString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1560636565813 for Jun must be in the range [-1.0,1]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 1560636565813 for Jun must be in the range [-1.0,1]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1560636565813" + "'", str6.equals("1560636565813"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1560636565813" + "'", str7.equals("1560636565813"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1560636565813" + "'", str8.equals("1560636565813"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1 + "'", number9.equals(1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        int int17 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        java.lang.String str19 = zonedChronology18.toString();
        org.joda.time.Chronology chronology20 = zonedChronology18.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36000000 + "'", int17 == 36000000);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +10:00]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], +10:00]"));
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Jun", (java.lang.Number) 1560636565813L, (java.lang.Number) (-1.0d), (java.lang.Number) 1);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1560636565813" + "'", str5.equals("1560636565813"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1560636565813L + "'", number6.equals(1560636565813L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1560636565813" + "'", str7.equals("1560636565813"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        long long5 = dateTimeZone1.convertLocalToUTC(48L, true);
        boolean boolean7 = dateTimeZone1.isStandardOffset((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-35999952L) + "'", long5 == (-35999952L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 9L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) 2019, 79760);
        org.joda.time.DateTime dateTime18 = dateTime16.minusYears(1);
        org.joda.time.DateTime.Property property19 = dateTime16.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
//        long long25 = offsetDateTimeField22.add((long) 13, (-771));
//        long long27 = offsetDateTimeField22.roundHalfFloor((long) 44);
//        int int28 = offsetDateTimeField22.getOffset();
//        long long30 = offsetDateTimeField22.roundHalfFloor(1560556799999L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-18491L) + "'", long25 == (-18491L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 48L + "'", long27 == 48L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560556800008L + "'", long30 == 1560556800008L);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekyear(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime12.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate20 = dateTime12.toLocalDate();
        java.lang.Class<?> wildcardClass21 = localDate20.getClass();
        org.joda.time.DateTime dateTime22 = dateTime3.withFields((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.DateTime.Property property23 = dateTime22.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, 1560636572000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime7.isEqualNow();
//        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
//        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
//        java.lang.String str23 = unsupportedDateTimeField21.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.dayOfMonth();
//        org.joda.time.DurationField durationField28 = gregorianChronology25.hours();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 'a', (org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime dateTime31 = dateTime29.plusMillis(79760);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime29.toLocalDateTime();
//        int[] intArray38 = new int[] { 79807, (short) 0, 79819155, 22 };
//        try {
//            int[] intArray40 = unsupportedDateTimeField21.set((org.joda.time.ReadablePartial) localDateTime32, 2552640, intArray38, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertNull(durationField22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 13, 24, 79802);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
        boolean boolean30 = dateTime29.isEqualNow();
        org.joda.time.DateTime.Property property31 = dateTime29.hourOfDay();
        org.joda.time.DateTime.Property property32 = dateTime29.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType33, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField42 = gregorianChronology41.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField42);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField21, dateTimeFieldType33, 79779, (-1), 2019);
        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField47.getWrappedField();
        long long50 = offsetDateTimeField47.roundHalfFloor(44L);
        long long52 = offsetDateTimeField47.roundHalfCeiling((long) (-10));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 44L + "'", long50 == 44L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-10L) + "'", long52 == (-10L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        boolean boolean22 = unsupportedDateTimeField21.isLenient();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField21.getDurationField();
        try {
            boolean boolean25 = unsupportedDateTimeField21.isLeap((long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str9 = dateTimeZone8.toString();
        org.joda.time.DateTime dateTime10 = dateTime3.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((-1));
        org.joda.time.Chronology chronology13 = dateTime10.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+10:00" + "'", str9.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(36000000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime7.isEqualNow();
//        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
//        boolean boolean22 = unsupportedDateTimeField21.isLenient();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
//        boolean boolean30 = dateTime29.isEqualNow();
//        org.joda.time.DateTime.Property property31 = dateTime29.hourOfDay();
//        org.joda.time.DateTime.Property property32 = dateTime29.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 24);
//        java.lang.String str43 = dividedDateTimeField41.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField44, 770);
//        org.joda.time.DurationField durationField47 = remainderDateTimeField44.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.dayOfMonth();
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology48);
//        boolean boolean52 = dateTime51.isEqualNow();
//        org.joda.time.DateTime.Property property53 = dateTime51.secondOfDay();
//        java.lang.String str54 = property53.getAsText();
//        java.lang.String str55 = property53.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.millisOfSecond();
//        org.joda.time.DurationField durationField58 = gregorianChronology56.hours();
//        boolean boolean59 = property53.equals((java.lang.Object) durationField58);
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField60 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType23, durationField47, durationField58);
//        long long62 = preciseDateTimeField60.roundFloor((-1L));
//        long long64 = preciseDateTimeField60.roundHalfCeiling((-18491L));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1" + "'", str43.equals("1"));
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "79841" + "'", str54.equals("79841"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Property[secondOfDay]" + "'", str55.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-24L) + "'", long62 == (-24L));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-18480L) + "'", long64 == (-18480L));
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime dateTime17 = dateTime11.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime19 = dateTime11.withEra(7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "79769", 0, 41);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.previousTransition(0L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = dateTime3.isEqualNow();
//        int int5 = dateTime3.getSecondOfDay();
//        int int6 = dateTime3.getMillisOfSecond();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime3.withCenturyOfEra((int) 'a');
//        org.joda.time.DateTime.Property property11 = dateTime3.year();
//        java.lang.String str12 = property11.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 79842 + "'", int5 == 79842);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 232 + "'", int6 == 232);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "year" + "'", str12.equals("year"));
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
//        int int12 = dateTime7.getMinuteOfHour();
//        org.joda.time.DateTime dateTime14 = dateTime7.minusHours(79760);
//        org.joda.time.DateTime.Property property15 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime17 = dateTime7.plusSeconds(9);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(36000000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral("1560636565813");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        long long24 = offsetDateTimeField22.roundHalfCeiling(768L);
        long long27 = offsetDateTimeField22.add(79810L, 600L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 768L + "'", long24 == 768L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 80410L + "'", long27 == 80410L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DurationField durationField13 = gregorianChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime10.withChronology((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        int int17 = dateTime15.getYear();
        org.joda.time.DateTime dateTime18 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime20 = dateTime18.minusYears(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readableDuration18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType14, 0, 4);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.appendYearOfCentury((int) (short) -1, 79807);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.hourOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "79773");
//        illegalFieldValueException13.prependMessage("T22:10:17.965Z");
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        java.lang.String str29 = dividedDateTimeField17.getName();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        long long32 = remainderDateTimeField30.roundHalfFloor((long) 79810);
        long long35 = remainderDateTimeField30.addWrapField((long) 41, (int) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "millisOfSecond" + "'", str29.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 79810L + "'", long32 == 79810L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 42L + "'", long35 == 42L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime7.isEqualNow();
//        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
//        boolean boolean22 = unsupportedDateTimeField21.isLenient();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
//        boolean boolean30 = dateTime29.isEqualNow();
//        org.joda.time.DateTime.Property property31 = dateTime29.hourOfDay();
//        org.joda.time.DateTime.Property property32 = dateTime29.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 24);
//        java.lang.String str43 = dividedDateTimeField41.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField44, 770);
//        org.joda.time.DurationField durationField47 = remainderDateTimeField44.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.dayOfMonth();
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology48);
//        boolean boolean52 = dateTime51.isEqualNow();
//        org.joda.time.DateTime.Property property53 = dateTime51.secondOfDay();
//        java.lang.String str54 = property53.getAsText();
//        java.lang.String str55 = property53.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.millisOfSecond();
//        org.joda.time.DurationField durationField58 = gregorianChronology56.hours();
//        boolean boolean59 = property53.equals((java.lang.Object) durationField58);
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField60 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType23, durationField47, durationField58);
//        long long62 = preciseDateTimeField60.roundFloor(0L);
//        org.joda.time.DurationField durationField63 = preciseDateTimeField60.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1" + "'", str43.equals("1"));
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "79843" + "'", str54.equals("79843"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Property[secondOfDay]" + "'", str55.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertNotNull(durationField63);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendClockhourOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        java.util.Locale locale20 = null;
//        int int21 = dividedDateTimeField17.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.dayOfMonth();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
//        boolean boolean26 = dateTime25.isEqualNow();
//        org.joda.time.DateTime.Property property27 = dateTime25.hourOfDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, dateTimeFieldType29, 21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DurationField durationField40 = gregorianChronology38.hours();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.dayOfMonth();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology45);
//        boolean boolean49 = dateTime48.isEqualNow();
//        org.joda.time.DateTime.Property property50 = dateTime48.hourOfDay();
//        org.joda.time.DateTime.Property property51 = dateTime48.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder42.appendSignedDecimal(dateTimeFieldType52, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField61 = gregorianChronology60.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField61);
//        boolean boolean63 = unsupportedDateTimeField62.isLenient();
//        org.joda.time.DurationField durationField64 = unsupportedDateTimeField62.getDurationField();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField65 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType29, durationField40, durationField64);
//        int int66 = preciseDateTimeField65.getMaximumValue();
//        long long68 = preciseDateTimeField65.roundCeiling((-35999020L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 23 + "'", int66 == 23);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-32400000L) + "'", long68 == (-32400000L));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
        org.joda.time.DateTime dateTime19 = dateTime15.plusWeeks(770);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        java.lang.String str22 = unsupportedDateTimeField21.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDateTimeField" + "'", str22.equals("UnsupportedDateTimeField"));
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
//        long long24 = offsetDateTimeField22.roundHalfFloor((long) (-771));
//        int int27 = offsetDateTimeField22.getDifference((long) '4', (long) 79779);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.util.Locale locale29 = dateTimeFormatter28.getLocale();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.dayOfMonth();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.dayOfMonth();
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology34);
//        boolean boolean38 = dateTime33.isAfter((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime40 = dateTime33.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate41 = dateTime33.toLocalDate();
//        java.lang.String str42 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate41);
//        int[] intArray45 = new int[] { 53 };
//        try {
//            int[] intArray47 = offsetDateTimeField22.set((org.joda.time.ReadablePartial) localDate41, 3, intArray45, 79802);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79802 for millisOfSecond must be in the range [770,793]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-771L) + "'", long24 == (-771L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-79727) + "'", int27 == (-79727));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNull(locale29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019166T������" + "'", str42.equals("2019166T������"));
//        org.junit.Assert.assertNotNull(intArray45);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long29 = cachedDateTimeZone27.previousTransition(10L);
        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
        java.lang.String str35 = cachedDateTimeZone27.getShortName((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+10:00" + "'", str35.equals("+10:00"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        java.util.Date date9 = dateTime7.toDate();
        boolean boolean11 = dateTime7.isBefore((long) 24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "79784", 19, 44);
        long long18 = fixedDateTimeZone16.nextTransition(0L);
        long long20 = fixedDateTimeZone16.previousTransition(0L);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) boolean11, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long29 = cachedDateTimeZone27.previousTransition(10L);
        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
        int int35 = cachedDateTimeZone27.getOffset((-604799900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.dayOfMonth();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
        boolean boolean42 = dateTime41.isEqualNow();
        org.joda.time.DateTime.Property property43 = dateTime41.hourOfDay();
        org.joda.time.DateTime.Property property44 = dateTime41.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType45, 24);
        java.lang.String str55 = dividedDateTimeField53.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField53, 4);
        long long60 = dividedDateTimeField53.roundHalfCeiling((-18491L));
        int int63 = dividedDateTimeField53.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
        boolean boolean65 = cachedDateTimeZone27.equals((java.lang.Object) dividedDateTimeField53);
        long long68 = dividedDateTimeField53.add((long) (-79727), 23);
        long long71 = dividedDateTimeField53.getDifferenceAsLong((long) (short) 100, 316L);
        int int72 = dividedDateTimeField53.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1" + "'", str55.equals("1"));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-18496L) + "'", long60 == (-18496L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-79175L) + "'", long68 == (-79175L));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-9L) + "'", long71 == (-9L));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 41 + "'", int72 == 41);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        int int24 = remainderDateTimeField20.get((-18376L));
        int int25 = remainderDateTimeField20.getDivisor();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime7.isEqualNow();
//        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
//        boolean boolean22 = unsupportedDateTimeField21.isLenient();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
//        long long26 = unsupportedDateTimeField21.add(0L, (-125999999L));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-10886399913600000L) + "'", long26 == (-10886399913600000L));
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime dateTime17 = dateTime11.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime18 = dateTime11.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property19 = dateTime11.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.hourOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        int int7 = property6.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        long long19 = dividedDateTimeField17.remainder((long) 79807);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 79015L + "'", long19 == 79015L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str3 = dateTimeZone2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean7 = dateTime5.isAfter((long) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        java.util.TimeZone timeZone10 = dateTimeZone9.toTimeZone();
        org.joda.time.DateTime dateTime11 = dateTime5.withZoneRetainFields(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int30 = remainderDateTimeField28.get((long) 4);
        java.util.Locale locale32 = null;
        java.lang.String str33 = remainderDateTimeField28.getAsShortText((-771L), locale32);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13" + "'", str33.equals("13"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long29 = cachedDateTimeZone27.previousTransition(10L);
        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone32 = cachedDateTimeZone27.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
        org.junit.Assert.assertNotNull(dateTimeZone32);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusDays((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(10);
        org.joda.time.DateTime dateTime15 = dateTime13.withYear(79802);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
//        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
//        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
//        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long29 = cachedDateTimeZone27.previousTransition(10L);
//        int int31 = cachedDateTimeZone27.getOffset((long) (short) 10);
//        long long33 = cachedDateTimeZone27.previousTransition((long) 'a');
//        int int35 = cachedDateTimeZone27.getOffset((-604799900L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.dayOfMonth();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
//        boolean boolean42 = dateTime41.isEqualNow();
//        org.joda.time.DateTime.Property property43 = dateTime41.hourOfDay();
//        org.joda.time.DateTime.Property property44 = dateTime41.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType45, 24);
//        java.lang.String str55 = dividedDateTimeField53.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField53, 4);
//        long long60 = dividedDateTimeField53.roundHalfCeiling((-18491L));
//        int int63 = dividedDateTimeField53.getDifference((long) 13, 0L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField53);
//        boolean boolean65 = cachedDateTimeZone27.equals((java.lang.Object) dividedDateTimeField53);
//        boolean boolean67 = dividedDateTimeField53.isLeap(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36000000 + "'", int35 == 36000000);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1" + "'", str55.equals("1"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-18496L) + "'", long60 == (-18496L));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (byte) 0);
        org.joda.time.DateTime.Property property14 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime11.plusYears(36000000);
        org.joda.time.DateTime dateTime18 = dateTime11.withWeekyear(28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.dayOfMonth();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
        boolean boolean30 = dateTime25.isAfter((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime32 = dateTime25.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate33 = dateTime25.toLocalDate();
        int[] intArray39 = new int[] { 7, (byte) 1, 79842, 79802 };
        try {
            int[] intArray41 = unsupportedDateTimeField21.addWrapField((org.joda.time.ReadablePartial) localDate33, 0, intArray39, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        long long4 = dateTimeZone1.adjustOffset(1969L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
//        java.lang.String str6 = property5.getAsText();
//        java.lang.String str7 = property5.toString();
//        org.joda.time.DateTime dateTime9 = property5.addToCopy((long) 44);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay(79795);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79795 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "79847" + "'", str6.equals("79847"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[secondOfDay]" + "'", str7.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
//        java.lang.String str6 = property5.getAsText();
//        java.lang.String str7 = property5.getName();
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (short) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "79847" + "'", str6.equals("79847"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "secondOfDay" + "'", str7.equals("secondOfDay"));
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        int int22 = dividedDateTimeField17.getLeapAmount(36000052L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfMonth();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology27);
//        boolean boolean31 = dateTime26.isAfter((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime26.minusMillis((int) (short) -1);
//        org.joda.time.DateTime dateTime35 = dateTime33.plusMillis((int) (byte) 100);
//        org.joda.time.DateTime.Property property36 = dateTime33.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.dayOfMonth();
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.dayOfMonth();
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology41);
//        boolean boolean45 = dateTime40.isAfter((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime47 = dateTime40.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate48 = dateTime40.toLocalDate();
//        java.lang.Class<?> wildcardClass49 = localDate48.getClass();
//        int int50 = property36.compareTo((org.joda.time.ReadablePartial) localDate48);
//        int int51 = dividedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate48);
//        java.lang.String str52 = dividedDateTimeField17.toString();
//        int int54 = dividedDateTimeField17.getLeapAmount((long) 23);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 41 + "'", int51 == 41);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str52.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear(980);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(232);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1970L, (-604799900L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 604801870L + "'", long2 == 604801870L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 79770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79780 + "'", int2 == 79780);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean6 = dateTime4.isAfter((long) 0);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
//        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime12.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate20 = dateTime12.toLocalDate();
//        org.joda.time.DateTime dateTime21 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate20);
//        org.joda.time.DateTime.Property property22 = dateTime4.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.dayOfMonth();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology25);
//        boolean boolean29 = dateTime28.isEqualNow();
//        org.joda.time.DateTime.Property property30 = dateTime28.hourOfDay();
//        org.joda.time.DateTime.Property property31 = dateTime28.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType32, 24);
//        java.lang.String str42 = dividedDateTimeField40.getAsText(1560636573041L);
//        java.util.Locale locale43 = null;
//        int int44 = dividedDateTimeField40.getMaximumTextLength(locale43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.dayOfMonth();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology45);
//        boolean boolean49 = dateTime48.isEqualNow();
//        org.joda.time.DateTime.Property property50 = dateTime48.hourOfDay();
//        org.joda.time.DateTime.Property property51 = dateTime48.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField40, dateTimeFieldType52, 21);
//        int int61 = dateTime4.get(dateTimeFieldType52);
//        org.joda.time.DateTime dateTime63 = dateTime4.minusMillis(79780);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 847 + "'", int61 == 847);
//        org.junit.Assert.assertNotNull(dateTime63);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime dateTime18 = dateTime16.withYearOfEra((int) (short) 1);
        org.joda.time.DateTime dateTime20 = dateTime16.plus((long) (-10));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfSecond();
        org.joda.time.DurationField durationField8 = gregorianChronology6.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(847, 2019, 770, 0, 490, 0, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 490 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(847, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 851 + "'", int2 == 851);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType14, 0, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendCenturyOfEra(44, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfDay(79770);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
//        org.joda.time.DurationField durationField13 = gregorianChronology11.weeks();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.yearOfEra();
//        org.joda.time.DateTime dateTime15 = dateTime10.withChronology((org.joda.time.Chronology) gregorianChronology11);
//        java.lang.String str16 = dateTime15.toString();
//        int int17 = dateTime15.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-01T00:00:00.000Z" + "'", str16.equals("2019-06-01T00:00:00.000Z"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 21 + "'", int17 == 21);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
        java.util.Locale locale25 = null;
        try {
            long long26 = unsupportedDateTimeField21.set((long) 13, "79773", locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
//        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime.Property property18 = dateTime16.monthOfYear();
//        org.joda.time.DateTime.Property property19 = dateTime16.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        long long21 = property19.getDifferenceAsLong(readableInstant20);
//        org.joda.time.DateTime dateTime23 = property19.setCopy("1");
//        org.joda.time.DurationField durationField24 = property19.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property19.getFieldType();
//        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType25);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfMonth();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology27);
//        boolean boolean31 = dateTime30.isEqualNow();
//        int int32 = dateTime30.getSecondOfDay();
//        org.joda.time.LocalTime localTime33 = dateTime30.toLocalTime();
//        int int34 = property26.compareTo((org.joda.time.ReadablePartial) localTime33);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 79849 + "'", int32 == 79849);
//        org.junit.Assert.assertNotNull(localTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        try {
            java.lang.String str5 = dateTime3.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 2019, (org.joda.time.Chronology) gregorianChronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(100L, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((-79727));
        boolean boolean6 = dateTime3.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int30 = remainderDateTimeField28.get((long) 4);
        java.lang.String str31 = remainderDateTimeField28.toString();
        boolean boolean32 = remainderDateTimeField28.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str31.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekyear(0);
        int int9 = dateTime3.getCenturyOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        boolean boolean13 = gregorianChronology10.equals((java.lang.Object) 0.0d);
        org.joda.time.DurationField durationField14 = gregorianChronology10.days();
        java.lang.String str15 = gregorianChronology10.toString();
        org.joda.time.DateTime dateTime16 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime18 = dateTime3.plusSeconds(22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21 + "'", int9 == 21);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[UTC]" + "'", str15.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) 0.0d);
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = gregorianChronology0.get(readablePeriod6, 1560636587000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        boolean boolean22 = unsupportedDateTimeField21.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
        try {
            int int24 = unsupportedDateTimeField21.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
        java.util.Locale locale23 = null;
        try {
            int int24 = unsupportedDateTimeField21.getMaximumShortTextLength(locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-06-01T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("32");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"32\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"32\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekyear(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime12.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate20 = dateTime12.toLocalDate();
        java.lang.Class<?> wildcardClass21 = localDate20.getClass();
        org.joda.time.DateTime dateTime22 = dateTime3.withFields((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.DateTime dateTime24 = dateTime3.plus((long) (short) 0);
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime27 = property25.setCopy(79802);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79802 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime7.minusSeconds(2019);
        boolean boolean13 = dateTime7.isAfterNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime6 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "79784", 19, 44);
        long long13 = fixedDateTimeZone11.nextTransition(0L);
        long long15 = fixedDateTimeZone11.previousTransition(0L);
        org.joda.time.DateTime dateTime16 = dateTime3.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 0L, 100);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfMonth();
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray10 = gregorianChronology0.get(readablePeriod7, (long) 6, 915L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime dateTime18 = dateTime11.withYear(980);
        org.joda.time.DateTime.Property property19 = dateTime11.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "79769");
        java.lang.String str21 = illegalFieldValueException20.getFieldName();
        java.lang.String str22 = illegalFieldValueException20.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = illegalFieldValueException20.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 79816L, "2019");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "millisOfSecond" + "'", str21.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "79769" + "'", str22.equals("79769"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean6 = dateTime4.isAfter((long) 0);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
//        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime12.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate20 = dateTime12.toLocalDate();
//        org.joda.time.DateTime dateTime21 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate20);
//        org.joda.time.DateTime.Property property22 = dateTime4.yearOfEra();
//        int int23 = dateTime4.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 50 + "'", int23 == 50);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
        org.joda.time.Interval interval11 = property10.toInterval();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval11);
        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval11);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(readableInterval13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        boolean boolean18 = dateTime16.isBeforeNow();
        org.joda.time.DateMidnight dateMidnight19 = dateTime16.toDateMidnight();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateMidnight19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean6 = dateTime4.isAfter((long) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime4.plusHours((-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(36000000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("1560636565813");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dividedDateTimeField17.getAsShortText(0L, locale22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        int int17 = dateTime15.getYear();
        org.joda.time.DateTime dateTime19 = dateTime15.plusSeconds((-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "dayOfMonth", "79770");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "1969", "");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "", "T22:10:21.670Z");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime11.toMutableDateTime(dateTimeZone18);
        org.joda.time.Chronology chronology20 = mutableDateTime19.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) '4');
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (byte) 0);
//        int int14 = dateTime13.getYearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfMonth();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology15);
//        boolean boolean19 = dateTime18.isEqualNow();
//        org.joda.time.DateTime dateTime21 = dateTime18.minus((long) (byte) 0);
//        org.joda.time.DateTime dateTime23 = dateTime18.withWeekyear(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfMonth();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfMonth();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology28);
//        boolean boolean32 = dateTime27.isAfter((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate35 = dateTime27.toLocalDate();
//        java.lang.Class<?> wildcardClass36 = localDate35.getClass();
//        org.joda.time.DateTime dateTime37 = dateTime18.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTime dateTime38 = dateTime13.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTime dateTime41 = dateTime13.withDurationAdded((long) 79797, 0);
//        org.joda.time.DateTime dateTime43 = dateTime41.plusSeconds(94);
//        boolean boolean45 = dateTime43.isEqual((-24L));
//        int int46 = dateTime43.getYearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        long long5 = durationField2.subtract(1560636587000L, (int) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1529100587000L + "'", long5 == 1529100587000L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1560636565813", "T22:10:17.965Z", 1969, 980);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (-771));
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField22.getAsText((-35999020L), locale26);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-771L) + "'", long24 == (-771L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "790" + "'", str27.equals("790"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime11.toDateTimeISO();
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime11.toYearMonthDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear(44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfDay(248);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        boolean boolean6 = dateTime5.isEqualNow();
//        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
//        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField20, 770);
//        org.joda.time.DurationField durationField23 = remainderDateTimeField20.getRangeDurationField();
//        long long25 = remainderDateTimeField20.roundHalfEven((long) 79779);
//        java.util.Locale locale26 = null;
//        int int27 = remainderDateTimeField20.getMaximumShortTextLength(locale26);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = remainderDateTimeField20.getAsShortText(94, locale29);
//        long long33 = remainderDateTimeField20.set((long) 22, 9);
//        boolean boolean34 = remainderDateTimeField20.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 79779L + "'", long25 == 79779L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "94" + "'", str30.equals("94"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9L + "'", long33 == 9L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekyear(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        boolean boolean17 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime12.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate20 = dateTime12.toLocalDate();
        java.lang.Class<?> wildcardClass21 = localDate20.getClass();
        org.joda.time.DateTime dateTime22 = dateTime3.withFields((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.DateTime dateTime24 = dateTime3.plus((long) (short) 0);
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfHour();
        java.util.Locale locale27 = null;
        try {
            org.joda.time.DateTime dateTime28 = property25.setCopy("", locale27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str3 = dateTimeZone2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0L, dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-36000771L), dateTimeZone1);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfMonth();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        boolean boolean10 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime5.minusMillis((int) (short) -1);
//        org.joda.time.LocalDate localDate13 = dateTime5.toLocalDate();
//        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withZoneUTC();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withLocale(locale16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019166T������" + "'", str14.equals("2019166T������"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 4);
        long long24 = dividedDateTimeField17.roundHalfCeiling((-18491L));
        int int27 = dividedDateTimeField17.getDifference((long) 13, 0L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int30 = remainderDateTimeField28.get((long) 4);
        boolean boolean31 = remainderDateTimeField28.isLenient();
        int int34 = remainderDateTimeField28.getDifference((long) (-771), (long) 2019);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-18496L) + "'", long24 == (-18496L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-2790) + "'", int34 == (-2790));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(100L, dateTimeZone2);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str6 = cachedDateTimeZone4.getNameKey((long) ' ');
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertNull(str6);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        int int11 = dateTime10.getYearOfCentury();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withMonthOfYear(79795);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79795 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        int int14 = dateTime13.getDayOfMonth();
        java.lang.String str16 = dateTime13.toString("1969");
        int int17 = dateTime13.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime10.dayOfYear();
//        int int14 = property13.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        boolean boolean6 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "79773");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType9, 24);
        java.lang.String str19 = dividedDateTimeField17.getAsText(1560636573041L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getLeapAmount(36000052L);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfMonth();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology27);
        boolean boolean31 = dateTime26.isAfter((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime26.minusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime35 = dateTime33.plusMillis((int) (byte) 100);
        org.joda.time.DateTime.Property property36 = dateTime33.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.dayOfMonth();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.dayOfMonth();
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology41);
        boolean boolean45 = dateTime40.isAfter((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime dateTime47 = dateTime40.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate48 = dateTime40.toLocalDate();
        java.lang.Class<?> wildcardClass49 = localDate48.getClass();
        int int50 = property36.compareTo((org.joda.time.ReadablePartial) localDate48);
        int int51 = dividedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate48);
        java.lang.String str52 = dividedDateTimeField17.toString();
        boolean boolean53 = dividedDateTimeField17.isLenient();
        int int54 = dividedDateTimeField17.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 41 + "'", int51 == 41);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str52.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 41 + "'", int54 == 41);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.dayOfMonth();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology5);
        boolean boolean9 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.monthOfYear();
        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.millisOfSecond();
        org.joda.time.DurationField durationField14 = gregorianChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.yearOfEra();
        org.joda.time.DateTime dateTime16 = dateTime11.withChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-771L), (org.joda.time.Chronology) gregorianChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.hourOfHalfday();
        boolean boolean32 = cachedDateTimeZone27.equals((java.lang.Object) dateTimeField31);
        int int34 = cachedDateTimeZone27.getOffset(97L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.dayOfMonth();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.dayOfMonth();
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology39);
        boolean boolean43 = dateTime38.isAfter((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime.Property property44 = dateTime42.monthOfYear();
        org.joda.time.DateTime dateTime46 = dateTime42.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime48 = dateTime46.plusMonths((int) (byte) 0);
        boolean boolean49 = cachedDateTimeZone27.equals((java.lang.Object) dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 36000000 + "'", int34 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(36000000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        int int17 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        java.lang.String str19 = zonedChronology18.toString();
        try {
            long long25 = zonedChronology18.getDateTimeMillis((-10L), (int) (byte) 0, (-2790), 21, 79797);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2790 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36000000 + "'", int17 == 36000000);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +10:00]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], +10:00]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate11 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime14 = dateTime3.withMinuteOfHour((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.Chronology chronology11 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gregorianChronology6);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(3, 94, 0, 490, 36, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 490 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.monthOfYear();
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean22 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.monthOfYear();
        org.joda.time.DateTime dateTime25 = dateTime21.withMillis((long) (short) 10);
        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.hourOfHalfday();
        boolean boolean32 = cachedDateTimeZone27.equals((java.lang.Object) dateTimeField31);
        java.lang.String str34 = cachedDateTimeZone27.getNameKey(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 36000000 + "'", int26 == 36000000);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (short) 0, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType14, 0, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendYearOfCentury((int) (short) 100, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendFractionOfMinute(1969, 303);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfSecond();
        boolean boolean8 = gregorianChronology5.equals((java.lang.Object) 0.0d);
        org.joda.time.Chronology chronology9 = gregorianChronology5.withUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) -1, chronology9);
        org.joda.time.DateTime dateTime11 = dateTime3.withChronology(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekyear(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTime dateTime16 = dateTime14.minusYears((int) (byte) 100);
        boolean boolean17 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime20 = dateTime14.withZone(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfMonth();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        boolean boolean18 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = dateTime13.minusMillis((int) (short) -1);
        org.joda.time.LocalDate localDate21 = dateTime13.toLocalDate();
        int int22 = property9.compareTo((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        boolean boolean27 = dateTime26.isEqualNow();
        org.joda.time.DateTime dateTime29 = dateTime26.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime31 = dateTime26.withWeekyear(0);
        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
        int int33 = property9.compareTo((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime.Property property34 = dateTime31.monthOfYear();
        org.joda.time.DateTime dateTime35 = property34.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (byte) 10);
        org.joda.time.Chronology chronology14 = dateTime11.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField5 = gregorianChronology4.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property9 = dateTime3.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
//        java.lang.String str6 = property5.getAsText();
//        java.lang.String str7 = property5.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfMonth();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
//        boolean boolean16 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property17 = dateTime15.monthOfYear();
//        org.joda.time.DateTime dateTime19 = dateTime15.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime21 = dateTime15.plusYears(79);
//        long long22 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
//        int int23 = dateTime21.getDayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "79854" + "'", str6.equals("79854"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[secondOfDay]" + "'", str7.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2493072000L) + "'", long22 == (-2493072000L));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendDayOfMonth(23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(100);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear(770);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.dayOfMonth();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
//        boolean boolean23 = dateTime22.isEqualNow();
//        org.joda.time.DateTime.Property property24 = dateTime22.hourOfDay();
//        org.joda.time.DateTime.Property property25 = dateTime22.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder16.appendSignedDecimal(dateTimeFieldType26, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField35 = gregorianChronology34.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField35);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType26, 2019, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType26, 79770, 13);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType26);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType26, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimePrinter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "79773");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType11, 490);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfMonth();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.hourOfDay();
        org.joda.time.DateTime.Property property14 = dateTime11.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType15, (int) (short) 0, 79);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType15, 23);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
        boolean boolean22 = unsupportedDateTimeField21.isLenient();
        boolean boolean23 = unsupportedDateTimeField21.isSupported();
        java.util.Locale locale26 = null;
        try {
            long long27 = unsupportedDateTimeField21.set((long) 847, "79849", locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime7.isEqualNow();
//        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType11, (int) (short) 0, 79);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField20);
//        boolean boolean22 = unsupportedDateTimeField21.isLenient();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField21.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.millisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.dayOfMonth();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
//        boolean boolean30 = dateTime29.isEqualNow();
//        org.joda.time.DateTime.Property property31 = dateTime29.hourOfDay();
//        org.joda.time.DateTime.Property property32 = dateTime29.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1970, (java.lang.Number) (byte) 10, (java.lang.Number) 1560636570831L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "79773");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 24);
//        java.lang.String str43 = dividedDateTimeField41.getAsText(1560636573041L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField44, 770);
//        org.joda.time.DurationField durationField47 = remainderDateTimeField44.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.dayOfMonth();
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology48);
//        boolean boolean52 = dateTime51.isEqualNow();
//        org.joda.time.DateTime.Property property53 = dateTime51.secondOfDay();
//        java.lang.String str54 = property53.getAsText();
//        java.lang.String str55 = property53.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.millisOfSecond();
//        org.joda.time.DurationField durationField58 = gregorianChronology56.hours();
//        boolean boolean59 = property53.equals((java.lang.Object) durationField58);
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField60 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType23, durationField47, durationField58);
//        long long62 = preciseDateTimeField60.roundFloor((-1L));
//        long long63 = preciseDateTimeField60.getUnitMillis();
//        int int65 = preciseDateTimeField60.get((long) 28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1" + "'", str43.equals("1"));
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "79854" + "'", str54.equals("79854"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Property[secondOfDay]" + "'", str55.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-24L) + "'", long62 == (-24L));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 24L + "'", long63 == 24L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePeriod4, (-18491L), (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
        org.joda.time.Interval interval11 = property10.toInterval();
        org.joda.time.DurationField durationField12 = property10.getRangeDurationField();
        java.lang.String str13 = property10.getName();
        java.lang.String str14 = property10.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "secondOfDay" + "'", str13.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[secondOfDay]" + "'", str14.equals("Property[secondOfDay]"));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        org.joda.time.DateTime dateTime15 = dateTime11.minusSeconds(6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str17 = dateTime11.toString(dateTimeFormatter16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.weekOfWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime11.toMutableDateTime((org.joda.time.Chronology) gregorianChronology18);
//        long long27 = gregorianChronology18.add((long) ' ', 1560636573048L, 28);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T22:10:54.826Z" + "'", str17.equals("T22:10:54.826Z"));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43697824045376L + "'", long27 == 43697824045376L);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
//        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
//        org.joda.time.Interval interval11 = property10.toInterval();
//        int int12 = property10.getMinimumValue();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfMonth();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.dayOfMonth();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
//        boolean boolean21 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime26 = dateTime24.withHourOfDay(0);
//        org.joda.time.DateTime dateTime28 = dateTime24.minusSeconds(6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.tTime();
//        java.lang.String str30 = dateTime24.toString(dateTimeFormatter29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.dayOfMonth();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology31.weekOfWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime36 = dateTime24.toMutableDateTime((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime39 = dateTime24.withDurationAdded(readableDuration37, 9);
//        long long40 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T22:10:54.941Z" + "'", str30.equals("T22:10:54.941Z"));
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(property41);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        int int17 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendTwoDigitYear(13);
        boolean boolean25 = zonedChronology18.equals((java.lang.Object) dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36000000 + "'", int17 == 36000000);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTime dateTime18 = property17.withMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        boolean boolean23 = dateTime22.isEqualNow();
        org.joda.time.DateTime dateTime25 = dateTime22.minus((long) (byte) 0);
        org.joda.time.DateTime dateTime27 = dateTime22.withWeekyear(0);
        long long28 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str7 = dateTimeZone6.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfMonth();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        boolean boolean16 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.monthOfYear();
        int int18 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.dayOfMonth();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
        boolean boolean27 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime.Property property28 = dateTime26.monthOfYear();
        org.joda.time.DateTime dateTime30 = dateTime26.withMillis((long) (short) 10);
        int int31 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime30);
        long long34 = dateTimeZone6.convertLocalToUTC(1560636573041L, false);
        try {
            org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(0, 36000000, 79813, 79842, 22, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79842 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+10:00" + "'", str7.equals("+10:00"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 36000000 + "'", int18 == 36000000);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36000000 + "'", int31 == 36000000);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560600573041L + "'", long34 == 1560600573041L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str3 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(3);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        java.lang.String str18 = property17.getAsShortText();
        org.joda.time.DurationField durationField19 = property17.getLeapDurationField();
        org.joda.time.DateTime dateTime20 = property17.roundHalfEvenCopy();
        org.joda.time.Interval interval21 = property17.toInterval();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(interval21);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
        int int13 = property12.getLeapAmount();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean8 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) (short) 1, (int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay(0);
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime11.toTimeOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime11.plusWeeks(2019);
//        org.joda.time.DateTime dateTime17 = dateTime11.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime11.withTimeAtStartOfDay();
//        int int19 = dateTime11.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//    }
//}

