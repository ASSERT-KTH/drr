import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int14 = fixedDateTimeZone6.getOffsetFromLocal((-3144960000000L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone8 = fixedDateTimeZone7.toTimeZone();
        java.util.TimeZone timeZone9 = fixedDateTimeZone7.toTimeZone();
        long long12 = fixedDateTimeZone7.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology13.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology13.getZone();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 10, (org.joda.time.Chronology) zonedChronology13);
        org.joda.time.Weeks weeks17 = period16.toStandardWeeks();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-90L) + "'", long12 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(weeks17);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.Period period14 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period16 = period14.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = period14.get(durationFieldType17);
        org.joda.time.Period period20 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes21 = period20.toStandardMinutes();
        org.joda.time.Period period23 = period20.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray24 = period20.getFieldTypes();
        org.joda.time.Period period25 = period14.withFields((org.joda.time.ReadablePeriod) period20);
        int[] intArray26 = period20.getValues();
        try {
            int[] intArray28 = offsetDateTimeField5.addWrapPartial(readablePartial11, (int) '#', intArray26, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(minutes21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldTypeArray24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        boolean boolean28 = unsupportedDurationField11.isSupported();
        try {
            long long31 = unsupportedDurationField11.add((-31449600100L), 189000000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        boolean boolean26 = unsupportedDateTimeField24.isLenient();
        boolean boolean27 = unsupportedDateTimeField24.isLenient();
        java.util.Locale locale30 = null;
        try {
            long long31 = unsupportedDateTimeField24.set(97619558403104L, "", locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.subtract(0L, (int) (byte) 100);
        int int35 = scaledDurationField24.getValue(2L, (long) (short) 1);
        long long38 = scaledDurationField24.getMillis(0L, (-259200000L));
        long long40 = scaledDurationField24.getMillis(97);
        long long43 = scaledDurationField24.getValueAsLong((-10L), (-10L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3144960000000L) + "'", long32 == (-3144960000000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 3050611200000L + "'", long40 == 3050611200000L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        long long9 = gregorianChronology0.getDateTimeMillis(96, (int) (byte) 1, 2, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-59137603200000L) + "'", long9 == (-59137603200000L));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.hourOfDay();
        org.joda.time.DurationField durationField17 = gregorianChronology15.years();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField20.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField20.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "DurationField[hours]");
        org.joda.time.DurationFieldType durationFieldType25 = illegalFieldValueException24.getDurationFieldType();
        java.lang.String str26 = illegalFieldValueException24.getIllegalStringValue();
        java.lang.Number number27 = illegalFieldValueException24.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = illegalFieldValueException24.getDateTimeFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType28);
        long long32 = zeroIsMaxDateTimeField29.getDifferenceAsLong(6048000033L, (-100L));
        long long34 = zeroIsMaxDateTimeField29.roundFloor(2L);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DurationField[hours]" + "'", str26.equals("DurationField[hours]"));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1680L + "'", long32 == 1680L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-100L) + "'", long34 == (-100L));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.Period period4 = new org.joda.time.Period(54, (-2), (int) ' ', 54);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(100);
        int int2 = period1.getMinutes();
        int int3 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str4 = jodaTimePermission3.toString();
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission3.newPermissionCollection();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long14 = fixedDateTimeZone11.adjustOffset((long) 10, false);
        boolean boolean16 = fixedDateTimeZone11.isStandardOffset((long) (short) 10);
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone11.getShortName((long) (short) -1, locale18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean21 = fixedDateTimeZone11.equals((java.lang.Object) iSOChronology20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.monthOfYear();
        boolean boolean23 = jodaTimePermission3.equals((java.lang.Object) iSOChronology20);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.052" + "'", str19.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getRangeDurationField();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField24.getRangeDurationField();
        java.util.Locale locale28 = null;
        try {
            int int29 = unsupportedDateTimeField24.getMaximumShortTextLength(locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling(31795200000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = remainderDateTimeField28.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.hourOfDay();
        org.joda.time.Period period37 = new org.joda.time.Period(1L);
        int[] intArray40 = gregorianChronology34.get((org.joda.time.ReadablePeriod) period37, (-1L), (-1L));
        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType43 = periodType42.withYearsRemoved();
        org.joda.time.PeriodType periodType44 = org.joda.time.DateTimeUtils.getPeriodType(periodType42);
        org.joda.time.PeriodType periodType45 = periodType44.withYearsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) (short) -1, periodType44);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType49 = periodType47.getFieldType((int) (short) 0);
        org.joda.time.Period period51 = period46.withField(durationFieldType49, (int) (short) -1);
        org.joda.time.Period period53 = period37.withFieldAdded(durationFieldType49, (int) (short) 100);
        org.joda.time.field.PreciseDurationField preciseDurationField55 = new org.joda.time.field.PreciseDurationField(durationFieldType49, (long) ' ');
        long long56 = preciseDurationField55.getUnitMillis();
        long long59 = preciseDurationField55.getMillis(100, 1560729600000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long66 = gregorianChronology60.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology60.hourOfHalfday();
        org.joda.time.DurationField durationField68 = gregorianChronology60.seconds();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField69 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, (org.joda.time.DurationField) preciseDurationField55, durationField68);
        org.joda.time.Period period71 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes72 = period71.toStandardMinutes();
        org.joda.time.Period period74 = period71.plusDays(97);
        org.joda.time.Period period76 = period71.plusMillis((int) '4');
        org.joda.time.Period period78 = period76.withYears((int) (short) 100);
        int int79 = period76.size();
        boolean boolean80 = preciseDurationField55.equals((java.lang.Object) int79);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31795200000L + "'", long32 == 31795200000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(durationFieldType49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 32L + "'", long56 == 32L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 3200L + "'", long59 == 3200L);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(minutes72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(period78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 8 + "'", int79 == 8);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.getValueAsLong(8639999980L, 355L);
        long long35 = scaledDurationField24.add(355L, (long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 355L + "'", long35 == 355L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType4 = period3.getPeriodType();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType7 = periodType6.withYearsRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = periodType6.isSupported(durationFieldType8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = period5.normalizedStandard(periodType10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period5.toDurationTo(readableInstant12);
        int int14 = period5.size();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period15 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        boolean boolean20 = iSOChronology13.equals((java.lang.Object) durationFieldType18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long28 = fixedDateTimeZone25.adjustOffset((-100L), true);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone25.getName((long) (byte) 10, locale30);
        org.joda.time.Chronology chronology32 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        int int31 = remainderDateTimeField28.getDivisor();
        int int32 = remainderDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 97 + "'", int31 == 97);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = zonedChronology20.getZone();
        java.lang.String str23 = dateTimeZone21.getShortName(97619558403104L);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.100" + "'", str23.equals("+00:00:00.100"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        boolean boolean12 = offsetDateTimeField5.isLeap((-8151736319999999965L));
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField5.getMaximumShortTextLength(locale13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsShortText((long) 0, locale16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField5.getMinimumValue(readablePartial18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2" + "'", str17.equals("2"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Period period2 = new org.joda.time.Period(35223552000000L, (long) 12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.Number number13 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType8, (java.lang.Number) 1.0d, number13, (java.lang.Number) 1);
        illegalFieldValueException15.prependMessage("LenientChronology[GregorianChronology[UTC]]");
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        try {
            long long28 = unsupportedDurationField24.getMillis((-3139171200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.Period period5 = period3.plusDays((int) (byte) 10);
        org.joda.time.Period period7 = period5.plusYears((int) (short) 1);
        org.joda.time.Period period9 = period7.plusMinutes((-52));
        org.joda.time.Period period11 = period9.minusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long15 = fixedDateTimeZone6.adjustOffset((-259200000L), false);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int17 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.Period period8 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds9 = period8.toStandardSeconds();
        int[] intArray10 = period8.getValues();
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        boolean boolean13 = offsetDateTimeField5.isLeap(8812800000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.plusMillis((int) '4');
        org.joda.time.Period period8 = org.joda.time.Period.millis(0);
        org.joda.time.Period period10 = period8.withSeconds((int) (byte) 1);
        int int11 = period8.getYears();
        org.joda.time.Period period13 = period8.minusMinutes(0);
        org.joda.time.Period period15 = period8.withYears((int) (short) 10);
        org.joda.time.Period period17 = org.joda.time.Period.years(0);
        org.joda.time.Period period19 = period17.withDays((int) (byte) 10);
        org.joda.time.Period period20 = period8.withFields((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period21 = period6.plus((org.joda.time.ReadablePeriod) period8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        int int12 = offsetDateTimeField5.getDifference((-100L), (long) 0);
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        long long16 = offsetDateTimeField5.getDifferenceAsLong((long) ' ', (long) 34947);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField5.getType();
        long long19 = offsetDateTimeField5.roundFloor(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        long long13 = unsupportedDurationField11.getUnitMillis();
        java.lang.String str14 = unsupportedDurationField11.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnsupportedDurationField[hours]" + "'", str14.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period3, (-1L), (-1L));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, periodType10);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = period12.withField(durationFieldType15, (int) (short) -1);
        org.joda.time.Period period19 = period3.withFieldAdded(durationFieldType15, (int) (short) 100);
        org.joda.time.field.PreciseDurationField preciseDurationField21 = new org.joda.time.field.PreciseDurationField(durationFieldType15, (long) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.hourOfDay();
        org.joda.time.DurationField durationField24 = gregorianChronology22.years();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 1);
        java.lang.String str29 = offsetDateTimeField27.getAsText((long) 52);
        org.joda.time.DurationField durationField30 = offsetDateTimeField27.getDurationField();
        long long33 = durationField30.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType36 = periodType35.withYearsRemoved();
        org.joda.time.PeriodType periodType37 = org.joda.time.DateTimeUtils.getPeriodType(periodType35);
        org.joda.time.PeriodType periodType38 = periodType37.withYearsRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) -1, periodType37);
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType((int) (short) 0);
        org.joda.time.Period period44 = period39.withField(durationFieldType42, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField46 = new org.joda.time.field.ScaledDurationField(durationField30, durationFieldType42, 52);
        java.lang.String str47 = scaledDurationField46.toString();
        long long49 = scaledDurationField46.getValueAsLong(6047999952L);
        boolean boolean51 = scaledDurationField46.equals((java.lang.Object) 97L);
        long long54 = scaledDurationField46.subtract(0L, (int) (byte) 100);
        int int57 = scaledDurationField46.getValue(2L, (long) (short) 1);
        long long60 = scaledDurationField46.getMillis(0L, (-259200000L));
        int int61 = preciseDurationField21.compareTo((org.joda.time.DurationField) scaledDurationField46);
        int int63 = scaledDurationField46.getValue((long) (-100));
        long long64 = scaledDurationField46.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2" + "'", str29.equals("2"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "DurationField[hours]" + "'", str47.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-3144960000000L) + "'", long54 == (-3144960000000L));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 31449600000L + "'", long64 == 31449600000L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long29 = dividedDateTimeField21.remainder(6047999952L);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = dividedDateTimeField21.getAsText(readablePartial30, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 6047999952L + "'", long29 == 6047999952L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.DurationField durationField24 = gregorianChronology22.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField24);
        try {
            int int27 = unsupportedDateTimeField25.get(1560629279853L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        int int11 = offsetDateTimeField5.getLeapAmount((-259200000L));
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField5.getAsText((int) (byte) 0, locale13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = jodaTimePermission1.equals(obj2);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.clockhourOfDay();
        org.joda.time.DurationField durationField8 = gregorianChronology6.weeks();
        org.joda.time.DurationField durationField9 = gregorianChronology6.centuries();
        boolean boolean10 = jodaTimePermission5.equals((java.lang.Object) gregorianChronology6);
        java.lang.String str11 = jodaTimePermission5.getName();
        org.joda.time.Period period13 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period15 = period13.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period13.toDurationTo(readableInstant16);
        org.joda.time.Period period19 = period13.withDays((-1));
        org.joda.time.Period period22 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period24 = period22.minusDays((-1));
        org.joda.time.Period period25 = period13.minus((org.joda.time.ReadablePeriod) period24);
        jodaTimePermission5.checkGuard((java.lang.Object) period24);
        java.security.PermissionCollection permissionCollection27 = jodaTimePermission5.newPermissionCollection();
        boolean boolean28 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology29.getZone();
        org.joda.time.Period period40 = new org.joda.time.Period((int) (short) 1, (int) (byte) 10, (int) (short) 1, (int) (short) 1, (int) 'a', (int) (short) 100, 10, 100);
        org.joda.time.Period period42 = period40.plusDays((int) '4');
        int[] intArray45 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period40, 0L, 519L);
        org.joda.time.Period period47 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes48 = period47.toStandardMinutes();
        org.joda.time.Period period50 = period47.plusDays(97);
        org.joda.time.Period period52 = period47.plusMillis((int) '4');
        org.joda.time.Minutes minutes53 = period52.toStandardMinutes();
        org.joda.time.Period period54 = period40.plus((org.joda.time.ReadablePeriod) minutes53);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.hourOfDay();
        org.joda.time.DurationField durationField57 = gregorianChronology55.years();
        org.joda.time.Period period59 = new org.joda.time.Period((long) ' ');
        long long62 = gregorianChronology55.add((org.joda.time.ReadablePeriod) period59, (long) '#', (int) (byte) 10);
        org.joda.time.Period period64 = period59.minusMinutes((int) (short) 100);
        org.joda.time.Period period66 = period59.plusMonths(0);
        org.joda.time.Period period67 = period40.withFields((org.joda.time.ReadablePeriod) period59);
        org.joda.time.Period period69 = period59.minusMonths((-6));
        jodaTimePermission5.checkGuard((java.lang.Object) period59);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(permissionCollection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(minutes48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(minutes53);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 355L + "'", long62 == 355L);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(period69);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(10L, false);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName((long) (byte) -1, locale11);
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone20 = fixedDateTimeZone19.toTimeZone();
        java.util.TimeZone timeZone21 = fixedDateTimeZone19.toTimeZone();
        long long24 = fixedDateTimeZone19.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Period period28 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period30 = period28.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType31 = null;
        int int32 = period30.indexOf(durationFieldType31);
        boolean boolean33 = iSOChronology26.equals((java.lang.Object) durationFieldType31);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long41 = fixedDateTimeZone38.adjustOffset((long) 10, false);
        boolean boolean43 = fixedDateTimeZone38.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology44 = iSOChronology26.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        boolean boolean45 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology26);
        int int47 = fixedDateTimeZone4.getStandardOffset((-49L));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-90L) + "'", long9 == (-90L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.100" + "'", str12.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-90L) + "'", long24 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long20 = fixedDateTimeZone17.convertLocalToUTC((long) (byte) 100, true);
        long long23 = fixedDateTimeZone17.adjustOffset((long) 10, true);
        org.joda.time.Chronology chronology24 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.Chronology chronology25 = zonedChronology12.withUTC();
        java.lang.String str26 = zonedChronology12.toString();
        java.lang.String str27 = zonedChronology12.toString();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str26.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str27.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long9 = gregorianChronology3.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType2, (org.joda.time.Chronology) gregorianChronology3);
        try {
            org.joda.time.Period period13 = period11.withMinutes((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 4, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[UTC]");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Millis" + "'", str1.equals("Millis"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (byte) 10);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.PeriodType periodType10 = periodType9.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType9);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period11.withField(durationFieldType14, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField17 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType14);
        int int18 = periodType5.indexOf(durationFieldType14);
        int int19 = period1.indexOf(durationFieldType14);
        org.joda.time.Period period21 = period1.plusSeconds((int) '4');
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Duration duration23 = period1.toDurationFrom(readableInstant22);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(unsupportedDurationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(duration23);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.subtract(0L, (int) (byte) 100);
        long long33 = scaledDurationField24.getUnitMillis();
        org.joda.time.DurationField durationField34 = scaledDurationField24.getWrappedField();
        long long35 = scaledDurationField24.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3144960000000L) + "'", long32 == (-3144960000000L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 31449600000L + "'", long33 == 31449600000L);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31449600000L + "'", long35 == 31449600000L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long6 = cachedDateTimeZone4.nextTransition(31795199948L);
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException("97");
        boolean boolean9 = cachedDateTimeZone4.equals((java.lang.Object) illegalInstantException8);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 31795199948L + "'", long6 == 31795199948L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int14 = fixedDateTimeZone6.getStandardOffset((long) (short) 0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        long long12 = offsetDateTimeField5.addWrapField(355L, 52);
        long long15 = offsetDateTimeField5.add((long) (short) 0, (-1L));
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = offsetDateTimeField5.getAsShortText(readablePartial16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31449600355L + "'", long12 == 31449600355L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-604800000L) + "'", long15 == (-604800000L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period4 = period2.minusDays((-1));
        org.joda.time.PeriodType periodType5 = period4.getPeriodType();
        org.joda.time.Days days6 = period4.toStandardDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(days6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        long long28 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.secondOfDay();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.secondOfDay();
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) 0, 0L, (org.joda.time.Chronology) gregorianChronology31);
        boolean boolean35 = unsupportedDurationField11.equals((java.lang.Object) 0L);
        java.lang.String str36 = unsupportedDurationField11.getName();
        java.lang.String str37 = unsupportedDurationField11.getName();
        org.joda.time.DurationField durationField38 = null;
        int int39 = unsupportedDurationField11.compareTo(durationField38);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hours" + "'", str36.equals("hours"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hours" + "'", str37.equals("hours"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long28 = scaledDurationField24.getValueAsLong((long) ' ', 4838400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 97);
        int int14 = offsetDateTimeField5.get(3050611200097L);
        long long16 = offsetDateTimeField5.roundFloor((-59137603200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36 + "'", int14 == 36);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-59137603200000L) + "'", long16 == (-59137603200000L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        boolean boolean13 = unsupportedDurationField11.isSupported();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = offsetDateTimeField5.getMinimumValue(readablePartial11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.hourOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology13.years();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 1);
        org.joda.time.DurationField durationField19 = offsetDateTimeField18.getLeapDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField18.getAsShortText((int) 'a', locale21);
        long long24 = offsetDateTimeField18.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.hourOfDay();
        org.joda.time.DurationField durationField27 = gregorianChronology25.years();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 1);
        org.joda.time.DurationField durationField31 = offsetDateTimeField30.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField30.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType32, (int) 'a');
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, "DurationField[hours]");
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsShortText(readablePartial13, (int) (byte) 100, locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100" + "'", str16.equals("100"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes7 = period6.toStandardMinutes();
        org.joda.time.Period period9 = period6.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period6.getFieldTypes();
        boolean boolean11 = lenientChronology4.equals((java.lang.Object) period6);
        org.joda.time.Chronology chronology12 = lenientChronology4.withUTC();
        long long20 = lenientChronology4.getDateTimeMillis(189000000, 96, (int) (short) 10, 0, (int) (short) 100, 52, 36399);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(minutes7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 5964202011346888399L + "'", long20 == 5964202011346888399L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        long long27 = scaledDurationField24.add((long) 'a', (long) 'a');
        long long30 = scaledDurationField24.getDifferenceAsLong((long) 1, (long) (short) 1);
        boolean boolean31 = scaledDurationField24.isPrecise();
        boolean boolean32 = scaledDurationField24.isPrecise();
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType34 = periodType33.withYearsRemoved();
        org.joda.time.PeriodType periodType35 = org.joda.time.DateTimeUtils.getPeriodType(periodType33);
        org.joda.time.PeriodType periodType36 = periodType35.withYearsRemoved();
        java.lang.String str37 = periodType35.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.hourOfDay();
        org.joda.time.DurationField durationField40 = gregorianChronology38.years();
        org.joda.time.Period period42 = new org.joda.time.Period((long) ' ');
        long long45 = gregorianChronology38.add((org.joda.time.ReadablePeriod) period42, (long) '#', (int) (byte) 10);
        org.joda.time.Period period47 = period42.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType50 = periodType49.withYearsRemoved();
        org.joda.time.PeriodType periodType51 = org.joda.time.DateTimeUtils.getPeriodType(periodType49);
        org.joda.time.PeriodType periodType52 = periodType51.withYearsRemoved();
        org.joda.time.Period period53 = new org.joda.time.Period((long) (short) -1, periodType51);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType56 = periodType54.getFieldType((int) (short) 0);
        org.joda.time.Period period58 = period53.withField(durationFieldType56, (int) (short) -1);
        boolean boolean59 = period47.isSupported(durationFieldType56);
        int int60 = periodType35.indexOf(durationFieldType56);
        org.joda.time.field.ScaledDurationField scaledDurationField62 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) scaledDurationField24, durationFieldType56, (int) '#');
        int int65 = scaledDurationField62.getValue((long) 96, (long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3050611200097L + "'", long27 == 3050611200097L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PeriodType[Hours]" + "'", str37.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 355L + "'", long45 == 355L);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            long long14 = unsupportedDurationField11.getMillis((-10L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Period period8 = new org.joda.time.Period((-97), 34947, (int) (byte) -1, 34947, (int) 'a', 52, (-1), 0);
        org.joda.time.Period period10 = period8.withYears(35);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) (short) 0);
        try {
            org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long12 = offsetDateTimeField5.add((long) (short) 1, (int) (short) 0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 4, 52, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for weekOfWeekyear must be in the range [52,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        long long27 = scaledDurationField24.add((long) 'a', (long) 'a');
        int int30 = scaledDurationField24.getDifference(5866559999999L, (long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3050611200097L + "'", long27 == 3050611200097L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 186 + "'", int30 == 186);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.subtract(0L, (int) (byte) 100);
        int int35 = scaledDurationField24.getValue(2L, (long) (short) 1);
        long long38 = scaledDurationField24.getMillis(0L, (-259200000L));
        long long40 = scaledDurationField24.getValueAsLong((-151L));
        int int43 = scaledDurationField24.getDifference((-18L), (-210866846396800L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3144960000000L) + "'", long32 == (-3144960000000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6704 + "'", int43 == 6704);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.DurationField durationField35 = gregorianChronology33.years();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1);
        org.joda.time.DurationField durationField39 = offsetDateTimeField38.getLeapDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((int) 'a', locale41);
        long long44 = offsetDateTimeField38.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.hourOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology45.years();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 1);
        org.joda.time.DurationField durationField51 = offsetDateTimeField50.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField50.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType52, (int) 'a');
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType52);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount((long) '#');
        int int58 = zeroIsMaxDateTimeField55.getMinimumValue();
        long long61 = zeroIsMaxDateTimeField55.getDifferenceAsLong(5866559999999L, (-59103730800000L));
        int int63 = zeroIsMaxDateTimeField55.getMinimumValue((long) '#');
        long long66 = zeroIsMaxDateTimeField55.add((long) 42, 35);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "97" + "'", str42.equals("97"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1107L + "'", long61 == 1107L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2053296000042L + "'", long66 == 2053296000042L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period5 = period3.minusDays((-1));
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        java.util.TimeZone timeZone15 = fixedDateTimeZone13.toTimeZone();
        long long18 = fixedDateTimeZone13.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = zonedChronology19.getZone();
        org.joda.time.Chronology chronology22 = zonedChronology19.withUTC();
        org.joda.time.Period period23 = new org.joda.time.Period(345600000L, periodType6, (org.joda.time.Chronology) zonedChronology19);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology19.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology19.minuteOfHour();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-90L) + "'", long18 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.DurationField durationField35 = gregorianChronology33.years();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1);
        org.joda.time.DurationField durationField39 = offsetDateTimeField38.getLeapDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((int) 'a', locale41);
        long long44 = offsetDateTimeField38.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.hourOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology45.years();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 1);
        org.joda.time.DurationField durationField51 = offsetDateTimeField50.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField50.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType52, (int) 'a');
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType52);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount((long) '#');
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = zeroIsMaxDateTimeField55.getMaximumValue(readablePartial59);
        int int62 = zeroIsMaxDateTimeField55.getLeapAmount(19612800000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "97" + "'", str42.equals("97"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 194L + "'", long2 == 194L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.DurationField durationField35 = gregorianChronology33.years();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1);
        org.joda.time.DurationField durationField39 = offsetDateTimeField38.getLeapDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((int) 'a', locale41);
        long long44 = offsetDateTimeField38.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.hourOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology45.years();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 1);
        org.joda.time.DurationField durationField51 = offsetDateTimeField50.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField50.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType52, (int) 'a');
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType52);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount((long) '#');
        int int58 = zeroIsMaxDateTimeField55.getMinimumValue();
        long long61 = zeroIsMaxDateTimeField55.getDifferenceAsLong(5866559999999L, (-59103730800000L));
        int int63 = zeroIsMaxDateTimeField55.getMinimumValue((long) '#');
        try {
            long long65 = zeroIsMaxDateTimeField55.roundHalfCeiling(345600000L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "97" + "'", str42.equals("97"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1107L + "'", long61 == 1107L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.hourOfDay();
        org.joda.time.DurationField durationField17 = gregorianChronology15.years();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField20.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField20.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "DurationField[hours]");
        org.joda.time.DurationFieldType durationFieldType25 = illegalFieldValueException24.getDurationFieldType();
        java.lang.String str26 = illegalFieldValueException24.getIllegalStringValue();
        java.lang.Number number27 = illegalFieldValueException24.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = illegalFieldValueException24.getDateTimeFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType28);
        long long32 = zeroIsMaxDateTimeField29.getDifferenceAsLong(6048000033L, (-100L));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = zeroIsMaxDateTimeField29.getType();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DurationField[hours]" + "'", str26.equals("DurationField[hours]"));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1680L + "'", long32 == 1680L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.DurationField durationField35 = gregorianChronology33.years();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1);
        org.joda.time.DurationField durationField39 = offsetDateTimeField38.getLeapDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((int) 'a', locale41);
        long long44 = offsetDateTimeField38.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.hourOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology45.years();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 1);
        org.joda.time.DurationField durationField51 = offsetDateTimeField50.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField50.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType52, (int) 'a');
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType52);
        int int58 = zeroIsMaxDateTimeField55.getDifference((long) (-6), (-43286400000L));
        try {
            long long60 = zeroIsMaxDateTimeField55.roundHalfEven(552407040259200000L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "97" + "'", str42.equals("97"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        boolean boolean6 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology2);
        java.lang.String str7 = jodaTimePermission1.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.hourOfDay();
        org.joda.time.DurationField durationField10 = gregorianChronology8.years();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 1);
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) offsetDateTimeField13);
        org.joda.time.JodaTimePermission jodaTimePermission16 = new org.joda.time.JodaTimePermission("+00:00:00.100");
        boolean boolean17 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission16);
        java.lang.String str18 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission20 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.clockhourOfDay();
        org.joda.time.DurationField durationField23 = gregorianChronology21.weeks();
        org.joda.time.DurationField durationField24 = gregorianChronology21.centuries();
        boolean boolean25 = jodaTimePermission20.equals((java.lang.Object) gregorianChronology21);
        java.lang.String str26 = jodaTimePermission20.getName();
        org.joda.time.Period period28 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period30 = period28.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period28.toDurationTo(readableInstant31);
        org.joda.time.Period period34 = period28.withDays((-1));
        org.joda.time.Period period37 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period39 = period37.minusDays((-1));
        org.joda.time.Period period40 = period28.minus((org.joda.time.ReadablePeriod) period39);
        jodaTimePermission20.checkGuard((java.lang.Object) period39);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone46 = new org.joda.time.tz.FixedDateTimeZone("", "2", 0, 2);
        boolean boolean47 = jodaTimePermission20.equals((java.lang.Object) fixedDateTimeZone46);
        boolean boolean48 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission20);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        org.joda.time.DurationField durationField25 = scaledDurationField24.getWrappedField();
        long long28 = scaledDurationField24.getMillis(0L, (long) (byte) 1);
        int int31 = scaledDurationField24.getDifference(52L, 99L);
        long long34 = scaledDurationField24.add(5684169635100L, 35);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 6784905635100L + "'", long34 == 6784905635100L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "+00:00:00.052");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "hi!", "");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "Hours", "10");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getName(locale13, "UnsupportedDateTimeField", "ZonedChronology[ISOChronology[UTC], ]");
        java.util.Locale locale17 = null;
        java.lang.String str20 = defaultNameProvider0.getName(locale17, "ZonedChronology[ISOChronology[UTC], ]", "97");
        java.util.Locale locale21 = null;
        java.lang.String str24 = defaultNameProvider0.getShortName(locale21, "org.joda.time.IllegalFieldValueException: Value 345600000 for PeriodType[Weeks] must be in the range [-5684169600000,200]", "DateTimeField[weekOfWeekyear]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        int int4 = period3.getHours();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period8 = period6.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period8.indexOf(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period8.get(durationFieldType11);
        org.joda.time.Period period14 = period8.withSeconds(10);
        org.joda.time.Period period15 = period3.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Seconds seconds16 = period3.toStandardSeconds();
        org.joda.time.MutablePeriod mutablePeriod17 = period3.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(seconds16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3104L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        int int4 = period1.getYears();
        org.joda.time.Period period6 = period1.minusMinutes(0);
        org.joda.time.Period period8 = period1.withYears((int) (short) 10);
        org.joda.time.Period period10 = period1.plusMinutes((-100));
        int int11 = period10.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        illegalFieldValueException4.prependMessage("ZonedChronology[ISOChronology[UTC], ]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) (byte) 100);
        java.lang.Number number13 = illegalFieldValueException12.getUpperBound();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Number number15 = illegalFieldValueException12.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType16 = illegalFieldValueException12.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 100 + "'", number13.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) -1 + "'", number15.equals((short) -1));
        org.junit.Assert.assertNull(durationFieldType16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology12.getZone();
        org.joda.time.Chronology chronology15 = zonedChronology12.withUTC();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = zonedChronology12.add(readablePeriod16, 0L, (-100));
        org.joda.time.Chronology chronology20 = zonedChronology12.withUTC();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.subtract(0L, (int) (byte) 100);
        long long35 = scaledDurationField24.add(2440588L, (int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType36 = scaledDurationField24.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3144960000000L) + "'", long32 == (-3144960000000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31452040588L + "'", long35 == 31452040588L);
        org.junit.Assert.assertNotNull(durationFieldType36);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.remainder((long) '#');
        long long14 = offsetDateTimeField5.roundCeiling(100L);
        int int16 = offsetDateTimeField5.get(259200035L);
        java.lang.String str17 = offsetDateTimeField5.getName();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (-52), 8, 6704);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for weekOfWeekyear must be in the range [8,6704]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200035L + "'", long12 == 259200035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345600000L + "'", long14 == 345600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "weekOfWeekyear" + "'", str17.equals("weekOfWeekyear"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        long long6 = gregorianChronology0.add((long) (short) -1, (long) '4', 10);
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.joda.time.Period period9 = org.joda.time.Period.seconds((int) '#');
        org.joda.time.Duration duration10 = period9.toStandardDuration();
        int int11 = period9.getSeconds();
        org.joda.time.Period period13 = org.joda.time.Period.millis(0);
        org.joda.time.Period period15 = period13.withSeconds((int) (byte) 1);
        int int16 = period15.getHours();
        org.joda.time.Period period18 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period20 = period18.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period20.indexOf(durationFieldType21);
        org.joda.time.DurationFieldType durationFieldType23 = null;
        int int24 = period20.get(durationFieldType23);
        org.joda.time.Period period26 = period20.withSeconds(10);
        org.joda.time.Period period27 = period15.plus((org.joda.time.ReadablePeriod) period20);
        org.joda.time.Seconds seconds28 = period15.toStandardSeconds();
        org.joda.time.Period period29 = period9.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period31 = period15.withMonths(54);
        int[] intArray34 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period31, 2111961599902L, 345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 519L + "'", long6 == 519L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(seconds28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology12.getZone();
        org.joda.time.Chronology chronology15 = zonedChronology12.withUTC();
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            long long18 = zonedChronology12.set(readablePartial16, (long) 189000000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.plusMinutes(0);
        org.joda.time.Duration duration4 = period1.toStandardDuration();
        org.joda.time.Period period6 = period1.minusHours((-1));
        org.joda.time.Period period8 = period6.withYears(0);
        org.joda.time.Days days9 = period8.toStandardDays();
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period8.toString(periodFormatter10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT1H" + "'", str11.equals("PT1H"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField24.getLeapDurationField();
        java.lang.String str31 = unsupportedDateTimeField24.getName();
        java.lang.String str32 = unsupportedDateTimeField24.toString();
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField24.getLeapDurationField();
        java.lang.String str34 = unsupportedDateTimeField24.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "weekOfWeekyear" + "'", str31.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnsupportedDateTimeField" + "'", str32.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "weekOfWeekyear" + "'", str34.equals("weekOfWeekyear"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
        long long10 = offsetDateTimeField5.roundHalfEven(31449600001L);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.hourOfDay();
        org.joda.time.DurationField durationField13 = gregorianChronology11.years();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 1);
        org.joda.time.DurationField durationField17 = offsetDateTimeField16.getLeapDurationField();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText((int) 'a', locale19);
        long long22 = offsetDateTimeField16.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.hourOfDay();
        org.joda.time.DurationField durationField25 = gregorianChronology23.years();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 1);
        org.joda.time.DurationField durationField29 = offsetDateTimeField28.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType30, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField34 = gregorianChronology33.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField34);
        boolean boolean36 = unsupportedDateTimeField35.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = unsupportedDateTimeField35.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType37, 97);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39, dateTimeFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31190400000L + "'", long10 == 31190400000L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        org.joda.time.DurationField durationField26 = unsupportedDateTimeField24.getLeapDurationField();
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField24.getLeapDurationField();
        try {
            int int29 = unsupportedDateTimeField24.getMinimumValue((long) (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        java.lang.String str3 = periodType2.toString();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[Weeks]" + "'", str3.equals("PeriodType[Weeks]"));
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Weeks weeks3 = period2.toStandardWeeks();
        org.joda.time.Period period5 = period2.withWeeks(0);
        org.joda.time.Period period7 = period5.minusDays((-6));
        org.junit.Assert.assertNotNull(weeks3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField11.getType();
        try {
            long long16 = unsupportedDurationField11.getMillis(0, 35223552000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(durationFieldType13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        long long27 = scaledDurationField24.add((long) 'a', (long) 'a');
        long long30 = scaledDurationField24.getDifferenceAsLong((long) 1, (long) (short) 1);
        boolean boolean31 = scaledDurationField24.isPrecise();
        boolean boolean32 = scaledDurationField24.isPrecise();
        int int35 = scaledDurationField24.getValue(0L, 3144960000002L);
        long long38 = scaledDurationField24.add(0L, (long) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3050611200097L + "'", long27 == 3050611200097L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 314496000000L + "'", long38 == 314496000000L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        long long27 = scaledDurationField24.add((long) 'a', (long) 'a');
        long long30 = scaledDurationField24.getDifferenceAsLong((long) 1, (long) (short) 1);
        boolean boolean31 = scaledDurationField24.isPrecise();
        boolean boolean32 = scaledDurationField24.isPrecise();
        int int35 = scaledDurationField24.getValue(0L, 3144960000002L);
        org.joda.time.Period period37 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType38 = period37.getPeriodType();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.secondOfDay();
        try {
            org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) 3144960000002L, periodType38, (org.joda.time.Chronology) gregorianChronology39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3050611200097L + "'", long27 == 3050611200097L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.DurationField durationField35 = gregorianChronology33.years();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1);
        org.joda.time.DurationField durationField39 = offsetDateTimeField38.getLeapDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((int) 'a', locale41);
        long long44 = offsetDateTimeField38.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.hourOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology45.years();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 1);
        org.joda.time.DurationField durationField51 = offsetDateTimeField50.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField50.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType52, (int) 'a');
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType52);
        int int57 = zeroIsMaxDateTimeField55.getMaximumValue((-43200000000L));
        try {
            long long60 = zeroIsMaxDateTimeField55.set(2053296000042L, 6704);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6704 for weekOfWeekyear must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "97" + "'", str42.equals("97"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(33L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
        int int2 = period1.getSeconds();
        int int3 = period1.getDays();
        org.joda.time.Period period5 = period1.withDays(34947);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withWeeks(189000000);
        org.joda.time.Period period10 = period5.plusMonths(36399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 34947 + "'", int6 == 34947);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getRangeDurationField();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        long long29 = unsupportedDateTimeField24.add(4838400000L, (long) (short) 0);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = unsupportedDateTimeField24.getAsShortText(readablePartial30, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4838400000L + "'", long29 == 4838400000L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        java.util.Locale locale34 = null;
        java.lang.String str35 = dividedDateTimeField21.getAsShortText((-604800000L), locale34);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        java.lang.String str39 = dividedDateTimeField21.getAsShortText(readablePartial36, 49, locale38);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "49" + "'", str39.equals("49"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField24.getLeapDurationField();
        java.lang.String str31 = unsupportedDateTimeField24.getName();
        java.lang.String str32 = unsupportedDateTimeField24.toString();
        org.joda.time.DurationField durationField33 = unsupportedDateTimeField24.getLeapDurationField();
        try {
            int int35 = unsupportedDateTimeField24.get((-210866846396800L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "weekOfWeekyear" + "'", str31.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnsupportedDateTimeField" + "'", str32.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        int int26 = scaledDurationField24.getValue(259200000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
        org.joda.time.Period period38 = new org.joda.time.Period((int) (short) 1, (int) (byte) 10, (int) (short) 1, (int) (short) 1, (int) 'a', (int) (short) 100, 10, 100);
        org.joda.time.Period period40 = period38.plusDays((int) '4');
        int[] intArray43 = gregorianChronology27.get((org.joda.time.ReadablePeriod) period38, 0L, 519L);
        org.joda.time.Period period45 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes46 = period45.toStandardMinutes();
        org.joda.time.Period period48 = period45.plusDays(97);
        org.joda.time.Period period50 = period45.plusMillis((int) '4');
        org.joda.time.Minutes minutes51 = period50.toStandardMinutes();
        org.joda.time.Period period52 = period38.plus((org.joda.time.ReadablePeriod) minutes51);
        boolean boolean53 = scaledDurationField24.equals((java.lang.Object) period52);
        org.joda.time.DurationField durationField54 = scaledDurationField24.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(minutes46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(minutes51);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(durationField54);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getDurationField();
        long long28 = unsupportedDateTimeField24.add((-20L), 100L);
        boolean boolean29 = unsupportedDateTimeField24.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 8639999980L + "'", long28 == 8639999980L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.100");
        jodaTimePermission1.checkGuard((java.lang.Object) 'a');
        java.lang.String str4 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        java.lang.String str6 = periodType4.toString();
        org.joda.time.PeriodType periodType7 = periodType4.withSecondsRemoved();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.util.TimeZone timeZone16 = fixedDateTimeZone14.toTimeZone();
        long long19 = fixedDateTimeZone14.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Period period23 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period25 = period23.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        boolean boolean28 = iSOChronology21.equals((java.lang.Object) durationFieldType26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long36 = fixedDateTimeZone33.adjustOffset((long) 10, false);
        boolean boolean38 = fixedDateTimeZone33.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology39 = iSOChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.Period period40 = new org.joda.time.Period(6048000000L, (-604800000L), periodType7, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology21.hourOfDay();
        org.joda.time.ReadableInterval readableInterval42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone49 = fixedDateTimeZone48.toTimeZone();
        java.util.TimeZone timeZone50 = fixedDateTimeZone48.toTimeZone();
        long long53 = fixedDateTimeZone48.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology54 = org.joda.time.chrono.ZonedChronology.getInstance(chronology43, (org.joda.time.DateTimeZone) fixedDateTimeZone48);
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone48);
        org.joda.time.Period period57 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period59.indexOf(durationFieldType60);
        boolean boolean62 = iSOChronology55.equals((java.lang.Object) durationFieldType60);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone67 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long70 = fixedDateTimeZone67.adjustOffset((long) 10, false);
        boolean boolean72 = fixedDateTimeZone67.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology73 = iSOChronology55.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone67);
        java.lang.String str74 = fixedDateTimeZone67.getID();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone75 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone67);
        int int77 = cachedDateTimeZone75.getOffset(31449600000L);
        boolean boolean78 = cachedDateTimeZone75.isFixed();
        org.joda.time.chrono.ZonedChronology zonedChronology79 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology21, (org.joda.time.DateTimeZone) cachedDateTimeZone75);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[Hours]" + "'", str6.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-90L) + "'", long19 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-90L) + "'", long53 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology54);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 52 + "'", int77 == 52);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(zonedChronology79);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.remainder((long) '#');
        long long14 = offsetDateTimeField5.roundCeiling(100L);
        int int16 = offsetDateTimeField5.get(259200035L);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.hourOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology17.years();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 1);
        org.joda.time.DurationField durationField23 = offsetDateTimeField22.getLeapDurationField();
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField22.getAsShortText((int) 'a', locale25);
        long long28 = offsetDateTimeField22.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.hourOfDay();
        org.joda.time.DurationField durationField31 = gregorianChronology29.years();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 1);
        org.joda.time.DurationField durationField35 = offsetDateTimeField34.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, dateTimeFieldType36, (int) 'a');
        long long40 = dividedDateTimeField38.remainder((long) 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.hourOfDay();
        org.joda.time.DurationField durationField43 = gregorianChronology41.years();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology41.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 1);
        org.joda.time.DurationField durationField47 = offsetDateTimeField46.getLeapDurationField();
        java.util.Locale locale49 = null;
        java.lang.String str50 = offsetDateTimeField46.getAsShortText((int) 'a', locale49);
        long long52 = offsetDateTimeField46.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology53.hourOfDay();
        org.joda.time.DurationField durationField55 = gregorianChronology53.years();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology53.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, 1);
        org.joda.time.DurationField durationField59 = offsetDateTimeField58.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField46, dateTimeFieldType60, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField64 = gregorianChronology63.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType60, durationField64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38, dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType60, 35);
        int int69 = remainderDateTimeField68.getDivisor();
        int int70 = remainderDateTimeField68.getMinimumValue();
        try {
            long long73 = remainderDateTimeField68.set((long) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [0,34]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200035L + "'", long12 == 259200035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345600000L + "'", long14 == 345600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "97" + "'", str26.equals("97"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-259200000L) + "'", long28 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 97L + "'", long40 == 97L);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "97" + "'", str50.equals("97"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-259200000L) + "'", long52 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 35 + "'", int69 == 35);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
        int int2 = period1.getSeconds();
        int int3 = period1.getDays();
        org.joda.time.Period period5 = period1.withDays(34947);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.Period period7 = period5.withFields(readablePeriod6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling(31795200000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = remainderDateTimeField28.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.hourOfDay();
        org.joda.time.Period period37 = new org.joda.time.Period(1L);
        int[] intArray40 = gregorianChronology34.get((org.joda.time.ReadablePeriod) period37, (-1L), (-1L));
        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType43 = periodType42.withYearsRemoved();
        org.joda.time.PeriodType periodType44 = org.joda.time.DateTimeUtils.getPeriodType(periodType42);
        org.joda.time.PeriodType periodType45 = periodType44.withYearsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) (short) -1, periodType44);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType49 = periodType47.getFieldType((int) (short) 0);
        org.joda.time.Period period51 = period46.withField(durationFieldType49, (int) (short) -1);
        org.joda.time.Period period53 = period37.withFieldAdded(durationFieldType49, (int) (short) 100);
        org.joda.time.field.PreciseDurationField preciseDurationField55 = new org.joda.time.field.PreciseDurationField(durationFieldType49, (long) ' ');
        long long56 = preciseDurationField55.getUnitMillis();
        long long59 = preciseDurationField55.getMillis(100, 1560729600000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long66 = gregorianChronology60.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology60.hourOfHalfday();
        org.joda.time.DurationField durationField68 = gregorianChronology60.seconds();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField69 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, (org.joda.time.DurationField) preciseDurationField55, durationField68);
        long long71 = preciseDateTimeField69.roundCeiling((-59137603200000L));
        long long73 = preciseDateTimeField69.remainder(259200000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31795200000L + "'", long32 == 31795200000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(durationFieldType49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 32L + "'", long56 == 32L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 3200L + "'", long59 == 3200L);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-59137603200000L) + "'", long71 == (-59137603200000L));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        boolean boolean6 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology2);
        java.lang.String str7 = jodaTimePermission1.getName();
        org.joda.time.Period period9 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period11 = period9.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationTo(readableInstant12);
        org.joda.time.Period period15 = period9.withDays((-1));
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period20 = period18.minusDays((-1));
        org.joda.time.Period period21 = period9.minus((org.joda.time.ReadablePeriod) period20);
        jodaTimePermission1.checkGuard((java.lang.Object) period20);
        java.lang.String str23 = jodaTimePermission1.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long31 = fixedDateTimeZone28.convertLocalToUTC((long) (byte) 100, true);
        long long34 = fixedDateTimeZone28.adjustOffset((long) 10, true);
        long long37 = fixedDateTimeZone28.convertLocalToUTC((long) (short) 1, false);
        int int39 = fixedDateTimeZone28.getOffsetFromLocal(0L);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        jodaTimePermission1.checkGuard((java.lang.Object) fixedDateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str23.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-99L) + "'", long37 == (-99L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone40);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str31 = dividedDateTimeField21.toString();
        org.joda.time.DurationField durationField32 = dividedDateTimeField21.getDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.DurationField durationField35 = gregorianChronology33.years();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 1);
        org.joda.time.DurationField durationField39 = offsetDateTimeField38.getLeapDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField38.getAsShortText((int) 'a', locale41);
        long long44 = offsetDateTimeField38.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.hourOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology45.years();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 1);
        org.joda.time.DurationField durationField51 = offsetDateTimeField50.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField50.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType52, (int) 'a');
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType52);
        int int58 = zeroIsMaxDateTimeField55.getDifference((long) (-6), (-43286400000L));
        int int60 = zeroIsMaxDateTimeField55.getMaximumValue((long) (byte) 100);
        try {
            long long63 = zeroIsMaxDateTimeField55.addWrapField((long) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str31.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "97" + "'", str42.equals("97"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period15 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        boolean boolean20 = iSOChronology13.equals((java.lang.Object) durationFieldType18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long28 = fixedDateTimeZone25.adjustOffset((-100L), true);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone25.getName((long) (byte) 10, locale30);
        org.joda.time.Chronology chronology32 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        java.util.Locale locale34 = null;
        java.lang.String str35 = fixedDateTimeZone25.getName((-20L), locale34);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone37 = cachedDateTimeZone36.getUncachedZone();
        java.lang.String str39 = cachedDateTimeZone36.getNameKey((-43286400000L));
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.052" + "'", str35.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getRangeDurationField();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        long long29 = unsupportedDateTimeField24.add(4838400000L, (long) (short) 0);
        long long32 = unsupportedDateTimeField24.add((-1L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4838400000L + "'", long29 == 4838400000L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        java.lang.String str30 = unsupportedDateTimeField24.getName();
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField24.getAsShortText(readablePartial31, 186, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "weekOfWeekyear" + "'", str30.equals("weekOfWeekyear"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.DurationField durationField12 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 97);
        int int14 = offsetDateTimeField5.get(3050611200097L);
        boolean boolean15 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36 + "'", int14 == 36);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        long long7 = offsetDateTimeField5.remainder((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundFloor((long) 35);
        long long11 = offsetDateTimeField5.roundHalfFloor(32L);
        long long14 = offsetDateTimeField5.add((long) 4, 259200000L);
        boolean boolean16 = offsetDateTimeField5.isLeap(6048000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 259200000L + "'", long7 == 259200000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 156764160000000004L + "'", long14 == 156764160000000004L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling(31795200000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = remainderDateTimeField28.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.hourOfDay();
        org.joda.time.Period period37 = new org.joda.time.Period(1L);
        int[] intArray40 = gregorianChronology34.get((org.joda.time.ReadablePeriod) period37, (-1L), (-1L));
        org.joda.time.PeriodType periodType42 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType43 = periodType42.withYearsRemoved();
        org.joda.time.PeriodType periodType44 = org.joda.time.DateTimeUtils.getPeriodType(periodType42);
        org.joda.time.PeriodType periodType45 = periodType44.withYearsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) (short) -1, periodType44);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType49 = periodType47.getFieldType((int) (short) 0);
        org.joda.time.Period period51 = period46.withField(durationFieldType49, (int) (short) -1);
        org.joda.time.Period period53 = period37.withFieldAdded(durationFieldType49, (int) (short) 100);
        org.joda.time.field.PreciseDurationField preciseDurationField55 = new org.joda.time.field.PreciseDurationField(durationFieldType49, (long) ' ');
        long long56 = preciseDurationField55.getUnitMillis();
        long long59 = preciseDurationField55.getMillis(100, 1560729600000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long66 = gregorianChronology60.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology60.hourOfHalfday();
        org.joda.time.DurationField durationField68 = gregorianChronology60.seconds();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField69 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType33, (org.joda.time.DurationField) preciseDurationField55, durationField68);
        long long71 = preciseDateTimeField69.roundCeiling((-59137603200000L));
        int int73 = preciseDateTimeField69.get((-18L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31795200000L + "'", long32 == 31795200000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(durationFieldType49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 32L + "'", long56 == 32L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 3200L + "'", long59 == 3200L);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-59137603200000L) + "'", long71 == (-59137603200000L));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 30 + "'", int73 == 30);
    }
}

