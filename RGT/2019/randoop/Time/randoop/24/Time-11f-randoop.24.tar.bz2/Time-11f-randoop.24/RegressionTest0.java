import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 100, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for  must be in the range [35,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("hi!", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.PeriodType periodType6 = null;
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) fixedDateTimeZone4, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.PeriodType periodType1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) 'a', periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        int[] intArray5 = new int[] { '4', (-1), (byte) 1 };
        try {
            gregorianChronology0.validate(readablePartial1, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100, (java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = new org.joda.time.DurationFieldType[] { durationFieldType0 };
        try {
            org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.forFields(durationFieldTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) (byte) 0, 100, (int) (byte) 1, (int) '4', (int) (byte) 100, (int) (byte) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.PeriodType periodType1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) (-1L), periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.lang.String str6 = fixedDateTimeZone4.getName((long) (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone4.getClass();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.50000037d + "'", double1 == 2440587.50000037d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePartial2, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (byte) 10);
        try {
            int int5 = period1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.052\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray9 = new int[] { (byte) 0, (byte) 0, 0, (byte) -1 };
        try {
            gregorianChronology0.validate(readablePartial4, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology3.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfDay();
        org.joda.time.Period period12 = new org.joda.time.Period(1L);
        int[] intArray15 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period12, (-1L), (-1L));
        try {
            int[] intArray17 = offsetDateTimeField5.addWrapField(readablePartial7, 0, intArray15, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period3.withField(durationFieldType4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = offsetDateTimeField5.getAsText(readablePartial10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, periodType3);
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.plusMillis((int) '4');
        int int7 = period6.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 52);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        long long6 = gregorianChronology0.add((long) (short) -1, (long) '4', 10);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 519L + "'", long6 == 519L);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560629279853L + "'", long1 == 1560629279853L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        boolean boolean7 = offsetDateTimeField5.isSupported();
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) (byte) 1, (org.joda.time.Chronology) gregorianChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePartial4, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(355L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) ' ', false, 1L);
        org.joda.time.ReadableInstant readableInstant9 = null;
        int int10 = fixedDateTimeZone4.getOffset(readableInstant9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-20L) + "'", long8 == (-20L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period3, (-1L), (-1L));
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(35, (-1), 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) (short) 0, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 0, (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period15 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        boolean boolean20 = iSOChronology13.equals((java.lang.Object) durationFieldType18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long28 = fixedDateTimeZone25.adjustOffset((-100L), true);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone25.getName((long) (byte) 10, locale30);
        org.joda.time.Chronology chronology32 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        try {
            long long38 = iSOChronology13.getDateTimeMillis((-99L), (int) (byte) 100, 100, 52, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        java.lang.String str2 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.Period period23 = new org.joda.time.Period((int) (short) 1, (int) (byte) 10, (int) (short) 1, (int) (short) 1, (int) 'a', (int) (short) 100, 10, 100);
        org.joda.time.Period period25 = period23.plusDays((int) '4');
        int[] intArray28 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period23, 0L, 519L);
        java.util.Locale locale30 = null;
        try {
            int[] intArray31 = offsetDateTimeField5.set(readablePartial10, (int) (byte) 10, intArray28, "PT0S", locale30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0S\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '#');
        org.joda.time.Duration duration2 = period1.toStandardDuration();
        long long3 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35000L + "'", long3 == 35000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 1, 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PT0S", "");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        long long5 = gregorianChronology0.add((long) (short) -1, 1L, 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 99L + "'", long5 == 99L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (short) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName((long) (short) -1, locale11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long20 = fixedDateTimeZone17.convertLocalToUTC((long) (byte) 100, true);
        long long23 = fixedDateTimeZone17.adjustOffset((long) 10, true);
        long long25 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone17, 6048000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 6047999952L + "'", long25 == 6047999952L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-604800000L), "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) (-100L), (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.Period period1 = org.joda.time.Period.months(52);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[Hours]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[Hours]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "+00:00:00.052");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.clockhourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(6048000000L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2", false);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = fixedDateTimeZone4.getOffset(readableInstant7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusMonths(0);
        org.junit.Assert.assertNotNull(period2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            int int13 = unsupportedDurationField11.getValue(31449600355L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText((long) 35, locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long14 = unsupportedDurationField11.getDifferenceAsLong((long) (short) 0, 99L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.add(0L, (int) (short) 10);
        org.joda.time.DurationField durationField11 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6048000000L + "'", long10 == 6048000000L);
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT0S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT0S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ');
        long long7 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period4, (long) '#', (int) (byte) 10);
        int int8 = period4.getMonths();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 355L + "'", long7 == 355L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 100, true);
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) (byte) -1);
        java.lang.String str10 = fixedDateTimeZone4.getID();
        long long14 = fixedDateTimeZone4.convertLocalToUTC(100L, true, 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone10 = fixedDateTimeZone9.toTimeZone();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        long long14 = fixedDateTimeZone9.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) gregorianChronology0, (org.joda.time.Chronology) iSOChronology16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-90L) + "'", long14 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(iSOChronology16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            int int15 = unsupportedDurationField11.getValue((long) (-1), 2L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long13 = unsupportedDurationField11.getValueAsLong(345600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.add(0L, (int) (short) 10);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray13 = null;
        try {
            int[] intArray15 = offsetDateTimeField5.addWrapPartial(readablePartial11, 0, intArray13, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6048000000L + "'", long10 == 6048000000L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        long long6 = gregorianChronology0.add((long) (short) -1, (long) '4', 10);
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 519L + "'", long6 == 519L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (int) '4', 97, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for weekOfWeekyear must be in the range [97,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            long long14 = unsupportedDurationField11.getMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.052/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = offsetDateTimeField5.getDifferenceAsLong((long) (-1), (long) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundFloor((long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        int int12 = offsetDateTimeField5.getDifference((-100L), (long) 0);
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsShortText(readablePartial14, (int) (byte) 10, locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10" + "'", str17.equals("10"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '#');
        org.joda.time.Duration duration2 = period1.toStandardDuration();
        int int3 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, (int) (byte) 100, 2, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for millisOfSecond must be in the range [2,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        try {
            long long28 = unsupportedDurationField24.getValueAsLong((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long14 = unsupportedDurationField11.getValueAsLong(97L, (-20L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            int int14 = unsupportedDurationField11.getValue((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, 0L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.hourOfDay();
        org.joda.time.DurationField durationField10 = gregorianChronology8.years();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 1);
        org.joda.time.DurationField durationField14 = offsetDateTimeField13.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, "DurationField[hours]");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType15, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DurationField[hours]");
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        java.lang.Number number11 = illegalFieldValueException9.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        org.joda.time.Period period5 = period3.minusSeconds((int) 'a');
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        try {
            long long29 = unsupportedDurationField24.getMillis((int) (short) 10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
        try {
            long long13 = offsetDateTimeField5.set((long) (short) 10, "DurationField[hours]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DurationField[hours]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        java.lang.String str4 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((-100L), true);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 10, locale9);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-100L) + "'", long7 == (-100L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.052" + "'", str10.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.hourOfDay();
        org.joda.time.DurationField durationField29 = gregorianChronology27.years();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1);
        org.joda.time.ReadablePartial readablePartial33 = null;
        org.joda.time.Period period35 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds36 = period35.toStandardSeconds();
        int[] intArray37 = period35.getValues();
        int int38 = offsetDateTimeField32.getMinimumValue(readablePartial33, intArray37);
        java.util.Locale locale40 = null;
        try {
            int[] intArray41 = unsupportedDateTimeField24.set(readablePartial25, (int) 'a', intArray37, "PT0S", locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(seconds36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.PeriodType periodType6 = periodType5.withYearsRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, periodType5);
        org.joda.time.PeriodType periodType8 = periodType5.withMinutesRemoved();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            long long26 = unsupportedDateTimeField24.remainder((long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 1);
        org.joda.time.Period period3 = period1.plusMonths(100);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.Period period1 = org.joda.time.Period.months((-1));
        try {
            org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        java.lang.String str4 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0S" + "'", str4.equals("PT0S"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-97), 35000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35097L) + "'", long2 == (-35097L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, 0L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period1.toDurationTo(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.hourOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology5.years();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 1);
        org.joda.time.DurationField durationField11 = offsetDateTimeField10.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, "DurationField[hours]");
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long14 = unsupportedDurationField11.getMillis((long) (-97), 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        try {
            long long23 = dividedDateTimeField21.roundFloor(100L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '#');
        org.joda.time.Duration duration2 = period1.toStandardDuration();
        int int3 = period1.getSeconds();
        try {
            int int5 = period1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period15 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        boolean boolean20 = iSOChronology13.equals((java.lang.Object) durationFieldType18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long28 = fixedDateTimeZone25.adjustOffset((long) 10, false);
        boolean boolean30 = fixedDateTimeZone25.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology31 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        int int33 = fixedDateTimeZone25.getOffsetFromLocal(31449600000L);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 52 + "'", int33 == 52);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        try {
            long long14 = unsupportedDurationField11.getDifferenceAsLong((-35097L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            long long15 = unsupportedDurationField11.getDifferenceAsLong((long) 35, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 100, true);
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) (byte) -1);
        java.lang.String str10 = fixedDateTimeZone4.getID();
        long long12 = fixedDateTimeZone4.previousTransition((long) 52);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.remainder((long) '#');
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200035L + "'", long12 == 259200035L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period15 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        boolean boolean20 = iSOChronology13.equals((java.lang.Object) durationFieldType18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long28 = fixedDateTimeZone25.adjustOffset((-100L), true);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone25.getName((long) (byte) 10, locale30);
        org.joda.time.Chronology chronology32 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DurationField durationField33 = iSOChronology13.minutes();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.hourOfDay();
        org.joda.time.Period period30 = new org.joda.time.Period(1L);
        int[] intArray33 = gregorianChronology27.get((org.joda.time.ReadablePeriod) period30, (-1L), (-1L));
        try {
            int[] intArray35 = unsupportedDateTimeField24.add(readablePartial25, (-97), intArray33, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.util.Locale locale26 = null;
        try {
            int int27 = unsupportedDateTimeField24.getMaximumShortTextLength(locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(100);
        org.joda.time.Period period3 = period1.minusMinutes((int) (short) 1);
        org.joda.time.Minutes minutes4 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 100, true);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", 2, (int) (short) -1, 0, '#', 97, 0, 10, false, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        long long7 = gregorianChronology0.add(52L, 31449600000L, (int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31449599948L) + "'", long7 == (-31449599948L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = offsetDateTimeField5.add((-90L), (int) 'a');
        boolean boolean12 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 58665599910L + "'", long11 == 58665599910L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.clockhourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(6048000000L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Days days4 = period3.toStandardDays();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(days4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 1, periodType1);
        try {
            org.joda.time.Period period4 = period2.minusMinutes((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '#');
        int int2 = period1.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        try {
            long long27 = unsupportedDateTimeField24.remainder((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        try {
            long long29 = unsupportedDurationField11.getMillis((int) (byte) 10, 6047999952L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        java.lang.String str11 = period5.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0H" + "'", str11.equals("PT0H"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        org.joda.time.DurationField durationField25 = scaledDurationField24.getWrappedField();
        long long27 = scaledDurationField24.getMillis((long) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31449600000L) + "'", long27 == (-31449600000L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 1, (int) (byte) 10, (int) (short) 1, (int) (short) 1, (int) 'a', (int) (short) 100, 10, 100);
        try {
            org.joda.time.Hours hours9 = period8.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long16 = fixedDateTimeZone13.adjustOffset((long) 10, false);
        boolean boolean18 = fixedDateTimeZone13.isStandardOffset((long) (short) 10);
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone13.getShortName((long) (short) -1, locale20);
        long long23 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone13, (long) (byte) 10);
        java.util.TimeZone timeZone24 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.052" + "'", str21.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "+00:00:00.052");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "PeriodType[Weeks]", "PeriodType[Weeks]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        int int4 = period3.getSeconds();
        org.joda.time.Period period6 = period3.plusHours((int) '4');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes8 = period7.toStandardMinutes();
        org.joda.time.Period period10 = period7.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period7.getFieldTypes();
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period7);
        int int13 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 1);
        java.lang.String str8 = offsetDateTimeField6.getAsShortText((long) (byte) 0);
        long long11 = offsetDateTimeField6.set(100L, "2");
        long long13 = offsetDateTimeField6.remainder((long) '#');
        long long15 = offsetDateTimeField6.roundCeiling(100L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.hourOfDay();
        org.joda.time.DurationField durationField18 = gregorianChronology16.years();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 1);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getLeapDurationField();
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField21.getAsShortText((int) 'a', locale24);
        long long27 = offsetDateTimeField21.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.hourOfDay();
        org.joda.time.DurationField durationField30 = gregorianChronology28.years();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 1);
        org.joda.time.DurationField durationField34 = offsetDateTimeField33.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField33.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, dateTimeFieldType35, (int) 'a');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType35, 35);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2" + "'", str8.equals("2"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 259200035L + "'", long13 == 259200035L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345600000L + "'", long15 == 345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "97" + "'", str25.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-259200000L) + "'", long27 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField24.getAsShortText(readablePartial25, 0, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            long long27 = unsupportedDateTimeField24.set(100L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        long long14 = offsetDateTimeField5.getDifferenceAsLong((long) (byte) -1, 6048000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-10L) + "'", long14 == (-10L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 100, true);
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) (byte) -1);
        long long12 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone4.getName(35000L, locale14);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-100L) + "'", long12 == (-100L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.hourOfDay();
        org.joda.time.Period period29 = new org.joda.time.Period(1L);
        int[] intArray32 = gregorianChronology26.get((org.joda.time.ReadablePeriod) period29, (-1L), (-1L));
        try {
            int int33 = unsupportedDateTimeField24.getMaximumValue(readablePartial25, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        try {
            long long27 = unsupportedDateTimeField24.roundHalfCeiling((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (byte) 10);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType6 = periodType5.withYearsRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(6048000000L, periodType7);
        try {
            org.joda.time.Period period10 = period1.withPeriodType(periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundCeiling(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial10);
        long long14 = offsetDateTimeField5.add(259200000L, (int) ' ');
        long long17 = offsetDateTimeField5.addWrapField((long) (byte) 1, (int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 345600000L + "'", long9 == 345600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 19612800000L + "'", long14 == 19612800000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600001L + "'", long17 == 31449600001L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        java.util.Locale locale25 = null;
        try {
            int int26 = unsupportedDateTimeField24.getMaximumShortTextLength(locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560629294707L + "'", long0 == 1560629294707L);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withMinutesRemoved();
        org.joda.time.ReadableInterval readableInterval7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        java.util.TimeZone timeZone15 = fixedDateTimeZone13.toTimeZone();
        long long18 = fixedDateTimeZone13.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long27 = fixedDateTimeZone24.convertLocalToUTC((long) (byte) 100, true);
        long long30 = fixedDateTimeZone24.adjustOffset((long) 10, true);
        org.joda.time.Chronology chronology31 = zonedChronology19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.Period period32 = new org.joda.time.Period((long) 2, (long) 97, periodType6, chronology31);
        org.joda.time.Period period33 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType6);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-90L) + "'", long18 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(6048000000L, periodType3);
        try {
            org.joda.time.Period period7 = period5.minusMillis((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        int int9 = fixedDateTimeZone4.getOffset((-99L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = unsupportedDateTimeField24.getAsShortText((int) ' ', locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (short) 10);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(1560629279853L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(100);
        org.joda.time.Period period3 = period1.minusMinutes((int) (short) 1);
        org.joda.time.Period period5 = period3.plusHours((int) '4');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        try {
            long long29 = unsupportedDateTimeField24.roundFloor(19612800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            int int15 = unsupportedDurationField11.getDifference(259200035L, 6047999952L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        long long6 = gregorianChronology0.add((long) (short) -1, (long) '4', 10);
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        long long10 = durationField7.subtract(99L, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 519L + "'", long6 == 519L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-255139199901L) + "'", long10 == (-255139199901L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        java.lang.Class<?> wildcardClass4 = period3.getClass();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds7 = period6.toStandardSeconds();
        org.joda.time.Period period8 = period3.withFields((org.joda.time.ReadablePeriod) seconds7);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(seconds7);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(10L, false);
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) 100L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-90L) + "'", long9 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((-1L), 2, (int) (short) 100, (-2), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(6048000000L, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfDay();
        long long13 = gregorianChronology7.add((long) (short) -1, (long) '4', 10);
        org.joda.time.DurationField durationField14 = gregorianChronology7.seconds();
        boolean boolean15 = periodType6.equals((java.lang.Object) gregorianChronology7);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 519L + "'", long13 == 519L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        try {
            int int28 = unsupportedDurationField24.getValue((-259200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.plusMinutes(0);
        org.joda.time.Duration duration4 = period1.toStandardDuration();
        org.joda.time.Period period6 = period1.minusHours((-1));
        org.joda.time.Period period8 = period1.minusYears((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        try {
            int int26 = unsupportedDateTimeField24.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.minusYears(35);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        try {
            long long23 = dividedDateTimeField21.roundHalfEven(1560629279853L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.minusDays((int) (short) 1);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) (short) 1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        int int12 = offsetDateTimeField5.getDifference((-100L), (long) 0);
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) offsetDateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        org.joda.time.DurationField durationField25 = scaledDurationField24.getWrappedField();
        long long28 = scaledDurationField24.getMillis(0L, (long) (byte) 1);
        int int31 = scaledDurationField24.getDifference((long) (byte) 1, (-604800000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 97);
        boolean boolean13 = offsetDateTimeField12.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        int int24 = dividedDateTimeField21.getDivisor();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.hourOfDay();
        org.joda.time.DurationField durationField28 = gregorianChronology26.years();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 1);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.Period period34 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds35 = period34.toStandardSeconds();
        int[] intArray36 = period34.getValues();
        int int37 = offsetDateTimeField31.getMinimumValue(readablePartial32, intArray36);
        int int38 = dividedDateTimeField21.getMinimumValue(readablePartial25, intArray36);
        try {
            long long40 = dividedDateTimeField21.roundCeiling((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 97 + "'", int24 == 97);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(seconds35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ');
        long long7 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period4, (long) '#', (int) (byte) 10);
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 355L + "'", long7 == 355L);
        org.junit.Assert.assertNotNull(duration8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        try {
            long long23 = dividedDateTimeField21.roundFloor((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long20 = fixedDateTimeZone17.convertLocalToUTC((long) (byte) 100, true);
        long long23 = fixedDateTimeZone17.adjustOffset((long) 10, true);
        org.joda.time.Chronology chronology24 = zonedChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        java.lang.String str25 = zonedChronology12.toString();
        org.joda.time.DurationField durationField26 = zonedChronology12.years();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str25.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        long long9 = offsetDateTimeField5.roundCeiling(1560629294707L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560729600000L + "'", long9 == 1560729600000L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.subtract(0L, (int) (byte) 100);
        int int35 = scaledDurationField24.getValue(2L, (long) (short) 1);
        long long38 = scaledDurationField24.getValueAsLong(259200000L, (long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3144960000000L) + "'", long32 == (-3144960000000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 10, (long) '4');
        java.lang.String str3 = period2.toString();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period8 = period6.minusDays((-1));
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period2.withPeriodType(periodType9);
        int int11 = period10.getMillis();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT0.042S" + "'", str3.equals("PT0.042S"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 42 + "'", int11 == 42);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(100);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("DurationField[hours]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DurationField[hours]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 10);
        int int2 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 2, true);
        long long9 = fixedDateTimeZone4.convertUTCToLocal((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 200L + "'", long9 == 200L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "DurationField[hours]");
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        java.lang.String str11 = illegalFieldValueException9.getIllegalStringValue();
        java.lang.Throwable[] throwableArray12 = illegalFieldValueException9.getSuppressed();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DurationField[hours]" + "'", str11.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.Period period4 = period1.plusDays((int) (short) -1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("+00:00:00.052", (int) (short) 10, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for +00:00:00.052 must be in the range [97,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 100, true);
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) (byte) -1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(6048000000L, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withYearsRemoved();
        java.lang.String str7 = periodType3.getName();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Hours" + "'", str7.equals("Hours"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.weekyears();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.Period period31 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period32 = period31.normalizedStandard();
        int[] intArray34 = gregorianChronology27.get((org.joda.time.ReadablePeriod) period32, (long) 1);
        java.util.Locale locale36 = null;
        try {
            int[] intArray37 = unsupportedDateTimeField24.set(readablePartial25, (int) (short) -1, intArray34, "+00:00:00.052", locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period3.indexOf(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.get(durationFieldType6);
        org.joda.time.Period period9 = period3.plusMonths((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-2), (int) '#', (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period((-8151736319999999965L), (-1L), periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 8151736319999999");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Seconds seconds5 = period3.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(seconds5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = unsupportedDateTimeField24.getAsShortText((int) '#', locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        int[] intArray3 = period1.getValues();
        org.joda.time.Period period5 = period1.minusSeconds((-2));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            int int15 = unsupportedDurationField11.getDifference(31449600000L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.util.TimeZone timeZone13 = fixedDateTimeZone11.toTimeZone();
        long long16 = fixedDateTimeZone11.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance(chronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.era();
        int int21 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-90L) + "'", long16 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (byte) -1, 42, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [42,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) (byte) -1, (java.lang.Number) 259200035L, (java.lang.Number) (byte) -1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (short) -1, 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [0,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = periodType3.isSupported(durationFieldType5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfDay();
        org.joda.time.Period period10 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period11 = new org.joda.time.Period((-20L), (-259079000L), periodType3);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period11.toDurationTo(readableInstant12);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(duration13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(100);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        try {
            int int28 = unsupportedDateTimeField24.getMaximumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 10, (long) '4');
        java.lang.String str3 = period2.toString();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period8 = period6.minusDays((-1));
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period2.withPeriodType(periodType9);
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = period10.toString(periodFormatter11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT0.042S" + "'", str3.equals("PT0.042S"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT0.042S" + "'", str12.equals("PT0.042S"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            boolean boolean26 = unsupportedDateTimeField24.isLeap((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "2", 0, 2);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PT0H");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        java.lang.String str6 = periodType4.toString();
        org.joda.time.PeriodType periodType7 = periodType4.withSecondsRemoved();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.util.TimeZone timeZone16 = fixedDateTimeZone14.toTimeZone();
        long long19 = fixedDateTimeZone14.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Period period23 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period25 = period23.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        boolean boolean28 = iSOChronology21.equals((java.lang.Object) durationFieldType26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long36 = fixedDateTimeZone33.adjustOffset((long) 10, false);
        boolean boolean38 = fixedDateTimeZone33.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology39 = iSOChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.Period period40 = new org.joda.time.Period(6048000000L, (-604800000L), periodType7, (org.joda.time.Chronology) iSOChronology21);
        java.lang.String str41 = iSOChronology21.toString();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology21.dayOfMonth();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[Hours]" + "'", str6.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-90L) + "'", long19 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[]" + "'", str41.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField24.getAsText((long) (byte) 10, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period(1L);
        int[] intArray18 = gregorianChronology12.get((org.joda.time.ReadablePeriod) period15, (-1L), (-1L));
        try {
            int[] intArray20 = offsetDateTimeField5.set(readablePartial10, (int) 'a', intArray18, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(97);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        try {
            long long29 = unsupportedDateTimeField24.remainder(1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.withHours((int) (byte) -1);
        org.joda.time.Period period4 = period0.plusHours((int) '4');
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        try {
            org.joda.time.DurationFieldType durationFieldType5 = period1.getFieldType((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 1);
        org.joda.time.DurationField durationField7 = offsetDateTimeField6.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField6.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "DurationField[hours]");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, 2, (-1), (int) ' ');
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long9 = gregorianChronology3.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType2, (org.joda.time.Chronology) gregorianChronology3);
        try {
            org.joda.time.Period period13 = period11.withMonths(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        long long12 = offsetDateTimeField5.addWrapField(355L, 52);
        int int13 = offsetDateTimeField5.getOffset();
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 0, 0, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31449600355L + "'", long12 == 31449600355L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long6 = gregorianChronology0.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        try {
            int int28 = unsupportedDateTimeField24.get((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.Period period5 = period3.plusDays((int) (byte) 10);
        org.joda.time.Period period7 = period5.plusYears((int) (short) 1);
        try {
            int int9 = period7.getValue((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.util.TimeZone timeZone13 = fixedDateTimeZone11.toTimeZone();
        long long16 = fixedDateTimeZone11.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance(chronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-90L) + "'", long16 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) ' ', false, 1L);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(31795200000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-20L) + "'", long8 == (-20L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        try {
            long long30 = dividedDateTimeField21.set(31449600001L, 42);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for weekOfWeekyear must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        long long5 = dateTimeZone2.getMillisKeepLocal(dateTimeZone3, 345600000L);
        java.lang.String str6 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 339899948L + "'", long5 == 339899948L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-01:35" + "'", str6.equals("-01:35"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            int int15 = unsupportedDurationField11.getValue((-98L), (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes8 = period7.toStandardMinutes();
        org.joda.time.Period period10 = period7.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period7.getFieldTypes();
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period14 = period12.minusMonths(35);
        org.joda.time.Period period16 = period12.minusSeconds(2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        org.joda.time.DurationField durationField8 = null;
        org.joda.time.DurationField durationField9 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField10 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType7, durationField8, durationField9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        boolean boolean7 = offsetDateTimeField5.isSupported();
        java.lang.Class<?> wildcardClass8 = offsetDateTimeField5.getClass();
        int int11 = offsetDateTimeField5.getDifference((-31449599948L), (long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-52) + "'", int11 == (-52));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, 0L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology2.getZone();
        org.joda.time.DurationField durationField8 = gregorianChronology2.days();
        try {
            long long16 = gregorianChronology2.getDateTimeMillis((int) (byte) 1, (int) '#', 35, (int) (byte) 100, 0, 2, (-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        boolean boolean23 = offsetDateTimeField5.isLeap(0L);
        org.joda.time.DurationField durationField24 = offsetDateTimeField5.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) -1, (-97), (int) '#', (int) (byte) 1, (int) (byte) 0, (int) (byte) 100, (-97), 97);
        int int9 = period8.getDays();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        try {
            long long28 = unsupportedDurationField24.getMillis(34947);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        java.lang.String str4 = periodType3.toString();
        org.joda.time.PeriodType periodType5 = periodType3.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[Hours]" + "'", str4.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long9 = gregorianChronology3.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-2), 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        java.lang.String str14 = zonedChronology12.toString();
        org.joda.time.Chronology chronology15 = zonedChronology12.withUTC();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        long long30 = scaledDurationField24.getDifferenceAsLong((long) (byte) 10, (-31449600000L));
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType32 = periodType31.withMillisRemoved();
        try {
            org.joda.time.Period period33 = new org.joda.time.Period((java.lang.Object) (-31449600000L), periodType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        long long12 = offsetDateTimeField5.addWrapField(355L, 52);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField5.getMaximumShortTextLength(locale13);
        long long16 = offsetDateTimeField5.roundCeiling((-2L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31449600355L + "'", long12 == 31449600355L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 345600000L + "'", long16 == 345600000L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray11 = null;
        java.util.Locale locale13 = null;
        try {
            int[] intArray14 = offsetDateTimeField5.set(readablePartial9, (int) 'a', intArray11, "DateTimeField[weekOfWeekyear]", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[weekOfWeekyear]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, (int) '#');
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.PeriodType periodType7 = periodType6.withYearsRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.PeriodType periodType9 = periodType6.withMinutesRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = iSOChronology10.years();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) (byte) -1, periodType9, (org.joda.time.Chronology) iSOChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        java.util.Locale locale27 = null;
        try {
            long long28 = unsupportedDateTimeField24.set((long) (short) 100, "UnsupportedDateTimeField", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period3.indexOf(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.get(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period3.get(durationFieldType8);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period12 = new org.joda.time.Period(10L, periodType11);
        org.joda.time.PeriodType periodType13 = periodType11.withMonthsRemoved();
        try {
            org.joda.time.Period period14 = period3.withPeriodType(periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period15 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        boolean boolean20 = iSOChronology13.equals((java.lang.Object) durationFieldType18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long28 = fixedDateTimeZone25.adjustOffset((-100L), true);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone25.getName((long) (byte) 10, locale30);
        org.joda.time.Chronology chronology32 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        java.util.Locale locale34 = null;
        java.lang.String str35 = fixedDateTimeZone25.getName((-20L), locale34);
        java.lang.String str37 = fixedDateTimeZone25.getNameKey((long) 94);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-100L) + "'", long28 == (-100L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.052" + "'", str35.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        int int4 = periodType2.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period4 = period2.minusWeeks((int) (short) 10);
        org.joda.time.Period period6 = period4.minusWeeks((int) (short) 100);
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology24.years();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 1);
        org.joda.time.DurationField durationField30 = offsetDateTimeField29.getLeapDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText((int) 'a', locale32);
        long long35 = offsetDateTimeField29.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType43, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField47);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType43);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.hourOfDay();
        org.joda.time.DurationField durationField52 = gregorianChronology50.years();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology50.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 1);
        java.lang.String str57 = offsetDateTimeField55.getAsText((long) 52);
        org.joda.time.DurationField durationField58 = offsetDateTimeField55.getDurationField();
        long long61 = durationField58.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType64 = periodType63.withYearsRemoved();
        org.joda.time.PeriodType periodType65 = org.joda.time.DateTimeUtils.getPeriodType(periodType63);
        org.joda.time.PeriodType periodType66 = periodType65.withYearsRemoved();
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) -1, periodType65);
        org.joda.time.PeriodType periodType68 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType70 = periodType68.getFieldType((int) (short) 0);
        org.joda.time.Period period72 = period67.withField(durationFieldType70, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField74 = new org.joda.time.field.ScaledDurationField(durationField58, durationFieldType70, 52);
        java.lang.String str75 = scaledDurationField74.toString();
        long long77 = scaledDurationField74.getValueAsLong(6047999952L);
        boolean boolean79 = scaledDurationField74.equals((java.lang.Object) 97L);
        long long82 = scaledDurationField74.add((long) '#', (-259200000L));
        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField84 = gregorianChronology83.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField85 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType43, (org.joda.time.DurationField) scaledDurationField74, durationField84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259200000L) + "'", long35 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2" + "'", str57.equals("2"));
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 10L + "'", long61 == 10L);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(periodType66);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertNotNull(durationFieldType70);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "DurationField[hours]" + "'", str75.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-8151736319999999965L) + "'", long82 == (-8151736319999999965L));
        org.junit.Assert.assertNotNull(gregorianChronology83);
        org.junit.Assert.assertNotNull(durationField84);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, 97);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField12.getAsText((long) (short) -1, locale14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "99" + "'", str15.equals("99"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period3, (-1L), (-1L));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, periodType10);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = period12.withField(durationFieldType15, (int) (short) -1);
        org.joda.time.Period period19 = period3.withFieldAdded(durationFieldType15, (int) (short) 100);
        org.joda.time.Period period21 = period3.plusYears((int) (byte) 10);
        org.joda.time.PeriodType periodType22 = period3.getPeriodType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.remainder((long) '#');
        int int14 = offsetDateTimeField5.getMaximumValue((long) 96);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200035L + "'", long12 == 259200035L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 54 + "'", int14 == 54);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (-52), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-52) + "'", int3 == (-52));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            int int25 = unsupportedDateTimeField24.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        boolean boolean28 = unsupportedDurationField11.isSupported();
        try {
            long long30 = unsupportedDurationField11.getMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 0, 259200035L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundCeiling(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial10);
        long long13 = offsetDateTimeField5.roundHalfFloor((-151L));
        long long15 = offsetDateTimeField5.roundHalfCeiling((long) (short) 0);
        long long17 = offsetDateTimeField5.roundHalfFloor((-90L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 345600000L + "'", long9 == 345600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200000L) + "'", long17 == (-259200000L));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.remainder((long) '#');
        long long14 = offsetDateTimeField5.roundCeiling(100L);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.hourOfDay();
        org.joda.time.DurationField durationField17 = gregorianChronology15.years();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField20.getLeapDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField20.getAsShortText((int) 'a', locale23);
        long long26 = offsetDateTimeField20.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.hourOfDay();
        org.joda.time.DurationField durationField29 = gregorianChronology27.years();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1);
        org.joda.time.DurationField durationField33 = offsetDateTimeField32.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField32.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType34, (int) 'a');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType34, 35);
        int int40 = dividedDateTimeField38.get((long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200035L + "'", long12 == 259200035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345600000L + "'", long14 == 345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        org.joda.time.Chronology chronology14 = zonedChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology12.yearOfCentury();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.millisOfSecond();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 52, periodType1, (org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.util.TimeZone timeZone13 = fixedDateTimeZone11.toTimeZone();
        long long16 = fixedDateTimeZone11.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance(chronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone20 = zonedChronology19.getZone();
        try {
            long long25 = zonedChronology19.getDateTimeMillis(35, 96, (int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-90L) + "'", long16 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        try {
            long long33 = dividedDateTimeField21.set((-31449600000L), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.plusMinutes(0);
        org.joda.time.Period period5 = period1.multipliedBy((int) '4');
        org.joda.time.Period period7 = period5.withMonths((-2));
        org.joda.time.Days days8 = period5.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(days8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundCeiling(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial10);
        long long13 = offsetDateTimeField5.roundHalfFloor((-151L));
        long long15 = offsetDateTimeField5.roundCeiling((long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 345600000L + "'", long9 == 345600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345600000L + "'", long15 == 345600000L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        try {
            long long30 = dividedDateTimeField21.addWrapField((long) 10, 34947);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        try {
            long long33 = dividedDateTimeField21.set((long) (-1), 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for weekOfWeekyear must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 1);
        org.joda.time.Period period3 = period1.plusMonths(100);
        org.joda.time.Period period5 = period1.minusMillis(100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundHalfFloor(1L);
        try {
            long long12 = offsetDateTimeField5.set(6048000000L, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        long long30 = remainderDateTimeField28.roundFloor((-2L));
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.hourOfDay();
        org.joda.time.Period period36 = new org.joda.time.Period(1L);
        int[] intArray39 = gregorianChronology33.get((org.joda.time.ReadablePeriod) period36, (-1L), (-1L));
        try {
            int[] intArray41 = remainderDateTimeField28.add(readablePartial31, (int) (short) 100, intArray39, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-259200000L) + "'", long30 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.plusMinutes(0);
        org.joda.time.Period period5 = period3.multipliedBy(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            long long15 = unsupportedDurationField11.getMillis((int) (short) 1, (-100L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.Period period4 = new org.joda.time.Period(35000L, (long) 0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Hours hours5 = period4.toStandardHours();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(hours5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (short) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName((long) (short) -1, locale11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.monthOfYear();
        org.joda.time.Period period17 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period19 = period17.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period17.get(durationFieldType20);
        org.joda.time.Period period23 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes24 = period23.toStandardMinutes();
        org.joda.time.Period period26 = period23.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray27 = period23.getFieldTypes();
        org.joda.time.Period period28 = period17.withFields((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period30 = period28.minusMonths(35);
        org.joda.time.Period period32 = period28.withMillis(35);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.Period period34 = period28.withFields(readablePeriod33);
        org.joda.time.Period period36 = period34.withSeconds(4);
        org.joda.time.PeriodType periodType37 = period36.getPeriodType();
        boolean boolean38 = iSOChronology13.equals((java.lang.Object) periodType37);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(minutes24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldTypeArray27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.plusMillis((int) '4');
        org.joda.time.Period period8 = period6.withYears((int) (short) 100);
        try {
            org.joda.time.Minutes minutes9 = period8.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period7 = period5.plusMinutes((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) (byte) 10);
        org.joda.time.Period period10 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType12 = periodType11.withMonthsRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withSecondsRemoved();
        org.joda.time.Period period14 = period7.normalizedStandard(periodType13);
        int int15 = period14.getDays();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-6) + "'", int15 == (-6));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder((-255139199901L));
        long long28 = dividedDateTimeField21.getDifferenceAsLong(6048000000L, (long) '#');
        try {
            long long30 = dividedDateTimeField21.roundHalfEven(32L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-255139199901L) + "'", long25 == (-255139199901L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField24.getName();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hours" + "'", str27.equals("hours"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = gregorianChronology0.get(readablePartial3, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        long long27 = scaledDurationField24.getValueAsLong(1560629294707L, 1560629279853L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 49L + "'", long27 == 49L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT0H");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT0H' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        try {
            long long28 = unsupportedDateTimeField24.roundHalfEven((-59137603200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2", (java.lang.Number) (-10L), (java.lang.Number) 58665599910L, (java.lang.Number) 31449600000L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(58665599849L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2441266.4999982524d + "'", double1 == 2441266.4999982524d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period5 = period3.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.weeks();
        java.lang.String str9 = periodType8.toString();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType8);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.millisOfSecond();
        long long25 = gregorianChronology16.getDateTimeMillis((-259200000L), 0, 2, 1, (int) (short) 0);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 100, (long) '4', periodType13, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType13);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PeriodType[Weeks]" + "'", str9.equals("PeriodType[Weeks]"));
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-259079000L) + "'", long25 == (-259079000L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType1.isSupported(durationFieldType3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, periodType1, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.months();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            long long12 = gregorianChronology5.set(readablePartial10, (long) 42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMinutes((int) (byte) 10);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        boolean boolean10 = period1.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        java.lang.String str2 = periodType1.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[Hours]" + "'", str2.equals("PeriodType[Hours]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long9 = gregorianChronology3.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.PeriodType periodType12 = periodType2.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        java.lang.String str6 = periodType4.toString();
        org.joda.time.PeriodType periodType7 = periodType4.withSecondsRemoved();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.util.TimeZone timeZone16 = fixedDateTimeZone14.toTimeZone();
        long long19 = fixedDateTimeZone14.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Period period23 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period25 = period23.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        boolean boolean28 = iSOChronology21.equals((java.lang.Object) durationFieldType26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long36 = fixedDateTimeZone33.adjustOffset((long) 10, false);
        boolean boolean38 = fixedDateTimeZone33.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology39 = iSOChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.Period period40 = new org.joda.time.Period(6048000000L, (-604800000L), periodType7, (org.joda.time.Chronology) iSOChronology21);
        java.lang.String str41 = iSOChronology21.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.hourOfDay();
        org.joda.time.DurationField durationField44 = gregorianChronology42.years();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology42.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 1);
        org.joda.time.DurationField durationField48 = offsetDateTimeField47.getLeapDurationField();
        java.util.Locale locale50 = null;
        java.lang.String str51 = offsetDateTimeField47.getAsShortText((int) 'a', locale50);
        long long53 = offsetDateTimeField47.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.hourOfDay();
        org.joda.time.DurationField durationField56 = gregorianChronology54.years();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology54.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 1);
        org.joda.time.DurationField durationField60 = offsetDateTimeField59.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField59.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField47, dateTimeFieldType61, (int) 'a');
        long long65 = dividedDateTimeField63.remainder((long) 97);
        long long67 = dividedDateTimeField63.remainder(31449600000L);
        java.lang.String str68 = dividedDateTimeField63.getName();
        int int69 = dividedDateTimeField63.getMinimumValue();
        long long72 = dividedDateTimeField63.getDifferenceAsLong((-43286400000L), 0L);
        java.lang.String str73 = dividedDateTimeField63.toString();
        long long76 = dividedDateTimeField63.add((-151L), (long) (short) 1);
        boolean boolean77 = iSOChronology21.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[Hours]" + "'", str6.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-90L) + "'", long19 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[]" + "'", str41.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "97" + "'", str51.equals("97"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-259200000L) + "'", long53 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 97L + "'", long65 == 97L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 31449600000L + "'", long67 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "weekOfWeekyear" + "'", str68.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str73.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 58665599849L + "'", long76 == 58665599849L);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period7 = period5.plusMinutes((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) (byte) 10);
        org.joda.time.Period period10 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType12 = periodType11.withMonthsRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withSecondsRemoved();
        org.joda.time.Period period14 = period7.normalizedStandard(periodType13);
        try {
            int int16 = period7.getValue(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        boolean boolean9 = offsetDateTimeField5.isLeap((long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long12 = offsetDateTimeField5.add((long) (short) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField5.getWrappedField();
        long long15 = offsetDateTimeField5.roundHalfFloor(6048000000L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsText((int) (short) 100, locale17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5788800000L + "'", long15 == 5788800000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        try {
            long long27 = unsupportedDateTimeField24.set(4838400002L, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        try {
            long long30 = unsupportedDurationField11.getMillis(0L, 19612800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("PeriodType[Weeks]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PeriodType[Weeks]\" is malformed at \"eriodType[Weeks]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        org.joda.time.ReadablePartial readablePartial27 = null;
        try {
            int int28 = unsupportedDateTimeField24.getMinimumValue(readablePartial27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long9 = offsetDateTimeField5.roundCeiling(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.hourOfDay();
        org.joda.time.DurationField durationField13 = gregorianChronology11.years();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 1);
        org.joda.time.DurationField durationField17 = offsetDateTimeField16.getLeapDurationField();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText((int) 'a', locale19);
        long long22 = offsetDateTimeField16.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.hourOfDay();
        org.joda.time.DurationField durationField25 = gregorianChronology23.years();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 1);
        org.joda.time.DurationField durationField29 = offsetDateTimeField28.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType30, (int) 'a');
        long long34 = dividedDateTimeField32.remainder((long) 97);
        int int35 = dividedDateTimeField32.getDivisor();
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.hourOfDay();
        org.joda.time.DurationField durationField39 = gregorianChronology37.years();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, 1);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.Period period45 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds46 = period45.toStandardSeconds();
        int[] intArray47 = period45.getValues();
        int int48 = offsetDateTimeField42.getMinimumValue(readablePartial43, intArray47);
        int int49 = dividedDateTimeField32.getMinimumValue(readablePartial36, intArray47);
        int int50 = offsetDateTimeField5.getMaximumValue(readablePartial10, intArray47);
        long long53 = offsetDateTimeField5.add(33L, (long) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 345600000L + "'", long9 == 345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200000L) + "'", long22 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 97 + "'", int35 == 97);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(seconds46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 54 + "'", int50 == 54);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 6048000033L + "'", long53 == 6048000033L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ISOChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ISOChronology[]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        long long17 = fixedDateTimeZone12.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long20 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone12, (long) (short) 100);
        boolean boolean21 = fixedDateTimeZone12.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-90L) + "'", long17 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.hourOfDay();
        org.joda.time.DurationField durationField8 = gregorianChronology6.years();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.weekOfWeekyear();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology6);
        try {
            org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) periodType2, periodType5, (org.joda.time.Chronology) lenientChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        java.lang.String str14 = zonedChronology12.toString();
        org.joda.time.DurationField durationField15 = zonedChronology12.months();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((long) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getLeapDurationField();
        try {
            long long13 = offsetDateTimeField5.set((-20L), "DateTimeField[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[weekOfWeekyear]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ZonedChronology[ISOChronology[UTC], ]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ZonedChronology[ISOChronology[UTC], ]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMillisRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period((-259079000L), 5788800000L, periodType5);
        try {
            org.joda.time.Minutes minutes7 = period6.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsShortText((long) (byte) 0);
        long long10 = offsetDateTimeField5.set(100L, "2");
        long long12 = offsetDateTimeField5.remainder((long) '#');
        long long14 = offsetDateTimeField5.roundCeiling(100L);
        int int16 = offsetDateTimeField5.get(259200035L);
        try {
            long long19 = offsetDateTimeField5.add(519L, 58665599849L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 58665599849 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200035L + "'", long12 == 259200035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 345600000L + "'", long14 == 345600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.plusMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.hourOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology7.years();
        org.joda.time.Period period11 = new org.joda.time.Period((long) ' ');
        long long14 = gregorianChronology7.add((org.joda.time.ReadablePeriod) period11, (long) '#', (int) (byte) 10);
        org.joda.time.Period period16 = period11.minusMinutes((int) (short) 100);
        org.joda.time.Period period17 = period1.plus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period19 = period17.minusMillis((int) (short) 0);
        int int20 = period17.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 355L + "'", long14 == 355L);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-100) + "'", int20 == (-100));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        java.util.TimeZone timeZone12 = fixedDateTimeZone10.toTimeZone();
        long long15 = fixedDateTimeZone10.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int18 = fixedDateTimeZone10.getOffsetFromLocal((-1L));
        int int20 = fixedDateTimeZone10.getOffsetFromLocal((long) (short) 1);
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone28 = fixedDateTimeZone27.toTimeZone();
        java.util.TimeZone timeZone29 = fixedDateTimeZone27.toTimeZone();
        long long32 = fixedDateTimeZone27.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance(chronology22, (org.joda.time.DateTimeZone) fixedDateTimeZone27);
        long long35 = fixedDateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone27, 2L);
        org.joda.time.Chronology chronology36 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-90L) + "'", long15 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-90L) + "'", long32 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period3, (-1L), (-1L));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, periodType10);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = period12.withField(durationFieldType15, (int) (short) -1);
        org.joda.time.Period period19 = period3.withFieldAdded(durationFieldType15, (int) (short) 100);
        int int20 = period19.getMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        org.joda.time.DurationField durationField26 = unsupportedDateTimeField24.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = gregorianChronology29.weekyears();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.hourOfDay();
        org.joda.time.Period period33 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period34 = period33.normalizedStandard();
        int[] intArray36 = gregorianChronology29.get((org.joda.time.ReadablePeriod) period34, (long) 1);
        java.util.Locale locale38 = null;
        try {
            int[] intArray39 = unsupportedDateTimeField24.set(readablePartial27, (int) (short) 10, intArray36, "2", locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.Period period7 = new org.joda.time.Period((long) ' ');
        long long10 = gregorianChronology3.add((org.joda.time.ReadablePeriod) period7, (long) '#', (int) (byte) 10);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.PeriodType periodType12 = periodType2.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 355L + "'", long10 == 355L);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-2), "PT0.042S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        org.joda.time.Period period26 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period28 = period26.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period26.get(durationFieldType29);
        org.joda.time.Period period32 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes33 = period32.toStandardMinutes();
        org.joda.time.Period period35 = period32.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray36 = period32.getFieldTypes();
        org.joda.time.Period period37 = period26.withFields((org.joda.time.ReadablePeriod) period32);
        org.joda.time.Period period39 = period37.minusMonths(35);
        org.joda.time.Period period41 = period37.withMillis(35);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.Period period43 = period37.withFields(readablePeriod42);
        int int44 = period43.getHours();
        org.joda.time.Period period46 = period43.minusMinutes((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.hourOfDay();
        org.joda.time.DurationField durationField49 = gregorianChronology47.years();
        org.joda.time.Period period51 = new org.joda.time.Period((long) ' ');
        long long54 = gregorianChronology47.add((org.joda.time.ReadablePeriod) period51, (long) '#', (int) (byte) 10);
        org.joda.time.Period period56 = period51.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType58 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType59 = periodType58.withYearsRemoved();
        org.joda.time.PeriodType periodType60 = org.joda.time.DateTimeUtils.getPeriodType(periodType58);
        org.joda.time.PeriodType periodType61 = periodType60.withYearsRemoved();
        org.joda.time.Period period62 = new org.joda.time.Period((long) (short) -1, periodType60);
        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType65 = periodType63.getFieldType((int) (short) 0);
        org.joda.time.Period period67 = period62.withField(durationFieldType65, (int) (short) -1);
        boolean boolean68 = period56.isSupported(durationFieldType65);
        org.joda.time.Period period70 = period43.withField(durationFieldType65, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField72 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType65, 42);
        long long75 = scaledDurationField72.getDifferenceAsLong((long) (-52), 32L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(minutes33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldTypeArray36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 355L + "'", long54 == 355L);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(periodType60);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(durationFieldType65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, (-1L));
        org.joda.time.Period period4 = period2.minusDays((-1));
        org.joda.time.PeriodType periodType5 = period4.getPeriodType();
        org.joda.time.Hours hours6 = period4.toStandardHours();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(hours6);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField24.getRangeDurationField();
        try {
            int int30 = unsupportedDateTimeField24.getLeapAmount(19612800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Period period11 = new org.joda.time.Period((int) (short) 1, (int) (byte) 10, (int) (short) 1, (int) (short) 1, (int) 'a', (int) (short) 100, 10, 100);
        org.joda.time.Period period13 = period11.plusDays((int) '4');
        int[] intArray16 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period11, 0L, 519L);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period11.toDurationTo(readableInstant17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(duration18);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        long long8 = gregorianChronology1.add((org.joda.time.ReadablePeriod) period5, (long) '#', (int) (byte) 10);
        org.joda.time.Period period10 = period5.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType13 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) -1, periodType14);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (short) 0);
        org.joda.time.Period period21 = period16.withField(durationFieldType19, (int) (short) -1);
        boolean boolean22 = period10.isSupported(durationFieldType19);
        boolean boolean23 = periodType0.isSupported(durationFieldType19);
        org.joda.time.PeriodType periodType24 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 355L + "'", long8 == 355L);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.plusMinutes(0);
        org.joda.time.Duration duration4 = period1.toStandardDuration();
        org.joda.time.Period period6 = period1.minusHours((-1));
        org.joda.time.Period period8 = period1.minusSeconds((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        boolean boolean26 = unsupportedDateTimeField24.isLenient();
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = unsupportedDateTimeField24.getAsShortText(49, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int14 = fixedDateTimeZone6.getOffsetFromLocal((-1L));
        int int16 = fixedDateTimeZone6.getOffsetFromLocal((long) (short) 1);
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone24 = fixedDateTimeZone23.toTimeZone();
        java.util.TimeZone timeZone25 = fixedDateTimeZone23.toTimeZone();
        long long28 = fixedDateTimeZone23.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        long long31 = fixedDateTimeZone6.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone23, 2L);
        int int33 = fixedDateTimeZone6.getOffsetFromLocal(6048000033L);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-90L) + "'", long28 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-99L), (long) (-100));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        try {
            java.lang.String str29 = unsupportedDateTimeField24.getAsText((long) (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        org.joda.time.DurationField durationField25 = scaledDurationField24.getWrappedField();
        long long28 = scaledDurationField24.getMillis(10, (-20L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 314496000000L + "'", long28 == 314496000000L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType4 = period3.getPeriodType();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType7 = periodType6.withYearsRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = periodType6.isSupported(durationFieldType8);
        org.joda.time.PeriodType periodType10 = periodType6.withYearsRemoved();
        org.joda.time.Period period11 = period5.normalizedStandard(periodType10);
        try {
            org.joda.time.Period period13 = period11.minusSeconds((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        long long6 = gregorianChronology0.add((long) (short) -1, (long) '4', 10);
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 519L + "'", long6 == 519L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        boolean boolean26 = unsupportedDateTimeField24.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.hourOfDay();
        org.joda.time.DurationField durationField29 = gregorianChronology27.years();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1);
        org.joda.time.DurationField durationField33 = offsetDateTimeField32.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField32.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, "DurationField[hours]");
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType34, 2, (-1), (int) ' ');
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField24, dateTimeFieldType34, (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 0, 0L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField6 = gregorianChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Period period1 = org.joda.time.Period.days(94);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        boolean boolean27 = unsupportedDurationField11.isSupported();
        try {
            long long30 = unsupportedDurationField11.getValueAsLong(52L, (long) 54);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("PT0H", false);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder0.toDateTimeZone("99", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.100", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.100/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(58665599849L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.Period period6 = period1.plusMillis((int) '4');
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Period period9 = period6.withField(durationFieldType7, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        int int6 = offsetDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long8 = fixedDateTimeZone5.convertLocalToUTC((long) (byte) 100, true);
        long long11 = fixedDateTimeZone5.adjustOffset((long) 10, true);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone5.getShortName((-99L), locale13);
        boolean boolean15 = fixedDateTimeZone5.isFixed();
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.100" + "'", str14.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.ReadableInterval readableInterval14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone21 = fixedDateTimeZone20.toTimeZone();
        java.util.TimeZone timeZone22 = fixedDateTimeZone20.toTimeZone();
        long long25 = fixedDateTimeZone20.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long34 = fixedDateTimeZone31.convertLocalToUTC((long) (byte) 100, true);
        long long37 = fixedDateTimeZone31.adjustOffset((long) 10, true);
        org.joda.time.Chronology chronology38 = zonedChronology26.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        long long40 = fixedDateTimeZone31.convertUTCToLocal(0L);
        java.util.TimeZone timeZone41 = fixedDateTimeZone31.toTimeZone();
        org.joda.time.Chronology chronology42 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-90L) + "'", long25 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(chronology42);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        java.lang.String str6 = periodType4.toString();
        org.joda.time.PeriodType periodType7 = periodType4.withSecondsRemoved();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.util.TimeZone timeZone16 = fixedDateTimeZone14.toTimeZone();
        long long19 = fixedDateTimeZone14.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Period period23 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period25 = period23.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        boolean boolean28 = iSOChronology21.equals((java.lang.Object) durationFieldType26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long36 = fixedDateTimeZone33.adjustOffset((long) 10, false);
        boolean boolean38 = fixedDateTimeZone33.isStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology39 = iSOChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.Period period40 = new org.joda.time.Period(6048000000L, (-604800000L), periodType7, (org.joda.time.Chronology) iSOChronology21);
        java.lang.String str41 = iSOChronology21.toString();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology21.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[Hours]" + "'", str6.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-90L) + "'", long19 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[]" + "'", str41.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2", false);
        int int5 = dateTimeZone3.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long26 = dividedDateTimeField21.getDifferenceAsLong(314496000000L, (long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, (-1), 49, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        try {
            long long24 = offsetDateTimeField5.set(0L, "0");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        org.joda.time.ReadablePartial readablePartial27 = null;
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = unsupportedDateTimeField24.getAsText(readablePartial27, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField24.getRangeDurationField();
        try {
            long long30 = unsupportedDateTimeField24.roundHalfCeiling(31190400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.Period period29 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds30 = period29.toStandardSeconds();
        int[] intArray31 = period29.getValues();
        try {
            int[] intArray33 = unsupportedDateTimeField24.add(readablePartial26, 10, intArray31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(seconds30);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 1, "");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        try {
            long long30 = unsupportedDurationField11.getValueAsLong(3050611200000L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        long long32 = dividedDateTimeField21.remainder(1560729600000L);
        int int35 = dividedDateTimeField21.getDifference((long) 4, (-1L));
        try {
            long long38 = dividedDateTimeField21.add((-59137603200000L), (-3144960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -305061120000000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560729600000L + "'", long32 == 1560729600000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology24.years();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 1);
        org.joda.time.DurationField durationField30 = offsetDateTimeField29.getLeapDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText((int) 'a', locale32);
        long long35 = offsetDateTimeField29.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType43, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField47);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 1560629279853L, (java.lang.Number) 0L, (java.lang.Number) (-20L));
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 35L, "97");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259200000L) + "'", long35 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        boolean boolean31 = dividedDateTimeField21.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField24.getRangeDurationField();
        java.util.Locale locale29 = null;
        try {
            int int30 = unsupportedDateTimeField24.getMaximumShortTextLength(locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.joda.time.Period period7 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes8 = period7.toStandardMinutes();
        org.joda.time.Period period10 = period7.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period7.getFieldTypes();
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period14 = period1.minusMillis((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (short) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName((long) (short) -1, locale11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.clockhourOfDay();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period1.toDurationTo(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.Hours hours8 = period7.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(hours8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling(31795200000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = remainderDateTimeField28.getType();
        int int34 = remainderDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31795200000L + "'", long32 == 31795200000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        int int4 = period3.getHours();
        org.joda.time.Period period6 = period3.minusMonths(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        java.lang.String str30 = unsupportedDateTimeField24.getName();
        try {
            long long33 = unsupportedDateTimeField24.addWrapField((long) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "weekOfWeekyear" + "'", str30.equals("weekOfWeekyear"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.junit.Assert.assertNotNull(period0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.hourOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology13.years();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 1);
        java.lang.String str20 = offsetDateTimeField18.getAsShortText((long) (byte) 0);
        long long22 = offsetDateTimeField18.roundCeiling(0L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology24.years();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 1);
        org.joda.time.DurationField durationField30 = offsetDateTimeField29.getLeapDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText((int) 'a', locale32);
        long long35 = offsetDateTimeField29.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType43, (int) 'a');
        long long47 = dividedDateTimeField45.remainder((long) 97);
        int int48 = dividedDateTimeField45.getDivisor();
        org.joda.time.ReadablePartial readablePartial49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.hourOfDay();
        org.joda.time.DurationField durationField52 = gregorianChronology50.years();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology50.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 1);
        org.joda.time.ReadablePartial readablePartial56 = null;
        org.joda.time.Period period58 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds59 = period58.toStandardSeconds();
        int[] intArray60 = period58.getValues();
        int int61 = offsetDateTimeField55.getMinimumValue(readablePartial56, intArray60);
        int int62 = dividedDateTimeField45.getMinimumValue(readablePartial49, intArray60);
        int int63 = offsetDateTimeField18.getMaximumValue(readablePartial23, intArray60);
        int int64 = offsetDateTimeField5.getMaximumValue(readablePartial12, intArray60);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2" + "'", str20.equals("2"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 345600000L + "'", long22 == 345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259200000L) + "'", long35 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 97L + "'", long47 == 97L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(seconds59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 54 + "'", int63 == 54);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 54 + "'", int64 == 54);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        java.lang.String str14 = zonedChronology12.toString();
        org.joda.time.ReadablePartial readablePartial15 = null;
        try {
            int[] intArray17 = zonedChronology12.get(readablePartial15, (long) (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 100, (long) 34947, periodType2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        try {
            long long30 = unsupportedDurationField11.getMillis(1560629279853L, (-31449600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period4 = period2.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.weeks();
        java.lang.String str8 = periodType7.toString();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType7);
        org.joda.time.MutablePeriod mutablePeriod10 = period9.toMutablePeriod();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PeriodType[Weeks]" + "'", str8.equals("PeriodType[Weeks]"));
        org.junit.Assert.assertNotNull(mutablePeriod10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        long long30 = unsupportedDateTimeField24.add(259200000L, 6393600000L);
        java.util.Locale locale32 = null;
        try {
            java.lang.String str33 = unsupportedDateTimeField24.getAsText((int) (short) 1, locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 552407040259200000L + "'", long30 == 552407040259200000L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ');
        long long7 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period4, (long) '#', (int) (byte) 10);
        org.joda.time.Period period9 = period4.minusMinutes((int) (short) 100);
        org.joda.time.Period period11 = period4.plusMonths(0);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period11.toString(periodFormatter12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 355L + "'", long7 == 355L);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.032S" + "'", str13.equals("PT0.032S"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Weeks]", (java.lang.Number) 345600000L, (java.lang.Number) (-5684169600000L), (java.lang.Number) 200L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-5684169600000L) + "'", number5.equals((-5684169600000L)));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ');
        long long7 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period4, (long) '#', (int) (byte) 10);
        org.joda.time.Minutes minutes8 = period4.toStandardMinutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 355L + "'", long7 == 355L);
        org.junit.Assert.assertNotNull(minutes8);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        int int32 = unsupportedDateTimeField24.getDifference(259200035L, 35000L);
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = unsupportedDateTimeField24.getAsShortText(58665599849L, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0.042S", "GregorianChronology[UTC]", 54, 96);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        boolean boolean6 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology2);
        java.lang.String str7 = jodaTimePermission1.getName();
        java.lang.String str8 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling((-43286400000L));
        long long34 = remainderDateTimeField28.roundHalfFloor((-259079000L));
        try {
            long long37 = remainderDateTimeField28.set((-59137603200000L), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [2,54]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-43200000000L) + "'", long32 == (-43200000000L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-259200000L) + "'", long34 == (-259200000L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period1.getFieldTypes();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        long long17 = fixedDateTimeZone12.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period1, chronology7);
        org.joda.time.Period period21 = period19.minusMonths(1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-90L) + "'", long17 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 0);
        java.lang.String str2 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 1);
        int int4 = period3.getHours();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period8 = period6.minusMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period8.indexOf(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period8.get(durationFieldType11);
        org.joda.time.Period period14 = period8.withSeconds(10);
        org.joda.time.Period period15 = period3.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period17 = period3.plusMonths((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        int int12 = offsetDateTimeField5.getDifference((-100L), (long) 0);
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        java.lang.String str15 = offsetDateTimeField5.getAsText(259200000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField5.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField5.getAsShortText(54, locale9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "54" + "'", str10.equals("54"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling((-43286400000L));
        long long34 = remainderDateTimeField28.roundHalfFloor((-259079000L));
        int int35 = remainderDateTimeField28.getMaximumValue();
        int int37 = remainderDateTimeField28.get(2440588L);
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        java.lang.String str41 = remainderDateTimeField28.getAsText(readablePartial38, 2, locale40);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-43200000000L) + "'", long32 == (-43200000000L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-259200000L) + "'", long34 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 96 + "'", int35 == 96);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2" + "'", str41.equals("2"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        long long25 = dividedDateTimeField21.remainder(31449600000L);
        java.lang.String str26 = dividedDateTimeField21.getName();
        int int27 = dividedDateTimeField21.getMinimumValue();
        long long30 = dividedDateTimeField21.getDifferenceAsLong((-43286400000L), 0L);
        long long33 = dividedDateTimeField21.getDifferenceAsLong(0L, 345600000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekOfWeekyear" + "'", str26.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.Period period1 = new org.joda.time.Period(1L);
        int int2 = period1.getSeconds();
        int int3 = period1.getDays();
        org.joda.time.Minutes minutes4 = period1.toStandardMinutes();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(minutes4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        java.lang.String str27 = unsupportedDurationField11.toString();
        try {
            int int29 = unsupportedDurationField11.getValue(31452040588L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UnsupportedDurationField[hours]" + "'", str27.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "97");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("10.0", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"10.0/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology24.years();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 1);
        org.joda.time.DurationField durationField30 = offsetDateTimeField29.getLeapDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText((int) 'a', locale32);
        long long35 = offsetDateTimeField29.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType43, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField47);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType43);
        org.joda.time.DurationField durationField50 = remainderDateTimeField49.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial51 = null;
        java.util.Locale locale52 = null;
        try {
            java.lang.String str53 = remainderDateTimeField49.getAsShortText(readablePartial51, locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259200000L) + "'", long35 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertNotNull(durationField50);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long12 = offsetDateTimeField5.add((long) (short) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField5.getWrappedField();
        long long15 = offsetDateTimeField5.roundHalfFloor(6048000000L);
        try {
            long long18 = offsetDateTimeField5.add((long) 54, (-31449599948L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -31449599948 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5788800000L + "'", long15 == 5788800000L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) ' ');
        org.joda.time.Period period3 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period5 = period3.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.get(durationFieldType6);
        org.joda.time.Period period9 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes10 = period9.toStandardMinutes();
        org.joda.time.Period period12 = period9.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period9.getFieldTypes();
        org.joda.time.Period period14 = period3.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period16 = period14.minusMonths(35);
        org.joda.time.Period period17 = period1.withFields((org.joda.time.ReadablePeriod) period14);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(minutes10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period3, (-1L), (-1L));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, periodType10);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = period12.withField(durationFieldType15, (int) (short) -1);
        org.joda.time.Period period19 = period3.withFieldAdded(durationFieldType15, (int) (short) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType15, "2");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        java.lang.String str30 = unsupportedDateTimeField24.getName();
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField24.getAsText(readablePartial31, 0, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "weekOfWeekyear" + "'", str30.equals("weekOfWeekyear"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period7 = period5.plusMinutes((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) (byte) 10);
        org.joda.time.Period period10 = period3.minus((org.joda.time.ReadablePeriod) period7);
        int int11 = period7.getMillis();
        org.joda.time.Period period13 = period7.withMinutes((int) (short) 10);
        java.lang.String str14 = period7.toString();
        try {
            org.joda.time.DurationFieldType durationFieldType16 = period7.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1WT32M" + "'", str14.equals("P-1WT32M"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        long long28 = unsupportedDateTimeField24.add((long) 54, (long) 2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 172800054L + "'", long28 == 172800054L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        java.lang.String str30 = unsupportedDateTimeField24.getName();
        try {
            int int31 = unsupportedDateTimeField24.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "weekOfWeekyear" + "'", str30.equals("weekOfWeekyear"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        int int12 = offsetDateTimeField5.getDifference((-100L), (long) 0);
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        long long16 = offsetDateTimeField5.getDifferenceAsLong((long) ' ', (long) 34947);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField5.getType();
        boolean boolean19 = offsetDateTimeField5.isLeap(6047999952L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        int int12 = offsetDateTimeField5.getDifference((-100L), (long) 0);
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        long long16 = offsetDateTimeField5.getDifferenceAsLong((long) ' ', (long) 34947);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.weekyears();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfDay();
        org.joda.time.Period period23 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period24 = period23.normalizedStandard();
        int[] intArray26 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period24, (long) 1);
        try {
            int[] intArray28 = offsetDateTimeField5.addWrapPartial(readablePartial17, (int) '4', intArray26, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsText(10, locale23);
        long long27 = dividedDateTimeField21.add(6393600000L, (long) (-97));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        long long32 = remainderDateTimeField28.roundCeiling(31795200000L);
        int int33 = remainderDateTimeField28.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial34 = null;
        int int35 = remainderDateTimeField28.getMinimumValue(readablePartial34);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10" + "'", str24.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5684169600000L) + "'", long27 == (-5684169600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31795200000L + "'", long32 == 31795200000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 96 + "'", int33 == 96);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology1.years();
        org.joda.time.Period period5 = new org.joda.time.Period((long) ' ');
        long long8 = gregorianChronology1.add((org.joda.time.ReadablePeriod) period5, (long) '#', (int) (byte) 10);
        org.joda.time.Period period10 = period5.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType13 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) -1, periodType14);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType((int) (short) 0);
        org.joda.time.Period period21 = period16.withField(durationFieldType19, (int) (short) -1);
        boolean boolean22 = period10.isSupported(durationFieldType19);
        boolean boolean23 = periodType0.isSupported(durationFieldType19);
        boolean boolean25 = periodType0.equals((java.lang.Object) "10.0");
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 355L + "'", long8 == 355L);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            long long14 = unsupportedDurationField11.getMillis((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        java.lang.String str25 = scaledDurationField24.toString();
        long long27 = scaledDurationField24.getValueAsLong(6047999952L);
        boolean boolean29 = scaledDurationField24.equals((java.lang.Object) 97L);
        long long32 = scaledDurationField24.subtract(19612800000L, 2L);
        try {
            long long35 = scaledDurationField24.getMillis((-43286400000L), (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -2250892800000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DurationField[hours]" + "'", str25.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-43286400000L) + "'", long32 == (-43286400000L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        long long30 = unsupportedDateTimeField24.add(259200000L, 6393600000L);
        java.lang.String str31 = unsupportedDateTimeField24.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 552407040259200000L + "'", long30 == 552407040259200000L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.secondOfDay();
        org.joda.time.Chronology chronology14 = zonedChronology12.withUTC();
        boolean boolean16 = zonedChronology12.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 2, true);
        long long9 = fixedDateTimeZone4.previousTransition((long) 10);
        java.lang.String str11 = fixedDateTimeZone4.getName((long) (-100));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        try {
            long long30 = unsupportedDateTimeField24.set((-3144960000000L), 42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period3 = period1.plusMinutes((int) ' ');
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period1.toDurationTo(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withHoursRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withMinutesRemoved();
        org.joda.time.PeriodType periodType12 = periodType10.withMillisRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant8, periodType10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period23 = period18.withField(durationFieldType21, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        java.lang.String str25 = unsupportedDurationField24.toString();
        int int26 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField24);
        boolean boolean27 = unsupportedDurationField11.isSupported();
        try {
            long long30 = unsupportedDurationField11.getValueAsLong((long) 1, 31190400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDurationField[hours]" + "'", str25.equals("UnsupportedDurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        int int29 = unsupportedDateTimeField24.getDifference(3050611200097L, 31190400000L);
        int int32 = unsupportedDateTimeField24.getDifference(259200035L, 35000L);
        try {
            long long35 = unsupportedDateTimeField24.set(345600000L, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 34947 + "'", int29 == 34947);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 1);
        org.joda.time.Period period3 = period1.plusMonths(100);
        org.joda.time.Period period5 = period1.minusHours((int) (byte) 100);
        org.joda.time.Period period7 = period5.plusHours((-100));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes7 = period6.toStandardMinutes();
        org.joda.time.Period period9 = period6.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period6.getFieldTypes();
        boolean boolean11 = lenientChronology4.equals((java.lang.Object) period6);
        org.joda.time.Chronology chronology12 = lenientChronology4.withUTC();
        org.joda.time.Chronology chronology13 = lenientChronology4.withUTC();
        java.lang.String str14 = lenientChronology4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(minutes7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str14.equals("LenientChronology[GregorianChronology[UTC]]"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', (int) (byte) 10, 2, (int) '#');
        org.joda.time.Period period6 = period4.minusHours((int) (short) -1);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField24.getRangeDurationField();
        long long31 = unsupportedDateTimeField24.add(1560629294707L, 31449600001L);
        try {
            int int32 = unsupportedDateTimeField24.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2717247000715694707L + "'", long31 == 2717247000715694707L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        org.joda.time.Period period26 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period28 = period26.plusMinutes((int) ' ');
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period26.get(durationFieldType29);
        org.joda.time.Period period32 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes33 = period32.toStandardMinutes();
        org.joda.time.Period period35 = period32.plusDays(97);
        org.joda.time.DurationFieldType[] durationFieldTypeArray36 = period32.getFieldTypes();
        org.joda.time.Period period37 = period26.withFields((org.joda.time.ReadablePeriod) period32);
        org.joda.time.Period period39 = period37.minusMonths(35);
        org.joda.time.Period period41 = period37.withMillis(35);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.Period period43 = period37.withFields(readablePeriod42);
        int int44 = period43.getHours();
        org.joda.time.Period period46 = period43.minusMinutes((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.hourOfDay();
        org.joda.time.DurationField durationField49 = gregorianChronology47.years();
        org.joda.time.Period period51 = new org.joda.time.Period((long) ' ');
        long long54 = gregorianChronology47.add((org.joda.time.ReadablePeriod) period51, (long) '#', (int) (byte) 10);
        org.joda.time.Period period56 = period51.minusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType58 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType59 = periodType58.withYearsRemoved();
        org.joda.time.PeriodType periodType60 = org.joda.time.DateTimeUtils.getPeriodType(periodType58);
        org.joda.time.PeriodType periodType61 = periodType60.withYearsRemoved();
        org.joda.time.Period period62 = new org.joda.time.Period((long) (short) -1, periodType60);
        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType65 = periodType63.getFieldType((int) (short) 0);
        org.joda.time.Period period67 = period62.withField(durationFieldType65, (int) (short) -1);
        boolean boolean68 = period56.isSupported(durationFieldType65);
        org.joda.time.Period period70 = period43.withField(durationFieldType65, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField72 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType65, 42);
        long long75 = scaledDurationField72.add(31449600000L, 49);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(minutes33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldTypeArray36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 355L + "'", long54 == 355L);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(periodType60);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(durationFieldType65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1276128000000L + "'", long75 == 1276128000000L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        long long7 = offsetDateTimeField5.remainder((long) (byte) 0);
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.Period period11 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Seconds seconds12 = period11.toStandardSeconds();
        int[] intArray13 = period11.getValues();
        try {
            int[] intArray15 = offsetDateTimeField5.addWrapField(readablePartial8, 0, intArray13, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 259200000L + "'", long7 == 259200000L);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(seconds12);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology24.years();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 1);
        org.joda.time.DurationField durationField30 = offsetDateTimeField29.getLeapDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText((int) 'a', locale32);
        long long35 = offsetDateTimeField29.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType43, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField47);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType43);
        int int50 = remainderDateTimeField49.getDivisor();
        org.joda.time.DurationField durationField51 = remainderDateTimeField49.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259200000L) + "'", long35 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 97 + "'", int50 == 97);
        org.junit.Assert.assertNotNull(durationField51);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 100);
        long long7 = fixedDateTimeZone4.adjustOffset((long) 10, false);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (short) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName((long) (short) -1, locale11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.millisOfSecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 52);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        long long11 = durationField8.subtract((long) 10, (int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.PeriodType periodType16 = periodType15.withYearsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType20 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period17.withField(durationFieldType20, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField24 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType20, 52);
        int int25 = scaledDurationField24.getScalar();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("100");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"100/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        try {
            long long28 = unsupportedDateTimeField24.remainder((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long6 = gregorianChronology0.getDateTimeMillis((long) (short) 10, (int) (short) 0, 0, 0, (int) (short) 100);
        try {
            long long14 = gregorianChronology0.getDateTimeMillis(1, 0, (int) (short) 10, (int) (byte) 10, (int) ' ', 42, 54);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        long long27 = unsupportedDateTimeField24.getDifferenceAsLong(99L, (-259079000L));
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField24.getRangeDurationField();
        long long31 = unsupportedDateTimeField24.add(1560629294707L, 31449600001L);
        try {
            long long34 = unsupportedDateTimeField24.set((long) 'a', "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2L + "'", long27 == 2L);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2717247000715694707L + "'", long31 == 2717247000715694707L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) readableInterval0, periodType2);
        org.joda.time.Period period5 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Period period7 = period5.plusMinutes((int) ' ');
        org.joda.time.Period period9 = period7.plusDays((int) (byte) 10);
        org.joda.time.Period period10 = period3.minus((org.joda.time.ReadablePeriod) period7);
        int int11 = period7.getMillis();
        org.joda.time.Period period13 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period15 = period13.minusWeeks(2);
        int int17 = period13.getValue(0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray18 = period13.getFieldTypes();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray18);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 97, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType1.isSupported(durationFieldType3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, periodType1, (org.joda.time.Chronology) gregorianChronology5);
        try {
            org.joda.time.Period period10 = period8.withYears((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("DateTimeField[weekOfWeekyear]", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearWeekDay();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((int) (byte) 0, (-52), 96, 0, (-6), (int) (short) -1, 34947, (-97), periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.DurationFieldType durationFieldType8 = periodType6.getFieldType((int) (short) 0);
        org.joda.time.Period period10 = period5.withField(durationFieldType8, (int) (short) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType8);
        java.lang.String str12 = unsupportedDurationField11.toString();
        try {
            int int15 = unsupportedDurationField11.getDifference(0L, (long) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnsupportedDurationField[hours]" + "'", str12.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.withHours((int) (byte) -1);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Period period6 = period3.minusYears(96);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone33 = fixedDateTimeZone32.toTimeZone();
        java.util.TimeZone timeZone34 = fixedDateTimeZone32.toTimeZone();
        long long37 = fixedDateTimeZone32.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance(chronology27, (org.joda.time.DateTimeZone) fixedDateTimeZone32);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology38.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone40 = zonedChronology38.getZone();
        org.joda.time.Chronology chronology41 = zonedChronology38.withUTC();
        org.joda.time.Period period43 = org.joda.time.Period.weeks((int) (byte) -1);
        org.joda.time.Minutes minutes44 = period43.toStandardMinutes();
        org.joda.time.Period period46 = period43.plusDays(97);
        org.joda.time.Period period48 = period43.plusMillis((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.hourOfDay();
        org.joda.time.DurationField durationField51 = gregorianChronology49.years();
        org.joda.time.Period period53 = new org.joda.time.Period((long) ' ');
        long long56 = gregorianChronology49.add((org.joda.time.ReadablePeriod) period53, (long) '#', (int) (byte) 10);
        org.joda.time.Period period58 = period53.minusMinutes((int) (short) 100);
        org.joda.time.Period period59 = period43.plus((org.joda.time.ReadablePeriod) period58);
        int[] intArray62 = zonedChronology38.get((org.joda.time.ReadablePeriod) period43, 200L, 0L);
        try {
            int int63 = unsupportedDateTimeField24.getMinimumValue(readablePartial25, intArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-90L) + "'", long37 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(minutes44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 355L + "'", long56 == 355L);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(intArray62);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        long long23 = dividedDateTimeField21.remainder((long) 97);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.hourOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology24.years();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 1);
        org.joda.time.DurationField durationField30 = offsetDateTimeField29.getLeapDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText((int) 'a', locale32);
        long long35 = offsetDateTimeField29.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfDay();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 1);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType43, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField47);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField21, dateTimeFieldType43);
        long long51 = remainderDateTimeField49.remainder((-210866846400000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259200000L) + "'", long35 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 561600000L + "'", long51 == 561600000L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        long long9 = gregorianChronology0.getDateTimeMillis((-259200000L), 0, 2, 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259079000L) + "'", long9 == (-259079000L));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        org.joda.time.DurationField durationField6 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText((int) 'a', locale8);
        long long11 = offsetDateTimeField5.roundHalfCeiling((-90L));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.years();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.days();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField23);
        boolean boolean25 = unsupportedDateTimeField24.isSupported();
        java.lang.String str26 = unsupportedDateTimeField24.toString();
        java.util.Locale locale29 = null;
        try {
            long long30 = unsupportedDateTimeField24.set(31795200000L, "P-1WT32M", locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97" + "'", str9.equals("97"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Period period8 = new org.joda.time.Period(2, (int) (byte) 100, 42, (-52), 42, 10, 54, (int) (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(1L);
        org.joda.time.PeriodType periodType4 = period3.getPeriodType();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.PeriodType periodType10 = periodType9.withYearsRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType9);
        org.joda.time.Period period12 = period5.plus((org.joda.time.ReadablePeriod) period11);
        int int13 = period5.getWeeks();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (short) 100);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone6.toTimeZone();
        long long11 = fixedDateTimeZone6.convertLocalToUTC(10L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.millisOfDay();
        long long18 = iSOChronology13.add((long) (-97), (long) (-1), 1);
        java.lang.String str19 = iSOChronology13.toString();
        org.joda.time.Chronology chronology20 = iSOChronology13.withUTC();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-90L) + "'", long11 == (-90L));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-98L) + "'", long18 == (-98L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[]" + "'", str19.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(chronology20);
    }
}

