import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = null;
        try {
            int int4 = mutableDateTime2.get(dateTimeField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            mutableDateTime2.add(durationFieldType3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        try {
            mutableDateTime2.setDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        try {
            long long9 = julianChronology0.getDateTimeMillis((int) (short) -1, (int) (short) 100, (int) '#', (int) '#', (int) (byte) 100, (int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 100, number2, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            long long2 = dateTimeFormatter0.parseMillis("4:00:00 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4:00:00 PM\" is malformed at \":00:00 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = julianChronology0.get(readablePeriod4, (long) (short) 1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (byte) 100, (int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        try {
            mutableDateTime2.setSecondOfMinute((-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-2), (int) (short) 0, (int) (byte) 0, (int) (byte) 10, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3500 + "'", int2 == 3500);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(97L, (long) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3104 + "'", int2 == 3104);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560344477339L + "'", long0 == 1560344477339L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("2019", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        mutableDateTime5.setSecondOfDay((int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter1.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter1.getParser();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField5 = julianChronology4.months();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.year();
        dateTimeParserBucket3.saveField(dateTimeField7, 1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (-2), (int) (byte) 0, 3500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for year must be in the range [0,3500]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        try {
            long long10 = julianChronology0.getDateTimeMillis(1, 4, 0, (-2), (-2), (int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withYear((int) ' ');
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 0, (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int int5 = property3.compareTo(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withField(dateTimeFieldType6, 3104);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withFieldAdded(durationFieldType4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        java.lang.Class<?> wildcardClass4 = julianChronology0.getClass();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str2 = iSOChronology1.toString();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) iSOChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("4:00:00 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4:00:00 PM\" is malformed at \":00:00 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        long long6 = durationField3.subtract(0L, (long) (short) -1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1000L + "'", long6 == 1000L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfEven();
        try {
            mutableDateTime6.setDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField5 = julianChronology4.months();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.year();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology4.millisOfDay();
        dateTimeParserBucket3.saveField(dateTimeField8, (int) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
//        int int6 = mutableDateTime5.getDayOfMonth();
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
//        try {
//            long long14 = dateTimeFormatter0.parseMillis("ISOChronology[UTC]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        int int5 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withMonthOfYear((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getDayOfMonth();
//        mutableDateTime2.setYear((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long8 = gJChronology0.getDateTimeMillis(3104, (int) (byte) 100, 12, 361, (int) (short) 10, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 361 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            long long3 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks((int) '#');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withFieldAdded(durationFieldType6, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone0.convertLocalToUTC((long) (short) 0, false, (long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28800000L + "'", long4 == 28800000L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0, (-1), 1, (int) (short) 100, 10, (-2), (int) (short) 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        long long7 = dateTimeZone5.convertUTCToLocal((long) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone5.getName(0L, locale9);
//        org.joda.time.DateTime dateTime11 = dateTime2.toDateTime(dateTimeZone5);
//        try {
//            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 9, false, (long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9L + "'", long5 == 9L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        int[] intArray3 = new int[] { (byte) 100 };
        try {
            gJChronology0.validate(readablePartial1, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.field.FieldUtils.verifyValueBounds("Coordinated Universal Time", (int) '#', 10, 3104);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, (org.joda.time.ReadableInstant) instant4);
        boolean boolean7 = instant1.isAfter((long) 1970);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendYear((-2), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 12, (int) (byte) 10, 1969, 0, 3500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
        java.lang.String str4 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.weekyear();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "4:00:00 PM", 0);
        java.io.Writer writer8 = null;
        try {
            dateTimeFormatter0.printTo(writer8, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2) + "'", int7 == (-2));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.weekyear();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "4:00:00 PM", 0);
        mutableDateTime3.add(3395L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2) + "'", int7 == (-2));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        try {
            long long20 = offsetDateTimeField17.set((long) (short) 1, "4:00:00 PM");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"4:00:00 PM\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DurationField durationField3 = julianChronology0.days();
        long long7 = julianChronology0.add((long) 292278993, (long) (short) 10, (int) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 292279993L + "'", long7 == 292279993L);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.year();
        org.joda.time.DurationField durationField5 = julianChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField8 = julianChronology7.months();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField10, 4);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology1.halfdayOfDay();
        long long17 = julianChronology1.add((long) (short) 100, (long) 1, (int) ' ');
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology1, locale18, (java.lang.Integer) 0, (int) '#');
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 132L + "'", long17 == 132L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        int int7 = property3.getLeapAmount();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        int int13 = skipUndoDateTimeField11.getMinimumValue((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray22 = new int[] { '4', (-1), (short) 10, (short) 100, (short) -1, (byte) 100 };
        java.util.Locale locale24 = null;
        try {
            int[] intArray25 = skipUndoDateTimeField11.set(readablePartial14, (int) 'a', intArray22, "Coordinated Universal Time", locale24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292269054) + "'", int13 == (-292269054));
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
        try {
            org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) julianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        try {
            long long21 = offsetDateTimeField17.set(0L, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for year must be in the range [0,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone3 = instant2.getZone();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField5 = julianChronology4.months();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.year();
        org.joda.time.DurationField durationField8 = julianChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology4.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField11 = julianChronology10.months();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology10.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology4, dateTimeField13, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField15.getType();
        int int17 = instant2.get(dateTimeFieldType16);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1560344477339L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 1, (int) (short) 100, (int) (byte) 0, (int) (byte) -1, (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) '#');
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(21682);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21682 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTimeISO();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        boolean boolean6 = property3.isLeap();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-2), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3) + "'", int2 == (-3));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210780360000000L) + "'", long1 == (-210780360000000L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray27 = new int[] { ' ', 1970, (short) 1, 292278993 };
        try {
            int[] intArray29 = skipUndoDateTimeField11.set(readablePartial21, 100, intArray27, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((int) (byte) 100, 12, 292272992, 1969, (int) '#', (int) 'a', (int) '4', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        long long18 = skipUndoDateTimeField11.addWrapField(1560344477339L, (int) '#');
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray23 = new int[] { (-292269054), 9 };
        java.util.Locale locale25 = null;
        try {
            int[] intArray26 = skipUndoDateTimeField11.set(readablePartial19, (-292269054), intArray23, "10", locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292269054");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2664882077339L + "'", long18 == 2664882077339L);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray27 = new int[] { ' ', 9700, (-292269054), 4, 9700, ' ' };
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField17.set(readablePartial19, (int) (short) -1, intArray27, "hi!", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[UTC]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[UTC]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendCenturyOfEra(3500, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendHourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        mutableDateTime2.setTime((long) 1970);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        java.lang.Object obj4 = dateTimeParserBucket3.saveState();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
//        int int6 = mutableDateTime5.getDayOfMonth();
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
//        int int10 = mutableDateTime5.getMillisOfDay();
//        try {
//            mutableDateTime5.setSecondOfMinute((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 21686206 + "'", int10 == 21686206);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        java.util.Locale locale13 = null;
        java.util.Calendar calendar14 = mutableDateTime2.toCalendar(locale13);
        java.lang.Object obj15 = mutableDateTime2.clone();
        int int16 = mutableDateTime2.getSecondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(calendar14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePeriod2, 63695916082768L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.era();
        try {
            mutableDateTime7.setSecondOfDay((-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property3.setCopy("JulianChronology[America/Los_Angeles]", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        try {
//            mutableDateTime2.setDateTime((int) (short) 100, (int) (short) 10, (int) (short) 100, (int) (byte) 1, 10, 21682, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21682 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 361 + "'", int3 == 361);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray21 = null;
        try {
            int[] intArray23 = offsetDateTimeField17.addWrapField(readablePartial19, 3500, intArray21, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        long long13 = skipUndoDateTimeField11.roundHalfFloor((long) ' ');
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField11.getAsShortText((long) 86399, locale15);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1152000000L + "'", long13 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (byte) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        try {
            long long18 = skipUndoDateTimeField11.set((long) 86399, "GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[America/Los_Angeles]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.year();
        int int5 = property4.getMaximumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        long long7 = durationField4.subtract(1L, 292272992);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-176766705562021999L) + "'", long7 == (-176766705562021999L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField5 = julianChronology1.seconds();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getName();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "weekyear" + "'", str4.equals("weekyear"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DurationField durationField2 = gJChronology0.centuries();
        java.lang.String str3 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str1.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.lang.String str34 = offsetDateTimeField32.getAsShortText((long) (-292269054));
        try {
            long long37 = offsetDateTimeField32.add(30384000001L, (-176766705562021999L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -176766705562021999");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5073" + "'", str34.equals("5073"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        try {
            long long40 = dividedDateTimeField37.add((-176766705562021999L), 63695916082768L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2229357062896880");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        long long13 = skipUndoDateTimeField11.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField11.getAsShortText(readablePartial14, 21682, locale16);
        java.util.Locale locale18 = null;
        int int19 = skipUndoDateTimeField11.getMaximumShortTextLength(locale18);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1152000000L + "'", long13 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "21682" + "'", str17.equals("21682"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((int) 'a', (int) (short) 1, (int) (byte) 10, 9700, 3, (int) '4', (int) (short) 1, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology2);
        boolean boolean4 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.LocalDate localDate7 = dateTimeFormatter0.parseLocalDate("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(dateTimeZone5);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
//        int int6 = mutableDateTime5.getDayOfMonth();
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
//        int int14 = dateTimeZone11.getOffsetFromLocal((long) 361);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, 0L, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 1969, (org.joda.time.Chronology) iSOChronology1, locale4, (java.lang.Integer) (-2018), 292272992);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant11 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone12 = instant11.getZone();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField14 = julianChronology13.months();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology13.year();
        org.joda.time.DurationField durationField17 = julianChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology13.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField20 = julianChronology19.months();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology19.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology13, dateTimeField22, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipUndoDateTimeField24.getType();
        int int26 = instant11.get(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType25);
        int int28 = mutableDateTime2.get(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        int int19 = offsetDateTimeField17.get((long) 9);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int int21 = offsetDateTimeField17.getMinimumValue(readablePartial20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime2.weekOfWeekyear();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("-1", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        int int19 = offsetDateTimeField17.get((long) 9);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField17.getAsText((long) (short) 1, locale21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.era();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.weekyear();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "4:00:00 PM", 0);
        java.util.Date date8 = mutableDateTime3.toDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2) + "'", int7 == (-2));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("4:00:00 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1009843200000L, "-1");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 9700, (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1009843200000L, "-1");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getLeapDurationField();
        try {
            long long21 = offsetDateTimeField17.set((long) 361, 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for year must be in the range [0,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        try {
            long long79 = remainderDateTimeField76.set(9L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for year must be in the range [0,34]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.append(dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withDefaultYear((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral("1969");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getRangeDurationField();
        int int20 = offsetDateTimeField17.getMinimumValue((long) (-2));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.weekyear();
        mutableDateTime4.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone10 = instant9.getZone();
        org.joda.time.Instant instant12 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant9, (org.joda.time.ReadableInstant) instant12);
        mutableDateTime4.setTime((org.joda.time.ReadableInstant) instant12);
        java.util.Locale locale15 = null;
        java.util.Calendar calendar16 = mutableDateTime4.toCalendar(locale15);
        java.lang.Object obj17 = mutableDateTime4.clone();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        mutableDateTime4.add(readablePeriod18, (-1));
        int int21 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) mutableDateTime4);
        try {
            mutableDateTime4.setMillisOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(calendar16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(5, 0, 21685927, 3104, 1970, 86399, 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3104 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField6 = mutableDateTime2.getRoundingField();
        mutableDateTime2.setSecondOfDay((int) (byte) 10);
        org.joda.time.Instant instant9 = mutableDateTime2.toInstant();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNull(dateTimeField6);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.DurationField durationField4 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear((int) (byte) 10, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText((long) 'a', locale13);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = skipUndoDateTimeField11.getMaximumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = skipUndoDateTimeField11.getAsShortText(readablePartial18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272992 + "'", int17 == 292272992);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        try {
            long long79 = dividedDateTimeField37.add((long) (byte) 0, 1836085927L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 64263007445");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        int int5 = property3.getMaximumValueOverall();
        int int6 = property3.getMinimumValue();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder2.appendDayOfMonth(5);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        long long13 = skipUndoDateTimeField11.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray19 = new int[] { '4', (byte) 10, (byte) 100 };
        java.util.Locale locale21 = null;
        try {
            int[] intArray22 = skipUndoDateTimeField11.set(readablePartial14, (int) (short) 1, intArray19, "10", locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1152000000L + "'", long13 == 1152000000L);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) 'a', (-2018), (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2018 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withDayOfWeek(21692);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21692 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1969) + "'", int1 == (-1969));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getRangeDurationField();
        java.util.Locale locale21 = null;
        try {
            long long22 = offsetDateTimeField17.set((long) (byte) 100, "GJChronology[America/Los_Angeles]", locale21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[America/Los_Angeles]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '#', 3, (-3), 0, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField32.getAsText((long) (byte) 0, locale34);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "5073" + "'", str35.equals("5073"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial78 = null;
        int[] intArray86 = new int[] { 86399, 9, 21685927, (-1), 5, (short) 10 };
        try {
            int[] intArray88 = remainderDateTimeField76.addWrapField(readablePartial78, 0, intArray86, 21685927);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertNotNull(intArray86);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1970");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendHourOfHalfday(0);
        dateTimeFormatterBuilder9.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
//        int int6 = mutableDateTime5.getDayOfMonth();
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
//        int int10 = mutableDateTime5.getMillisOfDay();
//        mutableDateTime5.setMinuteOfDay((int) (short) 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 21695074 + "'", int10 == 21695074);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        try {
            long long13 = julianChronology0.getDateTimeMillis((-292275054), (int) (short) -1, (int) (byte) 0, (int) (short) 100, 21685927, 0, 21682);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.year();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.dayOfWeek();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundCeiling();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        long long10 = durationField7.subtract((long) 12, (-2));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 63504000012L + "'", long10 == 63504000012L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.set((int) (short) 0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        org.joda.time.MutableDateTime mutableDateTime8 = property3.roundHalfFloor();
        org.joda.time.ReadableInstant readableInstant9 = null;
        try {
            int int10 = property3.compareTo(readableInstant9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = julianChronology0.set(readablePartial1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 86399);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4:01:26 PM PST" + "'", str2.equals("4:01:26 PM PST"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        java.util.TimeZone timeZone5 = dateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long5 = dateTimeZone3.convertUTCToLocal((long) 'a');
        java.lang.String str6 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology7 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTimeISO();
        try {
            mutableDateTime4.setMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: JulianChronology[America/Los_Angeles]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 30384000001L, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(buddhistChronology4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        long long20 = offsetDateTimeField17.addWrapField((long) 21685927, (int) '4');
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray25 = new int[] { (-1), (-25200000) };
        try {
            int[] intArray27 = offsetDateTimeField17.addWrapPartial(readablePartial21, (int) (byte) 100, intArray25, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1836085927L + "'", long20 == 1836085927L);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfMonth();
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = dateTime2.toString("1969-12-31T16:00:00.000-08:00", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = property7.set("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
//        int int6 = mutableDateTime5.getDayOfMonth();
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
//        int int14 = dateTimeZone11.getOffsetFromLocal((long) 361);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = julianChronology1.months();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.DurationField durationField4 = julianChronology1.seconds();
//        org.joda.time.DurationField durationField5 = julianChronology1.centuries();
//        org.joda.time.Chronology chronology6 = julianChronology1.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter7.getZone();
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(obj10, dateTimeZone11);
//        int int13 = mutableDateTime12.getDayOfMonth();
//        int int16 = dateTimeFormatter7.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime12, "hi!", (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter7.withZone(dateTimeZone18);
//        int int21 = dateTimeZone18.getOffsetFromLocal((long) 361);
//        org.joda.time.Chronology chronology22 = julianChronology1.withZone(dateTimeZone18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter0.withZone(dateTimeZone18);
//        int int25 = dateTimeZone18.getOffsetFromLocal((long) 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNull(chronology8);
//        org.junit.Assert.assertNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfEven();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime6.add(readablePeriod7, (-3));
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        int int11 = julianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology10.getZone();
        java.util.TimeZone timeZone13 = dateTimeZone12.toTimeZone();
        mutableDateTime6.setZoneRetainFields(dateTimeZone12);
        try {
            mutableDateTime6.setDayOfWeek(21695074);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21695074 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.weekyear();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "4:00:00 PM", 0);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime3.add(readableDuration8, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2) + "'", int7 == (-2));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField8 = julianChronology7.months();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.year();
        org.joda.time.DurationField durationField11 = julianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField14 = julianChronology13.months();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology13.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField16, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipUndoDateTimeField18.getType();
        int int22 = skipUndoDateTimeField18.getDifference((long) 3104, 0L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField18.getAsText((int) (short) 10, locale24);
        long long27 = skipUndoDateTimeField18.roundHalfFloor((long) 4);
        long long29 = skipUndoDateTimeField18.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField31 = julianChronology30.months();
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology30);
        org.joda.time.DateTimeField dateTimeField33 = julianChronology30.year();
        org.joda.time.DurationField durationField34 = julianChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology30.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField37 = julianChronology36.months();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology36);
        org.joda.time.DateTimeField dateTimeField39 = julianChronology36.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology30, dateTimeField39, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType42, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField46 = julianChronology45.months();
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology45);
        org.joda.time.DateTimeField dateTimeField48 = julianChronology45.year();
        org.joda.time.DurationField durationField49 = julianChronology45.weeks();
        org.joda.time.DateTimeField dateTimeField50 = julianChronology45.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology45, dateTimeField54, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = skipUndoDateTimeField56.getType();
        int int60 = skipUndoDateTimeField56.getDifference((long) 3104, 0L);
        java.util.Locale locale62 = null;
        java.lang.String str63 = skipUndoDateTimeField56.getAsText((int) (short) 10, locale62);
        long long65 = skipUndoDateTimeField56.roundHalfFloor((long) 4);
        long long67 = skipUndoDateTimeField56.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField69 = julianChronology68.months();
        org.joda.time.MutableDateTime mutableDateTime70 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology68);
        org.joda.time.DateTimeField dateTimeField71 = julianChronology68.year();
        org.joda.time.DurationField durationField72 = julianChronology68.weeks();
        org.joda.time.DateTimeField dateTimeField73 = julianChronology68.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField75 = julianChronology74.months();
        org.joda.time.MutableDateTime mutableDateTime76 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology74);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology74.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology68, dateTimeField77, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField82 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, dateTimeFieldType80, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField83 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField44, dateTimeFieldType80);
        org.joda.time.DurationField durationField84 = remainderDateTimeField83.getRangeDurationField();
        java.lang.String str85 = remainderDateTimeField83.getName();
        boolean boolean86 = remainderDateTimeField83.isLenient();
        mutableDateTime6.setRounding((org.joda.time.DateTimeField) remainderDateTimeField83);
        int int88 = mutableDateTime6.getSecondOfMinute();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1152000000L + "'", long27 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1152000000L + "'", long29 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10" + "'", str63.equals("10"));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1152000000L + "'", long65 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1152000000L + "'", long67 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology68);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "year" + "'", str85.equals("year"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-292275054));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.lang.String str34 = offsetDateTimeField32.getAsShortText((long) (-292269054));
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.DurationField durationField39 = julianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField42 = julianChronology41.months();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology41);
        org.joda.time.DateTimeField dateTimeField44 = julianChronology41.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField44, 4);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField46.getAsShortText(readablePartial47, (int) (short) -1, locale49);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.DurationField durationField55 = julianChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology51.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField58 = julianChronology57.months();
        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology57);
        org.joda.time.DateTimeField dateTimeField60 = julianChronology57.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology51, dateTimeField60, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = skipUndoDateTimeField62.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField46, dateTimeFieldType63, 3104, (-292269054), 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType63);
        long long71 = offsetDateTimeField32.getDifferenceAsLong((-210780360000000L), (long) '4');
        org.joda.time.ReadablePartial readablePartial72 = null;
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField75 = julianChronology74.months();
        org.joda.time.MutableDateTime mutableDateTime76 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology74);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology74.year();
        org.joda.time.DurationField durationField78 = julianChronology74.weeks();
        org.joda.time.DateTimeField dateTimeField79 = julianChronology74.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField81 = julianChronology80.months();
        org.joda.time.MutableDateTime mutableDateTime82 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology80);
        org.joda.time.DateTimeField dateTimeField83 = julianChronology80.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology74, dateTimeField83, 4);
        long long87 = skipUndoDateTimeField85.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial88 = null;
        java.util.Locale locale90 = null;
        java.lang.String str91 = skipUndoDateTimeField85.getAsShortText(readablePartial88, 21682, locale90);
        org.joda.time.ReadablePartial readablePartial92 = null;
        int[] intArray94 = new int[] { 1970 };
        int int95 = skipUndoDateTimeField85.getMaximumValue(readablePartial92, intArray94);
        java.util.Locale locale97 = null;
        try {
            int[] intArray98 = offsetDateTimeField32.set(readablePartial72, 1, intArray94, "UTC", locale97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5073" + "'", str34.equals("5073"));
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-6679L) + "'", long71 == (-6679L));
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(julianChronology80);
        org.junit.Assert.assertNotNull(durationField81);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1152000000L + "'", long87 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "21682" + "'", str91.equals("21682"));
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 292272992 + "'", int95 == 292272992);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        try {
            long long8 = iSOChronology0.getDateTimeMillis((long) (short) 100, 0, 361, 3104, 21682);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 361 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add((long) (short) 0, (long) '#', (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3395L + "'", long6 == 3395L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime2.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withMinuteOfHour(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getName(0L, locale5);
//        long long9 = dateTimeZone1.adjustOffset((long) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.weekyear();
//        java.util.Locale locale18 = null;
//        int int19 = property17.getMaximumTextLength(locale18);
//        org.joda.time.MutableDateTime mutableDateTime20 = property17.roundHalfEven();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField22 = julianChronology21.months();
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology21);
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology21.year();
//        org.joda.time.DurationField durationField25 = julianChronology21.weeks();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = julianChronology27.months();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology27);
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField30, 4);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField32.getAsShortText(readablePartial33, (int) (short) -1, locale35);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = julianChronology37.months();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology37);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology37.year();
//        org.joda.time.DurationField durationField41 = julianChronology37.weeks();
//        org.joda.time.DateTimeField dateTimeField42 = julianChronology37.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = julianChronology43.months();
//        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology43.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology37, dateTimeField46, 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipUndoDateTimeField48.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField32, dateTimeFieldType49, 3104, (-292269054), 0);
//        mutableDateTime20.set(dateTimeFieldType49, 1970);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField56 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType49);
//        long long58 = zeroIsMaxDateTimeField56.roundHalfEven(28799999L);
//        org.joda.time.Instant instant60 = new org.joda.time.Instant((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone61 = instant60.getZone();
//        org.joda.time.DateTime dateTime62 = instant60.toDateTimeISO();
//        org.joda.time.DateTime.Property property63 = dateTime62.weekyear();
//        org.joda.time.TimeOfDay timeOfDay64 = dateTime62.toTimeOfDay();
//        int[] intArray65 = null;
//        try {
//            int int66 = zeroIsMaxDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay64, intArray65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28799999L + "'", long58 == 28799999L);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(timeOfDay64);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology2, locale3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (short) -1, (org.joda.time.Chronology) julianChronology2, locale5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray9 = julianChronology2.get(readablePeriod7, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField25 = julianChronology24.months();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology24);
        org.joda.time.DateTimeField dateTimeField27 = julianChronology24.year();
        org.joda.time.DurationField durationField28 = julianChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology24.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField31 = julianChronology30.months();
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology30);
        org.joda.time.DateTimeField dateTimeField33 = julianChronology30.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology24, dateTimeField33, 4);
        long long37 = skipUndoDateTimeField35.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField35.getAsShortText(readablePartial38, 21682, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray44 = new int[] { 1970 };
        int int45 = skipUndoDateTimeField35.getMaximumValue(readablePartial42, intArray44);
        try {
            int[] intArray47 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) timeOfDay22, 0, intArray44, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1152000000L + "'", long37 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "21682" + "'", str41.equals("21682"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292272992 + "'", int45 == 292272992);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        int[] intArray26 = new int[] { 5, 10 };
        try {
            int[] intArray28 = unsupportedDateTimeField16.add((org.joda.time.ReadablePartial) timeOfDay22, 21695074, intArray26, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks((int) '#');
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay((-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) timeOfDay22, (int) '#', locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        long long20 = skipUndoDateTimeField11.set(0L, 9);
        org.joda.time.DurationField durationField21 = skipUndoDateTimeField11.getRangeDurationField();
        org.joda.time.DurationField durationField22 = skipUndoDateTimeField11.getDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, 5);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField24.getAsText(0, locale26);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61852896422000L) + "'", long20 == (-61852896422000L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(12, 9700, 3, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, (org.joda.time.ReadableInstant) instant4);
        org.joda.time.Instant instant7 = instant4.withMillis((long) (short) 1);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant10 = instant7.withDurationAdded(readableDuration8, (int) (short) 100);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant10.plus(readableDuration11);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        boolean boolean77 = remainderDateTimeField76.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        try {
            int int18 = unsupportedDateTimeField16.getMaximumValue((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology25 = iSOChronology24.withUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField28 = julianChronology27.months();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology27);
        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.year();
        org.joda.time.DurationField durationField31 = julianChronology27.weeks();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology27.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField34 = julianChronology33.months();
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology33);
        org.joda.time.DateTimeField dateTimeField36 = julianChronology33.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology27, dateTimeField36, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipUndoDateTimeField38.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, dateTimeFieldType39, (int) (short) -1);
        int int43 = offsetDateTimeField41.get((long) 9);
        org.joda.time.ReadablePartial readablePartial44 = null;
        int[] intArray49 = new int[] { 9, (-25200000), (short) 10, 0 };
        int int50 = offsetDateTimeField41.getMaximumValue(readablePartial44, intArray49);
        java.util.Locale locale52 = null;
        try {
            int[] intArray53 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) timeOfDay22, (-3), intArray49, "5073", locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 30 + "'", int50 == 30);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        java.lang.String str78 = remainderDateTimeField76.getName();
        int int79 = remainderDateTimeField76.getMinimumValue();
        java.util.Locale locale81 = null;
        java.lang.String str82 = remainderDateTimeField76.getAsShortText((long) (-3), locale81);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "year" + "'", str78.equals("year"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "9" + "'", str82.equals("9"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        int int8 = mutableDateTime7.getDayOfMonth();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 28 + "'", int8 == 28);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        try {
            int int18 = unsupportedDateTimeField16.getMaximumValue((long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 4, 132L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 136L + "'", long2 == 136L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        long long20 = skipUndoDateTimeField11.set(0L, 9);
        org.joda.time.DurationField durationField21 = skipUndoDateTimeField11.getRangeDurationField();
        java.lang.String str22 = skipUndoDateTimeField11.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61852896422000L) + "'", long20 == (-61852896422000L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[year]" + "'", str22.equals("DateTimeField[year]"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        mutableDateTime7.setMillis((long) 35);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        int[] intArray24 = new int[] {};
        try {
            int[] intArray26 = unsupportedDateTimeField16.addWrapField((org.joda.time.ReadablePartial) timeOfDay22, 86399, intArray24, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        long long79 = remainderDateTimeField76.add((long) 21685927, 21682);
        try {
            long long82 = remainderDateTimeField76.set((long) 16, 361);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 361 for year must be in the range [0,34]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 684231858085927L + "'", long79 == 684231858085927L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        java.lang.Object obj5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekyear();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.joda.time.MutableDateTime mutableDateTime11 = property8.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str13 = mutableDateTime11.toString(dateTimeFormatter12);
        org.joda.time.Instant instant15 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = instant15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField18 = julianChronology17.months();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.year();
        org.joda.time.DurationField durationField21 = julianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology17.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology17, dateTimeField26, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField28.getType();
        int int30 = instant15.get(dateTimeFieldType29);
        mutableDateTime11.set(dateTimeFieldType29, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType29, (-2018), 16, 86399);
        long long38 = offsetDateTimeField36.roundFloor((long) 86399);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-29T00:00:00.000-08:00" + "'", str13.equals("1969-12-29T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 86399L + "'", long38 == 86399L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-2018));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: -2018");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1836085927L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 158426957332800000L + "'", long1 == 158426957332800000L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) timeOfDay22, (int) (byte) 100, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean15 = julianChronology0.equals((java.lang.Object) dateTimeFormatter14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) julianChronology16);
        java.lang.Object obj19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(obj19, dateTimeZone20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.weekyear();
        mutableDateTime21.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant26 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone27 = instant26.getZone();
        org.joda.time.Instant instant29 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant26, (org.joda.time.ReadableInstant) instant29);
        mutableDateTime21.setTime((org.joda.time.ReadableInstant) instant29);
        java.util.Locale locale32 = null;
        java.util.Calendar calendar33 = mutableDateTime21.toCalendar(locale32);
        java.lang.Object obj34 = mutableDateTime21.clone();
        boolean boolean35 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter18, (java.lang.Object) mutableDateTime21);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(calendar33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        java.lang.String str78 = remainderDateTimeField76.getName();
        int int79 = remainderDateTimeField76.getMinimumValue();
        long long82 = remainderDateTimeField76.addWrapField(0L, (int) '#');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "year" + "'", str78.equals("year"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            mutableDateTime7.add(durationFieldType9, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292275054L) + "'", long8 == (-292275054L));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.lang.String str34 = offsetDateTimeField32.getAsShortText((long) (-292269054));
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.DurationField durationField39 = julianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField42 = julianChronology41.months();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology41);
        org.joda.time.DateTimeField dateTimeField44 = julianChronology41.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField44, 4);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField46.getAsShortText(readablePartial47, (int) (short) -1, locale49);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.DurationField durationField55 = julianChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology51.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField58 = julianChronology57.months();
        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology57);
        org.joda.time.DateTimeField dateTimeField60 = julianChronology57.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology51, dateTimeField60, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = skipUndoDateTimeField62.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField46, dateTimeFieldType63, 3104, (-292269054), 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType63);
        try {
            long long71 = delegatedDateTimeField68.set((long) (-28800000), 3104);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3104 for year must be in the range [-292265950,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5073" + "'", str34.equals("5073"));
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        try {
            long long10 = julianChronology0.getDateTimeMillis((-2), (-292275054), (int) (short) 0, 1969, (-3), 30, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "weekyear", "1969-12-29T00:00:00.000-08:00");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder2.appendDayOfMonth(5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder2.appendFractionOfSecond((-1969), 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        try {
            java.lang.String str18 = unsupportedDateTimeField16.getAsText((long) 21692);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("5073", 3500);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder0.setFixedSavings("UTC", (int) ' ');
        java.io.OutputStream outputStream11 = null;
        try {
            dateTimeZoneBuilder0.writeTo("9", outputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.minusHours((int) (byte) 1);
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withMinuteOfHour(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant3 = instant1.withMillis((long) '4');
        org.joda.time.MutableDateTime mutableDateTime4 = instant1.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(30384000005L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone3 = instant2.getZone();
        org.joda.time.DateTime dateTime4 = instant2.toDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
        java.lang.Class<?> wildcardClass6 = dateTime4.getClass();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = dateTimeFormatter0.parseMutableDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-365T16:00:00-08:00" + "'", str7.equals("1969-365T16:00:00-08:00"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        java.lang.Object obj3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
        int int6 = mutableDateTime5.getDayOfMonth();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
        int int14 = dateTimeZone11.getOffsetFromLocal((long) 361);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        long long19 = dateTimeZone15.convertLocalToUTC((long) 1, false, (-9223331333227200000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 18 + "'", int6 == 18);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        int int3 = mutableDateTime2.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        int int6 = mutableDateTime2.getSecondOfMinute();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("year");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"year\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours(1970);
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfMonth(3);
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withTime((int) (byte) 100, (-292275054), (int) (byte) 100, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1969-12-29T00:00:00.000-08:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-29T00:00:00.000-08:00\" is malformed at \"69-12-29T00:00:00.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        int int33 = skipUndoDateTimeField11.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-292269054) + "'", int33 == (-292269054));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
        try {
            mutableDateTime4.setDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, (org.joda.time.ReadableInstant) instant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant4.minus(readableDuration6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        long long20 = skipUndoDateTimeField11.set(0L, 9);
        boolean boolean22 = skipUndoDateTimeField11.isLeap((long) 3);
        int int24 = skipUndoDateTimeField11.get(86399L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61852896422000L) + "'", long20 == (-61852896422000L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(3, (-292275054), (int) (byte) -1, 86399, (int) (byte) 1, 86399, 21685927);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        long long39 = dividedDateTimeField37.roundFloor((long) 21682);
        int int40 = dividedDateTimeField37.getMinimumValue();
        try {
            long long43 = dividedDateTimeField37.add(10L, 63695916082768L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2229357062896880");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-314467200000L) + "'", long39 == (-314467200000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-8350545) + "'", int40 == (-8350545));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.append(dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfDay(3500, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendHourOfHalfday(3104);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendTimeZoneOffset("2019", false, (-25200000), 21695074);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology5 = dateTimeFormatter4.getChronology();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter4.getZone();
        java.lang.Object obj7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, dateTimeZone8);
        int int10 = mutableDateTime9.getDayOfMonth();
        int int13 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "hi!", (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter4.withZone(dateTimeZone15);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(chronology5);
        org.junit.Assert.assertNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.util.Locale locale17 = null;
        try {
            int int18 = unsupportedDateTimeField16.getMaximumTextLength(locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        int int3 = mutableDateTime2.getMinuteOfDay();
        int int4 = mutableDateTime2.getSecondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology5);
        mutableDateTime2.setChronology((org.joda.time.Chronology) iSOChronology5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 480 + "'", int3 == 480);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 28800 + "'", int4 == 28800);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = skipUndoDateTimeField11.getMaximumValue(readablePartial16);
        long long20 = skipUndoDateTimeField11.addWrapField((-210780360000000L), 292278993);
        java.lang.String str22 = skipUndoDateTimeField11.getAsText((long) (-8350545));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272992 + "'", int17 == 292272992);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9223331333227200000L) + "'", long20 == (-9223331333227200000L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969" + "'", str22.equals("1969"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        java.lang.Object obj3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
        int int6 = mutableDateTime5.getDayOfMonth();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
        int int14 = dateTimeZone11.getOffsetFromLocal((long) 361);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 18 + "'", int6 == 18);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.weekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = instant8.getZone();
//        java.lang.String str11 = dateTimeZone9.getName((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        int int15 = dateTimeZone12.getOffsetFromLocal(292279993L);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(21692, (-8350545), (-25200000), 0, (-292269054), 21685927, (int) (byte) 10, dateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269054 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        java.lang.String str78 = remainderDateTimeField76.getName();
        int int79 = remainderDateTimeField76.getMaximumValue();
        int int81 = remainderDateTimeField76.getMaximumValue((long) 4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "year" + "'", str78.equals("year"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 34 + "'", int79 == 34);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 34 + "'", int81 == 34);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getYearOfEra();
        org.joda.time.DateTime dateTime5 = dateTime2.minusWeeks((-292275054));
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField16.getAsText((int) (byte) 10, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField25 = julianChronology24.months();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology24);
        org.joda.time.DateTimeField dateTimeField27 = julianChronology24.year();
        org.joda.time.DurationField durationField28 = julianChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology24.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField31 = julianChronology30.months();
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology30);
        org.joda.time.DateTimeField dateTimeField33 = julianChronology30.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology24, dateTimeField33, 4);
        long long37 = skipUndoDateTimeField35.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField35.getAsShortText(readablePartial38, 21682, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray44 = new int[] { 1970 };
        int int45 = skipUndoDateTimeField35.getMaximumValue(readablePartial42, intArray44);
        try {
            int[] intArray47 = unsupportedDateTimeField16.addWrapField((org.joda.time.ReadablePartial) timeOfDay22, 18, intArray44, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1152000000L + "'", long37 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "21682" + "'", str41.equals("21682"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292272992 + "'", int45 == 292272992);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withYear((int) ' ');
        org.joda.time.Instant instant6 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = instant6.getZone();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField9 = julianChronology8.months();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.year();
        org.joda.time.DurationField durationField12 = julianChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology8.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField15 = julianChronology14.months();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology14.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField17, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField19.getType();
        int int21 = instant6.get(dateTimeFieldType20);
        org.joda.time.DateTime dateTime23 = dateTime2.withField(dateTimeFieldType20, (int) (short) 0);
        org.joda.time.DateTime dateTime25 = dateTime2.withYearOfCentury((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.set(0);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsShortText(locale7);
        int int9 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        long long20 = skipUndoDateTimeField11.set(0L, 9);
        int int22 = skipUndoDateTimeField11.getMaximumValue(0L);
        long long24 = skipUndoDateTimeField11.roundHalfEven((long) (short) 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61852896422000L) + "'", long20 == (-61852896422000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272992 + "'", int22 == 292272992);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1152000000L + "'", long24 == 1152000000L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3, (int) (short) 100);
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime2.add(readableDuration6, (int) (short) 1);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(3);
        java.lang.Appendable appendable3 = null;
        java.lang.Object obj4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj4, dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.weekyear();
        java.lang.String str8 = property7.getAsText();
        org.joda.time.MutableDateTime mutableDateTime10 = property7.add(10);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) mutableDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970" + "'", str8.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.Chronology chronology9 = buddhistChronology4.withZone(dateTimeZone5);
        try {
            long long14 = buddhistChronology4.getDateTimeMillis((int) (byte) 10, (int) (byte) -1, 21682, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (-101), (-8350545), 1969);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-1L));
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTimeISO();
        long long4 = instant1.getMillis();
        boolean boolean5 = instant1.isEqualNow();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        org.joda.time.Instant instant19 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone20 = instant19.getZone();
        org.joda.time.DateTime dateTime21 = instant19.toDateTimeISO();
        org.joda.time.DateTime.Property property22 = dateTime21.weekyear();
        org.joda.time.TimeOfDay timeOfDay23 = dateTime21.toTimeOfDay();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) timeOfDay23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(timeOfDay23);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019", (int) (byte) 10, 35, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for 2019 must be in the range [35,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1009843200000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("Coordinated Universal Time");
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField13 = julianChronology12.months();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology12);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology12.year();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology12.millisOfDay();
        java.lang.Object obj17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(obj17, dateTimeZone18);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.weekyear();
        java.util.Locale locale21 = null;
        int int22 = property20.getMaximumTextLength(locale21);
        org.joda.time.MutableDateTime mutableDateTime23 = property20.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str25 = mutableDateTime23.toString(dateTimeFormatter24);
        org.joda.time.Instant instant27 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone28 = instant27.getZone();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.DurationField durationField33 = julianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology29.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology29, dateTimeField38, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipUndoDateTimeField40.getType();
        int int42 = instant27.get(dateTimeFieldType41);
        mutableDateTime23.set(dateTimeFieldType41, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType41, (-2018), 16, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder11.appendFixedSignedDecimal(dateTimeFieldType41, 3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str25.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1970 + "'", int42 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("Coordinated Universal Time");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendTwoDigitYear(10);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long6 = dateTimeZone4.convertUTCToLocal((long) 'a');
        java.lang.String str7 = dateTimeZone4.getID();
        org.joda.time.Chronology chronology8 = iSOChronology1.withZone(dateTimeZone4);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) iSOChronology1, locale9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField12 = julianChronology11.months();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology11);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology11.year();
        org.joda.time.DurationField durationField15 = julianChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology11.secondOfMinute();
        dateTimeParserBucket10.saveField(dateTimeField16, (int) (byte) -1);
        java.lang.Object obj19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(obj19, dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant27 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone28 = instant27.getZone();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.DurationField durationField33 = julianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology29.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology29, dateTimeField38, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipUndoDateTimeField40.getType();
        int int42 = instant27.get(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendText(dateTimeFieldType41);
        mutableDateTime21.set(dateTimeFieldType41, 10);
        java.util.Locale locale47 = null;
        dateTimeParserBucket10.saveField(dateTimeFieldType41, "-1", locale47);
        org.joda.time.Chronology chronology49 = dateTimeParserBucket10.getChronology();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1970 + "'", int42 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(chronology49);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = instant8.getZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField11 = julianChronology10.months();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology10.year();
        org.joda.time.DurationField durationField14 = julianChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology10.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField19, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField21.getType();
        int int23 = instant8.get(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType22);
        mutableDateTime2.set(dateTimeFieldType22, 10);
        try {
            mutableDateTime2.setTime(4, 9, (-1969), 361);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1969 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) (-28800000));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800000L + "'", long2 == 28800000L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        org.joda.time.Instant instant17 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone18 = instant17.getZone();
        org.joda.time.DateTime dateTime19 = instant17.toDateTimeISO();
        org.joda.time.DateTime.Property property20 = dateTime19.weekyear();
        org.joda.time.TimeOfDay timeOfDay21 = dateTime19.toTimeOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = iSOChronology23.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField27 = julianChronology26.months();
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology26);
        org.joda.time.DateTimeField dateTimeField29 = julianChronology26.year();
        org.joda.time.DurationField durationField30 = julianChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology26.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField33 = julianChronology32.months();
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology32);
        org.joda.time.DateTimeField dateTimeField35 = julianChronology32.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology26, dateTimeField35, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType38, (int) (short) -1);
        int int42 = offsetDateTimeField40.get((long) 9);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray48 = new int[] { 9, (-25200000), (short) 10, 0 };
        int int49 = offsetDateTimeField40.getMaximumValue(readablePartial43, intArray48);
        try {
            int[] intArray51 = skipUndoDateTimeField11.add((org.joda.time.ReadablePartial) timeOfDay21, (-1), intArray48, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(timeOfDay21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 30 + "'", int49 == 30);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendTimeZoneOffset("2019", "year", false, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField(0);
        int int6 = mutableDateTime5.getRoundingMode();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = instant10.getZone();
        org.joda.time.DateTime dateTime12 = instant10.toDateTimeISO();
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        org.joda.time.TimeOfDay timeOfDay14 = dateTime12.toTimeOfDay();
        try {
            int int15 = property7.compareTo((org.joda.time.ReadablePartial) timeOfDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(timeOfDay14);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = instant3.getZone();
        org.joda.time.DateTime dateTime5 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime5.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(timeOfDay7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((long) (-1), chronology1, locale2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField8 = julianChronology7.months();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.year();
        org.joda.time.DurationField durationField11 = julianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField14 = julianChronology13.months();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology13.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField16, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipUndoDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType19, (int) (short) -1);
        java.util.Locale locale23 = null;
        dateTimeParserBucket3.saveField(dateTimeFieldType19, "ISOChronology[UTC]", locale23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeParserBucket3.getZone();
        java.lang.Integer int26 = dateTimeParserBucket3.getOffsetInteger();
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNull(int26);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 3500);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        long long6 = julianChronology0.add(0L, 3395L, 1969);
        org.joda.time.Instant instant8 = new org.joda.time.Instant((-1L));
        org.joda.time.MutableDateTime mutableDateTime9 = instant8.toMutableDateTime();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) mutableDateTime9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6684755L + "'", long6 == 6684755L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        long long79 = remainderDateTimeField76.roundHalfCeiling(28799999L);
        try {
            long long82 = remainderDateTimeField76.set((long) 86399, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for year must be in the range [0,34]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1152000000L + "'", long79 == 1152000000L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 1, (java.lang.Number) 63504000012L, (java.lang.Number) 9L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendCenturyOfEra(3500, (int) ' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfHour((int) 'a', 35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        java.lang.Object obj5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekyear();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.joda.time.MutableDateTime mutableDateTime11 = property8.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str13 = mutableDateTime11.toString(dateTimeFormatter12);
        org.joda.time.Instant instant15 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = instant15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField18 = julianChronology17.months();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.year();
        org.joda.time.DurationField durationField21 = julianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology17.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology17, dateTimeField26, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField28.getType();
        int int30 = instant15.get(dateTimeFieldType29);
        mutableDateTime11.set(dateTimeFieldType29, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType29, (-2018), 16, 86399);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField36.getType();
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField36.getAsShortText((-1), locale39);
        long long42 = offsetDateTimeField36.roundHalfFloor((long) 3500);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str13.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-1" + "'", str40.equals("-1"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3500L + "'", long42 == 3500L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        try {
            int int23 = unsupportedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        try {
            long long80 = remainderDateTimeField76.set(86399L, "JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.lang.String str34 = offsetDateTimeField32.getAsShortText((long) (-292269054));
        long long37 = offsetDateTimeField32.addWrapField((-210780360000000L), (int) (byte) -1);
        long long39 = offsetDateTimeField32.roundCeiling((long) 5);
        org.joda.time.DurationField durationField40 = offsetDateTimeField32.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5073" + "'", str34.equals("5073"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-210811896000000L) + "'", long37 == (-210811896000000L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1152000000L + "'", long39 == 1152000000L);
        org.junit.Assert.assertNull(durationField40);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = instant3.getZone();
        org.joda.time.DateTime dateTime5 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime5.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) timeOfDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(timeOfDay7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        int int13 = skipUndoDateTimeField11.getMinimumValue((long) (short) 10);
        long long16 = skipUndoDateTimeField11.add((long) 0, 28800);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292269054) + "'", int13 == (-292269054));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 908858876400000L + "'", long16 == 908858876400000L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str8 = mutableDateTime6.toString(dateTimeFormatter7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.era();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str8.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField(0);
        int int6 = mutableDateTime5.getRoundingMode();
        boolean boolean8 = mutableDateTime5.isAfter((long) 292272992);
        mutableDateTime5.add(1836085927L);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendCenturyOfEra(3500, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder21.appendDayOfWeek((int) '4');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder21.appendTimeZoneShortName(strMap29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder21.appendMinuteOfHour((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology34 = dateTimeFormatter33.getChronology();
        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter33.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder21.appendOptional(dateTimeParser36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder14.appendOptional(dateTimeParser36);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParser36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNull(chronology34);
        org.junit.Assert.assertNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = unsupportedDateTimeField16.getAsShortText((long) (-292275054), locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.append(dateTimePrinter11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        java.lang.String str19 = skipUndoDateTimeField11.getAsText(63504000012L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1971" + "'", str19.equals("1971"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        try {
            long long12 = julianChronology0.getDateTimeMillis(21695074, 1, 480, (-1969), 0, (int) 'a', (-8350545));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField1, (-2018));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-795411611683621984L), (java.lang.Number) 292278993L, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        long long20 = skipUndoDateTimeField11.set(0L, 9);
        boolean boolean21 = skipUndoDateTimeField11.isSupported();
        org.joda.time.DurationField durationField22 = skipUndoDateTimeField11.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61852896422000L) + "'", long20 == (-61852896422000L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-25200000));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.2083333335d + "'", double1 == 2440587.2083333335d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean2 = dateTimeFormatter1.isOffsetParsed();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("DateTimeField[year]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-1L));
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        long long16 = skipUndoDateTimeField14.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField14.getAsShortText(readablePartial17, 21682, locale19);
        mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14, (int) (short) 1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1152000000L + "'", long16 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "21682" + "'", str20.equals("21682"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-1969), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2069L) + "'", long2 == (-2069L));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        long long35 = offsetDateTimeField32.set((long) 16, (-25200000));
        java.util.Locale locale36 = null;
        int int37 = offsetDateTimeField32.getMaximumShortTextLength(locale36);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-795411611683621984L) + "'", long35 == (-795411611683621984L));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        java.lang.Object obj5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekyear();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.joda.time.MutableDateTime mutableDateTime11 = property8.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str13 = mutableDateTime11.toString(dateTimeFormatter12);
        org.joda.time.Instant instant15 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = instant15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField18 = julianChronology17.months();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.year();
        org.joda.time.DurationField durationField21 = julianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology17.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology17, dateTimeField26, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField28.getType();
        int int30 = instant15.get(dateTimeFieldType29);
        mutableDateTime11.set(dateTimeFieldType29, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType29, (-2018), 16, 86399);
        long long39 = offsetDateTimeField36.getDifferenceAsLong(1560344493587L, (-176766705562021999L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str13.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 176768265906515586L + "'", long39 == 176768265906515586L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        org.joda.time.MutableDateTime mutableDateTime13 = instant10.toMutableDateTimeISO();
        long long14 = instant10.getMillis();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        boolean boolean16 = skipUndoDateTimeField11.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField8 = julianChronology7.months();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.year();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology7.millisOfDay();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-8350545), 86399, 100, 3104, 970, (-292269054), (-3), (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3104 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 5, (long) 3104);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3109L + "'", long2 == 3109L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-8350545));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4033501735d + "'", double1 == 2440587.4033501735d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        long long79 = remainderDateTimeField76.add((long) 21685927, 21682);
        long long81 = remainderDateTimeField76.remainder((long) 5);
        long long83 = remainderDateTimeField76.roundHalfCeiling((long) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 684231858085927L + "'", long79 == 684231858085927L);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 30384000005L + "'", long81 == 30384000005L);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1152000000L + "'", long83 == 1152000000L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-210811896000000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 635L + "'", long1 == 635L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        java.util.TimeZone timeZone10 = dateTimeZone9.toTimeZone();
        java.lang.Object obj11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(obj11, dateTimeZone12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.weekyear();
        mutableDateTime13.addWeekyears((int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime13);
        java.util.TimeZone timeZone18 = dateTimeZone9.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long22 = dateTimeZone20.convertUTCToLocal((long) 'a');
        long long24 = dateTimeZone9.getMillisKeepLocal(dateTimeZone20, (-9223331333227200000L));
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(100, 0, 292278993, 28, 0, 1970, 100, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9223331333255578000L) + "'", long24 == (-9223331333255578000L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
//        int int6 = mutableDateTime5.getDayOfMonth();
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
//        int int14 = dateTimeZone11.getOffsetFromLocal((long) 361);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.lang.String str17 = dateTimeZone11.getName((long) 3500);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) (short) 0, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter0.printTo(writer4, (long) 292272992);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        try {
            long long22 = unsupportedDateTimeField16.roundCeiling((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        java.util.Locale locale13 = null;
        java.util.Calendar calendar14 = mutableDateTime2.toCalendar(locale13);
        mutableDateTime2.addMillis(361);
        boolean boolean18 = mutableDateTime2.isBefore((-795411611683621984L));
        int int19 = mutableDateTime2.getYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(calendar14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 3109L, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4) + "'", int1 == (-4));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(3);
        java.lang.Appendable appendable3 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone6 = instant5.getZone();
        org.joda.time.DateTime dateTime7 = instant5.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.weekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds((-1));
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        try {
            mutableDateTime2.setMonthOfYear(28);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        boolean boolean4 = dateTimeZone2.isStandardOffset(28799999L);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone2.getName(0L, locale6);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 21692);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 21692");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField5 = julianChronology4.months();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.year();
        dateTimeParserBucket3.saveField(dateTimeField7, 1);
        dateTimeParserBucket3.setOffset((java.lang.Integer) 21685927);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        java.util.Locale locale14 = null;
        try {
            dateTimeParserBucket3.saveField(dateTimeFieldType12, "5073", locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfMinute();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.millisOfSecond();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970" + "'", str4.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.Permission permission2 = null;
        boolean boolean3 = jodaTimePermission1.implies(permission2);
        java.lang.String str4 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str6 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(970, 28, (-1969), 0, 34, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        try {
            int int18 = unsupportedDateTimeField16.get((long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.era();
        mutableDateTime7.setSecondOfDay((int) 'a');
        org.joda.time.DateTime dateTime11 = mutableDateTime7.toDateTime();
        int int12 = mutableDateTime7.getDayOfMonth();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(0L);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField(0);
        int int6 = mutableDateTime5.getRoundingMode();
        try {
            mutableDateTime5.setDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969-12-29T00:00:00.000-08:00");
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        long long4 = durationField1.subtract((long) (-8350545), 136L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-82264750545L) + "'", long4 == (-82264750545L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField5 = julianChronology0.minutes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        java.lang.String str78 = remainderDateTimeField76.getName();
        boolean boolean79 = remainderDateTimeField76.isLenient();
        long long81 = remainderDateTimeField76.roundHalfCeiling((long) (-4));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "year" + "'", str78.equals("year"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1152000000L + "'", long81 == 1152000000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime2.year();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.dayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.lang.String str34 = offsetDateTimeField32.getAsShortText((long) (-292269054));
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.DurationField durationField39 = julianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField42 = julianChronology41.months();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology41);
        org.joda.time.DateTimeField dateTimeField44 = julianChronology41.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField44, 4);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField46.getAsShortText(readablePartial47, (int) (short) -1, locale49);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.DurationField durationField55 = julianChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology51.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField58 = julianChronology57.months();
        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology57);
        org.joda.time.DateTimeField dateTimeField60 = julianChronology57.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology51, dateTimeField60, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = skipUndoDateTimeField62.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField46, dateTimeFieldType63, 3104, (-292269054), 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType63);
        int int69 = offsetDateTimeField32.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5073" + "'", str34.equals("5073"));
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-292265950) + "'", int69 == (-292265950));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str8 = mutableDateTime6.toString(dateTimeFormatter7);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = instant10.getZone();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField13 = julianChronology12.months();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology12);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology12.year();
        org.joda.time.DurationField durationField16 = julianChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology12.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField19 = julianChronology18.months();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology18.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField21, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipUndoDateTimeField23.getType();
        int int25 = instant10.get(dateTimeFieldType24);
        mutableDateTime6.set(dateTimeFieldType24, 10);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField29 = julianChronology28.months();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology28);
        org.joda.time.DateTimeField dateTimeField31 = julianChronology28.year();
        org.joda.time.DurationField durationField32 = julianChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology28.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField35 = julianChronology34.months();
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology34);
        org.joda.time.DateTimeField dateTimeField37 = julianChronology34.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology28, dateTimeField37, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField39.getType();
        long long42 = skipUndoDateTimeField39.remainder(1L);
        int int45 = skipUndoDateTimeField39.getDifference(132L, 63695916082768L);
        long long48 = skipUndoDateTimeField39.set(0L, 9);
        org.joda.time.DurationField durationField49 = skipUndoDateTimeField39.getRangeDurationField();
        org.joda.time.DurationField durationField50 = skipUndoDateTimeField39.getDurationField();
        java.lang.Object obj51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime(obj51, dateTimeZone52);
        org.joda.time.MutableDateTime.Property property54 = mutableDateTime53.weekyear();
        java.util.Locale locale55 = null;
        int int56 = property54.getMaximumTextLength(locale55);
        org.joda.time.MutableDateTime mutableDateTime57 = property54.roundCeiling();
        org.joda.time.DurationField durationField58 = property54.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField59 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType24, durationField50, durationField58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str8.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 30384000001L + "'", long42 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-2018) + "'", int45 == (-2018));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61852896422000L) + "'", long48 == (-61852896422000L));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime57);
        org.junit.Assert.assertNotNull(durationField58);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = iSOChronology20.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, dateTimeFieldType35, (int) (short) -1);
        int int39 = offsetDateTimeField37.get((long) 9);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray45 = new int[] { 9, (-25200000), (short) 10, 0 };
        int int46 = offsetDateTimeField37.getMaximumValue(readablePartial40, intArray45);
        java.util.Locale locale48 = null;
        try {
            int[] intArray49 = unsupportedDateTimeField16.set(readablePartial18, (-292269054), intArray45, "1969-365", locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 30 + "'", int46 == 30);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.millisOfSecond();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.minuteOfHour();
        try {
            mutableDateTime6.setMinuteOfHour(9700);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970" + "'", str4.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("5073", dateTimeFormatter1);
        int int3 = dateTimeFormatter1.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.lang.Appendable appendable1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(obj2, dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.weekyear();
        mutableDateTime4.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone10 = instant9.getZone();
        org.joda.time.Instant instant12 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant9, (org.joda.time.ReadableInstant) instant12);
        mutableDateTime4.setTime((org.joda.time.ReadableInstant) instant12);
        mutableDateTime4.addMonths((-1));
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        mutableDateTime2.add(10L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = instant8.getZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField11 = julianChronology10.months();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology10.year();
        org.joda.time.DurationField durationField14 = julianChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology10.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology10, dateTimeField19, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField21.getType();
        int int23 = instant8.get(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType22);
        mutableDateTime2.set(dateTimeFieldType22, 10);
        java.util.Locale locale28 = null;
        java.lang.String str29 = mutableDateTime2.toString("10", locale28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "10" + "'", str29.equals("10"));
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getName(0L, locale5);
//        long long9 = dateTimeZone1.adjustOffset((long) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.weekyear();
//        java.util.Locale locale18 = null;
//        int int19 = property17.getMaximumTextLength(locale18);
//        org.joda.time.MutableDateTime mutableDateTime20 = property17.roundHalfEven();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField22 = julianChronology21.months();
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology21);
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology21.year();
//        org.joda.time.DurationField durationField25 = julianChronology21.weeks();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = julianChronology27.months();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology27);
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField30, 4);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField32.getAsShortText(readablePartial33, (int) (short) -1, locale35);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = julianChronology37.months();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology37);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology37.year();
//        org.joda.time.DurationField durationField41 = julianChronology37.weeks();
//        org.joda.time.DateTimeField dateTimeField42 = julianChronology37.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = julianChronology43.months();
//        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology43.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology37, dateTimeField46, 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipUndoDateTimeField48.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField32, dateTimeFieldType49, 3104, (-292269054), 0);
//        mutableDateTime20.set(dateTimeFieldType49, 1970);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField56 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType49);
//        boolean boolean58 = zeroIsMaxDateTimeField56.isLeap((long) (byte) 10);
//        long long60 = zeroIsMaxDateTimeField56.roundFloor((long) (-1969));
//        long long62 = zeroIsMaxDateTimeField56.roundFloor(705L);
//        try {
//            long long65 = zeroIsMaxDateTimeField56.set((long) 9, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for year must be in the range [1,1000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-1969L) + "'", long60 == (-1969L));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 705L + "'", long62 == 705L);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = unsupportedDateTimeField16.getAsText(3, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField17.getRangeDurationField();
        long long21 = offsetDateTimeField17.add(1009843200000L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1009843200000L + "'", long21 == 1009843200000L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField11.getType();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        java.lang.String str21 = unsupportedDateTimeField16.toString();
        org.joda.time.Instant instant23 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime24 = instant23.toDateTime();
        org.joda.time.DateTime dateTime26 = dateTime24.withYear((int) ' ');
        org.joda.time.DateTime dateTime28 = dateTime24.plusHours((int) (byte) 100);
        org.joda.time.DateTime.Property property29 = dateTime24.dayOfWeek();
        org.joda.time.LocalDate localDate30 = dateTime24.toLocalDate();
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = unsupportedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate30, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDateTimeField" + "'", str21.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(localDate30);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = unsupportedDateTimeField16.getAsText((-292265950), locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime9 = property3.add((long) (short) -1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970" + "'", str4.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        java.lang.Object obj5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj5, dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.weekyear();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.joda.time.MutableDateTime mutableDateTime11 = property8.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str13 = mutableDateTime11.toString(dateTimeFormatter12);
        org.joda.time.Instant instant15 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = instant15.getZone();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField18 = julianChronology17.months();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.year();
        org.joda.time.DurationField durationField21 = julianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology17.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology17, dateTimeField26, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField28.getType();
        int int30 = instant15.get(dateTimeFieldType29);
        mutableDateTime11.set(dateTimeFieldType29, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType29, (-2018), 16, 86399);
        long long38 = offsetDateTimeField36.roundHalfEven(292278993L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str13.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 292278993L + "'", long38 == 292278993L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfHour((int) (byte) 100, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        org.joda.time.Instant instant22 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone23 = instant22.getZone();
        org.joda.time.Instant instant25 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant22, (org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant28 = instant25.withMillis((long) (short) 1);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.Instant instant31 = instant28.withDurationAdded(readableDuration29, (int) (short) 100);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant33 = instant28.plus(readableDuration32);
        org.joda.time.DateTime dateTime34 = instant28.toDateTimeISO();
        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField38 = julianChronology37.months();
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology37);
        org.joda.time.DateTimeField dateTimeField40 = julianChronology37.year();
        org.joda.time.DurationField durationField41 = julianChronology37.weeks();
        org.joda.time.DateTimeField dateTimeField42 = julianChronology37.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField44 = julianChronology43.months();
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology43);
        org.joda.time.DateTimeField dateTimeField46 = julianChronology43.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology37, dateTimeField46, 4);
        long long50 = skipUndoDateTimeField48.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial51 = null;
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipUndoDateTimeField48.getAsShortText(readablePartial51, 21682, locale53);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray57 = new int[] { 1970 };
        int int58 = skipUndoDateTimeField48.getMaximumValue(readablePartial55, intArray57);
        java.util.Locale locale60 = null;
        try {
            int[] intArray61 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) localTime35, (-1969), intArray57, "100", locale60);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(instant33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localTime35);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1152000000L + "'", long50 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "21682" + "'", str54.equals("21682"));
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 292272992 + "'", int58 == 292272992);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) -1, locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField17 = julianChronology16.months();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology16.year();
        org.joda.time.DurationField durationField20 = julianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology16.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField23 = julianChronology22.months();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = julianChronology22.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField25, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType28, 3104, (-292269054), 0);
        java.lang.String str34 = offsetDateTimeField32.getAsShortText((long) (-292269054));
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.DurationField durationField39 = julianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField42 = julianChronology41.months();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology41);
        org.joda.time.DateTimeField dateTimeField44 = julianChronology41.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology35, dateTimeField44, 4);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField46.getAsShortText(readablePartial47, (int) (short) -1, locale49);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.DurationField durationField55 = julianChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology51.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField58 = julianChronology57.months();
        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology57);
        org.joda.time.DateTimeField dateTimeField60 = julianChronology57.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology51, dateTimeField60, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = skipUndoDateTimeField62.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField46, dateTimeFieldType63, 3104, (-292269054), 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType63);
        long long71 = offsetDateTimeField32.getDifferenceAsLong((-210780360000000L), (long) '4');
        try {
            long long74 = offsetDateTimeField32.add(0L, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5173 for year must be in the range [-292265950,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "5073" + "'", str34.equals("5073"));
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "-1" + "'", str50.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-6679L) + "'", long71 == (-6679L));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("Coordinated Universal Time");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField14 = julianChronology13.months();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology13.year();
        org.joda.time.DurationField durationField17 = julianChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology13.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField20 = julianChronology19.months();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology19.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology13, dateTimeField22, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipUndoDateTimeField24.getType();
        int int28 = skipUndoDateTimeField24.getDifference((long) 3104, 0L);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField24.getAsText((int) (short) 10, locale30);
        long long33 = skipUndoDateTimeField24.roundHalfFloor((long) 4);
        long long35 = skipUndoDateTimeField24.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField37 = julianChronology36.months();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology36);
        org.joda.time.DateTimeField dateTimeField39 = julianChronology36.year();
        org.joda.time.DurationField durationField40 = julianChronology36.weeks();
        org.joda.time.DateTimeField dateTimeField41 = julianChronology36.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField43 = julianChronology42.months();
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology42);
        org.joda.time.DateTimeField dateTimeField45 = julianChronology42.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology36, dateTimeField45, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipUndoDateTimeField47.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType48, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.DurationField durationField55 = julianChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology51.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology57 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField58 = julianChronology57.months();
        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology57);
        org.joda.time.DateTimeField dateTimeField60 = julianChronology57.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology51, dateTimeField60, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = skipUndoDateTimeField62.getType();
        int int66 = skipUndoDateTimeField62.getDifference((long) 3104, 0L);
        java.util.Locale locale68 = null;
        java.lang.String str69 = skipUndoDateTimeField62.getAsText((int) (short) 10, locale68);
        long long71 = skipUndoDateTimeField62.roundHalfFloor((long) 4);
        long long73 = skipUndoDateTimeField62.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField75 = julianChronology74.months();
        org.joda.time.MutableDateTime mutableDateTime76 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology74);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology74.year();
        org.joda.time.DurationField durationField78 = julianChronology74.weeks();
        org.joda.time.DateTimeField dateTimeField79 = julianChronology74.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField81 = julianChronology80.months();
        org.joda.time.MutableDateTime mutableDateTime82 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology80);
        org.joda.time.DateTimeField dateTimeField83 = julianChronology80.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology74, dateTimeField83, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = skipUndoDateTimeField85.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField62, dateTimeFieldType86, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField89 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField50, dateTimeFieldType86);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType86, 12, 3500);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10" + "'", str31.equals("10"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1152000000L + "'", long33 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1152000000L + "'", long35 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(julianChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "10" + "'", str69.equals("10"));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1152000000L + "'", long71 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1152000000L + "'", long73 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(julianChronology80);
        org.junit.Assert.assertNotNull(durationField81);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology3, locale4);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (short) -1, (org.joda.time.Chronology) julianChronology3, locale6);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology3.yearOfEra();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(378712885927L, (org.joda.time.Chronology) julianChronology3);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("year");
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField8 = julianChronology7.months();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.year();
        org.joda.time.DurationField durationField11 = julianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology7.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField14 = julianChronology13.months();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology13.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField16, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipUndoDateTimeField18.getType();
        int int22 = skipUndoDateTimeField18.getDifference((long) 3104, 0L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField18.getAsText((int) (short) 10, locale24);
        long long27 = skipUndoDateTimeField18.roundHalfFloor((long) 4);
        long long29 = skipUndoDateTimeField18.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField31 = julianChronology30.months();
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology30);
        org.joda.time.DateTimeField dateTimeField33 = julianChronology30.year();
        org.joda.time.DurationField durationField34 = julianChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology30.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField37 = julianChronology36.months();
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology36);
        org.joda.time.DateTimeField dateTimeField39 = julianChronology36.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology30, dateTimeField39, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField41.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType42, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField46 = julianChronology45.months();
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology45);
        org.joda.time.DateTimeField dateTimeField48 = julianChronology45.year();
        org.joda.time.DurationField durationField49 = julianChronology45.weeks();
        org.joda.time.DateTimeField dateTimeField50 = julianChronology45.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField52 = julianChronology51.months();
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology51);
        org.joda.time.DateTimeField dateTimeField54 = julianChronology51.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology45, dateTimeField54, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = skipUndoDateTimeField56.getType();
        int int60 = skipUndoDateTimeField56.getDifference((long) 3104, 0L);
        java.util.Locale locale62 = null;
        java.lang.String str63 = skipUndoDateTimeField56.getAsText((int) (short) 10, locale62);
        long long65 = skipUndoDateTimeField56.roundHalfFloor((long) 4);
        long long67 = skipUndoDateTimeField56.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField69 = julianChronology68.months();
        org.joda.time.MutableDateTime mutableDateTime70 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology68);
        org.joda.time.DateTimeField dateTimeField71 = julianChronology68.year();
        org.joda.time.DurationField durationField72 = julianChronology68.weeks();
        org.joda.time.DateTimeField dateTimeField73 = julianChronology68.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField75 = julianChronology74.months();
        org.joda.time.MutableDateTime mutableDateTime76 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology74);
        org.joda.time.DateTimeField dateTimeField77 = julianChronology74.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology68, dateTimeField77, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipUndoDateTimeField79.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField82 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField56, dateTimeFieldType80, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField83 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField44, dateTimeFieldType80);
        org.joda.time.DurationField durationField84 = remainderDateTimeField83.getRangeDurationField();
        java.lang.String str85 = remainderDateTimeField83.getName();
        boolean boolean86 = remainderDateTimeField83.isLenient();
        mutableDateTime6.setRounding((org.joda.time.DateTimeField) remainderDateTimeField83);
        org.joda.time.MutableDateTime mutableDateTime88 = mutableDateTime6.copy();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970" + "'", str4.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1152000000L + "'", long27 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1152000000L + "'", long29 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10" + "'", str63.equals("10"));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1152000000L + "'", long65 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1152000000L + "'", long67 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology68);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "year" + "'", str85.equals("year"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(mutableDateTime88);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYear(21692, 3500);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.addMonths((-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = instant31.getZone();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField34 = julianChronology33.months();
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology33);
        org.joda.time.DateTimeField dateTimeField36 = julianChronology33.year();
        org.joda.time.DurationField durationField37 = julianChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology33.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField40 = julianChronology39.months();
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology39);
        org.joda.time.DateTimeField dateTimeField42 = julianChronology39.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology33, dateTimeField42, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipUndoDateTimeField44.getType();
        int int46 = instant31.get(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType45);
        org.joda.time.MutableDateTime.Property property49 = mutableDateTime2.property(dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology51 = iSOChronology50.withUTC();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField54 = julianChronology53.months();
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology53);
        org.joda.time.DateTimeField dateTimeField56 = julianChronology53.year();
        org.joda.time.DurationField durationField57 = julianChronology53.weeks();
        org.joda.time.DateTimeField dateTimeField58 = julianChronology53.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField60 = julianChronology59.months();
        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology59);
        org.joda.time.DateTimeField dateTimeField62 = julianChronology59.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField64 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology53, dateTimeField62, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = skipUndoDateTimeField64.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, dateTimeFieldType65, (int) (short) -1);
        org.joda.time.DurationField durationField68 = offsetDateTimeField67.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField69 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, durationField68);
        long long72 = unsupportedDateTimeField69.add(0L, (-292265950));
        java.util.Locale locale74 = null;
        try {
            java.lang.String str75 = unsupportedDateTimeField69.getAsShortText(63684345600000L, locale74);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1970 + "'", int46 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField69);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-768585213043200000L) + "'", long72 == (-768585213043200000L));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.addWeekyears((int) 'a');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour((int) (byte) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField39 = julianChronology38.months();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology38);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology38.year();
        org.joda.time.DurationField durationField42 = julianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology38.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField45 = julianChronology44.months();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology44);
        org.joda.time.DateTimeField dateTimeField47 = julianChronology44.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology38, dateTimeField47, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = skipUndoDateTimeField49.getType();
        int int53 = skipUndoDateTimeField49.getDifference((long) 3104, 0L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField49.getAsText((int) (short) 10, locale55);
        long long58 = skipUndoDateTimeField49.roundHalfFloor((long) 4);
        long long60 = skipUndoDateTimeField49.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField62 = julianChronology61.months();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology61);
        org.joda.time.DateTimeField dateTimeField64 = julianChronology61.year();
        org.joda.time.DurationField durationField65 = julianChronology61.weeks();
        org.joda.time.DateTimeField dateTimeField66 = julianChronology61.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField68 = julianChronology67.months();
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology67);
        org.joda.time.DateTimeField dateTimeField70 = julianChronology67.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology61, dateTimeField70, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = skipUndoDateTimeField72.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType73, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37, dateTimeFieldType73);
        org.joda.time.DurationField durationField77 = remainderDateTimeField76.getRangeDurationField();
        java.lang.String str78 = remainderDateTimeField76.getName();
        boolean boolean79 = remainderDateTimeField76.isLenient();
        org.joda.time.DurationField durationField80 = remainderDateTimeField76.getRangeDurationField();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField82 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField76, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1152000000L + "'", long58 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1152000000L + "'", long60 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "year" + "'", str78.equals("year"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(durationField80);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plus(0L);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDayOfYear((-1969));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1969 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        long long20 = offsetDateTimeField17.addWrapField((long) 21685927, (int) '4');
        long long22 = offsetDateTimeField17.roundHalfEven(684231858085927L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1836085927L + "'", long20 == 1836085927L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 684231840000000L + "'", long22 == 684231840000000L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str8 = mutableDateTime6.toString(dateTimeFormatter7);
        mutableDateTime6.setYear(10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        long long14 = dateTimeZone11.adjustOffset(0L, false);
        int int16 = dateTimeZone11.getOffsetFromLocal(2664882077339L);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 10, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str8.equals("1971-01-04T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-25200000) + "'", int16 == (-25200000));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.minusHours((int) (byte) 1);
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfHour();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("BuddhistChronology[UTC]", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[UTC]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean15 = julianChronology0.equals((java.lang.Object) dateTimeFormatter14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeFormatter14.getZone();
        java.io.Writer writer17 = null;
        java.lang.Object obj18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(obj18, dateTimeZone19);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.weekyear();
        java.util.Locale locale22 = null;
        int int23 = property21.getMaximumTextLength(locale22);
        org.joda.time.MutableDateTime mutableDateTime24 = property21.roundHalfEven();
        int int25 = mutableDateTime24.getMonthOfYear();
        mutableDateTime24.setTime((long) 10);
        try {
            dateTimeFormatter14.printTo(writer17, (org.joda.time.ReadableInstant) mutableDateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long4 = dateTimeZone2.convertUTCToLocal((long) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone6.adjustOffset(0L, false);
        org.joda.time.Chronology chronology10 = buddhistChronology5.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withChronology(chronology10);
        java.lang.Object obj12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(obj12, dateTimeZone13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.weekyear();
        mutableDateTime14.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant19 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone20 = instant19.getZone();
        org.joda.time.Instant instant22 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant19, (org.joda.time.ReadableInstant) instant22);
        mutableDateTime14.setTime((org.joda.time.ReadableInstant) instant22);
        java.util.Locale locale25 = null;
        java.util.Calendar calendar26 = mutableDateTime14.toCalendar(locale25);
        java.lang.Object obj27 = mutableDateTime14.clone();
        int int28 = mutableDateTime14.getDayOfWeek();
        java.lang.String str29 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime14.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(calendar26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1969-365" + "'", str29.equals("1969-365"));
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        try {
            int int22 = unsupportedDateTimeField16.getMaximumValue((long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) 3109L, (java.lang.Number) 28800010L, (java.lang.Number) 5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(12, 28800, 2000, 0, 361, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 361 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology0.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 35);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2000);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withYear((int) ' ');
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withWeekOfWeekyear(28800);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.year();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology1.dayOfMonth();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) 35, (org.joda.time.Chronology) julianChronology1, locale8);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime6 = property3.add(10);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfFloor();
        java.lang.String str8 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970" + "'", str4.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1980" + "'", str8.equals("1980"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfDay();
        org.joda.time.DurationField durationField6 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withYear((int) ' ');
        org.joda.time.Instant instant6 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = instant6.getZone();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField9 = julianChronology8.months();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.year();
        org.joda.time.DurationField durationField12 = julianChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology8.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField15 = julianChronology14.months();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology14.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField17, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField19.getType();
        int int21 = instant6.get(dateTimeFieldType20);
        org.joda.time.DateTime dateTime23 = dateTime2.withField(dateTimeFieldType20, (int) (short) 0);
        org.joda.time.DateTime dateTime25 = dateTime2.minusYears((-1));
        org.joda.time.DateTime dateTime28 = dateTime2.withDurationAdded((long) 9, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("year", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"year\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        java.lang.Object obj4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj4, dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.weekyear();
        mutableDateTime6.addWeekyears((int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        mutableDateTime6.setDate(readableInstant11);
        mutableDateTime6.setWeekyear(361);
        mutableDateTime6.setSecondOfDay(1969);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "56");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("5073", 3500);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder0.setFixedSavings("UTC", (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder0.toDateTimeZone("null", true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfEven();
        mutableDateTime6.add((long) 12);
        org.joda.time.Chronology chronology9 = mutableDateTime6.getChronology();
        try {
            mutableDateTime6.setDayOfMonth(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.era();
        mutableDateTime7.setSecondOfDay((int) 'a');
        org.joda.time.DateTime dateTime11 = mutableDateTime7.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        long long14 = skipUndoDateTimeField11.remainder(1L);
        int int17 = skipUndoDateTimeField11.getDifference(132L, 63695916082768L);
        long long20 = skipUndoDateTimeField11.set(0L, 9);
        boolean boolean21 = skipUndoDateTimeField11.isSupported();
        int int22 = skipUndoDateTimeField11.getMaximumValue();
        java.util.Locale locale23 = null;
        int int24 = skipUndoDateTimeField11.getMaximumShortTextLength(locale23);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30384000001L + "'", long14 == 30384000001L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2018) + "'", int17 == (-2018));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61852896422000L) + "'", long20 == (-61852896422000L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292272992 + "'", int22 == 292272992);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = instant18.getZone();
        org.joda.time.DateTime dateTime20 = instant18.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
        try {
            int int23 = unsupportedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(timeOfDay22);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField(0);
        int int6 = mutableDateTime5.getRoundingMode();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = instant10.getZone();
        org.joda.time.Instant instant13 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant10, (org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant17 = instant13.withDurationAdded((long) ' ', (int) ' ');
        org.joda.time.Chronology chronology18 = instant17.getChronology();
        int int19 = property7.compareTo((org.joda.time.ReadableInstant) instant17);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfEven();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime6.add(readablePeriod7, (-3));
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        int int11 = julianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology10.getZone();
        java.util.TimeZone timeZone13 = dateTimeZone12.toTimeZone();
        mutableDateTime6.setZoneRetainFields(dateTimeZone12);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime6.dayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.Instant instant4 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, (org.joda.time.ReadableInstant) instant4);
        org.joda.time.Instant instant7 = instant1.minus((long) 'a');
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        mutableDateTime10.add(readableDuration11, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField14 = mutableDateTime10.getRoundingField();
        boolean boolean15 = instant7.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        int int17 = julianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
        java.util.TimeZone timeZone19 = dateTimeZone18.toTimeZone();
        java.lang.Object obj20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(obj20, dateTimeZone21);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.weekyear();
        mutableDateTime22.addWeekyears((int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.ReadableInstant readableInstant27 = null;
        mutableDateTime22.setDate(readableInstant27);
        mutableDateTime10.setDate(readableInstant27);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gJChronology26);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        try {
            long long6 = gJChronology0.getDateTimeMillis(29, 16, 292272992, 21692);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.weekyear();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "4:00:00 PM", 0);
        int int8 = mutableDateTime3.getDayOfMonth();
        try {
            mutableDateTime3.setWeekOfWeekyear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2) + "'", int7 == (-2));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-29T00:00:00.000-08:00", "", 9700, 21692);
        int int6 = fixedDateTimeZone4.getOffset(158426957332800000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9700 + "'", int6 == 9700);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("Coordinated Universal Time", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: Coordinated Universal Time");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder2.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime3 = mutableDateTime2.toDateTime();
        boolean boolean4 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(5);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str8 = mutableDateTime6.toString(dateTimeFormatter7);
        mutableDateTime6.setYear(10);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime6.add(readablePeriod11);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1971-01-04T00:00:00.000-08:00" + "'", str8.equals("1971-01-04T00:00:00.000-08:00"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gregorianChronology0.get(readablePeriod3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        long long13 = skipUndoDateTimeField11.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField11.getAsShortText(readablePartial14, 21682, locale16);
        org.joda.time.DateTimeField dateTimeField18 = skipUndoDateTimeField11.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1152000000L + "'", long13 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "21682" + "'", str17.equals("21682"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        java.lang.Object obj3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, dateTimeZone4);
        int int6 = mutableDateTime5.getDayOfMonth();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
        java.util.TimeZone timeZone13 = dateTimeZone11.toTimeZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.Instant instant16 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = instant16.getZone();
        org.joda.time.DateTime dateTime18 = instant16.toDateTimeISO();
        org.joda.time.DateTime.Property property19 = dateTime18.weekyear();
        java.lang.Class<?> wildcardClass20 = dateTime18.getClass();
        java.lang.String str21 = dateTimeFormatter14.print((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property22 = dateTime18.dayOfMonth();
        try {
            org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime18, 970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 970");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969-365T16:00:00-08:00" + "'", str21.equals("1969-365T16:00:00-08:00"));
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("5073");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
//        java.lang.String str4 = dateTimeZone2.getName((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        java.lang.String str7 = buddhistChronology6.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[UTC]" + "'", str7.equals("BuddhistChronology[UTC]"));
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField9 = julianChronology8.months();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.year();
        org.joda.time.DurationField durationField12 = julianChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology8.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField15 = julianChronology14.months();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology14.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField17, 4);
        int int21 = skipUndoDateTimeField19.getMinimumValue((long) (short) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField19);
        org.joda.time.DateTimeField dateTimeField23 = skipUndoDateTimeField19.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-292269054) + "'", int21 == (-292269054));
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfEven();
        int int7 = mutableDateTime6.getMonthOfYear();
        int int8 = mutableDateTime6.getRoundingMode();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        long long20 = unsupportedDateTimeField16.getDifferenceAsLong((-126230399990L), 0L);
        org.joda.time.Instant instant22 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone23 = instant22.getZone();
        org.joda.time.Instant instant25 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant22, (org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant28 = instant25.withMillis((long) (short) 1);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.Instant instant31 = instant28.withDurationAdded(readableDuration29, (int) (short) 100);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant33 = instant28.plus(readableDuration32);
        org.joda.time.DateTime dateTime34 = instant28.toDateTimeISO();
        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology38 = iSOChronology37.withUTC();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology37.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField41 = julianChronology40.months();
        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology40);
        org.joda.time.DateTimeField dateTimeField43 = julianChronology40.year();
        org.joda.time.DurationField durationField44 = julianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField45 = julianChronology40.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField47 = julianChronology46.months();
        org.joda.time.MutableDateTime mutableDateTime48 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology46);
        org.joda.time.DateTimeField dateTimeField49 = julianChronology46.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology40, dateTimeField49, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = skipUndoDateTimeField51.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType52, (int) (short) -1);
        int int56 = offsetDateTimeField54.get((long) 9);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray62 = new int[] { 9, (-25200000), (short) 10, 0 };
        int int63 = offsetDateTimeField54.getMaximumValue(readablePartial57, intArray62);
        try {
            int[] intArray65 = unsupportedDateTimeField16.add((org.joda.time.ReadablePartial) localTime35, 0, intArray62, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3L) + "'", long20 == (-3L));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(instant33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localTime35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 30 + "'", int63 == 30);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        java.util.Locale locale21 = null;
        int int22 = skipUndoDateTimeField11.getMaximumTextLength(locale21);
        int int24 = skipUndoDateTimeField11.get((long) 21685927);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1969-365", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-365\" is malformed at \"69-365\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        int int19 = offsetDateTimeField17.get((long) 9);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray25 = new int[] { 9, (-25200000), (short) 10, 0 };
        int int26 = offsetDateTimeField17.getMaximumValue(readablePartial20, intArray25);
        boolean boolean28 = offsetDateTimeField17.isLeap((long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 30 + "'", int26 == 30);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 292272992);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        boolean boolean5 = dateTime2.isAfter((long) 34);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        long long20 = unsupportedDateTimeField16.getDifferenceAsLong((-126230399990L), 0L);
        int int23 = unsupportedDateTimeField16.getDifference((-2018L), (long) 34);
        java.util.Locale locale24 = null;
        try {
            int int25 = unsupportedDateTimeField16.getMaximumTextLength(locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3L) + "'", long20 == (-3L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.set(0);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfMonth();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-29T00:00:00.000-08:00", "", 9700, 21692);
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 16, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int9 = fixedDateTimeZone5.getStandardOffset(292279993L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21692 + "'", int9 == 21692);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "1970", "");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        int int3 = mutableDateTime2.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        boolean boolean8 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.era();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long6 = gregorianChronology0.getDateTimeMillis(12, (int) (short) 1, (int) (short) 10, 480);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61787750399520L) + "'", long6 == (-61787750399520L));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusMinutes(292278993);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = julianChronology0.get(readablePeriod4, (long) '4', (-2018L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField5 = julianChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        int int20 = unsupportedDateTimeField16.getDifference((long) 30, 0L);
        java.lang.String str21 = unsupportedDateTimeField16.toString();
        org.joda.time.Instant instant23 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone24 = instant23.getZone();
        org.joda.time.DateTime dateTime25 = instant23.toDateTimeISO();
        org.joda.time.DateTime.Property property26 = dateTime25.weekyear();
        org.joda.time.TimeOfDay timeOfDay27 = dateTime25.toTimeOfDay();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.DurationField durationField33 = julianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology29.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField36 = julianChronology35.months();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology35);
        org.joda.time.DateTimeField dateTimeField38 = julianChronology35.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology29, dateTimeField38, 4);
        long long42 = skipUndoDateTimeField40.roundHalfFloor((long) ' ');
        org.joda.time.ReadablePartial readablePartial43 = null;
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipUndoDateTimeField40.getAsShortText(readablePartial43, 21682, locale45);
        org.joda.time.ReadablePartial readablePartial47 = null;
        int[] intArray49 = new int[] { 1970 };
        int int50 = skipUndoDateTimeField40.getMaximumValue(readablePartial47, intArray49);
        java.util.Locale locale52 = null;
        try {
            int[] intArray53 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) timeOfDay27, 2000, intArray49, "year", locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDateTimeField" + "'", str21.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(timeOfDay27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1152000000L + "'", long42 == 1152000000L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "21682" + "'", str46.equals("21682"));
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292272992 + "'", int50 == 292272992);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology8, locale9);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (short) -1, (org.joda.time.Chronology) julianChronology8, locale11);
        long long15 = dateTimeParserBucket12.computeMillis(false, "JulianChronology[America/Los_Angeles]");
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = iSOChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField20 = julianChronology19.months();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology19);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology19.year();
        org.joda.time.DurationField durationField23 = julianChronology19.weeks();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology19.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField26 = julianChronology25.months();
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology25);
        org.joda.time.DateTimeField dateTimeField28 = julianChronology25.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology19, dateTimeField28, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipUndoDateTimeField30.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType31, (int) (short) -1);
        java.util.Locale locale35 = null;
        dateTimeParserBucket12.saveField(dateTimeFieldType31, "21682", locale35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType31);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendClockhourOfDay((-292269054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        int int4 = property3.getMaximumValue();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfFloor();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField11.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getName(0L, locale5);
//        long long9 = dateTimeZone1.adjustOffset((long) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.weekyear();
//        java.util.Locale locale18 = null;
//        int int19 = property17.getMaximumTextLength(locale18);
//        org.joda.time.MutableDateTime mutableDateTime20 = property17.roundHalfEven();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField22 = julianChronology21.months();
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology21);
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology21.year();
//        org.joda.time.DurationField durationField25 = julianChronology21.weeks();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = julianChronology27.months();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology27);
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField30, 4);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField32.getAsShortText(readablePartial33, (int) (short) -1, locale35);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = julianChronology37.months();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology37);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology37.year();
//        org.joda.time.DurationField durationField41 = julianChronology37.weeks();
//        org.joda.time.DateTimeField dateTimeField42 = julianChronology37.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = julianChronology43.months();
//        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology43.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology37, dateTimeField46, 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipUndoDateTimeField48.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField32, dateTimeFieldType49, 3104, (-292269054), 0);
//        mutableDateTime20.set(dateTimeFieldType49, 1970);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField56 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType49);
//        boolean boolean58 = zeroIsMaxDateTimeField56.isLeap((long) (byte) 10);
//        long long60 = zeroIsMaxDateTimeField56.roundFloor((long) (-1969));
//        long long62 = zeroIsMaxDateTimeField56.roundFloor(705L);
//        java.util.Locale locale65 = null;
//        try {
//            long long66 = zeroIsMaxDateTimeField56.set((long) 1, "292272992", locale65);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272992 for year must be in the range [1,1000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-1969L) + "'", long60 == (-1969L));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 705L + "'", long62 == 705L);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-9223331333255578000L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9223331333255577990L) + "'", long2 == (-9223331333255577990L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DurationField durationField6 = julianChronology3.seconds();
        org.joda.time.DurationField durationField7 = julianChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) julianChronology3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.addWrapField((int) (short) 0);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.era();
        org.joda.time.MutableDateTime mutableDateTime9 = property8.roundFloor();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone2 = instant1.getZone();
        org.joda.time.DateTime dateTime3 = instant1.toDateTimeISO();
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        java.lang.Class<?> wildcardClass5 = dateTime3.getClass();
        org.joda.time.DateTime.Property property6 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        mutableDateTime2.addWeekyears((int) (byte) 0);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = instant7.getZone();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((-1L));
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, (org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) instant10);
        mutableDateTime2.addMonths((-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant31 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = instant31.getZone();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField34 = julianChronology33.months();
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology33);
        org.joda.time.DateTimeField dateTimeField36 = julianChronology33.year();
        org.joda.time.DurationField durationField37 = julianChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology33.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField40 = julianChronology39.months();
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology39);
        org.joda.time.DateTimeField dateTimeField42 = julianChronology39.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology33, dateTimeField42, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipUndoDateTimeField44.getType();
        int int46 = instant31.get(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder26.appendText(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder24.appendShortText(dateTimeFieldType45);
        org.joda.time.MutableDateTime.Property property49 = mutableDateTime2.property(dateTimeFieldType45);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology51 = iSOChronology50.withUTC();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField54 = julianChronology53.months();
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology53);
        org.joda.time.DateTimeField dateTimeField56 = julianChronology53.year();
        org.joda.time.DurationField durationField57 = julianChronology53.weeks();
        org.joda.time.DateTimeField dateTimeField58 = julianChronology53.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField60 = julianChronology59.months();
        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology59);
        org.joda.time.DateTimeField dateTimeField62 = julianChronology59.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField64 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology53, dateTimeField62, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = skipUndoDateTimeField64.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, dateTimeFieldType65, (int) (short) -1);
        org.joda.time.DurationField durationField68 = offsetDateTimeField67.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField69 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType45, durationField68);
        org.joda.time.ReadablePartial readablePartial70 = null;
        int[] intArray76 = new int[] { 2000, 9700, (short) 1, 1970 };
        try {
            int[] intArray78 = unsupportedDateTimeField69.set(readablePartial70, 3500, intArray76, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1970 + "'", int46 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField69);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(9, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        try {
            long long9 = gJChronology0.getDateTimeMillis(361, (int) (byte) 10, 970, 5, 2000, 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str1.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.secondOfMinute();
        org.joda.time.Chronology chronology4 = julianChronology1.withUTC();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        long long20 = skipUndoDateTimeField11.roundHalfFloor((long) 4);
        long long22 = skipUndoDateTimeField11.roundHalfFloor((long) 292278993);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField24 = julianChronology23.months();
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology23.year();
        org.joda.time.DurationField durationField27 = julianChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology23.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField30 = julianChronology29.months();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology29);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology29.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology23, dateTimeField32, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType35, (int) '#');
        long long39 = dividedDateTimeField37.roundFloor((long) 21682);
        int int40 = dividedDateTimeField37.getMinimumValue();
        int int41 = dividedDateTimeField37.getDivisor();
        int int42 = dividedDateTimeField37.getDivisor();
        int int43 = dividedDateTimeField37.getMaximumValue();
        long long46 = dividedDateTimeField37.set((-176766705562021999L), 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1152000000L + "'", long20 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1152000000L + "'", long22 == 1152000000L);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-314467200000L) + "'", long39 == (-314467200000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-8350545) + "'", int40 == (-8350545));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 35 + "'", int41 == 35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 35 + "'", int42 == 35);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8350656 + "'", int43 == 8350656);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-50772614821999L) + "'", long46 == (-50772614821999L));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.year();
        org.joda.time.DurationField durationField7 = julianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology3.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField10 = julianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField12, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType15, (int) (short) -1);
        int int19 = offsetDateTimeField17.get((long) 9);
        org.joda.time.DurationField durationField20 = offsetDateTimeField17.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("Coordinated Universal Time");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendTwoDigitYear(10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendHourOfHalfday((-8350545));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        long long3 = dateTimeZone1.convertUTCToLocal((long) 'a');
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getName(0L, locale5);
//        long long9 = dateTimeZone1.adjustOffset((long) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj14, dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.weekyear();
//        java.util.Locale locale18 = null;
//        int int19 = property17.getMaximumTextLength(locale18);
//        org.joda.time.MutableDateTime mutableDateTime20 = property17.roundHalfEven();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField22 = julianChronology21.months();
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology21);
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology21.year();
//        org.joda.time.DurationField durationField25 = julianChronology21.weeks();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = julianChronology27.months();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology27);
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField30, 4);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField32.getAsShortText(readablePartial33, (int) (short) -1, locale35);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = julianChronology37.months();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology37);
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology37.year();
//        org.joda.time.DurationField durationField41 = julianChronology37.weeks();
//        org.joda.time.DateTimeField dateTimeField42 = julianChronology37.secondOfMinute();
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = julianChronology43.months();
//        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology43.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology37, dateTimeField46, 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipUndoDateTimeField48.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField32, dateTimeFieldType49, 3104, (-292269054), 0);
//        mutableDateTime20.set(dateTimeFieldType49, 1970);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField56 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType49);
//        boolean boolean58 = zeroIsMaxDateTimeField56.isLeap((long) (byte) 10);
//        long long60 = zeroIsMaxDateTimeField56.roundFloor((long) (-1969));
//        int int62 = zeroIsMaxDateTimeField56.getLeapAmount(2664882077339L);
//        int int63 = zeroIsMaxDateTimeField56.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-1969L) + "'", long60 == (-1969L));
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(10L, (org.joda.time.Chronology) julianChronology1, locale2);
        long long4 = dateTimeParserBucket3.computeMillis();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField6 = julianChronology5.months();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.year();
        org.joda.time.DurationField durationField9 = julianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology5.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField12 = julianChronology11.months();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology11);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology11.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology5, dateTimeField14, 4);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField16.getAsShortText(readablePartial17, (int) (short) -1, locale19);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField22 = julianChronology21.months();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology21);
        org.joda.time.DateTimeField dateTimeField24 = julianChronology21.year();
        org.joda.time.DurationField durationField25 = julianChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology21.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField28 = julianChronology27.months();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology27);
        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField30, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipUndoDateTimeField32.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType33, 3104, (-292269054), 0);
        java.util.Locale locale39 = null;
        dateTimeParserBucket3.saveField(dateTimeFieldType33, "3500", locale39);
        int int41 = dateTimeParserBucket3.getOffset();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28800010L + "'", long4 == 28800010L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("Coordinated Universal Time");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendWeekyear(9700, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendFractionOfHour(35, 292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) 28, locale2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField(0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.minuteOfDay();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.minuteOfHour();
        mutableDateTime5.addYears(40);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        long long20 = unsupportedDateTimeField16.getDifferenceAsLong((-126230399990L), 0L);
        int int23 = unsupportedDateTimeField16.getDifference((-2018L), (long) 34);
        org.joda.time.Instant instant25 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone26 = instant25.getZone();
        org.joda.time.Instant instant28 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTime dateTime29 = instant28.toDateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfSecond();
        boolean boolean31 = instant25.isBefore((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime.Property property32 = dateTime29.year();
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfDay();
        org.joda.time.LocalDate localDate34 = dateTime29.toLocalDate();
        int[] intArray36 = null;
        try {
            int[] intArray38 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) localDate34, (-25200000), intArray36, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3L) + "'", long20 == (-3L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        int int13 = skipUndoDateTimeField11.getMinimumValue((long) (short) 10);
        int int15 = skipUndoDateTimeField11.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292269054) + "'", int13 == (-292269054));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 292272992 + "'", int15 == 292272992);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(4, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfMinute((int) (byte) 1, (int) (short) -1);
        org.joda.time.Instant instant16 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = instant16.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField19 = julianChronology18.months();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DateTimeField dateTimeField21 = julianChronology18.year();
        org.joda.time.DurationField durationField22 = julianChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology18.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField25 = julianChronology24.months();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology24);
        org.joda.time.DateTimeField dateTimeField27 = julianChronology24.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology18, dateTimeField27, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField29.getType();
        int int31 = instant16.get(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder9.appendShortText(dateTimeFieldType30);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder9.appendClockhourOfHalfday((-292265950));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1970 + "'", int31 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-1L));
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.Chronology chronology3 = instant1.getChronology();
        java.util.Date date4 = instant1.toDate();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant1.withDurationAdded(readableDuration5, 16);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField7 = julianChronology6.months();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9, 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipUndoDateTimeField11.getType();
        int int15 = skipUndoDateTimeField11.getDifference((long) 3104, 0L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField11.getAsText((int) (short) 10, locale17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField11.getAsText(21682, locale20);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "21682" + "'", str21.equals("21682"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }
}

