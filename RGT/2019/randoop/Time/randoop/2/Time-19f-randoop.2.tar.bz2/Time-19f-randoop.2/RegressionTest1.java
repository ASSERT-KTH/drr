import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str9 = iSOChronology8.toString();
//        org.joda.time.DurationField durationField10 = iSOChronology8.hours();
//        org.joda.time.DurationField durationField11 = iSOChronology8.months();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology8.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendTwoDigitYear(12, true);
//        boolean boolean22 = dateTimeFormatterBuilder21.canBuildFormatter();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds((int) (short) 1);
//        boolean boolean28 = dateTime24.isBefore((long) 0);
//        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property30 = dateTime24.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder21.appendText(dateTimeFieldType31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType31);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType31, 86399);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType31);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime42 = dateTime40.minusSeconds((int) ' ');
//        java.lang.String str43 = dateTime40.toString();
//        int int44 = dateTime40.getMonthOfYear();
//        org.joda.time.DateTime dateTime46 = dateTime40.withMillis(62L);
//        org.joda.time.DateTime dateTime48 = dateTime40.withWeekyear(0);
//        org.joda.time.DateTime.Property property49 = dateTime48.weekyear();
//        org.joda.time.DurationField durationField50 = property49.getLeapDurationField();
//        java.util.TimeZone timeZone51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime56 = dateTime54.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime58 = dateTime56.minusSeconds((int) ' ');
//        int int59 = dateTimeZone52.getOffset((org.joda.time.ReadableInstant) dateTime56);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
//        org.joda.time.DurationField durationField61 = gregorianChronology60.days();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType31, durationField50, durationField61);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str43.equals("1969-12-27T20:00:00.010Z"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property4.addToCopy((long) 2);
        org.joda.time.DateTime dateTime10 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime12 = property4.addWrapFieldToCopy(35);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (byte) 1, false);
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendPattern("GregorianChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        boolean boolean5 = dateTime1.isBefore((long) 0);
//        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime8 = dateTime6.withMillis(0L);
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime6.toGregorianCalendar();
//        org.joda.time.DateTime.Property property10 = dateTime6.monthOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime6.weekyear();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
//        java.lang.String str19 = dateTime13.toString(dateTimeFormatter17);
//        int int20 = dateTime13.getMinuteOfDay();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime13.toYearMonthDay();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime13.withFields(readablePartial22);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekyear();
//        boolean boolean25 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime23);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNull(chronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970-01-01" + "'", str19.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long32 = remainderDateTimeField27.add((long) (byte) 100, 21);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) remainderDateTimeField27, 2, (int) (byte) -1, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for dayOfMonth must be in the range [-1,-28800000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 21100L + "'", long32 == 21100L);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str2 = dateTimeFormatter0.print((long) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01" + "'", str2.equals("1970-01-01"));
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
//        java.lang.String str6 = dateTime3.toString();
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
//        boolean boolean8 = dateTime3.isBeforeNow();
//        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(1);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds(10);
//        org.joda.time.DateTime dateTime14 = dateTime12.withYear(21);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        boolean boolean5 = dateTime1.isBefore((long) 0);
//        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str10 = iSOChronology9.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
//        long long14 = durationField11.subtract((long) 960, (int) ' ');
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
//        long long20 = unsupportedDateTimeField15.add(999L, 4078200);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter21.withOffsetParsed();
//        org.joda.time.Chronology chronology23 = dateTimeFormatter22.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTimeFormatter22.getZone();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime28.minusSeconds((int) ' ');
//        java.lang.String str31 = dateTime28.toString();
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime28.toTimeOfDay();
//        java.lang.String str33 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) timeOfDay32);
//        java.util.Locale locale34 = null;
//        try {
//            java.lang.String str35 = unsupportedDateTimeField15.getAsText((org.joda.time.ReadablePartial) timeOfDay32, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 14681520000999L + "'", long20 == 14681520000999L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNull(chronology23);
//        org.junit.Assert.assertNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str31.equals("1969-12-27T20:00:00.010Z"));
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����-��-��" + "'", str33.equals("����-��-��"));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1969-12-31");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException13.getDurationFieldType();
        illegalFieldValueException13.prependMessage("1969-12-31");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        java.lang.String str22 = illegalFieldValueException21.toString();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.String str24 = illegalFieldValueException13.getIllegalValueAsString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str26 = illegalFieldValueException13.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType32 = illegalFieldValueException31.getDurationFieldType();
        java.lang.Number number33 = illegalFieldValueException31.getUpperBound();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException31);
        java.lang.Throwable[] throwableArray35 = illegalFieldValueException13.getSuppressed();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str22.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100.0" + "'", str24.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str26.equals("org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1) + "'", number33.equals((-1)));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfDay(69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfHour(86399, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("1969-12-27T12:00:00.010-08:00", "1969", true, 86399, (-2922749));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        try {
            long long19 = unsupportedDateTimeField15.roundHalfEven((-16L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTimeZoneOffset("DateTimeField[dayOfMonth]", false, (int) (byte) 100, (-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
//        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
//        org.joda.time.DurationField durationField11 = gregorianChronology9.months();
//        org.joda.time.DurationField durationField12 = gregorianChronology9.months();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        try {
//            int[] intArray16 = gregorianChronology9.get(readablePeriod13, (-7686200592000000L), 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology0.months();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
//        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
//        boolean boolean20 = dateTime16.isBefore((long) 0);
//        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str29 = iSOChronology28.toString();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
//        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
//        long long49 = remainderDateTimeField27.addWrapField((long) (byte) 1, 15);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 15001L + "'", long49 == 15001L);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
//        org.joda.time.DurationField durationField5 = iSOChronology2.months();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
//        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
//        boolean boolean22 = dateTime18.isBefore((long) 0);
//        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str31 = iSOChronology30.toString();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
//        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
//        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
//        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
//        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
//        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
//        long long61 = offsetDateTimeField59.roundHalfEven((-7686200592000000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-7686200592000000L) + "'", long61 == (-7686200592000000L));
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) 960);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
//        int int7 = dateTime6.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399010 + "'", int7 == 86399010);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        long long8 = iSOChronology0.add((long) (byte) 100, (long) (byte) -1, (int) (short) 1);
        try {
            long long13 = iSOChronology0.getDateTimeMillis(2000, 0, 32, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 99L + "'", long8 == 99L);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) ' ');
//        int int13 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        org.joda.time.DurationField durationField15 = gregorianChronology14.days();
//        org.joda.time.DurationField durationField16 = gregorianChronology14.months();
//        org.joda.time.DurationField durationField17 = gregorianChronology14.months();
//        try {
//            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1970, (-2922790), (int) 'a', 52, 2, (org.joda.time.Chronology) gregorianChronology14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology0.months();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
//        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
//        boolean boolean20 = dateTime16.isBefore((long) 0);
//        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str29 = iSOChronology28.toString();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
//        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str48 = iSOChronology47.toString();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
//        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
//        long long67 = remainderDateTimeField27.roundHalfCeiling(3600100L);
//        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology69 = iSOChronology68.withUTC();
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology68.weekyear();
//        org.joda.time.DurationField durationField71 = iSOChronology68.hours();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime75 = dateTime73.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime76 = dateTime73.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate77 = dateTime73.toLocalDate();
//        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str79 = iSOChronology78.toString();
//        org.joda.time.DateTimeField dateTimeField80 = iSOChronology78.secondOfDay();
//        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime84 = dateTime82.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime85 = dateTime82.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate86 = dateTime82.toLocalDate();
//        int[] intArray93 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology78.validate((org.joda.time.ReadablePartial) localDate86, intArray93);
//        iSOChronology68.validate((org.joda.time.ReadablePartial) localDate77, intArray93);
//        int int96 = remainderDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDate77);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3600000L + "'", long67 == 3600000L);
//        org.junit.Assert.assertNotNull(iSOChronology68);
//        org.junit.Assert.assertNotNull(chronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(mutableDateTime76);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertNotNull(iSOChronology78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "ISOChronology[UTC]" + "'", str79.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(mutableDateTime85);
//        org.junit.Assert.assertNotNull(localDate86);
//        org.junit.Assert.assertNotNull(intArray93);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int11 = cachedDateTimeZone9.getOffset((long) 100);
        boolean boolean12 = cachedDateTimeZone9.isFixed();
        boolean boolean13 = cachedDateTimeZone9.isFixed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime3.toMutableDateTimeISO();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
//        int int15 = fixedDateTimeZone13.getOffset((long) (byte) -1);
//        java.lang.String str16 = fixedDateTimeZone13.toString();
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        java.lang.String str18 = gregorianChronology8.toString();
//        org.joda.time.DateTime dateTime19 = dateTime3.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readablePeriod20);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str16.equals("1969-12-27T12:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[]" + "'", str18.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 12, (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 69);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long9 = fixedDateTimeZone4.convertUTCToLocal(1942L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 69L + "'", long6 == 69L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1954L + "'", long9 == 1954L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is malformed at \"69\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        int int5 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        java.lang.String str7 = property4.toString();
        org.joda.time.Interval interval8 = property4.toInterval();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[centuryOfEra]" + "'", str7.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        java.util.Locale locale18 = null;
        try {
            int int19 = unsupportedDateTimeField15.getMaximumShortTextLength(locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendSecondOfMinute(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitWeekyear((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.hours();
        org.joda.time.DurationField durationField40 = iSOChronology37.months();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology37.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(12, true);
        boolean boolean51 = dateTimeFormatterBuilder50.canBuildFormatter();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) (short) 1);
        boolean boolean57 = dateTime53.isBefore((long) 0);
        org.joda.time.DateTime dateTime58 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property59 = dateTime53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder50.appendText(dateTimeFieldType60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder45.appendShortText(dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField42, dateTimeFieldType60, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType60, 69);
        java.lang.String str69 = offsetDateTimeField67.getAsText(10L);
        int int70 = offsetDateTimeField67.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "69" + "'", str69.equals("69"));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 69 + "'", int70 == 69);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
//        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime1.getZone();
//        java.lang.String str9 = dateTimeZone8.toString();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(chronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendFractionOfHour(960, (-11));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfDay(1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime7 = dateTime1.plusMonths((-2922789));
        org.joda.time.TimeOfDay timeOfDay8 = dateTime1.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime1.withDayOfYear(86398);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86398 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(timeOfDay8);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology0.months();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
//        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
//        boolean boolean20 = dateTime16.isBefore((long) 0);
//        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str29 = iSOChronology28.toString();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
//        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
//        long long48 = remainderDateTimeField27.roundHalfEven(0L);
//        long long51 = remainderDateTimeField27.addWrapField((long) ' ', 52);
//        int int53 = remainderDateTimeField27.get((long) (byte) -1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52032L + "'", long51 == 52032L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime3.toMutableDateTimeISO();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
//        int int15 = fixedDateTimeZone13.getOffset((long) (byte) -1);
//        java.lang.String str16 = fixedDateTimeZone13.toString();
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
//        java.lang.String str18 = gregorianChronology8.toString();
//        org.joda.time.DateTime dateTime19 = dateTime3.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withDurationAdded(readableDuration20, 2100);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str16.equals("1969-12-27T12:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[]" + "'", str18.equals("GregorianChronology[]"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime9.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology14 = dateTimeFormatter13.getChronology();
//        java.lang.String str15 = dateTime9.toString(dateTimeFormatter13);
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter13.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendFractionOfDay(0, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendTwoDigitYear(12, true);
//        boolean boolean30 = dateTimeFormatterBuilder29.canBuildFormatter();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
//        boolean boolean36 = dateTime32.isBefore((long) 0);
//        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property38 = dateTime32.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder29.appendText(dateTimeFieldType39);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder19.appendDecimal(dateTimeFieldType39, (int) '#', (int) (short) 100);
//        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatterBuilder19.toParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder48.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendFractionOfDay(0, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder54.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder55.appendTwoDigitYear(12, true);
//        boolean boolean59 = dateTimeFormatterBuilder58.canBuildFormatter();
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime63 = dateTime61.minusSeconds((int) (short) 1);
//        boolean boolean65 = dateTime61.isBefore((long) 0);
//        org.joda.time.DateTime dateTime66 = dateTime61.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property67 = dateTime61.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property67.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder58.appendText(dateTimeFieldType68);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder48.appendDecimal(dateTimeFieldType68, (int) '#', (int) (short) 100);
//        org.joda.time.format.DateTimeParser dateTimeParser73 = dateTimeFormatterBuilder48.toParser();
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime77 = dateTime75.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime78 = dateTime75.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology80 = dateTimeFormatter79.getChronology();
//        java.lang.String str81 = dateTime75.toString(dateTimeFormatter79);
//        java.lang.Class<?> wildcardClass82 = dateTimeFormatter79.getClass();
//        org.joda.time.format.DateTimeParser dateTimeParser83 = dateTimeFormatter79.getParser();
//        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime87 = dateTime85.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime88 = dateTime85.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter89 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology90 = dateTimeFormatter89.getChronology();
//        java.lang.String str91 = dateTime85.toString(dateTimeFormatter89);
//        java.lang.Class<?> wildcardClass92 = dateTimeFormatter89.getClass();
//        org.joda.time.format.DateTimeParser dateTimeParser93 = dateTimeFormatter89.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray94 = new org.joda.time.format.DateTimeParser[] { dateTimeParser44, dateTimeParser73, dateTimeParser83, dateTimeParser93 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder5.append(dateTimePrinter7, dateTimeParserArray94);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder98 = dateTimeFormatterBuilder95.appendYear((int) 'a', (-2922790));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimePrinter7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01" + "'", str15.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeParser44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
//        org.junit.Assert.assertNotNull(dateTimeParser73);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(mutableDateTime78);
//        org.junit.Assert.assertNotNull(dateTimeFormatter79);
//        org.junit.Assert.assertNull(chronology80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "1970-01-01" + "'", str81.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(dateTimeParser83);
//        org.junit.Assert.assertNotNull(dateTime87);
//        org.junit.Assert.assertNotNull(mutableDateTime88);
//        org.junit.Assert.assertNotNull(dateTimeFormatter89);
//        org.junit.Assert.assertNull(chronology90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "1970-01-01" + "'", str91.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(wildcardClass92);
//        org.junit.Assert.assertNotNull(dateTimeParser93);
//        org.junit.Assert.assertNotNull(dateTimeParserArray94);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder95);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder98);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField27.getMaximumTextLength(locale29);
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = remainderDateTimeField27.getMinimumValue(readablePartial31);
        int int33 = remainderDateTimeField27.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 86398 + "'", int33 == 86398);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfDay(69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneOffset("ISOChronology[UTC]", "org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]", false, 1, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology7 = dateTimeFormatter6.getChronology();
//        java.lang.String str8 = dateTime2.toString(dateTimeFormatter6);
//        org.joda.time.DateTime dateTime11 = dateTime2.withDurationAdded(3600100L, (int) 'a');
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) ' ');
//        int int20 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField22 = gregorianChronology21.days();
//        org.joda.time.DateTime dateTime23 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime23);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01" + "'", str8.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
//        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        boolean boolean5 = dateTime1.isBefore((long) 0);
//        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
//        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) ' ');
//        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
//        long long25 = zonedChronology15.set((org.joda.time.ReadablePartial) localTime23, (long) (-28800000));
//        java.lang.String str26 = zonedChronology15.toString();
//        org.joda.time.Chronology chronology27 = zonedChronology15.withUTC();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localTime23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-14431989L) + "'", long25 == (-14431989L));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]" + "'", str26.equals("ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]"));
//        org.junit.Assert.assertNotNull(chronology27);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DurationField durationField3 = iSOChronology1.hours();
        org.joda.time.DurationField durationField4 = iSOChronology1.months();
        org.joda.time.DurationField durationField5 = iSOChronology1.halfdays();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(21100L, chronology6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(86399, 1, (int) (short) 1, 0, (int) '#');
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
//        org.joda.time.DurationField durationField3 = iSOChronology0.months();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
//        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
//        boolean boolean20 = dateTime16.isBefore((long) 0);
//        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str29 = iSOChronology28.toString();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
//        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
//        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
//        long long51 = remainderDateTimeField27.add((long) 2, (long) 10);
//        long long53 = remainderDateTimeField27.remainder((long) 0);
//        long long56 = remainderDateTimeField27.set(14681520000999L, 1200);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10002L + "'", long51 == 10002L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 14681521200999L + "'", long56 == 14681521200999L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) (byte) 0, 2000L);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str22 = iSOChronology21.toString();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.secondOfDay();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime25.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate29 = dateTime25.toLocalDate();
        int[] intArray36 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology21.validate((org.joda.time.ReadablePartial) localDate29, intArray36);
        int[] intArray42 = new int[] { 10, 57600010, (-2922789) };
        try {
            int[] intArray44 = unsupportedDateTimeField15.add((org.joda.time.ReadablePartial) localDate29, 0, intArray42, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[UTC]" + "'", str22.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.centuryOfEra();
        org.joda.time.DurationField durationField11 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
//        boolean boolean5 = dateTime1.isBefore((long) 0);
//        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
//        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) ' ');
//        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
//        long long25 = zonedChronology15.set((org.joda.time.ReadablePartial) localTime23, (long) (-28800000));
//        java.lang.Object obj26 = null;
//        boolean boolean27 = zonedChronology15.equals(obj26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        try {
//            int[] intArray31 = zonedChronology15.get(readablePeriod28, (long) 'a', 1000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localTime23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-14431989L) + "'", long25 == (-14431989L));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
//        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
//        org.joda.time.DurationField durationField11 = gregorianChronology9.months();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (short) 1);
//        boolean boolean17 = dateTime13.isBefore((long) 0);
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
//        int int26 = fixedDateTimeZone24.getOffset((long) (byte) -1);
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology19, (org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone28 = zonedChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((int) (short) 100);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) ' ');
//        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
//        long long37 = zonedChronology27.set((org.joda.time.ReadablePartial) localTime35, (long) (-28800000));
//        int[] intArray39 = gregorianChronology9.get((org.joda.time.ReadablePartial) localTime35, (long) (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(zonedChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localTime35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-14431989L) + "'", long37 == (-14431989L));
//        org.junit.Assert.assertNotNull(intArray39);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
//        org.joda.time.DurationField durationField5 = iSOChronology2.months();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
//        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
//        boolean boolean22 = dateTime18.isBefore((long) 0);
//        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str31 = iSOChronology30.toString();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
//        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
//        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
//        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
//        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
//        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
//        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
//        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
//        int int60 = offsetDateTimeField59.getMaximumValue();
//        long long62 = offsetDateTimeField59.roundFloor((-100L));
//        int int63 = offsetDateTimeField59.getMinimumValue();
//        int int64 = offsetDateTimeField59.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-2922650) + "'", int60 == (-2922650));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-31536000000L) + "'", long62 == (-31536000000L));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-2922749) + "'", int63 == (-2922749));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-2922749) + "'", int64 == (-2922749));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime10 = property4.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField11 = property4.getRangeDurationField();
        org.joda.time.DurationField durationField12 = property4.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        int int12 = mutableDateTime11.getWeekOfWeekyear();
        int int15 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", 960);
        java.util.Locale locale16 = dateTimeFormatter1.getLocale();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str18 = iSOChronology17.toString();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar28 = dateTime27.toGregorianCalendar();
        int int29 = dateTime27.getSecondOfMinute();
        java.lang.String str30 = dateTimeFormatter21.print((org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-961) + "'", int15 == (-961));
        org.junit.Assert.assertNull(locale16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[UTC]" + "'", str18.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianCalendar28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 28 + "'", int29 == 28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969-12-27" + "'", str30.equals("1969-12-27"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        try {
            long long8 = iSOChronology0.getDateTimeMillis((int) (short) -1, (int) '4', 0, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "", 69);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-70) + "'", int11 == (-70));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1000L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        long long46 = preciseDateTimeField44.getUnitMillis();
        long long48 = preciseDateTimeField44.remainder(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(14681520000999L, true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 14681520000999L + "'", long11 == 14681520000999L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1.0f), (java.lang.Number) 2000, (java.lang.Number) 126000100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField3 = iSOChronology0.hours();
        try {
            long long8 = iSOChronology0.getDateTimeMillis((-2922679), 0, 2922789, 4078200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.hours();
        org.joda.time.DurationField durationField40 = iSOChronology37.months();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology37.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(12, true);
        boolean boolean51 = dateTimeFormatterBuilder50.canBuildFormatter();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) (short) 1);
        boolean boolean57 = dateTime53.isBefore((long) 0);
        org.joda.time.DateTime dateTime58 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property59 = dateTime53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder50.appendText(dateTimeFieldType60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder45.appendShortText(dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField42, dateTimeFieldType60, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType60, 69);
        long long69 = remainderDateTimeField27.roundHalfCeiling((long) 1969);
        java.util.Locale locale70 = null;
        int int71 = remainderDateTimeField27.getMaximumShortTextLength(locale70);
        org.joda.time.DurationField durationField72 = remainderDateTimeField27.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2000L + "'", long69 == 2000L);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 5 + "'", int71 == 5);
        org.junit.Assert.assertNotNull(durationField72);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str4 = iSOChronology3.toString();
        long long8 = iSOChronology3.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        java.util.Locale locale10 = dateTimeFormatter9.getLocale();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withChronology(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNull(locale10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) '4', (int) ' ');
        int int27 = dateTime26.getMinuteOfHour();
        boolean boolean28 = zonedChronology15.equals((java.lang.Object) dateTime26);
        org.joda.time.DateTime.Property property29 = dateTime26.year();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property29);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1");
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (byte) 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        int int46 = preciseDateTimeField44.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 59999 + "'", int46 == 59999);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        boolean boolean17 = unsupportedDateTimeField15.isLenient();
        long long20 = unsupportedDateTimeField15.add(100L, (long) 35);
        try {
            java.lang.String str22 = unsupportedDateTimeField15.getAsShortText((-31532880000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 126000100L + "'", long20 == 126000100L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        int int2 = dateTime1.getMillisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readablePeriod3);
        int int5 = dateTime4.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DurationField durationField4 = iSOChronology0.halfdays();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology0.days();
        try {
            long long16 = iSOChronology0.getDateTimeMillis(28, (-11), 7, 52, 1200, 0, (-2922650));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str13 = iSOChronology12.toString();
        org.joda.time.DurationField durationField14 = iSOChronology12.hours();
        org.joda.time.DurationField durationField15 = iSOChronology12.months();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology12.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitYear(12, true);
        boolean boolean26 = dateTimeFormatterBuilder25.canBuildFormatter();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusSeconds((int) (short) 1);
        boolean boolean32 = dateTime28.isBefore((long) 0);
        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property34 = dateTime28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder25.appendText(dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder20.appendShortText(dateTimeFieldType35);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField17, dateTimeFieldType35, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str41 = iSOChronology40.toString();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.secondOfDay();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime46 = dateTime44.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime47 = dateTime44.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate48 = dateTime44.toLocalDate();
        int[] intArray55 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology40.validate((org.joda.time.ReadablePartial) localDate48, intArray55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = remainderDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate48, locale57);
        long long60 = remainderDateTimeField39.roundHalfEven((long) 2922789);
        int int62 = remainderDateTimeField39.getMinimumValue(3600100L);
        long long64 = remainderDateTimeField39.roundCeiling((long) (-2922790));
        long long66 = remainderDateTimeField39.roundCeiling((long) 960);
        long long68 = remainderDateTimeField39.roundHalfFloor(0L);
        long long71 = remainderDateTimeField39.add(97L, 22L);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = remainderDateTimeField39.getType();
        boolean boolean73 = dateTime11.isSupported(dateTimeFieldType72);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[UTC]" + "'", str13.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[UTC]" + "'", str41.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1" + "'", str58.equals("1"));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2923000L + "'", long60 == 2923000L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2922000L) + "'", long64 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1000L + "'", long66 == 1000L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 22097L + "'", long71 == 22097L);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        boolean boolean17 = unsupportedDateTimeField15.isLenient();
        long long20 = unsupportedDateTimeField15.add(100L, (long) 35);
        try {
            long long23 = unsupportedDateTimeField15.addWrapField((long) (byte) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 126000100L + "'", long20 == 126000100L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
        int int66 = remainderDateTimeField27.getMinimumValue();
        int int68 = remainderDateTimeField27.get(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        int int8 = dateTime6.getWeekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfYear();
        org.joda.time.DateTime.Property property10 = dateTime6.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str4 = iSOChronology3.toString();
        long long8 = iSOChronology3.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        boolean boolean10 = dateTimeFormatter9.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withDefaultYear(0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.secondOfDay();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime17.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate21 = dateTime17.toLocalDate();
        int[] intArray28 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology13.validate((org.joda.time.ReadablePartial) localDate21, intArray28);
        java.lang.String str30 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) localDate21);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970-01-01" + "'", str30.equals("1970-01-01"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long19 = fixedDateTimeZone17.convertUTCToLocal((long) (-1));
        long long21 = fixedDateTimeZone17.previousTransition((long) 28);
        int int23 = fixedDateTimeZone17.getOffsetFromLocal(0L);
        boolean boolean24 = dateTime1.equals((java.lang.Object) fixedDateTimeZone17);
        java.util.TimeZone timeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) ' ');
        int int33 = dateTimeZone26.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime34 = dateTime1.withZoneRetainFields(dateTimeZone26);
        java.lang.String str35 = dateTimeZone26.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28L + "'", long21 == 28L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(gregorianChronology36);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 12);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) (byte) 0);
        java.lang.String str11 = fixedDateTimeZone4.getName((long) 28);
        java.lang.String str12 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int8 = fixedDateTimeZone6.getOffset((long) (byte) -1);
        java.lang.String str9 = fixedDateTimeZone6.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        long long24 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology25 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) zonedChronology10);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology10.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str9.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        long long18 = unsupportedDateTimeField15.getDifferenceAsLong((long) (short) 0, (long) 57600010);
        try {
            long long20 = unsupportedDateTimeField15.roundFloor(1942L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-16L) + "'", long18 == (-16L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 21100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder4.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate17 = dateTime13.toLocalDate();
        int[] intArray24 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology9.validate((org.joda.time.ReadablePartial) localDate17, intArray24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str27 = iSOChronology26.toString();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.secondOfDay();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime30.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate34 = dateTime30.toLocalDate();
        int[] intArray41 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology26.validate((org.joda.time.ReadablePartial) localDate34, intArray41);
        iSOChronology5.validate((org.joda.time.ReadablePartial) localDate17, intArray41);
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadablePartial) localDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[UTC]" + "'", str27.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 2);
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add((-31532880000L), (-28800000));
        long long13 = offsetDateTimeField7.roundHalfCeiling((long) 1969);
        boolean boolean14 = offsetDateTimeField7.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1759532880000L) + "'", long11 == (-1759532880000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long32 = remainderDateTimeField27.add((long) (byte) 100, 21);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str36 = iSOChronology35.toString();
        org.joda.time.DurationField durationField37 = iSOChronology35.hours();
        org.joda.time.DurationField durationField38 = iSOChronology35.months();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology35.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology35.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder42.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendTwoDigitYear(12, true);
        boolean boolean49 = dateTimeFormatterBuilder48.canBuildFormatter();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        boolean boolean55 = dateTime51.isBefore((long) 0);
        org.joda.time.DateTime dateTime56 = dateTime51.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property57 = dateTime51.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder48.appendText(dateTimeFieldType58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder43.appendShortText(dateTimeFieldType58);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField(dateTimeField40, dateTimeFieldType58, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str64 = iSOChronology63.toString();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.secondOfDay();
        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime69 = dateTime67.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime70 = dateTime67.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate71 = dateTime67.toLocalDate();
        int[] intArray78 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology63.validate((org.joda.time.ReadablePartial) localDate71, intArray78);
        java.util.Locale locale80 = null;
        java.lang.String str81 = remainderDateTimeField62.getAsText((org.joda.time.ReadablePartial) localDate71, locale80);
        long long83 = remainderDateTimeField62.roundHalfEven((long) 2922789);
        int int85 = remainderDateTimeField62.getMinimumValue(3600100L);
        long long87 = remainderDateTimeField62.roundCeiling((long) (-2922790));
        long long89 = remainderDateTimeField62.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType90 = remainderDateTimeField62.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType90, (-2922749));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField96 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType90, 86399, (-2922790), 19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 21100L + "'", long32 == 21100L);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[UTC]" + "'", str36.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "ISOChronology[UTC]" + "'", str64.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(mutableDateTime70);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "1" + "'", str81.equals("1"));
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 2923000L + "'", long83 == 2923000L);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-2922000L) + "'", long87 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1000L + "'", long89 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType90);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (byte) 1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        long long20 = unsupportedDateTimeField15.add(999L, 4078200);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 1);
        boolean boolean26 = dateTime22.isBefore((long) 0);
        org.joda.time.DateTime dateTime27 = dateTime22.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int35 = fixedDateTimeZone33.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance(chronology28, (org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone37 = zonedChronology36.getZone();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime41 = dateTime39.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime44 = dateTime43.toLocalTime();
        long long46 = zonedChronology36.set((org.joda.time.ReadablePartial) localTime44, (long) (-28800000));
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str49 = iSOChronology48.toString();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology48.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str53 = iSOChronology52.toString();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.secondOfDay();
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime58 = dateTime56.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime59 = dateTime56.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate60 = dateTime56.toLocalDate();
        int[] intArray67 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology52.validate((org.joda.time.ReadablePartial) localDate60, intArray67);
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str70 = iSOChronology69.toString();
        org.joda.time.DateTimeField dateTimeField71 = iSOChronology69.secondOfDay();
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime75 = dateTime73.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime76 = dateTime73.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate77 = dateTime73.toLocalDate();
        int[] intArray84 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology69.validate((org.joda.time.ReadablePartial) localDate77, intArray84);
        iSOChronology48.validate((org.joda.time.ReadablePartial) localDate60, intArray84);
        try {
            int[] intArray88 = unsupportedDateTimeField15.addWrapPartial((org.joda.time.ReadablePartial) localTime44, (int) (short) 10, intArray84, 4078200);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 14681520000999L + "'", long20 == 14681520000999L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localTime44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14431989L) + "'", long46 == (-14431989L));
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ISOChronology[UTC]" + "'", str49.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ISOChronology[UTC]" + "'", str53.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(mutableDateTime59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "ISOChronology[UTC]" + "'", str70.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(mutableDateTime76);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField15.getAsText((int) '4', locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long11 = fixedDateTimeZone9.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((-115199040L));
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(2100, 0, 69, (int) (short) -1, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.minusMinutes((-70));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) ' ');
        java.lang.String str18 = dateTime15.toString();
        int int19 = dateTime15.getMonthOfYear();
        org.joda.time.DateTime dateTime21 = dateTime15.minusMonths(2);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        org.joda.time.DateTime dateTime28 = dateTime25.minusDays((int) '#');
        int int29 = dateTime21.compareTo((org.joda.time.ReadableInstant) dateTime28);
        boolean boolean30 = property11.equals((java.lang.Object) int29);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str18.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) (byte) 0, 2000L);
        try {
            java.lang.String str22 = unsupportedDateTimeField15.getAsText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTime.Property property7 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.withDurationAdded(0L, (-70));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        boolean boolean17 = unsupportedDateTimeField15.isLenient();
        long long20 = unsupportedDateTimeField15.add(100L, (long) 35);
        try {
            long long22 = unsupportedDateTimeField15.remainder(14681520000999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 126000100L + "'", long20 == 126000100L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int11 = cachedDateTimeZone9.getOffset((long) 100);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone9.getUncachedZone();
        long long15 = dateTimeZone13.convertUTCToLocal(0L);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone13);
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateMidnight17);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 86399010);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86399010 + "'", int2 == 86399010);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        int int53 = remainderDateTimeField27.getDivisor();
        long long56 = remainderDateTimeField27.set((long) 15, 1970);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 86399 + "'", int53 == 86399);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1970015L + "'", long56 == 1970015L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withOffsetParsed();
        org.joda.time.Chronology chronology12 = dateTimeFormatter11.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology17 = dateTimeFormatter16.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter16.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str20 = iSOChronology19.toString();
        long long24 = iSOChronology19.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean27 = iSOChronology19.equals((java.lang.Object) dateTimeFormatter26);
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder7.append(dateTimePrinter13, dateTimeParser28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder7.appendFractionOfHour((int) (short) 0, 86398);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ISOChronology[UTC]" + "'", str20.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) '4', (int) ' ');
        int int27 = dateTime26.getMinuteOfHour();
        boolean boolean28 = zonedChronology15.equals((java.lang.Object) dateTime26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale35 = null;
        java.lang.String str36 = fixedDateTimeZone33.getName((-100L), locale35);
        java.util.TimeZone timeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime42 = dateTime40.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime44 = dateTime42.minusSeconds((int) ' ');
        int int45 = dateTimeZone38.getOffset((org.joda.time.ReadableInstant) dateTime42);
        long long47 = fixedDateTimeZone33.getMillisKeepLocal(dateTimeZone38, 3600100L);
        long long49 = fixedDateTimeZone33.nextTransition((long) (-2922789));
        java.util.Locale locale51 = null;
        java.lang.String str52 = fixedDateTimeZone33.getName(0L, locale51);
        org.joda.time.Chronology chronology53 = zonedChronology15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00" + "'", str36.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3600100L + "'", long47 == 3600100L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2922789L) + "'", long49 == (-2922789L));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+00:00" + "'", str52.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology53);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime15 = dateTime3.minusYears(960);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds((int) ' ');
        boolean boolean22 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime15.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(0, (int) ' ', 960, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long11 = fixedDateTimeZone9.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName(350L, locale14);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10, (-28800000), 19, (int) (byte) 100, 4078200, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "2019-06-15", "Property[centuryOfEra]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "2019-06-15", "1969-12-27T20:00:00.010Z");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "millisOfSecond", "1970-01-01");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", (java.lang.Number) (-1.0d), (java.lang.Number) 1.0f, (java.lang.Number) 0);
        java.lang.Throwable[] throwableArray11 = illegalFieldValueException10.getSuppressed();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str13 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.lang.String str5 = property4.toString();
        int int6 = property4.getLeapAmount();
        org.joda.time.Interval interval7 = property4.toInterval();
        int int8 = property4.get();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[centuryOfEra]" + "'", str5.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long16 = fixedDateTimeZone14.convertUTCToLocal((long) (-1));
        long long18 = fixedDateTimeZone14.previousTransition((long) 28);
        java.util.TimeZone timeZone19 = fixedDateTimeZone14.toTimeZone();
        long long23 = fixedDateTimeZone14.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology24 = zonedChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        long long27 = cachedDateTimeZone25.previousTransition((long) 2000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28L + "'", long18 == 28L);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2000L + "'", long27 == 2000L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        long long46 = preciseDateTimeField44.getUnitMillis();
        long long48 = preciseDateTimeField44.roundFloor((long) 960);
        try {
            long long51 = preciseDateTimeField44.set((long) (short) 1, (-2922790));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922790 for dayOfMonth must be in the range [0,59999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 960L + "'", long48 == 960L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long32 = remainderDateTimeField27.add((long) (byte) 100, 21);
        int int34 = remainderDateTimeField27.getLeapAmount(69L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 21100L + "'", long32 == 21100L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds(10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime12.plusYears(2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-1), (-70), 69, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 1);
        boolean boolean15 = dateTime11.isBefore((long) 0);
        org.joda.time.DateTime dateTime16 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) '4');
        org.joda.time.DateTime.Property property21 = dateTime16.minuteOfDay();
        org.joda.time.DurationField durationField22 = property21.getDurationField();
        org.joda.time.Interval interval23 = property21.toInterval();
        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval23);
        boolean boolean25 = iSOChronology0.equals((java.lang.Object) readableInterval24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(interval23);
        org.junit.Assert.assertNotNull(readableInterval24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) (byte) 0, 2000L);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime22.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate26 = dateTime22.toLocalDate();
        int[] intArray31 = new int[] { ' ', (byte) 0, 4, 19 };
        try {
            int int32 = unsupportedDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate26, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        try {
            java.lang.String str18 = unsupportedDateTimeField15.getAsText((long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-2922000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int28 = remainderDateTimeField27.getDivisor();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.secondOfDay();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime35 = dateTime33.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime36 = dateTime33.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate37 = dateTime33.toLocalDate();
        int[] intArray44 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology29.validate((org.joda.time.ReadablePartial) localDate37, intArray44);
        int[] intArray51 = new int[] { 2922789, (-2922789), (-2922650), 86398, 57600010 };
        int int52 = remainderDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDate37, intArray51);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter53.withPivotYear((java.lang.Integer) 69);
        org.joda.time.LocalTime localTime57 = dateTimeFormatter53.parseLocalTime("1969-12-27T20:00:00.010Z");
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str60 = iSOChronology59.toString();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology59.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str64 = iSOChronology63.toString();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.secondOfDay();
        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime69 = dateTime67.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime70 = dateTime67.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate71 = dateTime67.toLocalDate();
        int[] intArray78 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology63.validate((org.joda.time.ReadablePartial) localDate71, intArray78);
        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str81 = iSOChronology80.toString();
        org.joda.time.DateTimeField dateTimeField82 = iSOChronology80.secondOfDay();
        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime86 = dateTime84.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime87 = dateTime84.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate88 = dateTime84.toLocalDate();
        int[] intArray95 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology80.validate((org.joda.time.ReadablePartial) localDate88, intArray95);
        iSOChronology59.validate((org.joda.time.ReadablePartial) localDate71, intArray95);
        try {
            int[] intArray99 = remainderDateTimeField27.add((org.joda.time.ReadablePartial) localTime57, (int) (short) 0, intArray95, (-2922789));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86399 + "'", int28 == 86399);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[UTC]" + "'", str30.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(localTime57);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "ISOChronology[UTC]" + "'", str60.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "ISOChronology[UTC]" + "'", str64.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(mutableDateTime70);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(iSOChronology80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "ISOChronology[UTC]" + "'", str81.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(mutableDateTime87);
        org.junit.Assert.assertNotNull(localDate88);
        org.junit.Assert.assertNotNull(intArray95);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property4.addToCopy((long) 2);
        org.joda.time.DateTime dateTime10 = property4.roundFloorCopy();
        int int11 = property4.getMaximumValue();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property4.getAsText(locale12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2922789 + "'", int11 == 2922789);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "19" + "'", str13.equals("19"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime6.minuteOfDay();
        org.joda.time.DurationField durationField12 = property11.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property11.getAsText(locale13);
        org.joda.time.DurationField durationField15 = property11.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.minusMonths(2);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime13.minusDays((int) '#');
        int int17 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime16);
        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3024000990L) + "'", long18 == (-3024000990L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("hi!", (int) '#');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((long) 100);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology17 = dateTimeFormatter16.getChronology();
        java.lang.String str18 = dateTime12.toString(dateTimeFormatter16);
        org.joda.time.DateTime dateTime21 = dateTime12.withDurationAdded(3600100L, (int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime12.dayOfMonth();
        int int23 = cachedDateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime25 = dateTime12.withYearOfEra((int) '#');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(chronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01" + "'", str18.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendTimeZoneOffset("Property[centuryOfEra]", true, 1969, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((-961));
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readablePeriod14);
        int int16 = dateTime15.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getName((-100L), locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) ' ');
        int int30 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 3600100L);
        org.joda.time.DateTime dateTime33 = dateTime13.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime34 = dateTime33.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600100L + "'", long32 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        boolean boolean10 = property4.isLeap();
        org.joda.time.Interval interval11 = property4.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(interval11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-16L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(75600350L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int8 = fixedDateTimeZone6.getOffset((long) (byte) -1);
        java.lang.String str9 = fixedDateTimeZone6.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        long long24 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology25 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) zonedChronology10);
        org.joda.time.DurationField durationField27 = zonedChronology10.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str9.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        int int8 = dateTime3.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1200 + "'", int8 == 1200);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (-2922790));
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long9 = fixedDateTimeZone7.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) fixedDateTimeZone7);
        long long15 = iSOChronology0.add(1560633921247L, 0L, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560633921247L + "'", long15 == 1560633921247L);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime6 = dateTime1.minusMinutes((int) (byte) -1);
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        long long46 = preciseDateTimeField44.getUnitMillis();
        int int47 = preciseDateTimeField44.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 59999 + "'", int47 == 59999);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        java.util.Locale locale13 = null;
        java.util.Calendar calendar14 = dateTime12.toCalendar(locale13);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(calendar14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        long long25 = zonedChronology15.set((org.joda.time.ReadablePartial) localTime23, (long) (-28800000));
        java.lang.String str26 = zonedChronology15.toString();
        try {
            long long31 = zonedChronology15.getDateTimeMillis((int) (byte) 10, (int) (short) 100, 86398, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-14431989L) + "'", long25 == (-14431989L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]" + "'", str26.equals("ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        long long50 = remainderDateTimeField27.roundHalfEven((long) 1);
        int int52 = remainderDateTimeField27.get(21L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        boolean boolean10 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.minus((long) (-1));
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime12.withYearOfEra(86398);
        try {
            org.joda.time.DateTime dateTime17 = dateTime12.withMinuteOfHour(86399010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399010 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        boolean boolean7 = dateTime3.isBefore((long) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) dateTime8);
        java.util.GregorianCalendar gregorianCalendar10 = dateTime8.toGregorianCalendar();
        org.joda.time.Chronology chronology11 = dateTime8.getChronology();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long20 = fixedDateTimeZone18.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = fixedDateTimeZone18.isLocalDateTimeGap(localDateTime21);
        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int25 = fixedDateTimeZone18.getStandardOffset((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime7 = dateTime1.plusMonths((-2922789));
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime10 = property8.setCopy("1969-12-27T12:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-27T12:00:00.010-08:00\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "Property[centuryOfEra]");
        java.lang.String str29 = illegalFieldValueException28.getIllegalStringValue();
        java.lang.Throwable[] throwableArray30 = illegalFieldValueException28.getSuppressed();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Property[centuryOfEra]" + "'", str29.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertNotNull(throwableArray30);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        long long47 = preciseDateTimeField44.roundCeiling((long) (-2922650));
        java.lang.String str48 = preciseDateTimeField44.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2922650L) + "'", long47 == (-2922650L));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str48.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendYearOfCentury(1969, (int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            long long17 = unsupportedDateTimeField15.roundHalfFloor((long) (-2922790));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        boolean boolean17 = unsupportedDateTimeField15.isLenient();
        long long20 = unsupportedDateTimeField15.add(100L, (long) 35);
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = unsupportedDateTimeField15.getAsShortText(2923000L, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 126000100L + "'", long20 == 126000100L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.GregorianCalendar gregorianCalendar1 = dateTime0.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gregorianCalendar1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        int int8 = dateTime7.getMinuteOfHour();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfCentury(4);
        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven(0L);
        long long51 = remainderDateTimeField27.addWrapField((long) ' ', 52);
        java.util.Locale locale53 = null;
        java.lang.String str54 = remainderDateTimeField27.getAsText(10, locale53);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52032L + "'", long51 == 52032L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 1);
        boolean boolean14 = dateTime10.isBefore((long) 0);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int23 = fixedDateTimeZone21.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology24.getZone();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime3.withZoneRetainFields(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter1.parseMutableDateTime("2019-06-15");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        long long6 = dateTimeZone4.convertUTCToLocal((long) 1969);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getName((-100L), locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) ' ');
        int int30 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 3600100L);
        org.joda.time.DateTime dateTime33 = dateTime13.withZone(dateTimeZone23);
        org.joda.time.LocalDate localDate34 = dateTime13.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600100L + "'", long32 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate34);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((java.lang.Integer) 69);
        org.joda.time.LocalTime localTime53 = dateTimeFormatter49.parseLocalTime("1969-12-27T20:00:00.010Z");
        java.util.Locale locale54 = null;
        try {
            java.lang.String str55 = remainderDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localTime53, locale54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(localTime53);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        boolean boolean13 = dateTime10.isAfter((-1L));
        org.joda.time.DateTime dateTime15 = dateTime10.minusYears(1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds(10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", 12, (int) (byte) 0);
        long long19 = fixedDateTimeZone17.nextTransition((long) 69);
        org.joda.time.DateTime dateTime20 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        try {
            org.joda.time.DateTime dateTime22 = dateTime10.withEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 69L + "'", long19 == 69L);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long13 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 0, false, 32L);
        int int15 = fixedDateTimeZone4.getOffset(75600350L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 100 + "'", number7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 100 + "'", number8.equals((short) 100));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        boolean boolean17 = unsupportedDateTimeField15.isLenient();
        long long20 = unsupportedDateTimeField15.add(100L, (long) 35);
        try {
            long long22 = unsupportedDateTimeField15.roundHalfFloor((long) 86398);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 126000100L + "'", long20 == 126000100L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        long long65 = offsetDateTimeField59.remainder((long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 31535999999L + "'", long65 == 31535999999L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", (java.lang.Number) (-1.0d), (java.lang.Number) 1.0f, (java.lang.Number) 0);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        java.lang.String str53 = remainderDateTimeField27.toString();
        java.util.Locale locale54 = null;
        int int55 = remainderDateTimeField27.getMaximumTextLength(locale54);
        long long57 = remainderDateTimeField27.roundHalfCeiling((long) 4078200);
        long long59 = remainderDateTimeField27.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str53.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 5 + "'", int55 == 5);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 4078000L + "'", long57 == 4078000L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendFractionOfHour(10, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitYear((int) '4', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendHourOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendCenturyOfEra(1200, 69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        boolean boolean10 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.monthOfYear();
        int int12 = property11.getMinimumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property11.getAsShortText(locale13);
        boolean boolean15 = property11.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Dec" + "'", str14.equals("Dec"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTimeZoneShortName(strMap18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter20.withOffsetParsed();
        org.joda.time.Chronology chronology22 = dateTimeFormatter21.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatter21.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser24 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter23, dateTimeParser24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology27 = dateTimeFormatter26.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatter26.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str30 = iSOChronology29.toString();
        long long34 = iSOChronology29.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean37 = iSOChronology29.equals((java.lang.Object) dateTimeFormatter36);
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder17.append(dateTimePrinter23, dateTimeParser38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder9.append(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[UTC]" + "'", str30.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = iSOChronology0.get(readablePeriod6, 14681521200999L, (long) 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1969-12-31");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException13.getDurationFieldType();
        illegalFieldValueException13.prependMessage("1969-12-31");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        java.lang.String str22 = illegalFieldValueException21.toString();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.String str24 = illegalFieldValueException13.getIllegalValueAsString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", "hi!");
        java.lang.String str29 = illegalFieldValueException28.getIllegalValueAsString();
        java.lang.String str30 = illegalFieldValueException28.getIllegalStringValue();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException28);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str22.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100.0" + "'", str24.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis(0L);
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.DurationField durationField10 = property9.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(59999, (-2922749), 0, 2922789, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime15 = dateTime3.minusYears(960);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds((int) ' ');
        boolean boolean22 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime21.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        java.io.Writer writer4 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) ' ');
        java.lang.String str11 = dateTime8.toString();
        try {
            dateTimeFormatter1.printTo(writer4, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str11.equals("1969-12-27T20:00:00.010Z"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven(0L);
        long long51 = remainderDateTimeField27.addWrapField((long) ' ', 52);
        int int54 = remainderDateTimeField27.getDifference(10L, (long) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52032L + "'", long51 == 52032L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        int int5 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        java.lang.String str7 = property4.toString();
        org.joda.time.Interval interval8 = property4.toInterval();
        org.joda.time.DateTime dateTime9 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[centuryOfEra]" + "'", str7.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 1);
        boolean boolean10 = dateTime6.isBefore((long) 0);
        org.joda.time.DateTime dateTime11 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int19 = fixedDateTimeZone17.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone21 = zonedChronology20.getZone();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
        long long30 = zonedChronology20.set((org.joda.time.ReadablePartial) localTime28, (long) (-28800000));
        java.lang.Object obj31 = null;
        boolean boolean32 = zonedChronology20.equals(obj31);
        try {
            org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((int) (short) 0, 21, (int) 'a', 8, 12, (org.joda.time.Chronology) zonedChronology20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localTime28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14431989L) + "'", long30 == (-14431989L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField59.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (-3024000990L), (java.lang.Number) (-3024000990L), (java.lang.Number) (-14431989L));
        java.lang.Number number71 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) 101L, (java.lang.Number) (-7686192729599900L), number71);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        long long8 = iSOChronology0.add((long) (byte) 100, (long) (byte) -1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology10 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 99L + "'", long8 == 99L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyearOfCentury();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime21.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology26 = dateTimeFormatter25.getChronology();
        java.lang.String str27 = dateTime21.toString(dateTimeFormatter25);
        int int28 = dateTime21.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime21.toYearMonthDay();
        long long31 = iSOChronology18.set((org.joda.time.ReadablePartial) yearMonthDay29, (-2922789L));
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology34 = iSOChronology33.withUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.weekyear();
        org.joda.time.DurationField durationField36 = iSOChronology33.hours();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate42 = dateTime38.toLocalDate();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str44 = iSOChronology43.toString();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.secondOfDay();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime49 = dateTime47.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime50 = dateTime47.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate51 = dateTime47.toLocalDate();
        int[] intArray58 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology43.validate((org.joda.time.ReadablePartial) localDate51, intArray58);
        iSOChronology33.validate((org.joda.time.ReadablePartial) localDate42, intArray58);
        try {
            int[] intArray62 = unsupportedDateTimeField15.set((org.joda.time.ReadablePartial) yearMonthDay29, 8, intArray58, (-11));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNull(chronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-01-01" + "'", str27.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 83477211L + "'", long31 == 83477211L);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ISOChronology[UTC]" + "'", str44.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ZonedChronology[GregorianChronology[UTC], 1969-12-27T12:00:00.010-08:00]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ZonedChronology[GregorianChronology[UTC], 1969-12-27T12:00:00.010-08:00]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 2, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long12 = fixedDateTimeZone10.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone10.getName(350L, locale15);
        org.joda.time.DateTime dateTime17 = dateTime5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (-1.0d), (java.lang.Number) 100.0d, (java.lang.Number) (-16L));
        java.lang.String str49 = illegalFieldValueException48.getIllegalStringValue();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        java.lang.String str53 = remainderDateTimeField27.toString();
        int int54 = remainderDateTimeField27.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str53.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 86398 + "'", int54 == 86398);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) (byte) 0, 2000L);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField15.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime15 = dateTime3.minusYears(960);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond(960);
        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfEra(69);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendWeekOfWeekyear(57600010);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField59.getType();
        boolean boolean66 = offsetDateTimeField59.isLeap(10002L);
        long long68 = offsetDateTimeField59.roundHalfFloor((-14431989L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendSecondOfMinute(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatterBuilder18.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(59999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendSecondOfDay(59999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (byte) 10, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYear(100, (int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("1969-12-27T12:00:00.010-08:00", "1969-12-27T20:00:00.010Z", false, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.ReadableInstant readableInstant3 = null;
        java.lang.String str4 = dateTimeFormatter0.print(readableInstant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31" + "'", str4.equals("1969-12-31"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DurationField durationField4 = iSOChronology0.halfdays();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            long long10 = iSOChronology0.set(readablePartial8, (-2921000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        int int8 = dateTime7.getMinuteOfHour();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfCentury(4);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 52, (-70));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds(10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusDays((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 12, (int) (byte) 0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 1439, (int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((-70));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendWeekyear((int) (short) 100, 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DurationField durationField12 = iSOChronology10.hours();
        org.joda.time.DurationField durationField13 = iSOChronology10.months();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitYear(12, true);
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildFormatter();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime26.minusSeconds((int) (short) 1);
        boolean boolean30 = dateTime26.isBefore((long) 0);
        org.joda.time.DateTime dateTime31 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property32 = dateTime26.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder23.appendText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType33);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField15, dateTimeFieldType33, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str39 = iSOChronology38.toString();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.secondOfDay();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime44 = dateTime42.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime45 = dateTime42.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate46 = dateTime42.toLocalDate();
        int[] intArray53 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology38.validate((org.joda.time.ReadablePartial) localDate46, intArray53);
        java.util.Locale locale55 = null;
        java.lang.String str56 = remainderDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDate46, locale55);
        long long58 = remainderDateTimeField37.roundHalfEven((long) 2922789);
        int int60 = remainderDateTimeField37.getMinimumValue(3600100L);
        long long62 = remainderDateTimeField37.roundCeiling((long) (-2922790));
        long long64 = remainderDateTimeField37.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = remainderDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder9.appendFixedSignedDecimal(dateTimeFieldType65, (int) (byte) 10);
        boolean boolean68 = dateTime1.isSupported(dateTimeFieldType65);
        java.util.Date date69 = dateTime1.toDate();
        int int70 = dateTime1.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[UTC]" + "'", str39.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1" + "'", str56.equals("1"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2923000L + "'", long58 == 2923000L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-2922000L) + "'", long62 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1000L + "'", long64 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean8 = dateTime5.isEqual((long) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime15 = dateTime3.minusYears(960);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime20 = dateTime15.withDate(52, 28, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        java.util.Locale locale49 = null;
        int int50 = remainderDateTimeField27.getMaximumShortTextLength(locale49);
        java.util.Locale locale51 = null;
        int int52 = remainderDateTimeField27.getMaximumShortTextLength(locale51);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.DurationField durationField11 = gregorianChronology9.months();
        org.joda.time.DurationField durationField12 = gregorianChronology9.months();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.era();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) '#', (long) (byte) 100);
        java.lang.String str21 = unsupportedDateTimeField15.toString();
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = unsupportedDateTimeField15.getAsText((long) 5, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UnsupportedDateTimeField" + "'", str21.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime10 = property4.roundHalfCeilingCopy();
        int int11 = dateTime10.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField59.getType();
        org.joda.time.DurationField durationField65 = offsetDateTimeField59.getRangeDurationField();
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField59.getAsShortText((-2922650), locale67);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "-2922650" + "'", str68.equals("-2922650"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter9);
        java.lang.String str11 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection12 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15" + "'", str11.equals("2019-06-15"));
        org.junit.Assert.assertNotNull(permissionCollection12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15");
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(chronology4);
        org.junit.Assert.assertNull(dateTimeZone5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfSecond();
        long long8 = iSOChronology0.getDateTimeMillis(0, (int) (byte) 10, 2, (int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62143459199990L) + "'", long8 == (-62143459199990L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withYearOfCentury(2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar6 = dateTime5.toGregorianCalendar();
        int int7 = dateTime5.getSecondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int16 = fixedDateTimeZone14.getOffset((long) (byte) -1);
        java.lang.String str17 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long25 = fixedDateTimeZone23.convertUTCToLocal((long) (-1));
        long long27 = fixedDateTimeZone23.previousTransition((long) 28);
        java.util.TimeZone timeZone28 = fixedDateTimeZone23.toTimeZone();
        long long32 = fixedDateTimeZone23.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology33 = zonedChronology18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) zonedChronology18);
        boolean boolean35 = dateTime34.isBeforeNow();
        boolean boolean36 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime34);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str17.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28L + "'", long27 == 28L);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        int int12 = property11.getLeapAmount();
        org.joda.time.DateTime dateTime14 = property11.addToCopy((-2922789));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.hours();
        org.joda.time.DurationField durationField40 = iSOChronology37.months();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology37.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(12, true);
        boolean boolean51 = dateTimeFormatterBuilder50.canBuildFormatter();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) (short) 1);
        boolean boolean57 = dateTime53.isBefore((long) 0);
        org.joda.time.DateTime dateTime58 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property59 = dateTime53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder50.appendText(dateTimeFieldType60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder45.appendShortText(dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField42, dateTimeFieldType60, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType60, 69);
        long long69 = remainderDateTimeField27.roundHalfCeiling((long) 1969);
        java.util.Locale locale70 = null;
        int int71 = remainderDateTimeField27.getMaximumShortTextLength(locale70);
        long long73 = remainderDateTimeField27.roundFloor(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2000L + "'", long69 == 2000L);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 5 + "'", int71 == 5);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime9 = dateTime3.withMinuteOfHour(8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property4.addToCopy((long) 2);
        org.joda.time.DateTime dateTime10 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0L);
        java.util.GregorianCalendar gregorianCalendar13 = dateTime12.toGregorianCalendar();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
        java.lang.String str19 = property18.getAsText();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str21 = iSOChronology20.toString();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str25 = iSOChronology24.toString();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.secondOfDay();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate32 = dateTime28.toLocalDate();
        int[] intArray39 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology24.validate((org.joda.time.ReadablePartial) localDate32, intArray39);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str42 = iSOChronology41.toString();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.secondOfDay();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime48 = dateTime45.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate49 = dateTime45.toLocalDate();
        int[] intArray56 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology41.validate((org.joda.time.ReadablePartial) localDate49, intArray56);
        iSOChronology20.validate((org.joda.time.ReadablePartial) localDate32, intArray56);
        int int59 = property18.compareTo((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime63 = dateTime61.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime65 = dateTime63.minusSeconds((int) ' ');
        java.lang.String str66 = dateTime63.toString();
        int int67 = dateTime63.getMonthOfYear();
        org.joda.time.DateTime dateTime68 = dateTime63.toDateTimeISO();
        int int69 = property18.compareTo((org.joda.time.ReadableInstant) dateTime68);
        org.joda.time.LocalDate localDate70 = dateTime68.toLocalDate();
        org.joda.time.DateTime dateTime71 = dateTime12.withFields((org.joda.time.ReadablePartial) localDate70);
        int int72 = property4.compareTo((org.joda.time.ReadablePartial) localDate70);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19" + "'", str19.equals("19"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[UTC]" + "'", str21.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[UTC]" + "'", str25.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ISOChronology[UTC]" + "'", str42.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str66.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 12 + "'", int67 == 12);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getName((-100L), locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) ' ');
        int int30 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 3600100L);
        org.joda.time.DateTime dateTime33 = dateTime13.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime35 = dateTime33.plusMinutes((-11));
        org.joda.time.DateTime.Property property36 = dateTime35.year();
        int int37 = property36.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600100L + "'", long32 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 292278993 + "'", int37 == 292278993);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime14.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology19 = dateTimeFormatter18.getChronology();
        java.lang.String str20 = dateTime14.toString(dateTimeFormatter18);
        java.lang.Class<?> wildcardClass21 = dateTimeFormatter18.getClass();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01" + "'", str20.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.DateTime.Property property7 = dateTime3.centuryOfEra();
        org.joda.time.Interval interval8 = property7.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology19 = iSOChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.weekyear();
        org.joda.time.DurationField durationField21 = iSOChronology18.hours();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime23.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate27 = dateTime23.toLocalDate();
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        iSOChronology18.validate((org.joda.time.ReadablePartial) localDate27, intArray43);
        try {
            int[] intArray47 = unsupportedDateTimeField15.addWrapField(readablePartial16, (-28800000), intArray43, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime13 = property11.addToCopy((long) (short) 1);
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime13.toCalendar(locale14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) (short) 1);
        boolean boolean21 = dateTime17.isBefore((long) 0);
        org.joda.time.DateTime dateTime22 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property23 = dateTime17.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str26 = iSOChronology25.toString();
        org.joda.time.DurationField durationField27 = iSOChronology25.hours();
        long long30 = durationField27.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField27);
        org.joda.time.DateTime.Property property32 = dateTime13.property(dateTimeFieldType24);
        org.joda.time.DateTime dateTime33 = property32.getDateTime();
        org.joda.time.DateTime dateTime34 = property32.getDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(calendar15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[UTC]" + "'", str26.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-115199040L) + "'", long30 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear(12, true);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 1);
        boolean boolean14 = dateTime10.isBefore((long) 0);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property16 = dateTime10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(59999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.DateTime.Property property7 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) ' ');
        java.lang.String str14 = dateTime11.toString();
        org.joda.time.TimeOfDay timeOfDay15 = dateTime11.toTimeOfDay();
        boolean boolean16 = dateTime11.isBeforeNow();
        org.joda.time.DateTime dateTime18 = dateTime11.plus((long) '4');
        int int19 = property7.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime23 = dateTime21.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime25 = dateTime23.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar26 = dateTime25.toGregorianCalendar();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime33 = dateTime30.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime34 = dateTime33.toMutableDateTime();
        org.joda.time.DateTime dateTime37 = dateTime33.withDurationAdded((long) 35, (int) '4');
        boolean boolean38 = dateTime25.isBefore((org.joda.time.ReadableInstant) dateTime37);
        int int39 = property7.getDifference((org.joda.time.ReadableInstant) dateTime37);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str14.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gregorianCalendar26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        int int10 = fixedDateTimeZone4.getOffset((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(83477211L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter1.getZone();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter1.printTo(stringBuffer4, 101L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getName((-100L), locale18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) ' ');
        int int28 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime25);
        long long30 = fixedDateTimeZone16.getMillisKeepLocal(dateTimeZone21, 3600100L);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = dateTimeZone21.isLocalDateTimeGap(localDateTime31);
        long long34 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone21, (long) 'a');
        java.lang.String str35 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3600100L + "'", long30 == 3600100L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        try {
            long long13 = iSOChronology0.getDateTimeMillis(0, 1, 59999, (int) (short) -1, 292278993, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-15");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]");
        java.lang.String str8 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar6 = dateTime5.toGregorianCalendar();
        org.joda.time.DateTime dateTime8 = dateTime5.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        org.joda.time.DurationField durationField10 = property9.getRangeDurationField();
        long long11 = property9.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 71968010L + "'", long11 == 71968010L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-62143459199990L), 28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        int int11 = property10.getMaximumValueOverall();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.DateTime dateTime14 = property10.setCopy("Coordinated Universal Time", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-31536000000L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        java.util.Locale locale31 = null;
        java.lang.String str32 = remainderDateTimeField27.getAsText((long) 52, locale31);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        boolean boolean38 = dateTime34.isBefore((long) 0);
        org.joda.time.DateTime dateTime39 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int47 = fixedDateTimeZone45.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology48 = org.joda.time.chrono.ZonedChronology.getInstance(chronology40, (org.joda.time.DateTimeZone) fixedDateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone49 = zonedChronology48.getZone();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime56 = dateTime55.toLocalTime();
        long long58 = zonedChronology48.set((org.joda.time.ReadablePartial) localTime56, (long) (-28800000));
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology61 = iSOChronology60.withUTC();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology60.weekyear();
        org.joda.time.DurationField durationField63 = iSOChronology60.hours();
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime67 = dateTime65.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime68 = dateTime65.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate69 = dateTime65.toLocalDate();
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str71 = iSOChronology70.toString();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology70.secondOfDay();
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime76 = dateTime74.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime77 = dateTime74.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate78 = dateTime74.toLocalDate();
        int[] intArray85 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology70.validate((org.joda.time.ReadablePartial) localDate78, intArray85);
        iSOChronology60.validate((org.joda.time.ReadablePartial) localDate69, intArray85);
        try {
            int[] intArray89 = remainderDateTimeField27.set((org.joda.time.ReadablePartial) localTime56, 0, intArray85, (-70));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for dayOfMonth must be in the range [0,86398]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localTime56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-14431989L) + "'", long58 == (-14431989L));
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(mutableDateTime68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "ISOChronology[UTC]" + "'", str71.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(mutableDateTime77);
        org.junit.Assert.assertNotNull(localDate78);
        org.junit.Assert.assertNotNull(intArray85);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long31 = remainderDateTimeField27.remainder((-1L));
        long long33 = remainderDateTimeField27.roundHalfFloor((-31536000000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = remainderDateTimeField27.getType();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime38 = dateTime36.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime39 = dateTime36.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate40 = dateTime36.toLocalDate();
        int int41 = remainderDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDate40);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 999L + "'", long31 == 999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-31536000000L) + "'", long33 == (-31536000000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 86398 + "'", int41 == 86398);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime5.minusMillis((-2922679));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        long long20 = unsupportedDateTimeField15.add(999L, 4078200);
        try {
            int int21 = unsupportedDateTimeField15.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 14681520000999L + "'", long20 == 14681520000999L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = iSOChronology0.add(readablePeriod4, 2100L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2100L + "'", long7 == 2100L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        int int64 = offsetDateTimeField59.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-2922749) + "'", int64 == (-2922749));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        int int2 = dateTime1.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
        java.lang.String str4 = dateTimeZone3.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendSecondOfMinute(1);
        boolean boolean18 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime20.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime24 = dateTime22.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property25 = dateTime22.year();
        java.lang.String str26 = property25.getAsShortText();
        java.lang.String str27 = property25.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType28, 0, (-2922789), (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder4.appendSignedDecimal(dateTimeFieldType28, 15, (-2922650));
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime39 = dateTime37.minusSeconds((int) (short) 1);
        boolean boolean41 = dateTime37.isBefore((long) 0);
        org.joda.time.DateTime dateTime42 = dateTime37.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property43 = dateTime37.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str46 = iSOChronology45.toString();
        org.joda.time.DurationField durationField47 = iSOChronology45.hours();
        long long50 = durationField47.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType44, 32, 28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1969" + "'", str26.equals("1969"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Property[year]" + "'", str27.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ISOChronology[UTC]" + "'", str46.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-115199040L) + "'", long50 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        long long54 = remainderDateTimeField27.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = remainderDateTimeField27.getType();
        org.joda.time.DurationField durationField56 = remainderDateTimeField27.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1000L + "'", long54 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(durationField56);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        long long51 = remainderDateTimeField27.add((long) 2, (long) 10);
        long long53 = remainderDateTimeField27.roundHalfFloor((-16L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10002L + "'", long51 == 10002L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        boolean boolean12 = gregorianChronology9.equals((java.lang.Object) 21);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray16 = gregorianChronology9.get(readablePeriod13, 2100L, 10002L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        long long20 = unsupportedDateTimeField15.add(999L, 4078200);
        long long23 = unsupportedDateTimeField15.add(350L, 21);
        boolean boolean24 = unsupportedDateTimeField15.isLenient();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 14681520000999L + "'", long20 == 14681520000999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 75600350L + "'", long23 == 75600350L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")"));
        org.junit.Assert.assertNotNull(permissionCollection4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1969-12-31");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        java.lang.String str13 = illegalFieldValueException12.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.String str15 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str19 = iSOChronology18.toString();
        org.joda.time.DurationField durationField20 = iSOChronology18.hours();
        org.joda.time.DurationField durationField21 = iSOChronology18.months();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology18.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendTwoDigitYear(12, true);
        boolean boolean32 = dateTimeFormatterBuilder31.canBuildFormatter();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        boolean boolean38 = dateTime34.isBefore((long) 0);
        org.joda.time.DateTime dateTime39 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property40 = dateTime34.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder31.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField23, dateTimeFieldType41, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str47 = iSOChronology46.toString();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.secondOfDay();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime52 = dateTime50.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime53 = dateTime50.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate54 = dateTime50.toLocalDate();
        int[] intArray61 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology46.validate((org.joda.time.ReadablePartial) localDate54, intArray61);
        java.util.Locale locale63 = null;
        java.lang.String str64 = remainderDateTimeField45.getAsText((org.joda.time.ReadablePartial) localDate54, locale63);
        long long66 = remainderDateTimeField45.roundHalfEven((long) 2922789);
        int int68 = remainderDateTimeField45.getMinimumValue(3600100L);
        long long70 = remainderDateTimeField45.roundCeiling((long) (-2922790));
        long long72 = remainderDateTimeField45.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = remainderDateTimeField45.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType73, (-2922749));
        int int77 = offsetDateTimeField75.get((long) (byte) 10);
        boolean boolean79 = offsetDateTimeField75.isLeap((long) 21);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = offsetDateTimeField75.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType80, (java.lang.Number) (-3024000990L), (java.lang.Number) (-3024000990L), (java.lang.Number) (-14431989L));
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException84);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100.0" + "'", str15.equals("100.0"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[UTC]" + "'", str47.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1" + "'", str64.equals("1"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2923000L + "'", long66 == 2923000L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-2922000L) + "'", long70 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1000L + "'", long72 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-2922679) + "'", int77 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = cachedDateTimeZone8.adjustOffset(10L, false);
        int int13 = cachedDateTimeZone8.getOffset((long) 12);
        boolean boolean14 = cachedDateTimeZone8.isFixed();
        int int16 = cachedDateTimeZone8.getStandardOffset(0L);
        long long18 = cachedDateTimeZone8.nextTransition((long) (-2922789));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2922789L) + "'", long18 == (-2922789L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.hours();
        org.joda.time.DurationField durationField40 = iSOChronology37.months();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology37.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(12, true);
        boolean boolean51 = dateTimeFormatterBuilder50.canBuildFormatter();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) (short) 1);
        boolean boolean57 = dateTime53.isBefore((long) 0);
        org.joda.time.DateTime dateTime58 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property59 = dateTime53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder50.appendText(dateTimeFieldType60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder45.appendShortText(dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField42, dateTimeFieldType60, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType60, 69);
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField67.getAsText((long) (-2922650), locale69);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "83546" + "'", str70.equals("83546"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (-2922650L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str4 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long20 = fixedDateTimeZone18.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = fixedDateTimeZone18.isLocalDateTimeGap(localDateTime21);
        org.joda.time.DateTime dateTime23 = dateTime13.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long30 = fixedDateTimeZone28.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        boolean boolean33 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime32);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        long long20 = unsupportedDateTimeField15.add(999L, 4078200);
        long long23 = unsupportedDateTimeField15.add(350L, 21);
        java.util.Locale locale24 = null;
        try {
            int int25 = unsupportedDateTimeField15.getMaximumShortTextLength(locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 14681520000999L + "'", long20 == 14681520000999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 75600350L + "'", long23 == 75600350L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis(21);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime3.withPeriodAdded(readablePeriod13, 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((-100L), locale6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
        int int16 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime13);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone9, 3600100L);
        boolean boolean19 = fixedDateTimeZone4.isFixed();
        int int21 = fixedDateTimeZone4.getOffsetFromLocal(52032L);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(chronology22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (short) 1);
        boolean boolean29 = dateTime25.isBefore((long) 0);
        org.joda.time.DateTime dateTime30 = dateTime25.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime30);
        int int32 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600100L + "'", long18 == 3600100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField27.getMaximumTextLength(locale29);
        int int32 = remainderDateTimeField27.getMinimumValue((long) 35);
        java.util.Locale locale34 = null;
        java.lang.String str35 = remainderDateTimeField27.getAsText((long) 1200, locale34);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1" + "'", str35.equals("1"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        boolean boolean16 = unsupportedDateTimeField15.isSupported();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getName(0L, locale11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        int int12 = mutableDateTime11.getWeekOfWeekyear();
        int int15 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", 960);
        boolean boolean16 = dateTimeFormatter1.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-961) + "'", int15 == (-961));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(52);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("", "hi!", true, 15, (-2922650));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology21 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.DateTime dateTime10 = dateTime1.withDurationAdded(3600100L, (int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.weekOfWeekyear();
        int int12 = property11.get();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis(0L);
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DurationField durationField12 = iSOChronology10.hours();
        org.joda.time.DurationField durationField13 = iSOChronology10.months();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitYear(12, true);
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildFormatter();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime26.minusSeconds((int) (short) 1);
        boolean boolean30 = dateTime26.isBefore((long) 0);
        org.joda.time.DateTime dateTime31 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property32 = dateTime26.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder23.appendText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType33);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField15, dateTimeFieldType33, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str39 = iSOChronology38.toString();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.secondOfDay();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime44 = dateTime42.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime45 = dateTime42.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate46 = dateTime42.toLocalDate();
        int[] intArray53 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology38.validate((org.joda.time.ReadablePartial) localDate46, intArray53);
        java.util.Locale locale55 = null;
        java.lang.String str56 = remainderDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDate46, locale55);
        long long58 = remainderDateTimeField37.roundHalfEven((long) 2922789);
        int int60 = remainderDateTimeField37.getMinimumValue(3600100L);
        long long62 = remainderDateTimeField37.roundCeiling((long) (-2922790));
        long long64 = remainderDateTimeField37.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = remainderDateTimeField37.getType();
        boolean boolean66 = dateTime8.isSupported(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[UTC]" + "'", str39.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1" + "'", str56.equals("1"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2923000L + "'", long58 == 2923000L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-2922000L) + "'", long62 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1000L + "'", long64 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) (byte) 10);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        int int12 = dateTime10.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str18 = iSOChronology17.toString();
        org.joda.time.DurationField durationField19 = iSOChronology17.hours();
        org.joda.time.DurationField durationField20 = iSOChronology17.months();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology17.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendTwoDigitYear(12, true);
        boolean boolean31 = dateTimeFormatterBuilder30.canBuildFormatter();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime35 = dateTime33.minusSeconds((int) (short) 1);
        boolean boolean37 = dateTime33.isBefore((long) 0);
        org.joda.time.DateTime dateTime38 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property39 = dateTime33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder25.appendShortText(dateTimeFieldType40);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType40, 86399);
        int int45 = remainderDateTimeField44.getDivisor();
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str47 = iSOChronology46.toString();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.secondOfDay();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime52 = dateTime50.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime53 = dateTime50.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate54 = dateTime50.toLocalDate();
        int[] intArray61 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology46.validate((org.joda.time.ReadablePartial) localDate54, intArray61);
        int[] intArray68 = new int[] { 2922789, (-2922789), (-2922650), 86398, 57600010 };
        int int69 = remainderDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) localDate54, intArray68);
        java.util.Locale locale70 = null;
        try {
            java.lang.String str71 = unsupportedDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate54, locale70);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[UTC]" + "'", str18.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 86399 + "'", int45 == 86399);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[UTC]" + "'", str47.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.ReadableInstant readableInstant2 = null;
        java.lang.String str3 = dateTimeFormatter0.print(readableInstant2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear(52);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-01-01" + "'", str3.equals("1969-01-01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 2);
        int int9 = offsetDateTimeField7.getLeapAmount((-7686200592000000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        int int5 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        java.lang.String str7 = property4.toString();
        java.lang.String str8 = property4.getAsShortText();
        org.joda.time.DateTime dateTime9 = property4.withMinimumValue();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DurationField durationField12 = iSOChronology10.hours();
        org.joda.time.DurationField durationField13 = iSOChronology10.months();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitYear(12, true);
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildFormatter();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime26.minusSeconds((int) (short) 1);
        boolean boolean30 = dateTime26.isBefore((long) 0);
        org.joda.time.DateTime dateTime31 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property32 = dateTime26.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder23.appendText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType33);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField15, dateTimeFieldType33, 86399);
        boolean boolean38 = remainderDateTimeField37.isSupported();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField37, (int) '4');
        boolean boolean41 = property4.equals((java.lang.Object) offsetDateTimeField40);
        java.util.Locale locale42 = null;
        int int43 = offsetDateTimeField40.getMaximumTextLength(locale42);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[centuryOfEra]" + "'", str7.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5 + "'", int43 == 5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        org.joda.time.ReadableInstant readableInstant7 = null;
        java.lang.String str8 = dateTimeFormatter5.print(readableInstant7);
        java.lang.String str10 = dateTimeFormatter5.print(0L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.append(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-01-01" + "'", str8.equals("1969-01-01"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-01-01" + "'", str10.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(960);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 1);
        boolean boolean12 = dateTime8.isBefore((long) 0);
        org.joda.time.DateTime dateTime13 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime8.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str17 = iSOChronology16.toString();
        org.joda.time.DurationField durationField18 = iSOChronology16.hours();
        long long21 = durationField18.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder2.appendSignedDecimal(dateTimeFieldType15, 2000, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-115199040L) + "'", long21 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plus((long) 69);
        boolean boolean3 = dateTime2.isEqualNow();
        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        boolean boolean16 = unsupportedDateTimeField15.isSupported();
        try {
            long long18 = unsupportedDateTimeField15.roundHalfFloor(10002L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTime dateTime9 = dateTime1.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 960, (java.lang.Number) 62L, (java.lang.Number) 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMinuteOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int60 = offsetDateTimeField59.getMaximumValue();
        long long62 = offsetDateTimeField59.roundFloor((-100L));
        int int63 = offsetDateTimeField59.getMinimumValue();
        int int65 = offsetDateTimeField59.getMinimumValue(2923000L);
        long long67 = offsetDateTimeField59.roundHalfEven(28L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-2922650) + "'", int60 == (-2922650));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-31536000000L) + "'", long62 == (-31536000000L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-2922749) + "'", int63 == (-2922749));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-2922749) + "'", int65 == (-2922749));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "Property[centuryOfEra]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 62L, (java.lang.Number) (byte) 10, (java.lang.Number) (-2922000L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property4.addToCopy((long) 2);
        org.joda.time.DateTime dateTime10 = property4.roundFloorCopy();
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.withFields(readablePartial11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        int int45 = preciseDateTimeField44.getMaximumValue();
        int int46 = preciseDateTimeField44.getRange();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 59999 + "'", int45 == 59999);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 60000 + "'", int46 == 60000);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 86399010, 0, 0, 0, (-961));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -961 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970-01-01", "����-��-��");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        java.lang.String str10 = property4.getAsString();
        org.joda.time.DateTime dateTime11 = property4.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("69");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"69\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNull(dateTimeParser6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int8 = fixedDateTimeZone6.getOffset((long) (byte) -1);
        java.lang.String str9 = fixedDateTimeZone6.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        long long24 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology25 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) zonedChronology10);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology10.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str9.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DurationField durationField3 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 1);
        boolean boolean14 = dateTime10.isBefore((long) 0);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property16 = dateTime10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime19.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime23 = dateTime21.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime21.year();
        java.lang.String str25 = property24.getAsShortText();
        java.lang.String str26 = property24.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 0, (-2922789), (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder34.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder40.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendTwoDigitYear(12, true);
        boolean boolean45 = dateTimeFormatterBuilder44.canBuildFormatter();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime49 = dateTime47.minusSeconds((int) (short) 1);
        boolean boolean51 = dateTime47.isBefore((long) 0);
        org.joda.time.DateTime dateTime52 = dateTime47.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property53 = dateTime47.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder44.appendText(dateTimeFieldType54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder34.appendDecimal(dateTimeFieldType54, (int) '#', (int) (short) 100);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime62 = dateTime60.minusSeconds((int) (short) 1);
        boolean boolean64 = dateTime60.isBefore((long) 0);
        org.joda.time.DateTime dateTime65 = dateTime60.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property66 = dateTime60.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray68 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8, dateTimeFieldType17, dateTimeFieldType27, dateTimeFieldType54, dateTimeFieldType67 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList69 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList69, dateTimeFieldTypeArray68);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList69, false, false);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList69, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[year]" + "'", str26.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.withWeekyear(0);
        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
        org.joda.time.DateTime.Property property13 = dateTime11.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime1.withFieldAdded(durationFieldType12, 1200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        boolean boolean27 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology21 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean23 = fixedDateTimeZone15.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology21 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int28 = fixedDateTimeZone26.getOffset((long) (byte) -1);
        java.lang.String str29 = fixedDateTimeZone26.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long33 = cachedDateTimeZone30.adjustOffset(10L, false);
        int int35 = cachedDateTimeZone30.getOffset((long) 12);
        boolean boolean36 = cachedDateTimeZone30.isFixed();
        org.joda.time.Chronology chronology37 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str29.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 2);
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getLeapDurationField();
        long long11 = offsetDateTimeField7.add((-31532880000L), (-28800000));
        long long13 = offsetDateTimeField7.roundHalfCeiling((long) 1969);
        boolean boolean15 = offsetDateTimeField7.isLeap((long) (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1759532880000L) + "'", long11 == (-1759532880000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969-12-27T12:00:00.010-08:00");
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
        boolean boolean4 = dateTime1.isEqual((long) 86398);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2000L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2000L + "'", long2 == 2000L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        java.lang.String str53 = remainderDateTimeField27.toString();
        java.util.Locale locale54 = null;
        int int55 = remainderDateTimeField27.getMaximumTextLength(locale54);
        long long57 = remainderDateTimeField27.roundHalfCeiling((long) 4078200);
        long long59 = remainderDateTimeField27.roundHalfCeiling(2100L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str53.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 5 + "'", int55 == 5);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 4078000L + "'", long57 == 4078000L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2000L + "'", long59 == 2000L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        long long47 = preciseDateTimeField44.addWrapField((long) 1969, 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2021L + "'", long47 == 2021L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar6 = dateTime5.toGregorianCalendar();
        int int7 = dateTime5.getSecondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        int int6 = dateTime5.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendFractionOfHour(960, (-11));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendWeekOfWeekyear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int8 = fixedDateTimeZone6.getOffset((long) (byte) -1);
        java.lang.String str9 = fixedDateTimeZone6.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        long long24 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology25 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) zonedChronology10);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) ' ');
        int int35 = dateTimeZone28.getOffset((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
        org.joda.time.Chronology chronology37 = zonedChronology10.withZone(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str9.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-12-27", "1969-12-27T20:00:00.010Z");
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        boolean boolean18 = dateTime14.isAfter((-7686192729599900L));
        org.joda.time.DateTime.Property property19 = dateTime14.centuryOfEra();
        int int20 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getName((-100L), locale18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) ' ');
        int int28 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime25);
        long long30 = fixedDateTimeZone16.getMillisKeepLocal(dateTimeZone21, 3600100L);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = dateTimeZone21.isLocalDateTimeGap(localDateTime31);
        long long34 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone21, (long) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.year();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3600100L + "'", long30 == 3600100L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        org.joda.time.DateTime.Property property9 = dateTime3.yearOfEra();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) (byte) 0, 2000L);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField15.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime7 = dateTime1.plusMonths((-2922789));
        org.joda.time.DateTime dateTime9 = dateTime1.plusHours(2000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) (short) 0);
        long long14 = fixedDateTimeZone4.convertLocalToUTC(0L, true, (long) 2100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        boolean boolean16 = unsupportedDateTimeField15.isSupported();
        try {
            int int18 = unsupportedDateTimeField15.getMaximumValue((-16L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(2922789);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear((int) (short) -1);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str4 = iSOChronology3.toString();
        long long8 = iSOChronology3.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean11 = iSOChronology3.equals((java.lang.Object) dateTimeFormatter10);
        java.io.Writer writer12 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds((int) (short) 1);
        boolean boolean18 = dateTime14.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime14.plusMonths((-2922789));
        org.joda.time.TimeOfDay timeOfDay21 = dateTime14.toTimeOfDay();
        try {
            dateTimeFormatter10.printTo(writer12, (org.joda.time.ReadablePartial) timeOfDay21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(timeOfDay21);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long9 = fixedDateTimeZone7.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) fixedDateTimeZone7);
        long long15 = iSOChronology0.add(1560633921247L, 0L, (int) (byte) 0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560633921247L + "'", long15 == 1560633921247L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMinuteOfDay((-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTime dateTime7 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long19 = fixedDateTimeZone17.convertUTCToLocal((long) (-1));
        long long21 = fixedDateTimeZone17.previousTransition((long) 28);
        int int23 = fixedDateTimeZone17.getOffsetFromLocal(0L);
        boolean boolean24 = dateTime1.equals((java.lang.Object) fixedDateTimeZone17);
        java.util.TimeZone timeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) ' ');
        int int33 = dateTimeZone26.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime34 = dateTime1.withZoneRetainFields(dateTimeZone26);
        org.joda.time.DateTime dateTime36 = dateTime34.minusYears(10);
        int int37 = dateTime34.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28L + "'", long21 == 28L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.DurationField durationField11 = gregorianChronology9.months();
        org.joda.time.DurationField durationField12 = gregorianChronology9.months();
        long long16 = gregorianChronology9.add(14681520000999L, (long) 0, 57600010);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long23 = fixedDateTimeZone21.convertUTCToLocal((long) (-1));
        long long25 = fixedDateTimeZone21.previousTransition((long) 28);
        java.util.TimeZone timeZone26 = fixedDateTimeZone21.toTimeZone();
        java.lang.String str28 = fixedDateTimeZone21.getName((long) (-2922749));
        boolean boolean29 = fixedDateTimeZone21.isFixed();
        org.joda.time.Chronology chronology30 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14681520000999L + "'", long16 == 14681520000999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28L + "'", long25 == 28L);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        int int11 = property10.getMaximumValueOverall();
        java.lang.Object obj12 = null;
        boolean boolean13 = property10.equals(obj12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMonths((-28800000));
        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(1000L, 19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            int int17 = unsupportedDateTimeField15.getMaximumValue((long) (-961));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int22 = fixedDateTimeZone20.getOffset((long) (byte) -1);
        java.lang.String str23 = fixedDateTimeZone20.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        int int26 = fixedDateTimeZone20.getStandardOffset(0L);
        boolean boolean27 = dateTime15.equals((java.lang.Object) int26);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str23.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        long long18 = unsupportedDateTimeField15.getDifferenceAsLong((long) (short) 0, (long) 57600010);
        try {
            int int19 = unsupportedDateTimeField15.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-16L) + "'", long18 == (-16L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.minusMonths(69);
        int int12 = dateTime11.getMinuteOfHour();
        org.joda.time.DateTime dateTime14 = dateTime11.withMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendSecondOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
        org.joda.time.DateTimeField dateTimeField66 = remainderDateTimeField27.getWrappedField();
        java.util.Locale locale68 = null;
        java.lang.String str69 = remainderDateTimeField27.getAsShortText(0L, locale68);
        long long72 = remainderDateTimeField27.set(2021L, "1");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1021L + "'", long72 == 1021L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int11 = cachedDateTimeZone9.getOffset((long) 100);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone9.getUncachedZone();
        long long15 = dateTimeZone13.convertUTCToLocal(0L);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone13);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) '#');
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        int int47 = preciseDateTimeField44.getMinimumValue(0L);
        long long50 = preciseDateTimeField44.set((long) (-70), 28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-59972L) + "'", long50 == (-59972L));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(2922789);
        int int7 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2922789 + "'", int7 == 2922789);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((long) 100);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone8.getUncachedZone();
        int int14 = cachedDateTimeZone8.getOffset(52032L);
        int int16 = cachedDateTimeZone8.getStandardOffset((long) 292278993);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear(2100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 292278993, (int) (short) -1, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        boolean boolean7 = dateTime6.isAfterNow();
        int int8 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeField7);
        boolean boolean10 = jodaTimePermission1.equals((java.lang.Object) 52032L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        boolean boolean11 = dateTime10.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField59.getType();
        org.joda.time.DurationField durationField65 = offsetDateTimeField59.getRangeDurationField();
        java.lang.String str67 = offsetDateTimeField59.getAsText(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "-2922679" + "'", str67.equals("-2922679"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 57600010);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        int int20 = unsupportedDateTimeField15.getDifference((long) '#', (long) (byte) 100);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds((int) ' ');
        java.lang.String str27 = dateTime24.toString();
        int int28 = dateTime24.getMonthOfYear();
        org.joda.time.DateTime dateTime30 = dateTime24.minusMonths(2);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
        org.joda.time.DateTime dateTime37 = dateTime34.minusDays((int) '#');
        int int38 = dateTime30.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime30.minus(readablePeriod39);
        org.joda.time.LocalTime localTime41 = dateTime40.toLocalTime();
        try {
            int int42 = unsupportedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localTime41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str27.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localTime41);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        org.joda.time.DateTime.Property property9 = dateTime3.yearOfEra();
        boolean boolean10 = property9.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1969-12-31");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException13.getDurationFieldType();
        illegalFieldValueException13.prependMessage("1969-12-31");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        java.lang.String str22 = illegalFieldValueException21.toString();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.String str24 = illegalFieldValueException13.getIllegalValueAsString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str26 = illegalFieldValueException13.toString();
        org.joda.time.DurationFieldType durationFieldType27 = illegalFieldValueException13.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str22.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100.0" + "'", str24.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str26.equals("org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertNull(durationFieldType27);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.withWeekyear(0);
        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
        org.joda.time.DurationField durationField13 = property12.getLeapDurationField();
        org.joda.time.DateTime dateTime15 = property12.addToCopy((long) ' ');
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekyear(20);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.DurationField durationField27 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long30 = durationField27.subtract(0L, (long) (short) -1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        boolean boolean36 = dateTime32.isBefore((long) 0);
        org.joda.time.DateTime dateTime37 = dateTime32.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) '4');
        org.joda.time.DateTime.Property property42 = dateTime37.minuteOfDay();
        org.joda.time.DurationField durationField43 = property42.getDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField27, durationField43);
        org.joda.time.DurationField durationField45 = preciseDateTimeField44.getRangeDurationField();
        long long47 = preciseDateTimeField44.roundCeiling((long) (-2922650));
        org.joda.time.DurationField durationField48 = preciseDateTimeField44.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2922650L) + "'", long47 == (-2922650L));
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.minusMonths(2);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.secondOfDay();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime18.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate22 = dateTime18.toLocalDate();
        int[] intArray29 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology14.validate((org.joda.time.ReadablePartial) localDate22, intArray29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str32 = iSOChronology31.toString();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.secondOfDay();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime37 = dateTime35.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime35.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate39 = dateTime35.toLocalDate();
        int[] intArray46 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology31.validate((org.joda.time.ReadablePartial) localDate39, intArray46);
        iSOChronology10.validate((org.joda.time.ReadablePartial) localDate22, intArray46);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology10.millisOfDay();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology10.halfdayOfDay();
        org.joda.time.MutableDateTime mutableDateTime51 = dateTime9.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[UTC]" + "'", str15.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[UTC]" + "'", str32.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(mutableDateTime51);
    }
}

