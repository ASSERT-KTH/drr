import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 0, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            java.lang.String str3 = dateTimeFormatter0.print(readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withYearOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = dateTime1.toString("", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        int int7 = fixedDateTimeZone5.getStandardOffset((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) 0.0d, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "1969-12-27T12:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        java.util.Date date5 = mutableDateTime4.toDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withWeekOfWeekyear((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        long long5 = durationField2.subtract((long) (short) 100, (long) (-1));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3600100L + "'", long5 == 3600100L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime6, (java.lang.Object) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod3, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 2922789);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        int int8 = dateTime7.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        boolean boolean10 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.minus((long) (-1));
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withMonthOfYear(2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.DateTime dateTime10 = dateTime1.withDurationAdded(3600100L, (int) 'a');
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withFieldAdded(durationFieldType11, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        java.lang.String str3 = dateTimeFormatter0.print(readableInstant2);
//        java.lang.String str5 = dateTimeFormatter0.print(0L);
//        try {
//            org.joda.time.LocalTime localTime7 = dateTimeFormatter0.parseLocalTime("Property[centuryOfEra]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[centuryOfEra]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-01-01" + "'", str5.equals("1970-01-01"));
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        int int8 = mutableDateTime7.getWeekOfWeekyear();
        boolean boolean10 = mutableDateTime7.isBefore((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        java.lang.String str3 = dateTimeFormatter0.print(readableInstant2);
//        java.lang.String str5 = dateTimeFormatter0.print(0L);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
//        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) '#');
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime9.toMutableDateTimeISO();
//        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "1970-01-01", 2922789);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-01-01" + "'", str5.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-2922790) + "'", int16 == (-2922790));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long17 = gregorianChronology9.getDateTimeMillis((int) 'a', 1, (int) ' ', (int) '#', 69, 12, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 69);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        try {
            long long11 = iSOChronology0.getDateTimeMillis((-28800000), 28, 2, (int) (short) 100, (-2922790), 1970, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.DateTime.Property property3 = dateTime1.property(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 1, 28, (int) '#', 35, (int) (byte) 100, 1, 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (byte) 1, 35, 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        try {
            long long15 = gregorianChronology9.getDateTimeMillis(32, (int) '#', (int) (byte) 0, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 100, 32, (-2922790), 32, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("1970-01-01", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01\" is malformed at \"-01-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            long long2 = dateTimeFormatter0.parseMillis("1969-12-27T12:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-27T12:00:00.010-08:00\" is malformed at \"-12-27T12:00:00.010-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) -1, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) 32);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        java.lang.String str7 = property6.getAsShortText();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1) + "'", number7.equals((-1)));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime8);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("19", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"19/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(10L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        int int4 = dateTime1.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str8 = iSOChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime((org.joda.time.Chronology) iSOChronology7);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2922789);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2922789) + "'", int1 == (-2922789));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 52, (-2922789), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2922749) + "'", int4 == (-2922749));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        boolean boolean7 = dateTime3.isBefore((long) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        try {
            int int11 = dateTime1.compareTo(readableInstant10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100.0\" is malformed at \"0.0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter5.getPrinter();
        java.io.Writer writer9 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
        try {
            dateTimeFormatter5.printTo(writer9, (org.joda.time.ReadablePartial) localTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localTime16);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str8 = iSOChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime((org.joda.time.Chronology) iSOChronology7);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withDayOfWeek(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        long long6 = durationField3.subtract(100L, 2922789);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-7686192729599900L) + "'", long6 == (-7686192729599900L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-12-27T12:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-27T12:00:00.010-08:00\" is malformed at \"-12-27T12:00:00.010-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1969-12-31", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 32L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendPattern("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("2019-06-15", "100.0", false, 2922789, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 100, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.Chronology chronology4 = dateTimeFormatter1.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType1, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendSignedDecimal(dateTimeFieldType3, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.lang.String str6 = fixedDateTimeZone4.getShortName(97L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronology();
        java.lang.String str9 = dateTime3.toString(dateTimeFormatter7);
        int int10 = dateTime3.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime3.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) yearMonthDay11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01" + "'", str9.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded((long) (-2922790), (int) ' ');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendCenturyOfEra((-2922790), 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.weekyearOfCentury();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '#', 35, 52, 0, 1970, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        boolean boolean7 = dateTime3.isBefore((long) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) dateTime8);
        java.util.GregorianCalendar gregorianCalendar10 = dateTime8.toGregorianCalendar();
        org.joda.time.ReadableInstant readableInstant11 = null;
        try {
            int int12 = dateTime8.compareTo(readableInstant11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        java.lang.String str4 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getYearOfEra();
        int int11 = dateTime9.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.Chronology chronology5 = mutableDateTime4.getChronology();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int12 = fixedDateTimeZone10.getOffset((long) (byte) -1);
        java.lang.String str13 = fixedDateTimeZone10.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology5, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long21 = fixedDateTimeZone19.convertUTCToLocal((long) (-1));
        long long23 = fixedDateTimeZone19.previousTransition((long) 28);
        java.util.TimeZone timeZone24 = fixedDateTimeZone19.toTimeZone();
        long long28 = fixedDateTimeZone19.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology29 = zonedChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        try {
            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(69, (int) (short) -1, 32, 35, 1, chronology29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str13.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28L + "'", long23 == 28L);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        boolean boolean10 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.minus((long) (-1));
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = property13.roundFloorCopy();
        int int15 = property13.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        java.lang.String str10 = fixedDateTimeZone4.getName((long) 52);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            long long15 = zonedChronology9.getDateTimeMillis((long) 960, (-2922749), 0, (int) '#', 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922749 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) '4', (int) ' ');
        int int27 = dateTime26.getMinuteOfHour();
        boolean boolean28 = zonedChronology15.equals((java.lang.Object) dateTime26);
        try {
            long long36 = zonedChronology15.getDateTimeMillis(0, 960, (int) '#', 1, (int) (short) 1, (int) (byte) 1, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-961), 52, (int) (short) -1, 960, 0, (int) '#', (int) '#', (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0d, (java.lang.Number) 1, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '19' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((-961));
        try {
            org.joda.time.DateTime dateTime15 = dateTime10.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendHourOfDay((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-12-27T20:00:00.010Z", "1970-01-01");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str3.equals("1969-12-27T20:00:00.010Z"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) -1, (int) (byte) -1, (int) (short) 1, 69, (-1), 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((-2922749), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        boolean boolean9 = dateTime5.isAfter((-7686192729599900L));
        org.joda.time.DateTime dateTime11 = dateTime5.withWeekyear((-2922749));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        boolean boolean10 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.monthOfYear();
        int int12 = property11.getMinimumValue();
        try {
            org.joda.time.DateTime dateTime14 = property11.setCopy("100.0");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"100.0\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(2000, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendSecondOfMinute(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withOffsetParsed();
        org.joda.time.Chronology chronology20 = dateTimeFormatter19.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter19.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser22 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder4.append(dateTimePrinter21, dateTimeParser22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str10 = dateTimeZone1.getShortName((long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        try {
            org.joda.time.LocalDate localDate9 = dateTimeFormatter5.parseLocalDate("Property[centuryOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[centuryOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        boolean boolean10 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime3.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyearOfCentury();
        int int9 = dateTime6.get(dateTimeField8);
        org.joda.time.DateTime dateTime11 = dateTime6.minusSeconds(1);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withDate(28, (int) (byte) 10, 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L);
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-W01-4T00:00:00Z" + "'", str3.equals("1970-W01-4T00:00:00Z"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        boolean boolean13 = dateTime11.isAfter((long) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.minus(readableDuration14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter1.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNull(dateTimeZone4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime6.minuteOfDay();
        try {
            org.joda.time.DateTime dateTime13 = property11.addToCopy((-7686192729599900L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -7686192729599900 * 60000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendSecondOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970-01-01", 12, (int) '#', 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for 1970-01-01 must be in the range [35,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePeriod1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property9 = dateTime6.year();
        java.lang.String str10 = property9.getAsShortText();
        java.lang.String str11 = property9.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[year]" + "'", str11.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        java.lang.String str7 = property6.getAsShortText();
        java.lang.String str8 = property6.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-2922789), (int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DurationField durationField16 = iSOChronology14.hours();
        org.joda.time.DurationField durationField17 = iSOChronology14.months();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime19.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar24 = dateTime23.toGregorianCalendar();
        org.joda.time.DateTime dateTime26 = dateTime23.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property27 = dateTime26.dayOfMonth();
        org.joda.time.DurationField durationField28 = property27.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField29 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField17, durationField28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[year]" + "'", str8.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[UTC]" + "'", str15.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianCalendar24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long14 = gregorianChronology9.getDateTimeMillis((int) (short) 100, 69, (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withDate(0, (int) (short) -1, (-2922749));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.append(dateTimeParser6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.yearOfEra();
        long long12 = iSOChronology0.add((long) (short) 10, (long) 69, 28);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1942L + "'", long12 == 1942L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) ' ');
        java.lang.String str7 = dateTime4.toString();
        int int8 = dateTime4.getMonthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillis(62L);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 86399, (java.lang.Object) 62L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str7.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
        int[] intArray19 = new int[] { 10, (-1) };
        try {
            gregorianChronology9.validate((org.joda.time.ReadablePartial) localTime16, intArray19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must not be smaller than 0");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localTime16);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        try {
            long long22 = zonedChronology15.getDateTimeMillis((long) (short) -1, 0, (int) (byte) 100, (int) (byte) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int8 = fixedDateTimeZone6.getOffset((long) (byte) -1);
        java.lang.String str9 = fixedDateTimeZone6.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        long long24 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology25 = zonedChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) -1, (org.joda.time.Chronology) zonedChronology10);
        java.lang.String str27 = zonedChronology10.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str9.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-27T12:00:00.010-08:00]" + "'", str27.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-27T12:00:00.010-08:00]"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1969-12-27T12:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 12, (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 69);
        long long8 = fixedDateTimeZone4.convertUTCToLocal((long) 10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 69L + "'", long6 == 69L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 22L + "'", long8 == 22L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear(12, true);
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildFormatter();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (short) 1);
        boolean boolean17 = dateTime13.isBefore((long) 0);
        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime13.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property19.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType20);
        try {
            org.joda.time.DateTime dateTime23 = dateTime3.withField(dateTimeFieldType20, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int[] intArray51 = new int[] {};
        try {
            int[] intArray53 = remainderDateTimeField27.addWrapField(readablePartial49, 1, intArray51, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(intArray51);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 1);
        boolean boolean14 = dateTime10.isBefore((long) 0);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property16 = dateTime10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime19.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime23 = dateTime21.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime21.year();
        java.lang.String str25 = property24.getAsShortText();
        java.lang.String str26 = property24.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 0, (-2922789), (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder34.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder40.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendTwoDigitYear(12, true);
        boolean boolean45 = dateTimeFormatterBuilder44.canBuildFormatter();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime49 = dateTime47.minusSeconds((int) (short) 1);
        boolean boolean51 = dateTime47.isBefore((long) 0);
        org.joda.time.DateTime dateTime52 = dateTime47.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property53 = dateTime47.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder44.appendText(dateTimeFieldType54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder34.appendDecimal(dateTimeFieldType54, (int) '#', (int) (short) 100);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime62 = dateTime60.minusSeconds((int) (short) 1);
        boolean boolean64 = dateTime60.isBefore((long) 0);
        org.joda.time.DateTime dateTime65 = dateTime60.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property66 = dateTime60.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray68 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8, dateTimeFieldType17, dateTimeFieldType27, dateTimeFieldType54, dateTimeFieldType67 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList69 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList69, dateTimeFieldTypeArray68);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList69, false, false);
        int int74 = dateTimeFormatter73.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[year]" + "'", str26.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2000 + "'", int74 == 2000);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(2000, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2100 + "'", int2 == 2100);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        int int10 = dateTime1.getDayOfYear();
        int int11 = dateTime1.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((int) (byte) -1, 0, (-2922749), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendCenturyOfEra((-2922790), (-2922789));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withYearOfCentury((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350L + "'", long2 == 350L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-2922000L), 1000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2921000L) + "'", long2 == (-2921000L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime33 = dateTime32.toLocalTime();
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localTime33, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localTime33);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withOffsetParsed();
        org.joda.time.Chronology chronology18 = dateTimeFormatter17.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser20 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray21 = new org.joda.time.format.DateTimeParser[] { dateTimeParser20 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.append(dateTimePrinter19, dateTimeParserArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeParserArray21);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[ISOChronology[UT...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(4, (int) (byte) -1, (-1), 2, 1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2000, (-2922749), 69, (-28800000), (int) '#', (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.DateTime.Property property7 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) ' ');
        java.lang.String str14 = dateTime11.toString();
        org.joda.time.TimeOfDay timeOfDay15 = dateTime11.toTimeOfDay();
        boolean boolean16 = dateTime11.isBeforeNow();
        org.joda.time.DateTime dateTime18 = dateTime11.plus((long) '4');
        int int19 = property7.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime21 = dateTime11.minusMonths(35);
        org.joda.time.ReadableInstant readableInstant22 = null;
        try {
            int int23 = dateTime11.compareTo(readableInstant22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str14.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 12, (int) (byte) 0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        int int12 = mutableDateTime11.getWeekOfWeekyear();
        int int15 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", 960);
        java.util.Locale locale16 = dateTimeFormatter1.getLocale();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str18 = iSOChronology17.toString();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        try {
            int[] intArray24 = iSOChronology17.get(readablePeriod22, 3600100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-961) + "'", int15 == (-961));
        org.junit.Assert.assertNull(locale16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[UTC]" + "'", str18.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) '#');
        dateTimeFormatterBuilder4.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DurationField durationField8 = iSOChronology6.hours();
        org.joda.time.DurationField durationField9 = iSOChronology6.months();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitYear(12, true);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildFormatter();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 1);
        boolean boolean26 = dateTime22.isBefore((long) 0);
        org.joda.time.DateTime dateTime27 = dateTime22.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property28 = dateTime22.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType29);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType29, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str35 = iSOChronology34.toString();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.secondOfDay();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate42 = dateTime38.toLocalDate();
        int[] intArray49 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology34.validate((org.joda.time.ReadablePartial) localDate42, intArray49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = remainderDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate42, locale51);
        long long54 = remainderDateTimeField33.roundHalfEven((long) 2922789);
        int int56 = remainderDateTimeField33.getMinimumValue(3600100L);
        long long58 = remainderDateTimeField33.roundCeiling((long) (-2922790));
        long long60 = remainderDateTimeField33.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = remainderDateTimeField33.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType61, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology65 = dateTimeFormatter64.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter66 = dateTimeFormatter64.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser67 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder5.append(dateTimePrinter66, dateTimeParser67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[UTC]" + "'", str35.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2923000L + "'", long54 == 2923000L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2922000L) + "'", long58 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1000L + "'", long60 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNull(chronology65);
        org.junit.Assert.assertNotNull(dateTimePrinter66);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.withWeekyear(0);
        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
        org.joda.time.DateTime dateTime13 = property12.getDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) '4', (int) ' ');
        int int27 = dateTime26.getMinuteOfHour();
        boolean boolean28 = zonedChronology15.equals((java.lang.Object) dateTime26);
        org.joda.time.DateTime dateTime29 = dateTime26.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter1.parseLocalDateTime("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (-961), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        long long51 = remainderDateTimeField27.add((long) 2, (long) 10);
        try {
            long long54 = remainderDateTimeField27.set((long) 2, (-2922790));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922790 for dayOfMonth must be in the range [0,86398]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10002L + "'", long51 == 10002L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        int int5 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        int int7 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-961));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(2000, (-1));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear((-2922790), (-2922789));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((-100L), locale6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
        int int16 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime13);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone9, 3600100L);
        long long21 = dateTimeZone9.adjustOffset((long) 28, true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600100L + "'", long18 == 3600100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28L + "'", long21 == 28L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property8 = dateTime5.year();
        java.lang.String str9 = property8.getAsShortText();
        java.lang.String str10 = property8.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[year]" + "'", str10.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        int int12 = mutableDateTime11.getWeekOfWeekyear();
        int int15 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", 960);
        java.util.Locale locale16 = dateTimeFormatter1.getLocale();
        org.joda.time.ReadablePartial readablePartial17 = null;
        try {
            java.lang.String str18 = dateTimeFormatter1.print(readablePartial17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-961) + "'", int15 == (-961));
        org.junit.Assert.assertNull(locale16);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime8 = dateTime3.toDateTimeISO();
        boolean boolean10 = dateTime3.isBefore(0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        int int2 = dateTime1.getMillisOfSecond();
        int int3 = dateTime1.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime3.year();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfCentury((int) ' ');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-2922789));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        int int7 = dateTime3.getMinuteOfHour();
        try {
            org.joda.time.DateTime dateTime9 = dateTime3.withDayOfWeek(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.lang.String str5 = property4.toString();
        java.lang.String str6 = property4.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[centuryOfEra]" + "'", str5.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[centuryOfEra]" + "'", str6.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder5.appendDecimal(dateTimeFieldType25, (int) '#', (int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType25, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar6 = dateTime5.toGregorianCalendar();
        org.joda.time.DateTime dateTime8 = dateTime5.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        org.joda.time.DurationField durationField10 = property9.getDurationField();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DurationField durationField8 = iSOChronology6.hours();
        org.joda.time.DurationField durationField9 = iSOChronology6.months();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitYear(12, true);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildFormatter();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 1);
        boolean boolean26 = dateTime22.isBefore((long) 0);
        org.joda.time.DateTime dateTime27 = dateTime22.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property28 = dateTime22.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType29);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType29, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str35 = iSOChronology34.toString();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.secondOfDay();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate42 = dateTime38.toLocalDate();
        int[] intArray49 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology34.validate((org.joda.time.ReadablePartial) localDate42, intArray49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = remainderDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate42, locale51);
        long long54 = remainderDateTimeField33.roundHalfEven((long) 2922789);
        int int56 = remainderDateTimeField33.getMinimumValue(3600100L);
        long long58 = remainderDateTimeField33.roundCeiling((long) (-2922790));
        long long60 = remainderDateTimeField33.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = remainderDateTimeField33.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType61, (int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder63.appendFractionOfDay((int) (byte) -1, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[UTC]" + "'", str35.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2923000L + "'", long54 == 2923000L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2922000L) + "'", long58 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1000L + "'", long60 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            long long18 = zonedChronology15.set(readablePartial16, (-100L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15");
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology21 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        try {
            long long27 = gregorianChronology9.getDateTimeMillis((long) 12, (int) (byte) -1, 0, 28, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) dateTime5);
        try {
            long long12 = iSOChronology0.getDateTimeMillis((int) '4', 0, 960, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 15, (-2922749));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1942L, (long) 2100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4078200 + "'", int2 == 4078200);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis(0L);
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.ReadableInstant readableInstant14 = null;
        boolean boolean15 = dateTime3.isBefore(readableInstant14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        long long5 = iSOChronology0.add((long) 100, 3600100L, 0);
        try {
            long long11 = iSOChronology0.getDateTimeMillis(0L, 2100, 12, 2100, 4078200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560633921247L + "'", long0 == 1560633921247L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-7686192729599900L), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7686192729599900L) + "'", long2 == (-7686192729599900L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMonths((-28800000));
        org.joda.time.DateTime dateTime8 = dateTime1.plusSeconds((-28800000));
        int int9 = dateTime8.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600010 + "'", int9 == 57600010);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str4 = iSOChronology3.toString();
        long long8 = iSOChronology3.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        java.lang.StringBuffer stringBuffer10 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer10, 999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(35, 12, (-1), 28, (int) '4', 960, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-15");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        java.lang.String str6 = jodaTimePermission4.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((-961));
        org.joda.time.DateTime.Property property14 = dateTime10.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) ' ');
        java.lang.String str14 = dateTime11.toString();
        int int15 = dateTime11.getMonthOfYear();
        org.joda.time.DateTime dateTime17 = dateTime11.withMillis(62L);
        org.joda.time.DateTime dateTime19 = dateTime11.minusMonths(69);
        int int20 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str14.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withOffsetParsed();
        org.joda.time.Chronology chronology7 = dateTimeFormatter6.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter6.getPrinter();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime15.toMutableDateTime();
        int int17 = mutableDateTime16.getWeekOfWeekyear();
        int int20 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime16, "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", 960);
        java.util.Locale locale21 = dateTimeFormatter6.getLocale();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str23 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) iSOChronology22);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(12, (int) (byte) 100, (int) 'a', 1970, 2, (org.joda.time.Chronology) iSOChronology22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-961) + "'", int20 == (-961));
        org.junit.Assert.assertNull(locale21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[UTC]" + "'", str23.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-12-27T20:00:00.010Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-27T20:00:00.010Z\" is malformed at \"Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969-12-31", (java.lang.Number) 100.0d, (java.lang.Number) 69, (java.lang.Number) 99L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 100 + "'", number7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0d + "'", number8.equals(100.0d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.yearOfEra();
        try {
            long long13 = iSOChronology0.getDateTimeMillis(28, (int) (short) 0, 4, 2100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        boolean boolean7 = dateTime6.isAfterNow();
        int int8 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) 'a');
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime6.toCalendar(locale11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(calendar12);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        long long7 = fixedDateTimeZone4.convertLocalToUTC((long) (byte) 100, true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 101L + "'", long7 == 101L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        try {
            org.joda.time.DateTime dateTime11 = dateTime3.withDate((int) (byte) 10, (int) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        long long54 = remainderDateTimeField27.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = remainderDateTimeField27.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder56.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder57.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder59.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder60.appendTwoDigitYear(12, true);
        boolean boolean64 = dateTimeFormatterBuilder63.canBuildFormatter();
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime68 = dateTime66.minusSeconds((int) (short) 1);
        boolean boolean70 = dateTime66.isBefore((long) 0);
        org.joda.time.DateTime dateTime71 = dateTime66.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property72 = dateTime66.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property72.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder63.appendText(dateTimeFieldType73);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder58.appendShortText(dateTimeFieldType73);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray76 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType55, dateTimeFieldType73 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList77 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList77, dateTimeFieldTypeArray76);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList77, false, true);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1000L + "'", long54 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter81);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getName((-100L), locale18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) ' ');
        int int28 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime25);
        long long30 = fixedDateTimeZone16.getMillisKeepLocal(dateTimeZone21, 3600100L);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = dateTimeZone21.isLocalDateTimeGap(localDateTime31);
        long long34 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone21, (long) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3600100L + "'", long30 == 3600100L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        boolean boolean9 = dateTime5.isAfter((-7686192729599900L));
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime5.withFieldAdded(durationFieldType10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        long long54 = remainderDateTimeField27.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = remainderDateTimeField27.getType();
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology57 = iSOChronology56.withUTC();
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology56.weekyear();
        org.joda.time.DurationField durationField59 = iSOChronology56.hours();
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime63 = dateTime61.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime64 = dateTime61.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate65 = dateTime61.toLocalDate();
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str67 = iSOChronology66.toString();
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.secondOfDay();
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime72 = dateTime70.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime73 = dateTime70.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate74 = dateTime70.toLocalDate();
        int[] intArray81 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology66.validate((org.joda.time.ReadablePartial) localDate74, intArray81);
        iSOChronology56.validate((org.joda.time.ReadablePartial) localDate65, intArray81);
        boolean boolean84 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate65);
        int int85 = remainderDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDate65);
        org.joda.time.DateTimeField dateTimeField86 = remainderDateTimeField27.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1000L + "'", long54 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(mutableDateTime64);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "ISOChronology[UTC]" + "'", str67.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(mutableDateTime73);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 86398 + "'", int85 == 86398);
        org.junit.Assert.assertNotNull(dateTimeField86);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            long long17 = zonedChronology9.getDateTimeMillis(0, (int) '4', (-2922790), (int) (short) 0, (-2922790), 2000, (-2922679));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922790 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plus((long) 69);
//        int int3 = dateTime2.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean4 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15");
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        boolean boolean13 = mutableDateTime11.isEqual((long) (byte) 100);
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "0", (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-11) + "'", int16 == (-11));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((long) 100);
        long long12 = cachedDateTimeZone8.previousTransition(69L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 69L + "'", long12 == 69L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis((int) '4');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((long) 100);
        boolean boolean11 = cachedDateTimeZone8.isFixed();
        boolean boolean12 = cachedDateTimeZone8.isFixed();
        boolean boolean14 = cachedDateTimeZone8.isStandardOffset((long) ' ');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTime dateTime8 = dateTime1.plusMonths((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds(10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int19 = fixedDateTimeZone17.getOffset((long) (byte) -1);
        java.lang.String str20 = fixedDateTimeZone17.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        long long24 = cachedDateTimeZone21.adjustOffset(10L, false);
        int int26 = cachedDateTimeZone21.getOffset((long) 12);
        org.joda.time.DateTime dateTime27 = dateTime12.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str20.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfDay();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder15.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeParser17);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 21, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronology();
        java.lang.String str9 = dateTime3.toString(dateTimeFormatter7);
        int int10 = dateTime3.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime3.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTime dateTime13 = dateTime3.withFields(readablePartial12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTime3);
        java.lang.String str15 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withDefaultYear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01" + "'", str9.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970" + "'", str15.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str4 = iSOChronology3.toString();
        long long8 = iSOChronology3.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        java.io.Writer writer10 = null;
        try {
            dateTimeFormatter0.printTo(writer10, (long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str8 = iSOChronology7.toString();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            int int17 = unsupportedDateTimeField15.getMinimumValue(10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        java.lang.Class<?> wildcardClass8 = dateTimeFormatter5.getClass();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter5.getParser();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime13.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        java.lang.String str19 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969-12-27" + "'", str19.equals("1969-12-27"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        try {
            long long53 = remainderDateTimeField27.set((long) 57600010, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = unsupportedDateTimeField15.getAsShortText(21, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long16 = fixedDateTimeZone14.convertUTCToLocal((long) (-1));
        long long18 = fixedDateTimeZone14.previousTransition((long) 28);
        java.util.TimeZone timeZone19 = fixedDateTimeZone14.toTimeZone();
        long long23 = fixedDateTimeZone14.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology24 = zonedChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28L + "'", long18 == 28L);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        java.lang.String str53 = remainderDateTimeField27.toString();
        long long55 = remainderDateTimeField27.roundCeiling(21L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str53.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1000L + "'", long55 == 1000L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property20 = dateTime19.centuryOfEra();
        java.lang.String str21 = property20.getAsText();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str23 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str27 = iSOChronology26.toString();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.secondOfDay();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime30.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate34 = dateTime30.toLocalDate();
        int[] intArray41 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology26.validate((org.joda.time.ReadablePartial) localDate34, intArray41);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str44 = iSOChronology43.toString();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.secondOfDay();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime49 = dateTime47.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime50 = dateTime47.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate51 = dateTime47.toLocalDate();
        int[] intArray58 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology43.validate((org.joda.time.ReadablePartial) localDate51, intArray58);
        iSOChronology22.validate((org.joda.time.ReadablePartial) localDate34, intArray58);
        int int61 = property20.compareTo((org.joda.time.ReadablePartial) localDate34);
        java.util.Locale locale62 = null;
        try {
            java.lang.String str63 = unsupportedDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDate34, locale62);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "19" + "'", str21.equals("19"));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[UTC]" + "'", str23.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[UTC]" + "'", str27.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ISOChronology[UTC]" + "'", str44.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            long long17 = unsupportedDateTimeField15.roundHalfCeiling((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        java.util.Locale locale16 = null;
        try {
            int int17 = unsupportedDateTimeField15.getMaximumTextLength(locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendMillisOfSecond(12);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendHourOfHalfday((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1969-12-31");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException13.getDurationFieldType();
        illegalFieldValueException13.prependMessage("1969-12-31");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException("2019-06-15", (java.lang.Number) 100.0d, (java.lang.Number) (short) 100, (java.lang.Number) (-1));
        java.lang.String str22 = illegalFieldValueException21.toString();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.String str24 = illegalFieldValueException13.getIllegalValueAsString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str26 = illegalFieldValueException13.toString();
        java.lang.Throwable[] throwableArray27 = illegalFieldValueException13.getSuppressed();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str22.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100.0" + "'", str24.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]" + "'", str26.equals("org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]"));
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
        org.joda.time.DateTimeField dateTimeField66 = remainderDateTimeField27.getWrappedField();
        java.util.Locale locale68 = null;
        java.lang.String str69 = remainderDateTimeField27.getAsShortText(0L, locale68);
        int int70 = remainderDateTimeField27.getDivisor();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 86399 + "'", int70 == 86399);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        try {
            long long55 = remainderDateTimeField27.set((long) 35, "org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: 1969-12-31: Value 100.0 for 2019-06-15 must be in the range [100,-1]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear(12, true);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 1);
        boolean boolean14 = dateTime10.isBefore((long) 0);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property16 = dateTime10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType17);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder2.appendSecondOfDay((-961));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendHourOfDay(32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((long) 100);
        int int12 = cachedDateTimeZone8.getOffset((-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) '#');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) '4', (int) ' ');
        int int27 = dateTime26.getMinuteOfHour();
        boolean boolean28 = zonedChronology15.equals((java.lang.Object) dateTime26);
        org.joda.time.DateTime dateTime30 = dateTime26.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(2000, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            int int16 = unsupportedDateTimeField15.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property20 = dateTime19.centuryOfEra();
        java.lang.String str21 = property20.getAsText();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str23 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str27 = iSOChronology26.toString();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.secondOfDay();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime33 = dateTime30.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate34 = dateTime30.toLocalDate();
        int[] intArray41 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology26.validate((org.joda.time.ReadablePartial) localDate34, intArray41);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str44 = iSOChronology43.toString();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.secondOfDay();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime49 = dateTime47.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime50 = dateTime47.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate51 = dateTime47.toLocalDate();
        int[] intArray58 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology43.validate((org.joda.time.ReadablePartial) localDate51, intArray58);
        iSOChronology22.validate((org.joda.time.ReadablePartial) localDate34, intArray58);
        int int61 = property20.compareTo((org.joda.time.ReadablePartial) localDate34);
        java.util.Locale locale63 = null;
        try {
            java.lang.String str64 = unsupportedDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDate34, 1, locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "19" + "'", str21.equals("19"));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[UTC]" + "'", str23.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[UTC]" + "'", str27.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ISOChronology[UTC]" + "'", str44.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime17.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology22 = dateTimeFormatter21.getChronology();
        java.lang.String str23 = dateTime17.toString(dateTimeFormatter21);
        int int24 = dateTime17.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime17.toYearMonthDay();
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField15.getAsText((org.joda.time.ReadablePartial) yearMonthDay25, 2100, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNull(chronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970-01-01" + "'", str23.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay25);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property22 = dateTime19.year();
        java.lang.String str23 = property22.getAsShortText();
        java.lang.String str24 = property22.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property22.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, 0, (-2922789), (int) (short) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder4.appendSignedDecimal(dateTimeFieldType25, (-2922790), (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969" + "'", str23.equals("1969"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[year]" + "'", str24.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        int int2 = dateTime1.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getName((-100L), locale18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) ' ');
        int int28 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime25);
        long long30 = fixedDateTimeZone16.getMillisKeepLocal(dateTimeZone21, 3600100L);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = dateTimeZone21.isLocalDateTimeGap(localDateTime31);
        long long34 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone21, (long) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long39 = fixedDateTimeZone4.convertLocalToUTC((long) 2100, false, (-115199040L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3600100L + "'", long30 == 3600100L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2100L + "'", long39 == 2100L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        try {
            long long32 = remainderDateTimeField27.set((long) (-961), "1970-01-01");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-01-01\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long17 = fixedDateTimeZone15.convertUTCToLocal((long) (-1));
        long long19 = fixedDateTimeZone15.previousTransition((long) 28);
        java.util.TimeZone timeZone20 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.Chronology chronology21 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendTwoDigitYear(12, true);
        boolean boolean27 = dateTimeFormatterBuilder26.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfSecond(2000, (-1));
        boolean boolean34 = gregorianChronology9.equals((java.lang.Object) dateTimeFormatterBuilder33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology9.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28L + "'", long19 == 28L);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology7 = dateTimeFormatter6.getChronology();
        java.lang.String str8 = dateTime2.toString(dateTimeFormatter6);
        int int9 = dateTime2.getMinuteOfDay();
        int int10 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime2);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2922789");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(chronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01" + "'", str8.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.minusMonths(69);
        org.joda.time.DateMidnight dateMidnight12 = dateTime3.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            long long18 = unsupportedDateTimeField15.set(10002L, "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        boolean boolean7 = dateTime6.isAfterNow();
        int int8 = dateTime6.getSecondOfDay();
        try {
            java.lang.String str10 = dateTime6.toString("Property[centuryOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((-100L), locale6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) ' ');
        int int16 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime13);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone9, 3600100L);
        long long20 = fixedDateTimeZone4.nextTransition((long) (-2922789));
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600100L + "'", long18 == 3600100L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2922789L) + "'", long20 == (-2922789L));
        org.junit.Assert.assertNotNull(iSOChronology21);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.DateTime.Property property7 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) ' ');
        java.lang.String str14 = dateTime11.toString();
        org.joda.time.TimeOfDay timeOfDay15 = dateTime11.toTimeOfDay();
        boolean boolean16 = dateTime11.isBeforeNow();
        org.joda.time.DateTime dateTime18 = dateTime11.plus((long) '4');
        int int19 = property7.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long26 = fixedDateTimeZone24.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime28.withMinuteOfHour((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str32 = iSOChronology31.toString();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone35 = iSOChronology31.getZone();
        org.joda.time.DateTime dateTime36 = dateTime28.withZone(dateTimeZone35);
        try {
            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((java.lang.Object) property7, dateTimeZone35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str14.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[UTC]" + "'", str32.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "Property[centuryOfEra]", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")", "hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfDay(69);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear((-2922650), (-2922789));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            long long17 = unsupportedDateTimeField15.roundHalfEven(1942L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 69);
        org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("1969-12-27T20:00:00.010Z");
        try {
            java.lang.String str6 = dateTimeFormatter0.print((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(localTime4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str11 = fixedDateTimeZone4.getName((long) (-2922749));
        long long15 = fixedDateTimeZone4.convertLocalToUTC(0L, true, 1942L);
        int int17 = fixedDateTimeZone4.getOffset((long) 52);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            long long17 = unsupportedDateTimeField15.roundFloor((long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear(12, true);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 1);
        boolean boolean14 = dateTime10.isBefore((long) 0);
        org.joda.time.DateTime dateTime15 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property16 = dateTime10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        int int9 = property4.getMaximumValueOverall();
        int int10 = property4.get();
        org.joda.time.DateTime dateTime11 = property4.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922789 + "'", int9 == 2922789);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime15 = dateTime3.minusYears(960);
        java.util.GregorianCalendar gregorianCalendar16 = dateTime3.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        try {
            long long32 = remainderDateTimeField27.addWrapField((long) (-961), (-11));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 172787 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendWeekyear((int) (short) 100, 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DurationField durationField12 = iSOChronology10.hours();
        org.joda.time.DurationField durationField13 = iSOChronology10.months();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitYear(12, true);
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildFormatter();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime28 = dateTime26.minusSeconds((int) (short) 1);
        boolean boolean30 = dateTime26.isBefore((long) 0);
        org.joda.time.DateTime dateTime31 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property32 = dateTime26.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder23.appendText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType33);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField15, dateTimeFieldType33, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str39 = iSOChronology38.toString();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.secondOfDay();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime44 = dateTime42.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime45 = dateTime42.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate46 = dateTime42.toLocalDate();
        int[] intArray53 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology38.validate((org.joda.time.ReadablePartial) localDate46, intArray53);
        java.util.Locale locale55 = null;
        java.lang.String str56 = remainderDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDate46, locale55);
        long long58 = remainderDateTimeField37.roundHalfEven((long) 2922789);
        int int60 = remainderDateTimeField37.getMinimumValue(3600100L);
        long long62 = remainderDateTimeField37.roundCeiling((long) (-2922790));
        long long64 = remainderDateTimeField37.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = remainderDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder9.appendFixedSignedDecimal(dateTimeFieldType65, (int) (byte) 10);
        boolean boolean68 = dateTime1.isSupported(dateTimeFieldType65);
        java.lang.String str69 = dateTime1.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[UTC]" + "'", str39.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1" + "'", str56.equals("1"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2923000L + "'", long58 == 2923000L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-2922000L) + "'", long62 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1000L + "'", long64 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str69.equals("1970-01-01T00:00:00.010Z"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfSecond();
        java.lang.String str6 = property5.getName();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "millisOfSecond" + "'", str6.equals("millisOfSecond"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate8 = dateTime4.toLocalDate();
        int[] intArray15 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology0.validate((org.joda.time.ReadablePartial) localDate8, intArray15);
        org.joda.time.DurationField durationField17 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = iSOChronology0.get(readablePeriod6, (long) (byte) 10, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DurationField durationField4 = iSOChronology0.halfdays();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1970, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property4.getAsText(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField27.getMaximumTextLength(locale29);
        int int32 = remainderDateTimeField27.getMinimumValue((long) 35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.LocalTime localTime35 = dateTimeFormatter33.parseLocalTime("2019-06-15");
        java.util.Locale locale36 = null;
        try {
            java.lang.String str37 = remainderDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localTime35, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(localTime35);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.DurationField durationField11 = gregorianChronology9.months();
        org.joda.time.DurationField durationField12 = gregorianChronology9.months();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField15 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType13, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        int int6 = dateTime5.getWeekOfWeekyear();
        int int7 = dateTime5.getEra();
        org.joda.time.DateTime dateTime9 = dateTime5.minusMinutes((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 2);
        long long10 = offsetDateTimeField7.add((-31536000000L), (int) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31532880000L) + "'", long10 == (-31532880000L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long19 = fixedDateTimeZone17.convertUTCToLocal((long) (-1));
        long long21 = fixedDateTimeZone17.previousTransition((long) 28);
        int int23 = fixedDateTimeZone17.getOffsetFromLocal(0L);
        boolean boolean24 = dateTime1.equals((java.lang.Object) fixedDateTimeZone17);
        java.util.TimeZone timeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) ' ');
        int int33 = dateTimeZone26.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime34 = dateTime1.withZoneRetainFields(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28L + "'", long21 == 28L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitYear(21, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(52, 69, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildPrinter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime20.year();
        java.lang.String str24 = property23.getAsShortText();
        java.lang.String str25 = property23.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType26, (-2922790), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Property[year]" + "'", str25.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime3.isAfter(0L);
        int int6 = dateTime3.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (-2922790), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2922790) + "'", int4 == (-2922790));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime3.plusMonths(57600010);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            long long17 = zonedChronology9.getDateTimeMillis((-1), (-1), (int) (short) 1, 28, (-2922749), 86399, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
        long long67 = remainderDateTimeField27.roundHalfCeiling(3600100L);
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime71 = dateTime69.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime73 = dateTime71.minusSeconds((int) ' ');
        java.lang.String str74 = dateTime71.toString();
        org.joda.time.TimeOfDay timeOfDay75 = dateTime71.toTimeOfDay();
        java.util.Locale locale76 = null;
        try {
            java.lang.String str77 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) timeOfDay75, locale76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3600000L + "'", long67 == 3600000L);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str74.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay75);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DurationField durationField10 = iSOChronology8.hours();
        org.joda.time.DurationField durationField11 = iSOChronology8.months();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology8.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendTwoDigitYear(12, true);
        boolean boolean22 = dateTimeFormatterBuilder21.canBuildFormatter();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds((int) (short) 1);
        boolean boolean28 = dateTime24.isBefore((long) 0);
        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property30 = dateTime24.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder21.appendText(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType31, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType31);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap37 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendTimeZoneShortName(strMap37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long32 = remainderDateTimeField27.add((long) (byte) 100, 21);
        boolean boolean33 = remainderDateTimeField27.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 21100L + "'", long32 == 21100L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        java.lang.String str3 = dateTimeFormatter0.print(readableInstant2);
//        java.lang.String str5 = dateTimeFormatter0.print(0L);
//        try {
//            org.joda.time.DateTime dateTime7 = dateTimeFormatter0.parseDateTime("19");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-01-01" + "'", str5.equals("1970-01-01"));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str5 = jodaTimePermission4.getName();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("2019-06-15");
        boolean boolean8 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission7);
        boolean boolean9 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        java.lang.String str10 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-15" + "'", str5.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15\")"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property21 = dateTime20.centuryOfEra();
        java.lang.String str22 = property21.getAsText();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str28 = iSOChronology27.toString();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.secondOfDay();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime33 = dateTime31.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate35 = dateTime31.toLocalDate();
        int[] intArray42 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology27.validate((org.joda.time.ReadablePartial) localDate35, intArray42);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str45 = iSOChronology44.toString();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology44.secondOfDay();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime50 = dateTime48.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime51 = dateTime48.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate52 = dateTime48.toLocalDate();
        int[] intArray59 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology44.validate((org.joda.time.ReadablePartial) localDate52, intArray59);
        iSOChronology23.validate((org.joda.time.ReadablePartial) localDate35, intArray59);
        int int62 = property21.compareTo((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str65 = iSOChronology64.toString();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology64.secondOfDay();
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime70 = dateTime68.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime71 = dateTime68.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate72 = dateTime68.toLocalDate();
        int[] intArray79 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology64.validate((org.joda.time.ReadablePartial) localDate72, intArray79);
        try {
            int[] intArray82 = unsupportedDateTimeField15.addWrapField((org.joda.time.ReadablePartial) localDate35, 1, intArray79, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "19" + "'", str22.equals("19"));
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[UTC]" + "'", str28.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ISOChronology[UTC]" + "'", str45.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "ISOChronology[UTC]" + "'", str65.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(mutableDateTime71);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getName((-100L), locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) ' ');
        int int30 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 3600100L);
        org.joda.time.DateTime dateTime33 = dateTime13.withZone(dateTimeZone23);
        long long35 = dateTimeZone23.convertUTCToLocal((-7686192729599900L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600100L + "'", long32 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-7686192729599900L) + "'", long35 == (-7686192729599900L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long13 = fixedDateTimeZone11.convertUTCToLocal((long) (-1));
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(1, 0, (int) (short) -1, 0, (int) (short) 100, 12, (-1), (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
        long long8 = fixedDateTimeZone4.previousTransition((long) 28);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long13 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 0, false, 32L);
        int int15 = fixedDateTimeZone4.getStandardOffset(10002L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
        org.joda.time.DateTimeField dateTimeField66 = remainderDateTimeField27.getWrappedField();
        java.util.Locale locale68 = null;
        java.lang.String str69 = remainderDateTimeField27.getAsShortText(0L, locale68);
        long long72 = remainderDateTimeField27.addWrapField(0L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(12, true);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 1);
        boolean boolean19 = dateTime15.isBefore((long) 0);
        org.joda.time.DateTime dateTime20 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder2.appendDecimal(dateTimeFieldType22, (int) '#', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendMillisOfDay(86398);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property4.addToCopy((long) 2);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime13.minusDays((int) '#');
        boolean boolean17 = dateTime16.isAfterNow();
        org.joda.time.DateTime dateTime19 = dateTime16.plus((long) 86398);
        long long20 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        boolean boolean7 = dateTime6.isAfterNow();
        int int8 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime6.minusMinutes((int) 'a');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusSeconds(10);
        boolean boolean14 = dateTime10.isBefore((long) (-2922790));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long16 = fixedDateTimeZone14.convertUTCToLocal((long) (-1));
        long long18 = fixedDateTimeZone14.previousTransition((long) 28);
        java.util.TimeZone timeZone19 = fixedDateTimeZone14.toTimeZone();
        long long23 = fixedDateTimeZone14.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology24 = zonedChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Chronology chronology25 = zonedChronology9.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str27 = iSOChronology26.toString();
        org.joda.time.DurationField durationField28 = iSOChronology26.hours();
        org.joda.time.DurationField durationField29 = iSOChronology26.months();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology26.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology26.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendTwoDigitYear(12, true);
        boolean boolean40 = dateTimeFormatterBuilder39.canBuildFormatter();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime44 = dateTime42.minusSeconds((int) (short) 1);
        boolean boolean46 = dateTime42.isBefore((long) 0);
        org.joda.time.DateTime dateTime47 = dateTime42.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property48 = dateTime42.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder39.appendText(dateTimeFieldType49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder34.appendShortText(dateTimeFieldType49);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType49, 86399);
        int int54 = remainderDateTimeField53.getDivisor();
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str56 = iSOChronology55.toString();
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology55.secondOfDay();
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime61 = dateTime59.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime62 = dateTime59.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate63 = dateTime59.toLocalDate();
        int[] intArray70 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology55.validate((org.joda.time.ReadablePartial) localDate63, intArray70);
        int[] intArray77 = new int[] { 2922789, (-2922789), (-2922650), 86398, 57600010 };
        int int78 = remainderDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) localDate63, intArray77);
        int[] intArray80 = zonedChronology9.get((org.joda.time.ReadablePartial) localDate63, (long) 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28L + "'", long18 == 28L);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[UTC]" + "'", str27.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 86399 + "'", int54 == 86399);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "ISOChronology[UTC]" + "'", str56.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(mutableDateTime62);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray80);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.hours();
        org.joda.time.DurationField durationField40 = iSOChronology37.months();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology37.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(12, true);
        boolean boolean51 = dateTimeFormatterBuilder50.canBuildFormatter();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) (short) 1);
        boolean boolean57 = dateTime53.isBefore((long) 0);
        org.joda.time.DateTime dateTime58 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property59 = dateTime53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder50.appendText(dateTimeFieldType60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder45.appendShortText(dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField42, dateTimeFieldType60, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType60, 69);
        long long70 = offsetDateTimeField67.getDifferenceAsLong((long) 100, 69L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(2000, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(2000, (-1));
        boolean boolean12 = dateTimeFormatterBuilder11.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronology();
        java.lang.String str9 = dateTime3.toString(dateTimeFormatter7);
        int int10 = dateTime3.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime3.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01" + "'", str9.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((int) ' ');
        int int8 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField10 = gregorianChronology9.days();
        org.joda.time.DurationField durationField11 = gregorianChronology9.months();
        try {
            long long16 = gregorianChronology9.getDateTimeMillis(5, (-2922679), 86398, 57600010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922679 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        int int12 = mutableDateTime11.getWeekOfWeekyear();
        int int15 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "org.joda.time.IllegalFieldValueException: Value 100.0 for 2019-06-15 must be in the range [100,-1]", 960);
        int int16 = mutableDateTime11.getEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-961) + "'", int15 == (-961));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            boolean boolean17 = unsupportedDateTimeField15.isLeap(1942L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        try {
            long long18 = unsupportedDateTimeField15.roundHalfFloor(28L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        try {
            long long19 = unsupportedDateTimeField15.roundHalfEven((long) 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((long) (byte) 0, locale2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        try {
            long long18 = unsupportedDateTimeField15.roundFloor((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        try {
            long long19 = unsupportedDateTimeField15.roundHalfCeiling((-2921000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.withWeekyear(0);
        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.withMillis((long) (-2922790));
        java.util.Locale locale15 = null;
        java.util.Calendar calendar16 = dateTime11.toCalendar(locale15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(calendar16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendTwoDigitYear(12, true);
        boolean boolean22 = dateTimeFormatterBuilder21.canBuildFormatter();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds((int) (short) 1);
        boolean boolean28 = dateTime24.isBefore((long) 0);
        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property30 = dateTime24.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder21.appendText(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType31, (int) '#', (int) (short) 100);
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatterBuilder11.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            int int17 = unsupportedDateTimeField15.getMinimumValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        long long25 = zonedChronology15.set((org.joda.time.ReadablePartial) localTime23, (long) (-28800000));
        try {
            long long31 = zonedChronology15.getDateTimeMillis(0L, 69, 28, (int) (byte) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-14431989L) + "'", long25 == (-14431989L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.DateTime.Property property7 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) ' ');
        java.lang.String str14 = dateTime11.toString();
        org.joda.time.TimeOfDay timeOfDay15 = dateTime11.toTimeOfDay();
        boolean boolean16 = dateTime11.isBeforeNow();
        org.joda.time.DateTime dateTime18 = dateTime11.plus((long) '4');
        int int19 = property7.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.Interval interval20 = property7.toInterval();
        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str14.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(interval20);
        org.junit.Assert.assertNotNull(readableInterval21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime3.minusDays((-2922790));
        org.joda.time.Chronology chronology12 = dateTime3.getChronology();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((-2922679));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendWeekOfWeekyear(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendMillisOfSecond(12);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        boolean boolean16 = dateTime12.isBefore((long) 0);
        org.joda.time.DateTime dateTime17 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property18 = dateTime12.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str21 = iSOChronology20.toString();
        org.joda.time.DurationField durationField22 = iSOChronology20.hours();
        long long25 = durationField22.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField22);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType19, (-2922789), (-2922679));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[UTC]" + "'", str21.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-115199040L) + "'", long25 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 4078200, (-2922679));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven(0L);
        long long51 = remainderDateTimeField27.addWrapField(32L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 32L + "'", long51 == 32L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 100, (-11), 32, (int) (short) 1, (-2922749), 12, (-2922650));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922749 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) '#');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyearOfCentury();
        int int11 = dateTime8.get(dateTimeField10);
        org.joda.time.DateTime dateTime13 = dateTime8.minusSeconds(1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime6.minuteOfDay();
        org.joda.time.Interval interval12 = property11.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(interval12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField8 = iSOChronology7.millis();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long6 = iSOChronology1.getDateTimeMillis(2000, (int) (byte) -1, 1, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int60 = offsetDateTimeField59.getMaximumValue();
        long long62 = offsetDateTimeField59.roundFloor((-100L));
        int int63 = offsetDateTimeField59.getOffset();
        long long65 = offsetDateTimeField59.roundCeiling((long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-2922650) + "'", int60 == (-2922650));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-31536000000L) + "'", long62 == (-31536000000L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-2922749) + "'", int63 == (-2922749));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getName((-100L), locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) ' ');
        int int30 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 3600100L);
        org.joda.time.DateTime dateTime33 = dateTime13.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime37 = dateTime35.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime35.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology40 = dateTimeFormatter39.getChronology();
        java.lang.String str41 = dateTime35.toString(dateTimeFormatter39);
        int int42 = dateTime35.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime35.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial44 = null;
        org.joda.time.DateTime dateTime45 = dateTime35.withFields(readablePartial44);
        org.joda.time.DateTime dateTime47 = dateTime45.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone52 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale54 = null;
        java.lang.String str55 = fixedDateTimeZone52.getName((-100L), locale54);
        java.util.TimeZone timeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime61 = dateTime59.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime63 = dateTime61.minusSeconds((int) ' ');
        int int64 = dateTimeZone57.getOffset((org.joda.time.ReadableInstant) dateTime61);
        long long66 = fixedDateTimeZone52.getMillisKeepLocal(dateTimeZone57, 3600100L);
        org.joda.time.DateTime dateTime67 = dateTime47.withZone(dateTimeZone57);
        org.joda.time.ReadableDuration readableDuration68 = null;
        org.joda.time.DateTime dateTime69 = dateTime47.plus(readableDuration68);
        int int70 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime47);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600100L + "'", long32 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNull(chronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970-01-01" + "'", str41.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "+00:00" + "'", str55.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 3600100L + "'", long66 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime53 = dateTime51.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime51.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate55 = dateTime51.toLocalDate();
        int[] intArray62 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology47.validate((org.joda.time.ReadablePartial) localDate55, intArray62);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate55, locale64);
        int int66 = remainderDateTimeField27.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType67, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[UTC]" + "'", str48.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1" + "'", str65.equals("1"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.DateTime dateTime10 = dateTime1.withDurationAdded(3600100L, (int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime1.dayOfMonth();
        java.lang.String str12 = property11.getAsText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str4 = iSOChronology3.toString();
        long long8 = iSOChronology3.add((long) 100, 3600100L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 1);
        boolean boolean15 = dateTime11.isBefore((long) 0);
        org.joda.time.DateTime dateTime16 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int24 = fixedDateTimeZone22.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology17, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology25.getZone();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime28.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime33 = dateTime32.toLocalTime();
        long long35 = zonedChronology25.set((org.joda.time.ReadablePartial) localTime33, (long) (-28800000));
        java.lang.String str36 = zonedChronology25.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) zonedChronology25);
        try {
            long long42 = zonedChronology25.getDateTimeMillis(1970, 10, 57600010, (-2922749));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922749 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localTime33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-14431989L) + "'", long35 == (-14431989L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]" + "'", str36.equals("ZonedChronology[ISOChronology[UTC], 1969-12-27T12:00:00.010-08:00]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long18 = fixedDateTimeZone12.adjustOffset((long) 10, true);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds((int) ' ');
        int int27 = dateTimeZone20.getOffset((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        long long30 = fixedDateTimeZone12.getMillisKeepLocal(dateTimeZone20, (long) 35);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 34L + "'", long30 == 34L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime13 = property11.addToCopy((long) (short) 1);
        org.joda.time.DurationField durationField14 = property11.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("2019-06-15");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        java.lang.String str6 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15" + "'", str6.equals("2019-06-15"));
        org.junit.Assert.assertNotNull(permissionCollection7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) ' ');
        int int13 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField15 = gregorianChronology14.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long22 = fixedDateTimeZone20.convertUTCToLocal((long) (-1));
        long long24 = fixedDateTimeZone20.previousTransition((long) 28);
        java.util.TimeZone timeZone25 = fixedDateTimeZone20.toTimeZone();
        org.joda.time.Chronology chronology26 = gregorianChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime27 = dateTime3.withChronology(chronology26);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28L + "'", long24 == 28L);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        boolean boolean8 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime10 = dateTime3.plus((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime3.withDayOfYear(12);
        boolean boolean13 = dateTime3.isAfterNow();
        org.joda.time.DateTime dateTime15 = dateTime3.minusYears(960);
        int int16 = dateTime15.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1200 + "'", int16 == 1200);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long16 = fixedDateTimeZone14.convertUTCToLocal((long) (-1));
        long long18 = fixedDateTimeZone14.previousTransition((long) 28);
        java.util.TimeZone timeZone19 = fixedDateTimeZone14.toTimeZone();
        long long23 = fixedDateTimeZone14.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology24 = zonedChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Chronology chronology25 = zonedChronology9.withUTC();
        java.lang.String str26 = zonedChronology9.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28L + "'", long18 == 28L);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 1969-12-27T12:00:00.010-08:00]" + "'", str26.equals("ZonedChronology[GregorianChronology[UTC], 1969-12-27T12:00:00.010-08:00]"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField15.getLeapDurationField();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField15.getAsShortText((-1), locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15");
        java.lang.String str4 = dateTimeFormatter0.print((long) '#');
        boolean boolean5 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01" + "'", str4.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-1), false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime1.getZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) ' ');
        java.util.GregorianCalendar gregorianCalendar15 = dateTime14.toGregorianCalendar();
        org.joda.time.DateTime dateTime17 = dateTime14.minusMonths((int) (short) 1);
        boolean boolean18 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str18 = iSOChronology17.toString();
        org.joda.time.DurationField durationField19 = iSOChronology17.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long26 = fixedDateTimeZone24.convertUTCToLocal((long) (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        boolean boolean28 = iSOChronology17.equals((java.lang.Object) fixedDateTimeZone24);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.secondOfDay();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime35 = dateTime33.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime36 = dateTime33.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate37 = dateTime33.toLocalDate();
        int[] intArray44 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology29.validate((org.joda.time.ReadablePartial) localDate37, intArray44);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str47 = iSOChronology46.toString();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology46.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str51 = iSOChronology50.toString();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.secondOfDay();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime56 = dateTime54.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime57 = dateTime54.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate58 = dateTime54.toLocalDate();
        int[] intArray65 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology50.validate((org.joda.time.ReadablePartial) localDate58, intArray65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str68 = iSOChronology67.toString();
        org.joda.time.DateTimeField dateTimeField69 = iSOChronology67.secondOfDay();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime73 = dateTime71.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime74 = dateTime71.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate75 = dateTime71.toLocalDate();
        int[] intArray82 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology67.validate((org.joda.time.ReadablePartial) localDate75, intArray82);
        iSOChronology46.validate((org.joda.time.ReadablePartial) localDate58, intArray82);
        iSOChronology17.validate((org.joda.time.ReadablePartial) localDate37, intArray82);
        try {
            int int86 = unsupportedDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[UTC]" + "'", str18.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[UTC]" + "'", str30.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[UTC]" + "'", str47.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ISOChronology[UTC]" + "'", str51.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(mutableDateTime57);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ISOChronology[UTC]" + "'", str68.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(mutableDateTime74);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertNotNull(intArray82);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = iSOChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.millisOfSecond();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField9, (-2922790), (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922790 for millisOfSecond must be in the range [0,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long32 = remainderDateTimeField27.add((long) (byte) 100, 21);
        int int33 = remainderDateTimeField27.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 21100L + "'", long32 == 21100L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 86398 + "'", int33 == 86398);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        boolean boolean13 = dateTime10.isAfter((-1L));
        int int14 = dateTime10.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DurationField durationField8 = iSOChronology6.hours();
        org.joda.time.DurationField durationField9 = iSOChronology6.months();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitYear(12, true);
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildFormatter();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 1);
        boolean boolean26 = dateTime22.isBefore((long) 0);
        org.joda.time.DateTime dateTime27 = dateTime22.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property28 = dateTime22.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder14.appendShortText(dateTimeFieldType29);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField11, dateTimeFieldType29, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str35 = iSOChronology34.toString();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.secondOfDay();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate42 = dateTime38.toLocalDate();
        int[] intArray49 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology34.validate((org.joda.time.ReadablePartial) localDate42, intArray49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = remainderDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate42, locale51);
        long long54 = remainderDateTimeField33.roundHalfEven((long) 2922789);
        int int56 = remainderDateTimeField33.getMinimumValue(3600100L);
        long long58 = remainderDateTimeField33.roundCeiling((long) (-2922790));
        long long60 = remainderDateTimeField33.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = remainderDateTimeField33.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType61, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[UTC]" + "'", str35.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2923000L + "'", long54 == 2923000L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2922000L) + "'", long58 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1000L + "'", long60 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        int int9 = property4.getMaximumValueOverall();
        int int10 = property4.get();
        int int11 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922789 + "'", int9 == 2922789);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        try {
            int int17 = unsupportedDateTimeField15.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        int int8 = dateTime7.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        java.util.Date date4 = dateTime3.toDate();
        org.joda.time.DateTime dateTime6 = dateTime3.withYear(57600010);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
//        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (-1));
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTwoDigitYear(12, true);
//        boolean boolean19 = dateTimeFormatterBuilder18.canBuildFormatter();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 1);
//        boolean boolean25 = dateTime21.isBefore((long) 0);
//        org.joda.time.DateTime dateTime26 = dateTime21.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property27 = dateTime21.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder18.appendText(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType28);
//        int int31 = dateTime10.get(dateTimeFieldType28);
//        org.joda.time.DateTime dateTime33 = dateTime10.minusMinutes((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.lang.String str5 = property4.toString();
        int int6 = property4.getLeapAmount();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 69);
        org.joda.time.LocalTime localTime11 = dateTimeFormatter7.parseLocalTime("1969-12-27T20:00:00.010Z");
        try {
            int int12 = property4.compareTo((org.joda.time.ReadablePartial) localTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[centuryOfEra]" + "'", str5.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(localTime11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder31.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.hours();
        org.joda.time.DurationField durationField40 = iSOChronology37.months();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology37.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology37.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(12, true);
        boolean boolean51 = dateTimeFormatterBuilder50.canBuildFormatter();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime55 = dateTime53.minusSeconds((int) (short) 1);
        boolean boolean57 = dateTime53.isBefore((long) 0);
        org.joda.time.DateTime dateTime58 = dateTime53.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property59 = dateTime53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder50.appendText(dateTimeFieldType60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder45.appendShortText(dateTimeFieldType60);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField42, dateTimeFieldType60, 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType60, 69);
        int int68 = remainderDateTimeField27.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1970-01-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01\" is malformed at \"70-01-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.DateTime.Property property7 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, readableInstant8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        int int6 = dateTime4.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1439 + "'", int6 == 1439);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime.Property property12 = dateTime11.weekyear();
        org.joda.time.DurationField durationField13 = property12.getRangeDurationField();
        org.joda.time.DurationField durationField14 = property12.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-961), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        org.joda.time.DateTime.Property property9 = dateTime3.yearOfEra();
        java.lang.String str10 = property9.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime();
        int int16 = dateTime12.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 1);
        boolean boolean11 = dateTime7.isBefore((long) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(2922789, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-2922650), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds((int) ' ');
        boolean boolean12 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.minus((long) (-1));
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.Chronology chronology16 = dateTime14.getChronology();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime13 = property11.addToCopy((long) (short) 1);
        java.lang.String str14 = property11.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfDay(0, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType23, (int) '#', (int) (short) 100);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) ' ');
        java.lang.String str9 = dateTime6.toString();
        org.joda.time.TimeOfDay timeOfDay10 = dateTime6.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) timeOfDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str9.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        boolean boolean13 = dateTime11.isAfter((long) 100);
        int int14 = dateTime11.getMinuteOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.minusDays(960);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 10002L, (-2922790));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        long long63 = offsetDateTimeField59.roundHalfCeiling((-7686192729599900L));
        long long65 = offsetDateTimeField59.roundHalfFloor(10L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-7686200592000000L) + "'", long63 == (-7686200592000000L));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(2000, (-1));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendCenturyOfEra((-2922650), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime9.toCalendar(locale11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long19 = fixedDateTimeZone17.convertUTCToLocal((long) (-1));
        long long21 = fixedDateTimeZone17.previousTransition((long) 28);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.DateTime dateTime23 = dateTime9.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28L + "'", long21 == 28L);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-2922790), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendMillisOfSecond(12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendWeekOfWeekyear(1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendFractionOfHour(86399, 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        int int8 = dateTime6.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime9.toCalendar(locale11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        int int29 = remainderDateTimeField27.getMaximumValue((long) 35);
        long long31 = remainderDateTimeField27.remainder((-1L));
        long long33 = remainderDateTimeField27.roundHalfFloor((-31536000000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = remainderDateTimeField27.getType();
        int int36 = remainderDateTimeField27.getMaximumValue((long) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86398 + "'", int29 == 86398);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 999L + "'", long31 == 999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-31536000000L) + "'", long33 == (-31536000000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86398 + "'", int36 == 86398);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "2019-06-15", "Property[centuryOfEra]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        java.lang.String str3 = dateTimeFormatter0.print(readableInstant2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.Chronology chronology5 = dateTimeFormatter0.getChronology();
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter0.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimePrinter6);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2100L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2100L + "'", long2 == 2100L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("100.0", "1969", 2, 86398);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DurationField durationField4 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone5.getName((-100L), locale7);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds((int) ' ');
        int int17 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime14);
        long long19 = fixedDateTimeZone5.getMillisKeepLocal(dateTimeZone10, 3600100L);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1970, dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600100L + "'", long19 == 3600100L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.joda.time.DurationField durationField5 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(4078200);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        java.util.Locale locale65 = null;
        java.lang.String str66 = offsetDateTimeField59.getAsShortText(12, locale65);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "12" + "'", str66.equals("12"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = cachedDateTimeZone8.getOffset((long) 100);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long13 = cachedDateTimeZone8.previousTransition((long) 960);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 960L + "'", long13 == 960L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendClockhourOfDay((-2922789));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int7 = fixedDateTimeZone5.getOffset((long) (byte) -1);
        java.lang.String str8 = fixedDateTimeZone5.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        long long16 = fixedDateTimeZone14.convertUTCToLocal((long) (-1));
        long long18 = fixedDateTimeZone14.previousTransition((long) 28);
        java.util.TimeZone timeZone19 = fixedDateTimeZone14.toTimeZone();
        long long23 = fixedDateTimeZone14.convertLocalToUTC((long) (short) 0, false, 32L);
        org.joda.time.Chronology chronology24 = zonedChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Chronology chronology25 = zonedChronology9.withUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime29 = dateTime27.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime31 = dateTime29.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        boolean boolean35 = dateTime31.isAfter((-7686192729599900L));
        org.joda.time.DateTime.Property property36 = dateTime31.centuryOfEra();
        boolean boolean37 = zonedChronology9.equals((java.lang.Object) dateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str8.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28L + "'", long18 == 28L);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField15.getType();
        try {
            long long18 = unsupportedDateTimeField15.roundHalfCeiling(1942L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "19");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getName((-100L), locale13);
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) ' ');
        int int23 = dateTimeZone16.getOffset((org.joda.time.ReadableInstant) dateTime20);
        long long25 = fixedDateTimeZone11.getMillisKeepLocal(dateTimeZone16, 3600100L);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone16.isLocalDateTimeGap(localDateTime26);
        int int29 = dateTimeZone16.getOffsetFromLocal((long) 28);
        try {
            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((int) (short) 10, (-961), 86398, 15, 57600010, (-2922789), 2100, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3600100L + "'", long25 == 3600100L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (byte) 0, (int) '#');
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getName((-100L), locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) ' ');
        int int30 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
        long long32 = fixedDateTimeZone18.getMillisKeepLocal(dateTimeZone23, 3600100L);
        org.joda.time.DateTime dateTime33 = dateTime13.withZone(dateTimeZone23);
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime13.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3600100L + "'", long32 == 3600100L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey(0L);
        int int12 = cachedDateTimeZone8.getStandardOffset((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-27T12:00:00.010-08:00" + "'", str7.equals("1969-12-27T12:00:00.010-08:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.DurationField durationField5 = iSOChronology2.months();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(12, true);
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildFormatter();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 1);
        boolean boolean22 = dateTime18.isBefore((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType25);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType25, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str31 = iSOChronology30.toString();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate38 = dateTime34.toLocalDate();
        int[] intArray45 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology30.validate((org.joda.time.ReadablePartial) localDate38, intArray45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = remainderDateTimeField29.getAsText((org.joda.time.ReadablePartial) localDate38, locale47);
        long long50 = remainderDateTimeField29.roundHalfEven((long) 2922789);
        int int52 = remainderDateTimeField29.getMinimumValue(3600100L);
        long long54 = remainderDateTimeField29.roundCeiling((long) (-2922790));
        long long56 = remainderDateTimeField29.roundCeiling((long) 960);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = remainderDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType57, (-2922749));
        int int61 = offsetDateTimeField59.get((long) (byte) 10);
        boolean boolean63 = offsetDateTimeField59.isLeap((long) 21);
        java.util.Locale locale64 = null;
        int int65 = offsetDateTimeField59.getMaximumTextLength(locale64);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ISOChronology[UTC]" + "'", str31.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2923000L + "'", long50 == 2923000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2922000L) + "'", long54 == (-2922000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1000L + "'", long56 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-2922679) + "'", int61 == (-2922679));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 8 + "'", int65 == 8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("1969-12-27T12:00:00.010-08:00", "ISOChronology[UTC]", (int) (short) -1, 2);
        int int14 = fixedDateTimeZone12.getOffset((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds((int) ' ');
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        long long25 = zonedChronology15.set((org.joda.time.ReadablePartial) localTime23, (long) (-28800000));
        java.lang.Object obj26 = null;
        boolean boolean27 = zonedChronology15.equals(obj26);
        try {
            long long35 = zonedChronology15.getDateTimeMillis((int) ' ', 69, 0, 2922789, 0, 0, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-14431989L) + "'", long25 == (-14431989L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        java.lang.String str6 = dateTime3.toString();
        int int7 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.withMillis(62L);
        org.joda.time.DateTime dateTime11 = dateTime3.withWeekyear(0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-27T20:00:00.010Z" + "'", str6.equals("1969-12-27T20:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, (int) '4');
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears((-961));
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((int) '4');
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        boolean boolean14 = dateTime10.isAfter((-7686192729599900L));
        boolean boolean15 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withPivotYear((java.lang.Integer) 69);
        org.joda.time.LocalTime localTime20 = dateTimeFormatter16.parseLocalTime("1969-12-27T20:00:00.010Z");
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = unsupportedDateTimeField15.getAsText((org.joda.time.ReadablePartial) localTime20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(localTime20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(12, true);
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.append(dateTimeFormatter6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.append(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven((long) 2922789);
        int int50 = remainderDateTimeField27.getMinimumValue(3600100L);
        long long52 = remainderDateTimeField27.roundCeiling((long) (-2922790));
        java.lang.String str53 = remainderDateTimeField27.toString();
        java.util.Locale locale54 = null;
        int int55 = remainderDateTimeField27.getMaximumTextLength(locale54);
        int int57 = remainderDateTimeField27.getLeapAmount((long) 2100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2923000L + "'", long48 == 2923000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2922000L) + "'", long52 == (-2922000L));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str53.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 5 + "'", int55 == 5);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        java.util.Locale locale7 = null;
        java.lang.String str8 = property4.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.minusMillis(86399);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        java.lang.String str7 = dateTime1.toString(dateTimeFormatter5);
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime1.toYearMonthDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.withFields(readablePartial10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime3.withDurationAdded((long) '4', (int) ' ');
        int int10 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        int int12 = property11.getLeapAmount();
        int int13 = property11.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(12, true);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildFormatter();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.minusSeconds((int) (short) 1);
        boolean boolean20 = dateTime16.isBefore((long) 0);
        org.joda.time.DateTime dateTime21 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendShortText(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType23, 86399);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.secondOfDay();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime32.toMutableDateTimeISO();
        org.joda.time.LocalDate localDate36 = dateTime32.toLocalDate();
        int[] intArray43 = new int[] { (short) -1, (byte) 10, 10, (byte) -1, '#', 100 };
        iSOChronology28.validate((org.joda.time.ReadablePartial) localDate36, intArray43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate36, locale45);
        long long48 = remainderDateTimeField27.roundHalfEven(0L);
        boolean boolean50 = remainderDateTimeField27.isLeap(3600000L);
        org.joda.time.DurationField durationField51 = remainderDateTimeField27.getRangeDurationField();
        boolean boolean52 = remainderDateTimeField27.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 100, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) (byte) -1, (int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((-961));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -961 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 1);
        boolean boolean5 = dateTime1.isBefore((long) 0);
        org.joda.time.DateTime dateTime6 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.hours();
        long long14 = durationField11.subtract((long) 960, (int) ' ');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField11);
        try {
            long long17 = unsupportedDateTimeField15.roundHalfCeiling(3600100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-115199040L) + "'", long14 == (-115199040L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-2922000L), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-29220000L) + "'", long2 == (-29220000L));
    }
}

