import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        int int11 = property9.getMaximumShortTextLength(locale10);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property9.getAsShortText(locale12);
//        org.joda.time.MonthDay monthDay15 = property9.addWrapFieldToCopy(28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay15);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.Chronology chronology3 = buddhistChronology1.withUTC();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology5 = gJChronology4.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.minuteOfDay();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology9 = gJChronology8.withUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.Chronology chronology11 = julianChronology6.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gJChronology4.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.Chronology chronology14 = buddhistChronology1.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsText((int) (short) 10, locale6);
        long long10 = delegatedDateTimeField2.add(31L, (int) (byte) 10);
        long long12 = delegatedDateTimeField2.remainder((long) 49);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 315705600031L + "'", long10 == 315705600031L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200049L + "'", long12 == 259200049L);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        int int13 = property9.getMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
//        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
//        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
//        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField24 = property9.getDurationField();
//        org.joda.time.DateTimeField dateTimeField25 = property9.getField();
//        java.lang.String str26 = property9.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant4.withDurationAdded(readableDuration5, (-1));
        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTime();
        int int9 = mutableDateTime8.getMonthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMinutes(2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(24);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis((-292275011));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        int int41 = offsetDateTimeField37.getLeapAmount(0L);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (short) 100);
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        long long50 = offsetDateTimeField37.roundHalfFloor((long) 22);
        org.joda.time.ReadablePartial readablePartial51 = null;
        java.util.Locale locale52 = null;
        try {
            java.lang.String str53 = offsetDateTimeField37.getAsShortText(readablePartial51, locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279024 + "'", int48 == 292279024);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200000L) + "'", long50 == (-259200000L));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(2019);
//        org.joda.time.DateTime dateTime5 = dateTime3.withEra((int) (byte) 0);
//        long long6 = dateTime3.getMillis();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560751455662L + "'", long6 == 1560751455662L);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter12.withDefaultYear(100);
        java.util.Locale locale16 = dateTimeFormatter15.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNull(locale16);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) 12);
//        java.lang.String str7 = dateTimeZone1.getShortName(315446400000L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((java.lang.Object) monthDay16);
        org.joda.time.MonthDay monthDay21 = monthDay16.minusMonths(30);
        int int22 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay21);
        long long24 = skipDateTimeField6.roundCeiling((long) 15);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2678400000L + "'", long24 == 2678400000L);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(chronology13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, (int) (short) 100);
//        int[] intArray19 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay17, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
//        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology20.minuteOfDay();
//        org.joda.time.MonthDay monthDay29 = monthDay17.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTime dateTime30 = dateTime11.toDateTime((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTime.Property property31 = dateTime11.era();
//        org.joda.time.DateTime dateTime33 = dateTime11.withMillisOfDay((int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = delegatedDateTimeField36.getAsShortText((int) (byte) 100, locale38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField36.getType();
//        boolean boolean41 = dateTime33.isSupported(dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType40, 31);
//        int int44 = dateTime3.get(dateTimeFieldType40);
//        int int45 = dateTime3.getDayOfYear();
//        try {
//            org.joda.time.DateTime dateTime47 = dateTime3.withDayOfMonth((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "100" + "'", str39.equals("100"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 105 + "'", int45 == 105);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int7 = skipDateTimeField6.getMaximumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText(0L, locale9);
        int int12 = skipDateTimeField6.get((long) 595);
        try {
            long long15 = skipDateTimeField6.set(315705600031L, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-25200000), 27, 2022);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1496 + "'", int3 == 1496);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        int int17 = unsupportedDateTimeField9.getDifference(1970L, 1555359865551L);
        try {
            long long20 = unsupportedDateTimeField9.set((-252201597981L), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-49) + "'", int17 == (-49));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField9.getType();
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField9.getLeapDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (short) 100);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusDays(0);
        java.lang.String str25 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = unsupportedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay22, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "����W���T������.000" + "'", str25.equals("����W���T������.000"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfMonth();
        try {
            long long11 = gJChronology0.getDateTimeMillis(1970, 57, 0, 0, 9, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        org.joda.time.DurationField durationField41 = offsetDateTimeField37.getRangeDurationField();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        boolean boolean45 = monthDay43.isSupported(dateTimeFieldType44);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((java.lang.Object) monthDay43);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 22, locale48);
        java.lang.String str50 = offsetDateTimeField37.toString();
        int int52 = offsetDateTimeField37.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "22" + "'", str49.equals("22"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DateTimeField[weekyear]" + "'", str50.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.MonthDay monthDay7 = monthDay4.withDayOfMonth(28);
        int int8 = monthDay7.getMonthOfYear();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime7.toMutableDateTime(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(chronology13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, (int) (short) 100);
        int[] intArray19 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay17, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology20.minuteOfDay();
        org.joda.time.MonthDay monthDay29 = monthDay17.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTime dateTime30 = dateTime11.toDateTime((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTime.Property property31 = dateTime11.era();
        org.joda.time.DateTime dateTime33 = dateTime11.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField36.getAsShortText((int) (byte) 100, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField36.getType();
        boolean boolean41 = dateTime33.isSupported(dateTimeFieldType40);
        int int42 = dateTime7.get(dateTimeFieldType40);
        org.joda.time.DateTime dateTime44 = dateTime7.plusHours(2019);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "100" + "'", str39.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipDateTimeField9);
        int int13 = skipDateTimeField9.getDifference((long) 0, (long) '4');
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        java.util.Locale locale25 = null;
        try {
            int[] intArray26 = skipDateTimeField9.set(readablePartial14, 4, intArray23, "����-06-15T��:��", locale25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-06-15T��:��\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        boolean boolean6 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay4.getFields();
        int int8 = monthDay4.getMonthOfYear();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        gregorianChronology10.validate((org.joda.time.ReadablePartial) monthDay13, intArray21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
        org.joda.time.MonthDay monthDay30 = monthDay28.plusDays(0);
        java.lang.String str31 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) monthDay28);
        int int32 = monthDay13.compareTo((org.joda.time.ReadablePartial) monthDay28);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = delegatedDateTimeField35.getAsShortText((int) (byte) 100, locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField35.getType();
        boolean boolean40 = monthDay13.isSupported(dateTimeFieldType39);
        boolean boolean41 = monthDay5.isSupported(dateTimeFieldType39);
        org.joda.time.ReadablePartial readablePartial42 = null;
        try {
            int int43 = monthDay5.compareTo(readablePartial42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "����W���T������.000" + "'", str31.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField9.getDurationField();
        try {
            int int17 = unsupportedDateTimeField9.getMaximumValue((long) 2022);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 1496, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = buddhistChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = buddhistChronology3.withZone(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology6, dateTimeField8, 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField10, (-49));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str4.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsText((int) (short) 10, locale6);
        long long10 = delegatedDateTimeField2.add(31L, (int) (byte) 10);
        int int12 = delegatedDateTimeField2.get(14329493548L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 315705600031L + "'", long10 == 315705600031L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        int int6 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-25200000) + "'", int6 == (-25200000));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        try {
            org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        org.joda.time.DurationField durationField41 = offsetDateTimeField37.getRangeDurationField();
        boolean boolean42 = offsetDateTimeField37.isLenient();
        int int44 = offsetDateTimeField37.getLeapAmount(28857600001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.Integer int4 = dateTimeFormatter3.getPivotYear();
        java.lang.Appendable appendable5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        org.joda.time.Instant instant10 = dateTime9.toInstant();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant13 = instant10.withDurationAdded(readableDuration11, (-1));
        org.joda.time.DateTime dateTime14 = instant13.toDateTime();
        try {
            dateTimeFormatter3.printTo(appendable5, (org.joda.time.ReadableInstant) instant13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00" + "'", str2.equals("00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(int4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gJChronology0.seconds();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        gregorianChronology16.validate((org.joda.time.ReadablePartial) monthDay19, intArray27);
        int int29 = offsetDateTimeField14.getMaximumValue(readablePartial15, intArray27);
        try {
            long long32 = offsetDateTimeField14.set((long) 1971, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [-292275022,-292275011]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275011) + "'", int29 == (-292275011));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        long long41 = offsetDateTimeField37.set(28658966613L, 4);
        long long44 = offsetDateTimeField37.add((long) 55, (long) (-2548));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62990291433387L) + "'", long41 == (-62990291433387L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-80406950399945L) + "'", long44 == (-80406950399945L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        int int17 = unsupportedDateTimeField9.getDifference(1970L, 1555359865551L);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField9.getAsShortText((long) (short) 100, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-49) + "'", int17 == (-49));
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
//        int int6 = dateTime1.getSecondOfDay();
//        boolean boolean8 = dateTime1.isAfter((long) '4');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 73519 + "'", int6 == 73519);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        java.util.Locale locale42 = null;
        try {
            long long43 = offsetDateTimeField37.set((-1L), "0.0", locale42);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0.0\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int7 = skipDateTimeField6.getMaximumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText(0L, locale9);
        int int12 = skipDateTimeField6.get((long) 595);
        int int14 = skipDateTimeField6.get(1560630286785L);
        java.lang.String str15 = skipDateTimeField6.toString();
        int int16 = skipDateTimeField6.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[monthOfYear]" + "'", str15.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter12.withDefaultYear(100);
        int int16 = dateTimeFormatter15.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) julianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipDateTimeField9);
        int int12 = skipDateTimeField9.get((long) (byte) 0);
        int int14 = skipDateTimeField9.getMaximumValue((-62230291199980L));
        long long16 = skipDateTimeField9.roundFloor((long) 363);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 292278993 + "'", int14 == 292278993);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology1.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        long long10 = delegatedDateTimeField2.getDifferenceAsLong((long) (-1), (long) 73515);
        try {
            long long13 = delegatedDateTimeField2.add(0L, 28857600001L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 28857600001");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(2019);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMillis(20);
        int int11 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime6);
        try {
            dateTimeFormatter1.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        java.util.Locale locale10 = null;
        try {
            int int11 = unsupportedDateTimeField9.getMaximumTextLength(locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        int int12 = unsupportedDateTimeField9.getDifference((long) 12, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((int) (byte) 100, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType9, 1970, 2019, (int) (byte) 1);
        int int14 = offsetDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((int) (short) 10, locale8);
        long long12 = delegatedDateTimeField4.add(31L, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, 9);
        java.lang.String str15 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 315705600031L + "'", long12 == 315705600031L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str15.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsShortText(readablePartial39, (-292275054), locale41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField37.getType();
        long long45 = offsetDateTimeField37.roundCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-292275054" + "'", str42.equals("-292275054"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 31795200000L + "'", long45 == 31795200000L);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        int int13 = property9.getMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
//        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
//        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
//        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime17.minus(readablePeriod24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        org.joda.time.DurationField durationField9 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime11 = property4.addWrapFieldToCopy((int) (short) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
//        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime.Property property12 = dateTime5.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime5.secondOfMinute();
//        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((-292275053));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 22 + "'", int11 == 22);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField37.getAsText((long) 15, locale39);
        long long43 = offsetDateTimeField37.add(110L, 2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2001" + "'", str40.equals("2001"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 63504000110L + "'", long43 == 63504000110L);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) 57, locale4);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime.Property property27 = dateTime7.era();
        org.joda.time.DateTime dateTime29 = dateTime7.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsShortText((int) (byte) 100, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        boolean boolean37 = dateTime29.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType36, 31);
        long long41 = offsetDateTimeField39.roundHalfFloor((long) 100);
        int int43 = offsetDateTimeField39.getLeapAmount(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay(dateTimeZone49);
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay(chronology52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.MonthDay monthDay56 = monthDay53.withPeriodAdded(readablePeriod54, (int) (short) 100);
        int[] intArray58 = iSOChronology51.get((org.joda.time.ReadablePartial) monthDay56, 0L);
        gregorianChronology47.validate((org.joda.time.ReadablePartial) monthDay50, intArray58);
        java.util.Locale locale61 = null;
        try {
            int[] intArray62 = skipDateTimeField44.set(readablePartial45, 12, intArray58, "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", locale61);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[ISOChronology[UTC], America/Los_Angeles]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("UnsupportedDateTimeField", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00" + "'", str2.equals("00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField9.getDurationField();
        java.lang.String str16 = unsupportedDateTimeField9.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "weekyear" + "'", str16.equals("weekyear"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.Instant instant6 = dateTime5.toInstant();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology8.hourOfDay();
        org.joda.time.DurationField durationField18 = iSOChronology8.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology8.getZone();
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = dateTimeZone21.isLocalDateTimeGap(localDateTime22);
        org.joda.time.MutableDateTime mutableDateTime24 = instant6.toMutableDateTime(dateTimeZone21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(chronology28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, (int) (short) 100);
        int[] intArray34 = iSOChronology27.get((org.joda.time.ReadablePartial) monthDay32, 0L);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology27.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology27.hourOfDay();
        org.joda.time.DurationField durationField37 = iSOChronology27.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) iSOChronology27);
        int int40 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime39);
        int int41 = dateTime39.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 70 + "'", int41 == 70);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        org.joda.time.MonthDay monthDay17 = monthDay15.minusMonths(1971);
        try {
            int int18 = unsupportedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (short) 100);
        boolean boolean13 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay12);
        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.DateTimeField[] dateTimeFieldArray15 = monthDay12.getFields();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (short) 100);
        int[] intArray24 = iSOChronology17.get((org.joda.time.ReadablePartial) monthDay22, 0L);
        try {
            int[] intArray26 = delegatedDateTimeField2.addWrapField((org.joda.time.ReadablePartial) monthDay12, (-1), intArray24, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldArray15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(8);
        try {
            org.joda.time.Instant instant5 = org.joda.time.Instant.parse("", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
//        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 'a');
//        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
//        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
//        int int19 = property17.get();
//        org.joda.time.DateTime dateTime20 = property17.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (-1));
//        org.joda.time.DateTime dateTime24 = monthDay3.toDateTime((org.joda.time.ReadableInstant) dateTime23);
//        boolean boolean25 = dateTime24.isEqualNow();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear(2);
        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
        java.util.Locale locale10 = null;
        try {
            org.joda.time.DateTime dateTime11 = property8.setCopy("20", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"20\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(2);
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(2);
        boolean boolean11 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime8);
        try {
            java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        int int11 = property9.getMaximumShortTextLength(locale10);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property9.getAsShortText(locale12);
//        int int14 = property9.getMaximumValueOverall();
//        org.joda.time.MonthDay monthDay16 = property9.addToCopy(17);
//        java.lang.String str17 = property9.getAsText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property9.getFieldType();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "15" + "'", str17.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            int int11 = unsupportedDateTimeField9.getMaximumValue((long) 1496);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        java.lang.String str14 = skipDateTimeField6.getAsShortText((long) 1970);
        int int15 = skipDateTimeField6.getMinimumValue();
        long long17 = skipDateTimeField6.roundFloor(0L);
        long long19 = skipDateTimeField6.roundHalfFloor((long) (byte) 0);
        java.util.Locale locale20 = null;
        int int21 = skipDateTimeField6.getMaximumShortTextLength(locale20);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Jan" + "'", str14.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(2);
//        org.joda.time.DateTime.Property property6 = dateTime3.millisOfDay();
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime3.toYearMonthDay();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) yearMonthDay7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        boolean boolean20 = monthDay13.isAfter((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
        int[] intArray30 = iSOChronology23.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(chronology32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay36 = monthDay33.withPeriodAdded(readablePeriod34, (int) (short) 100);
        int[] intArray38 = iSOChronology31.get((org.joda.time.ReadablePartial) monthDay36, 0L);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology31.minuteOfDay();
        org.joda.time.MonthDay monthDay40 = monthDay28.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTime dateTime41 = dateTime22.toDateTime((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTime.Property property42 = dateTime22.era();
        org.joda.time.DateTime dateTime44 = dateTime22.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        java.util.Locale locale49 = null;
        java.lang.String str50 = delegatedDateTimeField47.getAsShortText((int) (byte) 100, locale49);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField47.getType();
        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
        int int53 = monthDay13.indexOf(dateTimeFieldType51);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) (-28800000L), (java.lang.Number) 252806400000L, (java.lang.Number) 0.0d);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType51, (int) 'a', (int) '#', 292279024);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "100" + "'", str50.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        org.joda.time.DateTime dateTime10 = property4.addWrapFieldToCopy(10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329524057L + "'", long7 == 14329524057L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(22);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder5.setStandardOffset(1496);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019W161T202421.682Z", true);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("org.joda.time.IllegalFieldValueException: Value 0.0 for 2019W161T202414.069Z must be in the range [0.0,100]", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology0.hours();
        org.joda.time.DurationField durationField10 = iSOChronology0.weeks();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray14 = iSOChronology0.get(readablePeriod11, 0L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.getID();
        long long3 = dateTimeZone0.convertUTCToLocal((-61472476799900L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61472505177900L) + "'", long3 == (-61472505177900L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours((int) (short) 100);
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime8.toYearMonthDay();
        org.joda.time.DateTime.Property property12 = dateTime8.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime5.era();
        java.util.Locale locale12 = null;
        int int13 = property11.getMaximumTextLength(locale12);
        java.util.Locale locale14 = null;
        java.lang.String str15 = property11.getAsText(locale14);
        org.joda.time.DateTime dateTime16 = property11.withMinimumValue();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths(2);
        org.joda.time.DateTime.Property property21 = dateTime18.millisOfDay();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime18.withDurationAdded(readableDuration22, 100);
        org.joda.time.DateTime dateTime25 = dateTime18.withEarlierOffsetAtOverlap();
        boolean boolean26 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AD" + "'", str15.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        boolean boolean6 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay4.plus(readablePeriod7);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(monthDay8);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
//        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
//        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
//        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
//        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = dateTime20.plusMinutes(31);
//        int int25 = dateTime24.getYearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(chronology31);
//        org.joda.time.ReadablePeriod readablePeriod33 = null;
//        org.joda.time.MonthDay monthDay35 = monthDay32.withPeriodAdded(readablePeriod33, (int) (short) 100);
//        int[] intArray37 = iSOChronology30.get((org.joda.time.ReadablePartial) monthDay35, 0L);
//        gregorianChronology26.validate((org.joda.time.ReadablePartial) monthDay29, intArray37);
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology26.getZone();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone39);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((java.lang.Object) dateTime24, dateTimeZone39);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, 28857600001L, 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560630324844L + "'", long22 == 1560630324844L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 19 + "'", int25 == 19);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        int int40 = monthDay39.size();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.minus(readablePeriod48);
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) (byte) 100);
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        int int54 = monthDay39.indexOf(dateTimeFieldType53);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.monthOfYear();
        boolean boolean57 = monthDay39.equals((java.lang.Object) dateTimeField56);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292279024 + "'", int52 == 292279024);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((-292276974));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
//        org.joda.time.DurationField durationField10 = property4.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime dateTime14 = dateTime12.minus((long) 'a');
//        org.joda.time.DateTime.Property property15 = dateTime12.yearOfEra();
//        org.joda.time.DateTime dateTime16 = property15.roundFloorCopy();
//        org.joda.time.DateTime dateTime17 = property15.withMaximumValue();
//        int int18 = property4.getDifference((org.joda.time.ReadableInstant) dateTime17);
//        int int19 = property4.getLeapAmount();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329525230L + "'", long7 == 14329525230L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-292276974) + "'", int18 == (-292276974));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime.Property property27 = dateTime7.era();
        org.joda.time.DateTime dateTime29 = dateTime7.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsShortText((int) (byte) 100, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        boolean boolean37 = dateTime29.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType36, 31);
        long long41 = offsetDateTimeField39.roundHalfFloor((long) 100);
        int int43 = offsetDateTimeField39.getLeapAmount(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
        org.joda.time.ReadablePartial readablePartial45 = null;
        try {
            long long47 = copticChronology0.set(readablePartial45, (-62990291433387L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        boolean boolean7 = dateTime6.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime6.plusWeeks(2000);
        org.joda.time.DateTime dateTime11 = dateTime6.minusHours((int) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        int int6 = property4.get();
        org.joda.time.DateTime dateTime7 = property4.getDateTime();
        java.lang.String str8 = property4.getAsText();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (short) 100);
        int[] intArray18 = iSOChronology11.get((org.joda.time.ReadablePartial) monthDay16, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(chronology20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay24 = monthDay21.withPeriodAdded(readablePeriod22, (int) (short) 100);
        int[] intArray26 = iSOChronology19.get((org.joda.time.ReadablePartial) monthDay24, 0L);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology19.minuteOfDay();
        org.joda.time.MonthDay monthDay28 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTime dateTime29 = dateTime10.toDateTime((org.joda.time.Chronology) iSOChronology19);
        int int30 = dateTime29.getEra();
        long long31 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime29);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
        org.joda.time.MonthDay monthDay17 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.MonthDay monthDay19 = monthDay17.plusMonths((-1));
        int int20 = monthDay19.getMonthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.String str3 = dateTimeFormatter0.print((long) 222090);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31" + "'", str3.equals("1969-12-31"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.Integer int4 = dateTimeFormatter3.getPivotYear();
        java.lang.Appendable appendable5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minus((long) 'a');
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
        org.joda.time.DateTime dateTime12 = property10.withMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes(2019);
        org.joda.time.DateTime dateTime18 = dateTime14.minusMillis(20);
        int int19 = property10.compareTo((org.joda.time.ReadableInstant) dateTime14);
        try {
            dateTimeFormatter3.printTo(appendable5, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00" + "'", str2.equals("00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(int4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
        org.joda.time.MonthDay monthDay17 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, 31);
        org.joda.time.MonthDay.Property property21 = monthDay20.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        int int6 = fixedDateTimeZone4.getOffset((-2L));
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for 2019W161T202414.069Z must be in the range [0.0,100]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for 2019W161T202414.069Z must be in the range [0.0,100]"));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
//        long long6 = property5.remainder();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 745L + "'", long6 == 745L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.millisOfSecond();
        org.joda.time.DurationField durationField11 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        int int40 = monthDay39.size();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.minus(readablePeriod48);
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) (byte) 100);
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray51);
        long long55 = offsetDateTimeField37.add(14329457235L, 110L);
        int int58 = offsetDateTimeField37.getDifference((long) (short) 1, (long) 22);
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField37.getMaximumTextLength(locale59);
        int int62 = offsetDateTimeField37.getLeapAmount((long) 105);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292279024 + "'", int52 == 292279024);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3485881457235L + "'", long55 == 3485881457235L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399999);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(110L);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int12 = fixedDateTimeZone4.getOffset((long) 5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.get();
//        org.joda.time.DurationField durationField13 = property9.getRangeDurationField();
//        org.joda.time.MonthDay monthDay15 = property9.addWrapFieldToCopy((-292275053));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(monthDay15);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(2019);
        org.joda.time.DateTime dateTime5 = dateTime3.withEra((int) (byte) 0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 70);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        int int4 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology6 = gJChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime3.withZoneRetainFields(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-25200000) + "'", int4 == (-25200000));
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        int int10 = skipDateTimeField6.get((long) 2000);
        int int13 = skipDateTimeField6.getDifference((long) 28, (-62230291199980L));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 23664 + "'", int13 == 23664);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        int int22 = dateTime20.getYear();
        org.joda.time.DateTime dateTime24 = dateTime20.minusYears((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime26 = dateTime20.withHourOfDay((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        boolean boolean6 = dateTime3.isBeforeNow();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(chronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime3.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (byte) 1, 73519, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfSecond();
        boolean boolean2 = dateTime0.isEqualNow();
        org.joda.time.LocalTime localTime3 = dateTime0.toLocalTime();
        org.joda.time.DateTime dateTime6 = dateTime0.withDurationAdded((long) 15, 2000);
        org.joda.time.DateTime.Property property7 = dateTime0.monthOfYear();
        boolean boolean9 = dateTime0.isEqual(14329497816L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        int int4 = dateTime1.getSecondOfMinute();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gJChronology5.weeks();
//        boolean boolean7 = dateTime1.equals((java.lang.Object) gJChronology5);
//        java.util.GregorianCalendar gregorianCalendar8 = dateTime1.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 27 + "'", int4 == 27);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar8);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = buddhistChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.Chronology chronology6 = buddhistChronology3.withZone(dateTimeZone5);
//        org.joda.time.Chronology chronology7 = buddhistChronology3.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology9 = gJChronology8.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology3.withZone(dateTimeZone10);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
//        long long18 = dateTimeZone10.getMillisKeepLocal(dateTimeZone14, (long) (-25200000));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withZone(dateTimeZone14);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone14.getShortName(9059057595L, locale21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str4.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-25200000L) + "'", long18 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PST" + "'", str22.equals("PST"));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (short) 100);
        boolean boolean11 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay10);
        org.joda.time.MonthDay monthDay13 = monthDay10.minusDays(20);
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = monthDay13.getFields();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = monthDay18.isSupported(dateTimeFieldType19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay18.minus(readablePeriod21);
        int[] intArray24 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay22, (long) (byte) 100);
        java.util.Locale locale26 = null;
        java.lang.String str27 = monthDay22.toString("30", locale26);
        try {
            int int28 = unsupportedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "30" + "'", str27.equals("30"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019W161T202414.069Z" + "'", str7.equals("2019W161T202414.069Z"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 100 + "'", number9.equals((short) 100));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusYears(1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-292275053), 0, 3, (int) (byte) 1, 70, (int) (byte) 10, 55, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.append(dateTimePrinter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = offsetDateTimeField37.getAsText(readablePartial40, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        java.lang.Object obj8 = null;
        boolean boolean9 = property4.equals(obj8);
        org.joda.time.DateTime dateTime10 = property4.roundCeilingCopy();
        java.lang.String str11 = property4.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[yearOfEra]" + "'", str11.equals("Property[yearOfEra]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((int) (byte) 100, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType9, 1970, 2019, (int) (byte) 1);
        long long15 = offsetDateTimeField13.roundFloor((long) (short) 1);
        long long17 = offsetDateTimeField13.roundCeiling((long) (byte) 100);
        int int19 = offsetDateTimeField13.getLeapAmount(1574959772550L);
        long long21 = offsetDateTimeField13.roundCeiling((long) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 345600000L + "'", long17 == 345600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 345600000L + "'", long21 == 345600000L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        java.util.Locale locale17 = null;
        try {
            long long18 = unsupportedDateTimeField9.set(110L, "15", locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for 2019W161T202414.069Z must be in the range [0.0,100]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for 2019W161T202414.069Z must be in the range [0.0,100]"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((-292275023), (-292275023), (int) (byte) -1, 24, 31, (int) 'a', 49);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(12, 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 82 + "'", int2 == 82);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        org.joda.time.DateTime dateTime10 = property4.setCopy("22");
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329528879L + "'", long7 == 14329528879L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField9.getType();
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField9.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(chronology22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, (int) (short) 100);
        int[] intArray28 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay26, 0L);
        gregorianChronology17.validate((org.joda.time.ReadablePartial) monthDay20, intArray28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(chronology31);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.MonthDay monthDay35 = monthDay32.withPeriodAdded(readablePeriod33, (int) (short) 100);
        org.joda.time.MonthDay monthDay37 = monthDay35.plusDays(0);
        java.lang.String str38 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) monthDay35);
        int int39 = monthDay20.compareTo((org.joda.time.ReadablePartial) monthDay35);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.MonthDay monthDay41 = monthDay35.plus(readablePeriod40);
        java.util.Locale locale42 = null;
        try {
            java.lang.String str43 = unsupportedDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay35, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "����W���T������.000" + "'", str38.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(monthDay41);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = illegalFieldValueException12.getDateTimeFieldType();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019W161T202414.069Z" + "'", str7.equals("2019W161T202414.069Z"));
        org.junit.Assert.assertNull(dateTimeFieldType13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("-28800000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-28800000\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology10 = gJChronology9.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(2019);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis(20);
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime17);
        try {
            long long23 = limitChronology18.getDateTimeMillis(1, 0, 1496, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        try {
            long long16 = unsupportedDateTimeField9.roundFloor(97L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 'a');
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
        int int19 = property17.get();
        org.joda.time.DateTime dateTime20 = property17.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (-1));
        org.joda.time.DateTime dateTime24 = monthDay3.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.minusDays(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-80406950399945L), (java.lang.Number) 14329495605L, (java.lang.Number) 110L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (short) 100);
//        int[] intArray14 = iSOChronology7.get((org.joda.time.ReadablePartial) monthDay12, 0L);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology7.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
//        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(0);
//        java.lang.String str24 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay21);
//        org.joda.time.MonthDay.Property property25 = monthDay21.dayOfMonth();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = property25.getAsText(locale26);
//        int int28 = property25.get();
//        org.joda.time.MonthDay monthDay29 = property25.getMonthDay();
//        int int30 = property25.getMaximumValue();
//        java.lang.String str31 = property25.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property25.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType32);
//        org.joda.time.DateTime.Property property34 = dateTime6.property(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "����W���T������.000" + "'", str24.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "15" + "'", str27.equals("15"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 30 + "'", int30 == 30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Property[dayOfMonth]" + "'", str31.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(property34);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(24);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.minus(10L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.weekyears();
        boolean boolean5 = gregorianChronology1.equals((java.lang.Object) durationField4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
//        org.joda.time.DurationField durationField10 = property4.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime dateTime14 = dateTime12.minus((long) 'a');
//        org.joda.time.DateTime.Property property15 = dateTime12.yearOfEra();
//        org.joda.time.DateTime dateTime16 = property15.roundFloorCopy();
//        org.joda.time.DateTime dateTime17 = property15.withMaximumValue();
//        int int18 = property4.getDifference((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime19 = property4.getDateTime();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329529434L + "'", long7 == 14329529434L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-292276974) + "'", int18 == (-292276974));
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology16 = gJChronology15.withUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.Instant instant18 = gJChronology15.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology15.getZone();
        long long23 = dateTimeZone20.adjustOffset(31795200000L, false);
        long long27 = dateTimeZone20.convertLocalToUTC((long) 595, true, (long) 12);
        long long29 = dateTimeZone13.getMillisKeepLocal(dateTimeZone20, (long) (-25200000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31795200000L + "'", long23 == 31795200000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800595L + "'", long27 == 28800595L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-25200000L) + "'", long29 == (-25200000L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 2, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1970");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        int int4 = dateTime1.getYearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
//        org.joda.time.MonthDay monthDay16 = monthDay14.plusDays(0);
//        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay14);
//        org.joda.time.MonthDay.Property property18 = monthDay14.dayOfMonth();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property18.getAsText(locale19);
//        int int21 = property18.get();
//        org.joda.time.MonthDay monthDay22 = property18.getMonthDay();
//        int int23 = property18.getMaximumValue();
//        java.lang.String str24 = property18.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property18.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType25);
//        long long29 = zeroIsMaxDateTimeField26.add((-52887226021900L), (long) (byte) 100);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����W���T������.000" + "'", str17.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[dayOfMonth]" + "'", str24.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-52887220021900L) + "'", long29 == (-52887220021900L));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder2.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.Chronology chronology10 = dateTime8.getChronology();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withDayOfMonth(70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019W161T202414.069Z" + "'", str7.equals("2019W161T202414.069Z"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("20", "2019-09-28T16:49:32.115Z", 49, 0);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        int int13 = property9.getMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
//        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
//        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
//        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.MonthDay monthDay25 = property9.addWrapFieldToCopy(20);
//        try {
//            org.joda.time.MonthDay monthDay27 = property9.setCopy("");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(monthDay25);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        long long6 = dateTimeZone2.adjustOffset(14329460161L, false);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 14329460161L + "'", long6 == 14329460161L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfWeek(27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getShortName((long) 31, locale5);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((long) 8, locale4);
        org.joda.time.DurationField durationField6 = delegatedDateTimeField2.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970" + "'", str5.equals("1970"));
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
//        org.joda.time.DateTime.Property property6 = dateTime3.yearOfEra();
//        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) 1971);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime12 = dateTime10.minus((long) 'a');
//        org.joda.time.DateTime.Property property13 = dateTime10.yearOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundFloorCopy();
//        int int15 = property13.get();
//        org.joda.time.DateTime dateTime16 = property13.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (-1));
//        boolean boolean21 = dateTime16.isAfter((-252201597981L));
//        org.joda.time.DateTime dateTime23 = dateTime16.plusMonths((-292275023));
//        long long24 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime23);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019W161T202530.578Z" + "'", str5.equals("2019W161T202530.578Z"));
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24356251L + "'", long24 == 24356251L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology13.getZone();
        java.lang.String str16 = zonedChronology13.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str16.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        int int16 = dateTimeZone13.getOffsetFromLocal((long) (-292275053));
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        int int19 = dateTimeZone13.getOffsetFromLocal(1560630287597L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-25200000) + "'", int19 == (-25200000));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withDurationAdded(readableDuration5, 100);
        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(2);
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        java.util.Locale locale8 = null;
//        int int9 = property4.getMaximumShortTextLength(locale8);
//        org.joda.time.DateTime dateTime10 = property4.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property4.withMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329530862L + "'", long7 == 14329530862L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getCenturyOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(chronology13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, (int) (short) 100);
        int[] intArray19 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay17, 0L);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology12.minuteOfDay();
        org.joda.time.MonthDay monthDay21 = monthDay9.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime22 = dateTime3.toDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime.Property property23 = dateTime3.era();
        org.joda.time.DateTime dateTime25 = dateTime3.plusDays(2019);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime0, (org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology1.withZone(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (short) 100);
        int[] intArray24 = iSOChronology17.get((org.joda.time.ReadablePartial) monthDay22, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay30 = monthDay27.withPeriodAdded(readablePeriod28, (int) (short) 100);
        int[] intArray32 = iSOChronology25.get((org.joda.time.ReadablePartial) monthDay30, 0L);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology25.minuteOfDay();
        org.joda.time.MonthDay monthDay34 = monthDay22.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTime dateTime35 = dateTime16.toDateTime((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTime.Property property36 = dateTime16.era();
        org.joda.time.DateTime dateTime38 = dateTime16.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = delegatedDateTimeField41.getAsShortText((int) (byte) 100, locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = delegatedDateTimeField41.getType();
        boolean boolean46 = dateTime38.isSupported(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType45, 31);
        int int49 = offsetDateTimeField48.getOffset();
        boolean boolean51 = offsetDateTimeField48.isLeap((long) (short) 10);
        long long53 = offsetDateTimeField48.roundHalfEven((long) 595);
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField(chronology10, (org.joda.time.DateTimeField) offsetDateTimeField48);
        int int56 = offsetDateTimeField48.getLeapAmount((long) 70);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "100" + "'", str44.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 31 + "'", int49 == 31);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-259200000L) + "'", long53 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = unsupportedDateTimeField9.getAsText((-25200000), locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
//        org.joda.time.MonthDay monthDay16 = monthDay14.plusDays(0);
//        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay14);
//        org.joda.time.MonthDay.Property property18 = monthDay14.dayOfMonth();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property18.getAsText(locale19);
//        int int21 = property18.get();
//        org.joda.time.MonthDay monthDay22 = property18.getMonthDay();
//        int int23 = property18.getMaximumValue();
//        java.lang.String str24 = property18.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property18.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType25);
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        int int28 = zeroIsMaxDateTimeField26.getMinimumValue(readablePartial27);
//        long long31 = zeroIsMaxDateTimeField26.getDifferenceAsLong((long) ' ', 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����W���T������.000" + "'", str17.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[dayOfMonth]" + "'", str24.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        org.joda.time.DurationField durationField41 = offsetDateTimeField37.getRangeDurationField();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        boolean boolean45 = monthDay43.isSupported(dateTimeFieldType44);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((java.lang.Object) monthDay43);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 22, locale48);
        long long51 = offsetDateTimeField37.roundCeiling(140732657797L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "22" + "'", str49.equals("22"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 157593600000L + "'", long51 == 157593600000L);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
//        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) (short) 10);
//        java.lang.String str8 = dateTime3.toString();
//        org.joda.time.Instant instant9 = dateTime3.toInstant();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-04-15T20:25:31.862Z" + "'", str8.equals("2019-04-15T20:25:31.862Z"));
//        org.junit.Assert.assertNotNull(instant9);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField6.getAsText(readablePartial13, 1970, locale15);
        java.lang.String str17 = delegatedDateTimeField6.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[weekyear]" + "'", str17.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        gregorianChronology16.validate((org.joda.time.ReadablePartial) monthDay19, intArray27);
        int int29 = offsetDateTimeField14.getMaximumValue(readablePartial15, intArray27);
        int int31 = offsetDateTimeField14.getLeapAmount((long) (-25200000));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275011) + "'", int29 == (-292275011));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField12.getType();
        int int15 = skipUndoDateTimeField12.get(1970L);
        int int17 = skipUndoDateTimeField12.get(110L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1971 + "'", int15 == 1971);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1971 + "'", int17 == 1971);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) -1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (short) 100);
        boolean boolean11 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (short) 100);
        int[] intArray29 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay27, 0L);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology22.minuteOfDay();
        org.joda.time.MonthDay monthDay31 = monthDay19.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime.Property property33 = dateTime13.era();
        org.joda.time.DateTime dateTime35 = dateTime13.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField38.getAsShortText((int) (byte) 100, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField38.getType();
        boolean boolean43 = dateTime35.isSupported(dateTimeFieldType42);
        int int44 = monthDay4.indexOf(dateTimeFieldType42);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) (-28800000L), (java.lang.Number) 252806400000L, (java.lang.Number) 0.0d);
        java.lang.Number number49 = illegalFieldValueException48.getLowerBound();
        java.lang.Number number50 = illegalFieldValueException48.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "100" + "'", str41.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 252806400000L + "'", number49.equals(252806400000L));
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + (-28800000L) + "'", number50.equals((-28800000L)));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField11.getLeapDurationField();
        boolean boolean13 = delegatedDateTimeField11.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeField) skipDateTimeField14);
        int int18 = skipDateTimeField14.getDifference((long) 0, (long) '4');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay();
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) monthDay19, 0, locale21);
        int[] intArray24 = gJChronology0.get((org.joda.time.ReadablePartial) monthDay19, (long) 10);
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology0.getZone();
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(monthDay26);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        org.joda.time.DateTime dateTime23 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime dateTime24 = dateTime1.toDateTime();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        long long6 = delegatedDateTimeField2.set((long) 100, 12);
        int int8 = delegatedDateTimeField2.get(50400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61788182399900L) + "'", long6 == (-61788182399900L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        long long10 = delegatedDateTimeField2.getDifferenceAsLong((long) (-1), (long) 73515);
        long long12 = delegatedDateTimeField2.roundHalfFloor(110L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        boolean boolean41 = monthDay39.isSupported(dateTimeFieldType40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((java.lang.Object) monthDay39);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(30);
        org.joda.time.MonthDay monthDay46 = monthDay39.plusDays(2019);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 10, locale48);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray50 = monthDay46.getFieldTypes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray50);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        long long42 = offsetDateTimeField37.roundHalfEven((long) 595);
        long long44 = offsetDateTimeField37.roundHalfEven((long) 4);
        boolean boolean46 = offsetDateTimeField37.isLeap((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField37, dateTimeFieldType47, (int) (short) -1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-259200000L) + "'", long42 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200000L) + "'", long44 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime5.era();
        java.util.Locale locale12 = null;
        int int13 = property11.getMaximumTextLength(locale12);
        java.util.Locale locale15 = null;
        try {
            org.joda.time.DateTime dateTime16 = property11.setCopy("0", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology5 = gJChronology4.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        boolean boolean10 = delegatedDateTimeField8.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        int int12 = delegatedDateTimeField8.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = delegatedDateTimeField8.getMinimumValue(readablePartial13);
        boolean boolean15 = copticChronology1.equals((java.lang.Object) readablePartial13);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology1.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292278993 + "'", int12 == 292278993);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("100", (java.lang.Number) 86399999, (java.lang.Number) 14329524057L, (java.lang.Number) 157593600000L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
//        int int6 = property4.get();
//        org.joda.time.DateTime dateTime7 = property4.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (-1));
//        int int11 = dateTime7.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 25 + "'", int11 == 25);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        int int17 = unsupportedDateTimeField9.getDifference(1970L, 1555359865551L);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        boolean boolean21 = monthDay19.isSupported(dateTimeFieldType20);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((java.lang.Object) monthDay19);
        org.joda.time.MonthDay monthDay24 = monthDay19.minusMonths(30);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField28.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology30);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.MonthDay monthDay37 = monthDay34.withPeriodAdded(readablePeriod35, (int) (short) 100);
        int[] intArray39 = iSOChronology32.get((org.joda.time.ReadablePartial) monthDay37, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(chronology41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay45 = monthDay42.withPeriodAdded(readablePeriod43, (int) (short) 100);
        int[] intArray47 = iSOChronology40.get((org.joda.time.ReadablePartial) monthDay45, 0L);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology40.minuteOfDay();
        org.joda.time.MonthDay monthDay49 = monthDay37.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology40);
        org.joda.time.DateTime dateTime50 = dateTime31.toDateTime((org.joda.time.Chronology) iSOChronology40);
        org.joda.time.DateTime.Property property51 = dateTime31.era();
        org.joda.time.DateTime dateTime53 = dateTime31.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55);
        java.util.Locale locale58 = null;
        java.lang.String str59 = delegatedDateTimeField56.getAsShortText((int) (byte) 100, locale58);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = delegatedDateTimeField56.getType();
        boolean boolean61 = dateTime53.isSupported(dateTimeFieldType60);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField28, dateTimeFieldType60, 31);
        long long65 = offsetDateTimeField63.roundHalfFloor((long) 100);
        int int67 = offsetDateTimeField63.getLeapAmount(0L);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.MonthDay monthDay69 = new org.joda.time.MonthDay(chronology68);
        org.joda.time.ReadablePeriod readablePeriod70 = null;
        org.joda.time.MonthDay monthDay72 = monthDay69.withPeriodAdded(readablePeriod70, (int) (short) 100);
        boolean boolean73 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay72);
        int int74 = offsetDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) monthDay72);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField76 = gregorianChronology75.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.MonthDay monthDay78 = new org.joda.time.MonthDay(dateTimeZone77);
        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology80 = null;
        org.joda.time.MonthDay monthDay81 = new org.joda.time.MonthDay(chronology80);
        org.joda.time.ReadablePeriod readablePeriod82 = null;
        org.joda.time.MonthDay monthDay84 = monthDay81.withPeriodAdded(readablePeriod82, (int) (short) 100);
        int[] intArray86 = iSOChronology79.get((org.joda.time.ReadablePartial) monthDay84, 0L);
        gregorianChronology75.validate((org.joda.time.ReadablePartial) monthDay78, intArray86);
        org.joda.time.chrono.ISOChronology iSOChronology88 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology89 = null;
        org.joda.time.MonthDay monthDay90 = new org.joda.time.MonthDay(chronology89);
        org.joda.time.ReadablePeriod readablePeriod91 = null;
        org.joda.time.MonthDay monthDay93 = monthDay90.withPeriodAdded(readablePeriod91, (int) (short) 100);
        int[] intArray95 = iSOChronology88.get((org.joda.time.ReadablePartial) monthDay93, 0L);
        int int96 = offsetDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) monthDay78, intArray95);
        try {
            int[] intArray98 = unsupportedDateTimeField9.set((org.joda.time.ReadablePartial) monthDay19, 166, intArray95, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-49) + "'", int17 == (-49));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "100" + "'", str59.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-259200000L) + "'", long65 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292279024 + "'", int74 == 292279024);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(iSOChronology79);
        org.junit.Assert.assertNotNull(monthDay84);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(iSOChronology88);
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 292279024 + "'", int96 == 292279024);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((int) (byte) 100, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType9, 1970, 2019, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = offsetDateTimeField13.getDurationField();
        long long16 = offsetDateTimeField13.roundHalfFloor((long) 15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField13.getDurationField();
        try {
            long long20 = offsetDateTimeField13.set((long) ' ', "-292275054");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for weekyear must be in the range [2019,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        org.joda.time.DateTime dateTime23 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.DateTime dateTime26 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime23.plusMillis((int) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime.Property property27 = dateTime7.era();
        org.joda.time.DateTime dateTime29 = dateTime7.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsShortText((int) (byte) 100, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        boolean boolean37 = dateTime29.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType36, 31);
        long long41 = offsetDateTimeField39.roundHalfFloor((long) 100);
        int int43 = offsetDateTimeField39.getLeapAmount(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
        boolean boolean46 = skipDateTimeField44.isLeap((long) 1970);
        java.util.Locale locale47 = null;
        int int48 = skipDateTimeField44.getMaximumShortTextLength(locale47);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        java.lang.String str14 = unsupportedDateTimeField9.toString();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.minus((long) 'a');
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime20 = property19.roundFloorCopy();
        org.joda.time.DateTime dateTime21 = dateTime20.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        org.joda.time.Chronology chronology25 = dateTime23.getChronology();
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now(chronology25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        java.lang.String str30 = buddhistChronology29.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField32, (-1));
        long long36 = skipDateTimeField34.roundHalfFloor(0L);
        long long38 = skipDateTimeField34.roundHalfEven((long) 20);
        long long40 = skipDateTimeField34.roundHalfEven(0L);
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.MonthDay monthDay48 = monthDay45.withPeriodAdded(readablePeriod46, (int) (short) 100);
        int[] intArray50 = iSOChronology43.get((org.joda.time.ReadablePartial) monthDay48, 0L);
        int[] intArray52 = skipDateTimeField34.add((org.joda.time.ReadablePartial) monthDay41, 2, intArray50, 27);
        try {
            int[] intArray54 = unsupportedDateTimeField9.set((org.joda.time.ReadablePartial) monthDay26, 30, intArray50, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnsupportedDateTimeField" + "'", str14.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str30.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
//        int[] intArray16 = iSOChronology9.get((org.joda.time.ReadablePartial) monthDay14, 0L);
//        gregorianChronology5.validate((org.joda.time.ReadablePartial) monthDay8, intArray16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology5.getZone();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) 10, locale21);
//        org.joda.time.DateTime dateTime23 = dateTime3.toDateTime(dateTimeZone19);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime23.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-25200000) + "'", int4 == (-25200000));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
//        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property11 = dateTime5.era();
//        java.util.Locale locale12 = null;
//        int int13 = property11.getMaximumTextLength(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTime dateTime16 = property11.withMinimumValue();
//        int int17 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AD" + "'", str15.equals("AD"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 73534 + "'", int17 == 73534);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 'a');
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
        int int19 = property17.get();
        org.joda.time.DateTime dateTime20 = property17.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (-1));
        org.joda.time.DateTime dateTime24 = monthDay3.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = dateTime24.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(22);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addRecurringSavings("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", 12, 100, 70, '#', 2022, (-292275054), 30, false, 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(14329457235L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendYearOfCentury(49, 70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.plusMinutes(31);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime20.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 14329457235L + "'", long22 == 14329457235L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withSecondOfMinute(5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.yearOfCentury();
        try {
            long long7 = copticChronology0.getDateTimeMillis((-49), 24, (-292275053), 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusYears(1);
        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (short) 100);
        boolean boolean11 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (short) 100);
        int[] intArray29 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay27, 0L);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology22.minuteOfDay();
        org.joda.time.MonthDay monthDay31 = monthDay19.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime.Property property33 = dateTime13.era();
        org.joda.time.DateTime dateTime35 = dateTime13.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField38.getAsShortText((int) (byte) 100, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField38.getType();
        boolean boolean43 = dateTime35.isSupported(dateTimeFieldType42);
        int int44 = monthDay4.indexOf(dateTimeFieldType42);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) (-28800000L), (java.lang.Number) 252806400000L, (java.lang.Number) 0.0d);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "28");
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "100" + "'", str41.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsText(30, locale41);
        int int45 = offsetDateTimeField37.getDifference((long) 15, (long) 1971);
        boolean boolean47 = offsetDateTimeField37.isLeap((long) 23664);
        org.joda.time.DurationField durationField48 = offsetDateTimeField37.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "30" + "'", str42.equals("30"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.get();
        org.joda.time.MonthDay monthDay13 = property9.getMonthDay();
        java.lang.String str14 = property9.getName();
        java.lang.String str15 = property9.getName();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(chronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay20.withPeriodAdded(readablePeriod21, (int) (short) 100);
        int[] intArray25 = iSOChronology18.get((org.joda.time.ReadablePartial) monthDay23, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay31 = monthDay28.withPeriodAdded(readablePeriod29, (int) (short) 100);
        int[] intArray33 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology26.minuteOfDay();
        org.joda.time.MonthDay monthDay35 = monthDay23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTime dateTime36 = dateTime17.toDateTime((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTime.Property property37 = dateTime17.era();
        org.joda.time.DateTime dateTime39 = dateTime17.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField42.getAsShortText((int) (byte) 100, locale44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = delegatedDateTimeField42.getType();
        boolean boolean47 = dateTime39.isSupported(dateTimeFieldType46);
        int int48 = dateTime39.getMillisOfSecond();
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime39);
        int int50 = property9.compareTo((org.joda.time.ReadableInstant) dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "100" + "'", str45.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.yearOfEra();
        org.joda.time.DateTime.Property property7 = dateTime3.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970W163T202417.235Z" + "'", str5.equals("1970W163T202417.235Z"));
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 2022);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.weekyear();
        int int13 = dateTime7.get(dateTimeField12);
        int int14 = dateTime7.getYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        org.joda.time.MonthDay monthDay6 = monthDay4.minusMonths(1971);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(2);
        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths(2);
        boolean boolean17 = dateTime12.isEqual((org.joda.time.ReadableInstant) dateTime14);
        int int18 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTime.Property property19 = dateTime12.era();
        java.util.Locale locale20 = null;
        int int21 = property19.getMaximumTextLength(locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
        try {
            org.joda.time.MonthDay.Property property23 = monthDay6.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17 + "'", int18 == 17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DurationField durationField7 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTimeField dateTimeField9 = property4.getField();
        int int10 = property4.getMinimumValueOverall();
        org.joda.time.DateTime dateTime11 = property4.roundFloorCopy();
        int int12 = property4.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292278993 + "'", int12 == 292278993);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        int int10 = delegatedDateTimeField4.getDifference(0L, (long) 292279024);
        long long13 = delegatedDateTimeField4.add((-61788182399900L), (long) 10);
        long long16 = delegatedDateTimeField4.set(28658966613L, (int) '#');
        long long18 = delegatedDateTimeField4.remainder((long) (-1));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61472476799900L) + "'", long13 == (-61472476799900L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61033763433387L) + "'", long16 == (-61033763433387L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 259199999L + "'", long18 == 259199999L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        int int11 = dateTime5.getSecondOfMinute();
        org.joda.time.DateTime dateTime13 = dateTime5.plusMinutes(82);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 17 + "'", int11 == 17);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField12.getType();
        int int15 = skipUndoDateTimeField12.get(1970L);
        int int17 = skipUndoDateTimeField12.get((long) 57);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1971 + "'", int15 == 1971);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1971 + "'", int17 == 1971);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        try {
            long long8 = gJChronology0.getDateTimeMillis(100, (-292275054), 2, (-2548));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2548 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology16 = gJChronology15.withUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) monthDay18, 22, locale20);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "22" + "'", str21.equals("22"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
        boolean boolean6 = dateTime3.isBeforeNow();
        int int7 = dateTime3.getYearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970W163T202417.235Z" + "'", str5.equals("1970W163T202417.235Z"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.dayOfWeek();
        try {
            long long11 = gJChronology0.getDateTimeMillis((int) '#', 25, 6, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField9.getType();
        try {
            int int18 = unsupportedDateTimeField9.getMinimumValue((long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.minuteOfDay();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.Chronology chronology14 = julianChronology9.withZone(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime8.toMutableDateTime(dateTimeZone13);
        int int16 = mutableDateTime15.getDayOfYear();
        java.util.Date date17 = mutableDateTime15.toDate();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 166 + "'", int16 == 166);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("-292275054", 82, (-292275054), 31, '4', 20, (int) (short) -1, 292279024, false, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        int int17 = unsupportedDateTimeField9.getDifference(1970L, 1555359865551L);
        try {
            int int19 = unsupportedDateTimeField9.getLeapAmount((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-49) + "'", int17 == (-49));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, 100L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        java.lang.String str7 = property4.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[yearOfEra]" + "'", str7.equals("Property[yearOfEra]"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getCenturyOfEra();
        int int2 = dateTime0.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsShortText((int) (byte) 100, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        org.joda.time.DurationField durationField23 = delegatedDateTimeField22.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay31 = monthDay28.withPeriodAdded(readablePeriod29, (int) (short) 100);
        int[] intArray33 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(chronology35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay39 = monthDay36.withPeriodAdded(readablePeriod37, (int) (short) 100);
        int[] intArray41 = iSOChronology34.get((org.joda.time.ReadablePartial) monthDay39, 0L);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology34.minuteOfDay();
        org.joda.time.MonthDay monthDay43 = monthDay31.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTime dateTime44 = dateTime25.toDateTime((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTime.Property property45 = dateTime25.era();
        org.joda.time.DateTime dateTime47 = dateTime25.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField50.getAsShortText((int) (byte) 100, locale52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField50.getType();
        boolean boolean55 = dateTime47.isSupported(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField22, dateTimeFieldType54, 31);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay(chronology58);
        int int60 = monthDay59.size();
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology62);
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay(chronology64);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = null;
        boolean boolean67 = monthDay65.isSupported(dateTimeFieldType66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.MonthDay monthDay69 = monthDay65.minus(readablePeriod68);
        int[] intArray71 = iSOChronology62.get((org.joda.time.ReadablePartial) monthDay69, (long) (byte) 100);
        int int72 = offsetDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) monthDay59, intArray71);
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = null;
        int int74 = monthDay59.indexOf(dateTimeFieldType73);
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.MonthDay monthDay76 = new org.joda.time.MonthDay(chronology75);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.MonthDay monthDay79 = monthDay76.withPeriodAdded(readablePeriod77, (int) (short) 100);
        org.joda.time.MonthDay monthDay81 = monthDay79.plusDays(0);
        boolean boolean82 = monthDay59.isBefore((org.joda.time.ReadablePartial) monthDay79);
        int int83 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) monthDay59);
        java.util.Locale locale85 = null;
        java.lang.String str86 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) monthDay59, 24, locale85);
        long long89 = skipUndoDateTimeField12.addWrapField((-252201597981L), 86399999);
        long long91 = skipUndoDateTimeField12.roundCeiling((long) 292278993);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "100" + "'", str53.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292279024 + "'", int72 == 292279024);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(monthDay81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 292278993 + "'", int83 == 292278993);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "24" + "'", str86.equals("24"));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 2726520369148802019L + "'", long89 == 2726520369148802019L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 31795200000L + "'", long91 == 31795200000L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(20);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfEra(73519, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(1971);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        try {
            long long18 = zonedChronology13.getDateTimeMillis(222090, 73519, 70, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 73519 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("24");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.get();
        org.joda.time.MonthDay monthDay13 = property9.getMonthDay();
        java.lang.String str14 = property9.getName();
        java.lang.String str15 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property9.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.getMaximumValueOverall();
        int int13 = property9.getMaximumValue();
        int int14 = property9.get();
        java.lang.String str15 = property9.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[dayOfMonth]" + "'", str15.equals("Property[dayOfMonth]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((int) (byte) -1, 27, chronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
        org.joda.time.MonthDay monthDay17 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, 31);
        org.joda.time.MonthDay monthDay22 = monthDay17.minusMonths((-25200000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = julianChronology0.seconds();
        try {
            long long9 = julianChronology0.getDateTimeMillis(2019, 595, 57, 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 595 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.plusMinutes(31);
        boolean boolean25 = dateTime24.isEqualNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 14329457235L + "'", long22 == 14329457235L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        boolean boolean7 = dateTime3.isBefore(1561753456002L);
        try {
            org.joda.time.DateTime dateTime9 = dateTime3.withWeekOfWeekyear(73515);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 73515 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(1L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        gregorianChronology4.validate((org.joda.time.ReadablePartial) monthDay7, intArray15);
        boolean boolean17 = monthDay3.isAfter((org.joda.time.ReadablePartial) monthDay7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-25) + "'", int1 == (-25));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime7.toMutableDateTime(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(chronology13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, (int) (short) 100);
        int[] intArray19 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay17, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology20.minuteOfDay();
        org.joda.time.MonthDay monthDay29 = monthDay17.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTime dateTime30 = dateTime11.toDateTime((org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTime.Property property31 = dateTime11.era();
        org.joda.time.DateTime dateTime33 = dateTime11.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField36.getAsShortText((int) (byte) 100, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField36.getType();
        boolean boolean41 = dateTime33.isSupported(dateTimeFieldType40);
        int int42 = dateTime7.get(dateTimeFieldType40);
        org.joda.time.DurationFieldType durationFieldType43 = null;
        try {
            org.joda.time.DateTime dateTime45 = dateTime7.withFieldAdded(durationFieldType43, 23664);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "100" + "'", str39.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1970 + "'", int42 == 1970);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int5 = delegatedDateTimeField2.get(110L);
        long long7 = delegatedDateTimeField2.remainder(315446400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        int int10 = skipDateTimeField6.get((long) 2000);
        long long12 = skipDateTimeField6.remainder(745L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 745L + "'", long12 == 745L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        org.joda.time.MonthDay monthDay20 = monthDay18.plusDays(0);
        java.lang.String str21 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) monthDay18);
        int int22 = monthDay3.compareTo((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay18.plus(readablePeriod23);
        org.joda.time.DateTimeField[] dateTimeFieldArray25 = monthDay18.getFields();
        java.lang.String str27 = monthDay18.toString("73457595");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "����W���T������.000" + "'", str21.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(dateTimeFieldArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "73457595" + "'", str27.equals("73457595"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology1);
        long long8 = copticChronology1.getDateTimeMillis((int) (byte) 10, 6, (int) (short) 1, (int) (short) 100);
        java.lang.String str9 = copticChronology1.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-52887226021900L) + "'", long8 == (-52887226021900L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str9.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 'a');
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
        org.joda.time.DateTime dateTime19 = dateTime18.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime23 = dateTime18.minusDays((-1));
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology26 = gJChronology25.withUTC();
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology25.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone27);
        org.joda.time.Chronology chronology29 = copticChronology24.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime23.withZoneRetainFields(dateTimeZone27);
        int int32 = dateTimeZone27.getOffsetFromLocal(1560630287597L);
        org.joda.time.Chronology chronology33 = iSOChronology1.withZone(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-25200000) + "'", int32 == (-25200000));
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime3.minusWeeks(9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
        long long7 = property4.remainder();
        java.util.Locale locale8 = null;
        int int9 = property4.getMaximumShortTextLength(locale8);
        int int10 = property4.getMaximumValue();
        int int11 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329457235L + "'", long7 == 14329457235L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(20);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("24", "BuddhistChronology[America/Los_Angeles]", false, 2022, (-292275023));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology13.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str22 = fixedDateTimeZone20.getNameKey((long) 86399999);
        long long24 = dateTimeZone15.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, 1560751455662L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "15" + "'", str22.equals("15"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560726255631L + "'", long24 == 1560726255631L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        int int41 = offsetDateTimeField37.getOffset();
        org.joda.time.DurationField durationField42 = offsetDateTimeField37.getLeapDurationField();
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField37.getAsShortText(28, locale44);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "28" + "'", str45.equals("28"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withDate((-292276974), 55, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292276974 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField9.getDurationField();
        try {
            long long17 = unsupportedDateTimeField9.roundFloor(110L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.get();
        org.joda.time.MonthDay monthDay13 = property9.getMonthDay();
        int int14 = property9.getMaximumValue();
        java.lang.String str15 = property9.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths(2);
        org.joda.time.Instant instant20 = dateTime19.toInstant();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Instant instant23 = instant20.withDurationAdded(readableDuration21, (-1));
        boolean boolean24 = property9.equals((java.lang.Object) instant20);
        int int25 = property9.get();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 30 + "'", int14 == 30);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[dayOfMonth]" + "'", str15.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("00");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        org.joda.time.DateTime dateTime9 = property4.roundCeilingCopy();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DurationField durationField7 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        int int9 = property4.getLeapAmount();
        try {
            org.joda.time.DateTime dateTime11 = property4.addToCopy(14329457797L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 14329457797");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = dateTime1.getSecondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 73457 + "'", int6 == 73457);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField9.getType();
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField9.getLeapDurationField();
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField9.getAsShortText(27, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipDateTimeField9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsShortText(readablePartial39, (-292275054), locale41);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay47 = monthDay44.withPeriodAdded(readablePeriod45, (int) (short) 100);
        boolean boolean48 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay47);
        boolean boolean50 = monthDay47.equals((java.lang.Object) 10.0f);
        int int51 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay47);
        int int54 = offsetDateTimeField37.getDifference((long) 15, (long) 73534);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-292275054" + "'", str42.equals("-292275054"));
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-292275023) + "'", int51 == (-292275023));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay4.isSupported(dateTimeFieldType5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay4.minus(readablePeriod7);
        int[] intArray10 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay8, (long) (byte) 100);
        java.util.Locale locale12 = null;
        java.lang.String str13 = monthDay8.toString("30", locale12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (short) 100);
        int[] intArray29 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay27, 0L);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology22.minuteOfDay();
        org.joda.time.MonthDay monthDay31 = monthDay19.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.MonthDay monthDay33 = monthDay31.plusMonths((-1));
        boolean boolean34 = monthDay8.isAfter((org.joda.time.ReadablePartial) monthDay31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "30" + "'", str13.equals("30"));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("JulianChronology[UTC]");
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 595);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.Instant instant9 = dateTime5.toInstant();
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury(363);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 363 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (byte) 100, 105);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfMonth(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendDayOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.get();
        org.joda.time.MonthDay monthDay13 = property9.getMonthDay();
        int int14 = property9.getMaximumValue();
        java.lang.String str15 = property9.toString();
        org.joda.time.DurationField durationField16 = property9.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[dayOfMonth]" + "'", str15.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(57, 31, 2, 73519, 363, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 73519 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        long long10 = delegatedDateTimeField2.getDifferenceAsLong((long) (-1), (long) 73515);
        org.joda.time.DurationField durationField11 = delegatedDateTimeField2.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, 31, 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        org.joda.time.DateTime dateTime23 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay31 = monthDay28.withPeriodAdded(readablePeriod29, (int) (short) 100);
        int[] intArray33 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(chronology35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay39 = monthDay36.withPeriodAdded(readablePeriod37, (int) (short) 100);
        int[] intArray41 = iSOChronology34.get((org.joda.time.ReadablePartial) monthDay39, 0L);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology34.minuteOfDay();
        org.joda.time.MonthDay monthDay43 = monthDay31.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.MonthDay monthDay45 = monthDay43.plusMonths((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        int int47 = monthDay45.indexOf(dateTimeFieldType46);
        org.joda.time.DateTime dateTime48 = dateTime25.withFields((org.joda.time.ReadablePartial) monthDay45);
        int int49 = monthDay45.getMonthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 11 + "'", int49 == 11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology6 = gJChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(105, (int) 'a', 222090, 2022, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2022 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsText(30, locale41);
        int int45 = offsetDateTimeField37.getDifference((long) 15, (long) 1971);
        java.lang.String str46 = offsetDateTimeField37.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "30" + "'", str42.equals("30"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "weekyear" + "'", str46.equals("weekyear"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.plusMinutes(31);
        org.joda.time.DateTime.Property property25 = dateTime24.hourOfDay();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime(chronology26);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 595L + "'", long22 == 595L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(mutableDateTime27);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(20);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfYear((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        int int41 = offsetDateTimeField37.getLeapAmount(0L);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (short) 100);
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        int int49 = offsetDateTimeField37.getMaximumValue();
        int int52 = offsetDateTimeField37.getDifference(1L, (long) 'a');
        org.joda.time.DurationField durationField53 = offsetDateTimeField37.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279024 + "'", int48 == 292279024);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 292279024 + "'", int49 == 292279024);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(durationField53);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DurationField durationField7 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds(2000);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(2);
        org.joda.time.DateTime dateTime16 = dateTime14.minusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime18 = dateTime14.withDayOfYear((int) (short) 10);
        boolean boolean19 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField12.getType();
        java.lang.String str14 = skipUndoDateTimeField12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
        int[] intArray22 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay20, 0L);
        int int23 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay20);
        boolean boolean24 = skipUndoDateTimeField12.isLenient();
        org.joda.time.DateTimeField dateTimeField25 = skipUndoDateTimeField12.getWrappedField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[weekyear]" + "'", str14.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292278993 + "'", int23 == 292278993);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant4.withDurationAdded(readableDuration5, (-1));
        org.joda.time.DateTime dateTime8 = instant7.toDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withCenturyOfEra(10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.get();
        org.joda.time.DurationField durationField13 = property9.getRangeDurationField();
        java.lang.String str14 = property9.getName();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getShortName((long) 8, locale5);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.Chronology chronology4 = yearMonthDay3.getChronology();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        java.util.Locale locale42 = null;
        java.lang.String str43 = offsetDateTimeField37.getAsText(1440, locale42);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1440" + "'", str43.equals("1440"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.dayOfMonth();
        java.lang.String str5 = copticChronology1.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str5.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology13.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay29 = monthDay26.withPeriodAdded(readablePeriod27, (int) (short) 100);
        int[] intArray31 = iSOChronology24.get((org.joda.time.ReadablePartial) monthDay29, 0L);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology24.minuteOfDay();
        org.joda.time.MonthDay monthDay33 = monthDay21.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.MonthDay monthDay35 = monthDay33.plusMonths((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
        boolean boolean37 = monthDay33.isSupported(dateTimeFieldType36);
        boolean boolean38 = zonedChronology13.equals((java.lang.Object) dateTimeFieldType36);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        java.lang.String str9 = skipDateTimeField7.getAsText((long) 292279024);
        java.util.Locale locale10 = null;
        int int11 = skipDateTimeField7.getMaximumShortTextLength(locale10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970" + "'", str9.equals("1970"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withDayOfMonth((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfDay();
        boolean boolean8 = dateTime2.isAfter((long) 55);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        boolean boolean41 = monthDay39.isSupported(dateTimeFieldType40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((java.lang.Object) monthDay39);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(30);
        org.joda.time.MonthDay monthDay46 = monthDay39.plusDays(2019);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 10, locale48);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField37.getAsShortText((-28800000), locale51);
        boolean boolean53 = offsetDateTimeField37.isSupported();
        int int54 = offsetDateTimeField37.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-28800000" + "'", str52.equals("-28800000"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 31 + "'", int54 == 31);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.withDayOfMonth((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths(2);
        org.joda.time.DateTime dateTime21 = dateTime19.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMonths(2);
        boolean boolean26 = dateTime21.isEqual((org.joda.time.ReadableInstant) dateTime23);
        int int27 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property28 = dateTime21.era();
        java.util.Locale locale29 = null;
        int int30 = property28.getMaximumTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType31, 8);
        boolean boolean34 = dateTime7.isSupported(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.getMaximumValueOverall();
        int int13 = property9.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.MonthDay monthDay25 = property9.addWrapFieldToCopy(20);
        org.joda.time.MonthDay monthDay27 = property9.setCopy("15");
        java.lang.String str28 = property9.getName();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "dayOfMonth" + "'", str28.equals("dayOfMonth"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        int int11 = dateTime5.getSecondOfMinute();
        int int12 = dateTime5.getMinuteOfHour();
        org.joda.time.DateTime dateTime14 = dateTime5.plusHours(4);
        try {
            org.joda.time.DateTime dateTime16 = dateTime14.withDayOfWeek(24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("31");
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField6.getMaximumTextLength(locale13);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        int int4 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        long long7 = dateTimeZone2.getMillisKeepLocal(dateTimeZone5, (long) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.get();
        org.joda.time.MonthDay monthDay13 = property9.getMonthDay();
        int int14 = property9.getMaximumValue();
        int int15 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        int int39 = offsetDateTimeField37.getOffset();
        long long41 = offsetDateTimeField37.roundHalfFloor(14329524057L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int8 = skipDateTimeField6.get((long) 222090);
        int int9 = skipDateTimeField6.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (byte) 100, 105);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder5.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.getMaximumValueOverall();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property9.getAsShortText(locale13);
        try {
            org.joda.time.MonthDay monthDay16 = property9.setCopy("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[yearOfEra]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31" + "'", str14.equals("31"));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
//        int[] intArray16 = iSOChronology9.get((org.joda.time.ReadablePartial) monthDay14, 0L);
//        gregorianChronology5.validate((org.joda.time.ReadablePartial) monthDay8, intArray16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology5.getZone();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName((long) 10, locale21);
//        org.joda.time.DateTime dateTime23 = dateTime3.toDateTime(dateTimeZone19);
//        boolean boolean25 = dateTime23.isEqual(28658967459L);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime23.withPeriodAdded(readablePeriod26, 73457);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.Object obj3 = null;
        boolean boolean4 = gregorianChronology0.equals(obj3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (byte) 100, 105);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder5.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.String str5 = dateTime1.toString(dateTimeFormatter4);
        org.joda.time.Chronology chronology6 = dateTimeFormatter4.getChronolgy();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/1/70 12:00 AM" + "'", str5.equals("1/1/70 12:00 AM"));
        org.junit.Assert.assertNull(chronology6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.MonthDay monthDay9 = monthDay6.withDayOfMonth(28);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.Instant instant6 = dateTime5.toInstant();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology8.hourOfDay();
        org.joda.time.DurationField durationField18 = iSOChronology8.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology8.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology8.getZone();
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = dateTimeZone21.isLocalDateTimeGap(localDateTime22);
        org.joda.time.MutableDateTime mutableDateTime24 = instant6.toMutableDateTime(dateTimeZone21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(chronology28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, (int) (short) 100);
        int[] intArray34 = iSOChronology27.get((org.joda.time.ReadablePartial) monthDay32, 0L);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology27.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology27.hourOfDay();
        org.joda.time.DurationField durationField37 = iSOChronology27.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) iSOChronology27);
        int int40 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime39);
        long long42 = dateTimeZone21.convertUTCToLocal((-52887220021900L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-52887220021900L) + "'", long42 == (-52887220021900L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(595);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(2019);
        org.joda.time.DateTime dateTime12 = dateTime8.minusMillis(20);
        int int13 = property4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        org.joda.time.DurationField durationField23 = delegatedDateTimeField22.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay31 = monthDay28.withPeriodAdded(readablePeriod29, (int) (short) 100);
        int[] intArray33 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(chronology35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay39 = monthDay36.withPeriodAdded(readablePeriod37, (int) (short) 100);
        int[] intArray41 = iSOChronology34.get((org.joda.time.ReadablePartial) monthDay39, 0L);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology34.minuteOfDay();
        org.joda.time.MonthDay monthDay43 = monthDay31.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTime dateTime44 = dateTime25.toDateTime((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTime.Property property45 = dateTime25.era();
        org.joda.time.DateTime dateTime47 = dateTime25.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField50.getAsShortText((int) (byte) 100, locale52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField50.getType();
        boolean boolean55 = dateTime47.isSupported(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField22, dateTimeFieldType54, 31);
        int int58 = dateTime17.get(dateTimeFieldType54);
        int int59 = dateTime8.get(dateTimeFieldType54);
        java.lang.Class<?> wildcardClass60 = dateTime8.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "100" + "'", str53.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1969 + "'", int58 == 1969);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1970 + "'", int59 == 1970);
        org.junit.Assert.assertNotNull(wildcardClass60);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.joda.time.Instant instant4 = instant1.plus((long) 2000);
        org.joda.time.MutableDateTime mutableDateTime5 = instant4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        int int40 = monthDay39.size();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.minus(readablePeriod48);
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) (byte) 100);
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray51);
        long long55 = offsetDateTimeField37.add(14329457235L, 110L);
        int int58 = offsetDateTimeField37.getDifference((long) (short) 1, (long) 22);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = offsetDateTimeField37.getType();
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay(chronology60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.MonthDay monthDay64 = monthDay61.withPeriodAdded(readablePeriod62, (int) (short) 100);
        boolean boolean65 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay64);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay(chronology66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.MonthDay monthDay70 = monthDay67.withPeriodAdded(readablePeriod68, (int) (short) 100);
        boolean boolean71 = monthDay64.isAfter((org.joda.time.ReadablePartial) monthDay70);
        org.joda.time.MonthDay monthDay73 = monthDay70.minusDays(20);
        int int74 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay73);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292279024 + "'", int52 == 292279024);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3485881457235L + "'", long55 == 3485881457235L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292279024 + "'", int74 == 292279024);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (byte) 100, 105);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(chronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay20.withPeriodAdded(readablePeriod21, (int) (short) 100);
        int[] intArray25 = iSOChronology18.get((org.joda.time.ReadablePartial) monthDay23, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay31 = monthDay28.withPeriodAdded(readablePeriod29, (int) (short) 100);
        int[] intArray33 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology26.minuteOfDay();
        org.joda.time.MonthDay monthDay35 = monthDay23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTime dateTime36 = dateTime17.toDateTime((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTime.Property property37 = dateTime17.era();
        org.joda.time.DateTime dateTime39 = dateTime17.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField42.getAsShortText((int) (byte) 100, locale44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = delegatedDateTimeField42.getType();
        boolean boolean47 = dateTime39.isSupported(dateTimeFieldType46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField14, dateTimeFieldType46, 31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) 1560630255992L, (java.lang.Number) 1970L, (java.lang.Number) 14329458509L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType46, 70);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType46, 70, 1969, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for weekyear must be in the range [1969,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "100" + "'", str45.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.Chronology chronology6 = copticChronology1.withZone(dateTimeZone4);
        boolean boolean7 = buddhistChronology0.equals((java.lang.Object) dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime5.minusDays((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.plus((long) 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        try {
            int int12 = unsupportedDateTimeField9.getMaximumValue(1560630286785L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
        int[] intArray22 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay20, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
        int[] intArray30 = iSOChronology23.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology23.minuteOfDay();
        org.joda.time.MonthDay monthDay32 = monthDay20.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.MonthDay monthDay34 = monthDay32.plusMonths((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        boolean boolean36 = monthDay32.isSupported(dateTimeFieldType35);
        org.joda.time.MonthDay monthDay38 = monthDay32.plusMonths(0);
        try {
            int int39 = unsupportedDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(monthDay38);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField9.getType();
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField9.getAsText(1560630286785L, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        long long8 = gregorianChronology1.getDateTimeMillis(9, (int) (short) 1, 12, (int) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61882157221990L) + "'", long8 == (-61882157221990L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
        long long7 = property4.remainder();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
        org.joda.time.DurationField durationField10 = property4.getLeapDurationField();
        org.joda.time.Interval interval11 = property4.toInterval();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 595L + "'", long7 == 595L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(interval11);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(15);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder4.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.weekyear();
        int int13 = dateTime7.get(dateTimeField12);
        org.joda.time.DateTime.Property property14 = dateTime7.minuteOfHour();
        org.joda.time.Instant instant15 = new org.joda.time.Instant((java.lang.Object) dateTime7);
        org.joda.time.MutableDateTime mutableDateTime16 = instant15.toMutableDateTime();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        int int39 = offsetDateTimeField37.getOffset();
        long long41 = offsetDateTimeField37.roundCeiling((long) 22);
        try {
            long long44 = offsetDateTimeField37.add((long) 28, (-80406950399945L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -80406950399945");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 31795200000L + "'", long41 == 31795200000L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField9.getType();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
        int[] intArray20 = null;
        try {
            int[] intArray22 = unsupportedDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) monthDay18, (-25), intArray20, 23664);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundHalfEven((long) 292278993);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField2.getAsShortText(readablePartial5, 24, locale7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-259200000L) + "'", long4 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24" + "'", str8.equals("24"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = julianChronology0.weekyears();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minus((long) 'a');
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime12 = property10.addToCopy(0L);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        boolean boolean14 = julianChronology0.equals((java.lang.Object) property13);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        boolean boolean41 = monthDay39.isSupported(dateTimeFieldType40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((java.lang.Object) monthDay39);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(30);
        org.joda.time.MonthDay monthDay46 = monthDay39.plusDays(2019);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 10, locale48);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField37.getAsShortText((-28800000), locale51);
        int int54 = offsetDateTimeField37.get(2678400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-28800000" + "'", str52.equals("-28800000"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2001 + "'", int54 == 2001);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        org.joda.time.MonthDay monthDay20 = monthDay18.plusDays(0);
        java.lang.String str21 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) monthDay18);
        int int22 = monthDay3.compareTo((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay18.plus(readablePeriod23);
        int int25 = monthDay18.getMonthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "����W���T������.000" + "'", str21.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        boolean boolean41 = monthDay39.isSupported(dateTimeFieldType40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((java.lang.Object) monthDay39);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(30);
        org.joda.time.MonthDay monthDay46 = monthDay39.plusDays(2019);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 10, locale48);
        long long51 = offsetDateTimeField37.roundHalfEven(315705600031L);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.minus((long) 'a');
        org.joda.time.DateTime.Property property56 = dateTime53.yearOfEra();
        org.joda.time.DateTime dateTime57 = property56.roundFloorCopy();
        org.joda.time.TimeOfDay timeOfDay58 = dateTime57.toTimeOfDay();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology61 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone60);
        java.lang.String str62 = buddhistChronology61.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology61, dateTimeField64, (-1));
        long long68 = skipDateTimeField66.roundHalfFloor(0L);
        long long70 = skipDateTimeField66.roundHalfEven((long) 20);
        long long72 = skipDateTimeField66.roundHalfEven(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology76 = null;
        org.joda.time.MonthDay monthDay77 = new org.joda.time.MonthDay(chronology76);
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        org.joda.time.MonthDay monthDay80 = monthDay77.withPeriodAdded(readablePeriod78, (int) (short) 100);
        int[] intArray82 = iSOChronology75.get((org.joda.time.ReadablePartial) monthDay80, 0L);
        int[] intArray84 = skipDateTimeField66.add((org.joda.time.ReadablePartial) monthDay73, 2, intArray82, 27);
        java.util.Locale locale86 = null;
        try {
            int[] intArray87 = offsetDateTimeField37.set((org.joda.time.ReadablePartial) timeOfDay58, (int) (short) 100, intArray84, "1970W163T202417.235Z", locale86);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970W163T202417.235Z\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 315446400000L + "'", long51 == 315446400000L);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(timeOfDay58);
        org.junit.Assert.assertNotNull(buddhistChronology61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str62.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(iSOChronology75);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1970);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019-06-15", 31);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(chronology4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, (int) (short) 100);
        int[] intArray10 = iSOChronology3.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.hourOfDay();
        org.joda.time.DurationField durationField13 = iSOChronology3.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399999);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        java.lang.String str10 = fixedDateTimeZone4.getShortName((long) 15);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((-252201597981L));
        int int14 = fixedDateTimeZone4.getStandardOffset(1560630267123L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.031" + "'", str10.equals("+00:00:00.031"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        int int12 = unsupportedDateTimeField9.getDifference((long) 11, (long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendFractionOfHour((int) (short) -1, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (byte) 100, 105);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(1496);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "1970W013T160002.019-0800", 1, 30);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = buddhistChronology7.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField10, (-1));
        long long14 = skipDateTimeField12.roundHalfFloor(0L);
        long long16 = skipDateTimeField12.roundHalfEven((long) 20);
        long long18 = skipDateTimeField12.roundHalfEven(0L);
        long long21 = skipDateTimeField12.addWrapField((long) (byte) 1, (int) '#');
        int int22 = instant3.get((org.joda.time.DateTimeField) skipDateTimeField12);
        org.joda.time.DateTimeField dateTimeField23 = skipDateTimeField12.getWrappedField();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str8.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28857600001L + "'", long21 == 28857600001L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1440);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        org.joda.time.MonthDay monthDay16 = monthDay14.plusDays(0);
        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay.Property property18 = monthDay14.dayOfMonth();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        int int21 = property18.get();
        org.joda.time.MonthDay monthDay22 = property18.getMonthDay();
        int int23 = property18.getMaximumValue();
        java.lang.String str24 = property18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property18.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(chronology28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, (int) (short) 100);
        org.joda.time.MonthDay monthDay34 = monthDay32.plusDays(0);
        java.lang.String str35 = dateTimeFormatter27.print((org.joda.time.ReadablePartial) monthDay32);
        org.joda.time.MonthDay.Property property36 = monthDay32.dayOfMonth();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        int int39 = property36.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay41 = property36.addToCopy(292278993);
        org.joda.time.MonthDay monthDay43 = monthDay41.withDayOfMonth(1);
        int int44 = zeroIsMaxDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) monthDay41);
        int int46 = zeroIsMaxDateTimeField26.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����W���T������.000" + "'", str17.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[dayOfMonth]" + "'", str24.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "����W���T������.000" + "'", str35.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31" + "'", str38.equals("31"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1440 + "'", int44 == 1440);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1440 + "'", int46 == 1440);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsShortText(readablePartial39, (-292275054), locale41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField37.getType();
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField37.getAsShortText((-28800000), locale45);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-292275054" + "'", str42.equals("-292275054"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-28800000" + "'", str46.equals("-28800000"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(2);
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfDay();
        org.joda.time.Interval interval6 = property5.toInterval();
        int int7 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy(20);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.minuteOfDay();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology13 = gJChronology12.withUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology12.getZone();
        org.joda.time.Chronology chronology15 = julianChronology10.withZone(dateTimeZone14);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime9.toMutableDateTime(dateTimeZone14);
        int int17 = mutableDateTime16.getDayOfYear();
        int int20 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime16, "0", 25);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-26) + "'", int20 == (-26));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        int int41 = offsetDateTimeField37.getLeapAmount(0L);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (short) 100);
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        long long50 = offsetDateTimeField37.roundHalfFloor((long) 22);
        int int51 = offsetDateTimeField37.getMaximumValue();
        java.util.Locale locale52 = null;
        int int53 = offsetDateTimeField37.getMaximumShortTextLength(locale52);
        boolean boolean55 = offsetDateTimeField37.isLeap((-2L));
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField37.getAsShortText((-25200000), locale57);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279024 + "'", int48 == 292279024);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200000L) + "'", long50 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292279024 + "'", int51 == 292279024);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "-25200000" + "'", str58.equals("-25200000"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus(14329530862L);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.year();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int5 = delegatedDateTimeField2.get(110L);
        org.joda.time.DurationField durationField6 = delegatedDateTimeField2.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str16 = fixedDateTimeZone14.getNameKey((long) 86399999);
        int int18 = fixedDateTimeZone14.getStandardOffset((long) (short) 10);
        java.lang.String str20 = fixedDateTimeZone14.getShortName((long) 15);
        int int22 = fixedDateTimeZone14.getOffsetFromLocal((-252201597981L));
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime24 = dateTime8.toDateTime((org.joda.time.Chronology) julianChronology23);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "15" + "'", str16.equals("15"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.031" + "'", str20.equals("+00:00:00.031"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays(1);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(2019);
        int int4 = dateTime3.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
        long long7 = property4.remainder();
        int int8 = property4.get();
        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
        java.lang.String str10 = property4.getAsShortText();
        int int11 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1970L + "'", long7 == 1970L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
        org.joda.time.MonthDay monthDay17 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.MonthDay monthDay19 = monthDay17.plusMonths((-1));
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(chronology29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay33 = monthDay30.withPeriodAdded(readablePeriod31, (int) (short) 100);
        int[] intArray35 = iSOChronology28.get((org.joda.time.ReadablePartial) monthDay33, 0L);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology28.minuteOfDay();
        org.joda.time.MonthDay monthDay37 = monthDay25.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.MonthDay monthDay39 = monthDay37.plusMonths((-1));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(chronology41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay45 = monthDay42.withPeriodAdded(readablePeriod43, (int) (short) 100);
        org.joda.time.MonthDay monthDay47 = monthDay45.plusDays(0);
        java.lang.String str48 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) monthDay45);
        org.joda.time.MonthDay.Property property49 = monthDay45.dayOfMonth();
        java.util.Locale locale50 = null;
        java.lang.String str51 = property49.getAsText(locale50);
        int int52 = property49.getMaximumValueOverall();
        java.util.Locale locale53 = null;
        java.lang.String str54 = property49.getAsShortText(locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property49.getFieldType();
        int int56 = monthDay39.get(dateTimeFieldType55);
        try {
            org.joda.time.MonthDay monthDay58 = monthDay17.withField(dateTimeFieldType55, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "����W���T������.000" + "'", str48.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31" + "'", str51.equals("31"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31" + "'", str54.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 30 + "'", int56 == 30);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        org.joda.time.DurationField durationField9 = property4.getDurationField();
        java.lang.String str10 = property4.getAsShortText();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.DurationField durationField2 = copticChronology0.hours();
        org.joda.time.Chronology chronology3 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (byte) 100, 105);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendTwoDigitYear(0, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder3.addCutover(31, 'a', 17, 86399999, 73457, true, 73534);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime.Property property27 = dateTime7.era();
        org.joda.time.DateTime dateTime29 = dateTime7.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsShortText((int) (byte) 100, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        boolean boolean37 = dateTime29.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType36, 31);
        long long41 = offsetDateTimeField39.roundHalfFloor((long) 100);
        int int43 = offsetDateTimeField39.getLeapAmount(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        org.joda.time.MonthDay monthDay16 = monthDay14.plusDays(0);
        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay.Property property18 = monthDay14.dayOfMonth();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        int int21 = property18.get();
        org.joda.time.MonthDay monthDay22 = property18.getMonthDay();
        int int23 = property18.getMaximumValue();
        java.lang.String str24 = property18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property18.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = zeroIsMaxDateTimeField26.getMinimumValue(readablePartial27);
        boolean boolean30 = zeroIsMaxDateTimeField26.isLeap(1560630255992L);
        long long33 = zeroIsMaxDateTimeField26.add((long) 31, (long) 5);
        long long36 = zeroIsMaxDateTimeField26.add((long) (short) 100, 363);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����W���T������.000" + "'", str17.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[dayOfMonth]" + "'", str24.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 300031L + "'", long33 == 300031L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 21780100L + "'", long36 == 21780100L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 292278993);
        long long9 = delegatedDateTimeField4.add(0L, 8);
        boolean boolean10 = monthDay1.equals((java.lang.Object) delegatedDateTimeField4);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        long long17 = delegatedDateTimeField15.roundHalfEven((long) 292278993);
        long long20 = delegatedDateTimeField15.add(0L, 8);
        boolean boolean21 = monthDay12.equals((java.lang.Object) delegatedDateTimeField15);
        boolean boolean22 = monthDay1.isEqual((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        try {
            org.joda.time.MonthDay.Property property24 = monthDay1.property(dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-259200000L) + "'", long6 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 252806400000L + "'", long9 == 252806400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200000L) + "'", long17 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 252806400000L + "'", long20 == 252806400000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        int int12 = property9.getMaximumValueOverall();
        int int13 = property9.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
        java.util.Locale locale24 = null;
        int int25 = property9.getMaximumShortTextLength(locale24);
        org.joda.time.DurationField durationField26 = property9.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(22);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("1/1/70 12:00 AM", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019W161T202421.682Z", true);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("2019W161T202421.682Z", true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(97L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.LocalDateTime localDateTime2 = null;
        try {
            boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(2019);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0.0", "10");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipDateTimeField9);
        int int13 = skipDateTimeField9.getDifference((long) 0, (long) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (short) 100);
        int[] intArray29 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay27, 0L);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology22.minuteOfDay();
        org.joda.time.MonthDay monthDay31 = monthDay19.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.MonthDay monthDay33 = monthDay31.plusMonths((-1));
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay31, (int) (short) -1, locale35);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 10, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long6 = delegatedDateTimeField4.roundHalfEven((long) 292278993);
        long long9 = delegatedDateTimeField4.add(0L, 8);
        boolean boolean10 = monthDay1.equals((java.lang.Object) delegatedDateTimeField4);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = monthDay1.toString("Property[dayOfMonth]", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-259200000L) + "'", long6 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 252806400000L + "'", long9 == 252806400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        boolean boolean41 = monthDay39.isSupported(dateTimeFieldType40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((java.lang.Object) monthDay39);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(30);
        org.joda.time.MonthDay monthDay46 = monthDay39.plusDays(2019);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 10, locale48);
        long long51 = offsetDateTimeField37.roundHalfEven((-61472476799900L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61472736000000L) + "'", long51 == (-61472736000000L));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.shortTime();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withLocale(locale6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.append(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399999);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(110L);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str17 = fixedDateTimeZone15.getNameKey((long) 86399999);
        long long19 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, (long) (-292275011));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "15" + "'", str17.equals("15"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-292275011L) + "'", long19 == (-292275011L));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        org.joda.time.MonthDay monthDay16 = monthDay14.plusDays(0);
        java.lang.String str17 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay.Property property18 = monthDay14.dayOfMonth();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        int int21 = property18.get();
        org.joda.time.MonthDay monthDay22 = property18.getMonthDay();
        int int23 = property18.getMaximumValue();
        java.lang.String str24 = property18.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property18.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType25);
        long long29 = zeroIsMaxDateTimeField26.getDifferenceAsLong((long) (byte) 1, (long) (-49));
        int int31 = zeroIsMaxDateTimeField26.getLeapAmount((long) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����W���T������.000" + "'", str17.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[dayOfMonth]" + "'", str24.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long11 = skipDateTimeField6.getDifferenceAsLong((-28800000L), (long) 20);
        long long14 = skipDateTimeField6.getDifferenceAsLong((long) 10, 14329495605L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-5L) + "'", long14 == (-5L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        illegalFieldValueException4.prependMessage("CopticChronology[America/Los_Angeles]");
    }
}

