import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100, (java.lang.Number) 100L, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) (short) -1, (org.joda.time.Chronology) iSOChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 10, (int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '#', 0, (-1), (int) (short) 0, 1, (int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis((int) '4', (int) '4', (int) '#', (int) (short) 100, (int) '#', (int) (short) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gregorianChronology1.get(readablePeriod2, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        try {
            org.joda.time.DateTimeField dateTimeField6 = monthDay4.getField((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 32");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) (byte) 0, (int) (short) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, 0, 0, (int) '4', 0, 1, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        try {
//            int int7 = dateTime3.get(dateTimeFieldType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019W161T202412.339Z" + "'", str5.equals("2019W161T202412.339Z"));
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withTime((int) (short) -1, 100, 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
//        java.lang.StringBuffer stringBuffer6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(2);
//        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear((int) '#');
//        try {
//            dateTimeFormatter4.printTo(stringBuffer6, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019W161T202412.688Z" + "'", str5.equals("2019W161T202412.688Z"));
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) ' ', (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(2);
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.withDurationAdded(readableDuration6, 100);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(2);
        org.joda.time.DateTime dateTime14 = dateTime12.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime12.withDayOfYear((int) ' ');
        try {
            org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime8, (org.joda.time.ReadableDateTime) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        java.lang.String str5 = dateTime1.toString(dateTimeFormatter4);
//        java.lang.StringBuffer stringBuffer6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(chronology8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (short) 100);
//        int[] intArray14 = iSOChronology7.get((org.joda.time.ReadablePartial) monthDay12, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
//        int[] intArray22 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay20, 0L);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology15.minuteOfDay();
//        org.joda.time.MonthDay monthDay24 = monthDay12.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology15);
//        org.joda.time.MonthDay monthDay26 = monthDay24.plusMonths((-1));
//        try {
//            dateTimeFormatter4.printTo(stringBuffer6, (org.joda.time.ReadablePartial) monthDay24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6/15/19 8:24 PM" + "'", str5.equals("6/15/19 8:24 PM"));
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(monthDay26);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1, (java.lang.Number) 100L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            int int7 = monthDay4.get(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10, 2, (int) (short) 1, (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019W161T202414.069Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime5.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withDayOfMonth((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.weekyear();
        int int13 = dateTime7.get(dateTimeField12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime7.withHourOfDay((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = monthDay1.toString("2019W161T202410.781Z", locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        boolean boolean7 = dateTime6.isEqualNow();
        org.joda.time.DateTime dateTime9 = dateTime6.plusWeeks(2000);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withField(dateTimeFieldType10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W013T160002.019-0800" + "'", str2.equals("1970W013T160002.019-0800"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(2019);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
//        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology4.minuteOfDay();
//        int int13 = dateTime3.get(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 363 + "'", int13 == 363);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, 2000, 363, 363);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("6/15/19 8:24 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 6/15/19 8:24 PM");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 9, (java.lang.Number) (byte) 100, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        try {
            long long13 = durationField10.subtract(0L, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = monthDay1.isSupported(dateTimeFieldType2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) monthDay1);
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int int6 = monthDay4.compareTo(readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (int) '4', (int) (short) 1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = monthDay3.isSupported(dateTimeFieldType4);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
        java.lang.String str7 = property4.getAsShortText();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.DateTime.Property property23 = dateTime21.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        int int3 = dateTimeFormatter0.getDefaultYear();
        java.lang.Appendable appendable4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(2019);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMillis(20);
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("6/15/19 8:24 PM", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"6/15/19 8:24 PM/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        long long11 = iSOChronology0.add((long) (byte) 10, 10L, (int) (short) 10);
        try {
            long long19 = iSOChronology0.getDateTimeMillis((int) (byte) -1, (int) (short) 0, (int) (short) 0, (-1), (int) ' ', 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 110L + "'", long11 == 110L);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        org.joda.time.DateTime dateTime9 = property4.roundHalfFloorCopy();
//        java.util.Locale locale11 = null;
//        try {
//            java.lang.String str12 = dateTime9.toString("6/15/19 8:24 PM", locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329459507L + "'", long7 == 14329459507L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        try {
            long long11 = skipDateTimeField6.set((long) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 1, (int) (byte) 1, (int) (short) -1, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2019, 110L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 222090 + "'", int2 == 222090);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        boolean boolean4 = dateTime3.isEqualNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, readableInstant8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType3, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime5.era();
        try {
            org.joda.time.DateTime dateTime13 = property11.addToCopy((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withFieldAdded(durationFieldType2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '#', (int) 'a', (int) (short) -1, (-1), 100, (int) (byte) 1, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) 'a', locale4);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        int int7 = dateTime5.getDayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(2019, 0, 8, 9, 100, (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(0, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withDurationAdded(readableDuration5, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime.Property property9 = dateTime1.property(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        int int9 = monthDay8.size();
        try {
            boolean boolean10 = localDate6.isBefore((org.joda.time.ReadablePartial) monthDay8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField9, durationFieldType10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withWeekOfWeekyear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10L, (java.lang.Number) 20, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[America/Los_A...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DurationField durationField8 = iSOChronology0.eras();
        try {
            long long11 = durationField8.subtract(14329457235L, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560630255992L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560630256002L + "'", long2 == 1560630256002L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (short) 100);
        int[] intArray14 = iSOChronology7.get((org.joda.time.ReadablePartial) monthDay12, 0L);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology7.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology7.hourOfDay();
        org.joda.time.DurationField durationField17 = iSOChronology7.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) iSOChronology7);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(363, 2019, 0, 1, 0, 0, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(chronology4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, (int) (short) 100);
        int[] intArray10 = iSOChronology3.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(chronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (short) 100);
        int[] intArray18 = iSOChronology11.get((org.joda.time.ReadablePartial) monthDay16, 0L);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology11.minuteOfDay();
        org.joda.time.MonthDay monthDay20 = monthDay8.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTime dateTime21 = dateTime2.toDateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTime.Property property22 = dateTime2.era();
        org.joda.time.DateTime dateTime24 = dateTime2.withMillisOfDay((int) 'a');
        try {
            java.lang.String str25 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.MonthDay monthDay25 = monthDay23.plusMonths((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = monthDay25.indexOf(dateTimeFieldType26);
        try {
            int int28 = yearMonthDay5.compareTo((org.joda.time.ReadablePartial) monthDay25);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
//        boolean boolean6 = dateTimeFormatter4.isOffsetParsed();
//        java.lang.Appendable appendable7 = null;
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology9.getZone();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology9);
//        try {
//            dateTimeFormatter4.printTo(appendable7, (org.joda.time.ReadableInstant) dateTime11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019W161T202422.216Z" + "'", str5.equals("2019W161T202422.216Z"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = buddhistChronology0.get(readablePeriod1, (long) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-1), 2, (int) (byte) -1, (int) (byte) -1, (int) (byte) 10, (int) (short) 1, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology6 = gJChronology5.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getShortName((long) 'a', locale9);
//        try {
//            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(363, (int) (byte) 1, (int) ' ', 12, (int) (byte) -1, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField3.getAsShortText((int) (byte) 100, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField3.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        org.joda.time.DateTime dateTime23 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.DateTime.Property property26 = dateTime25.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) 'a', locale4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
//        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
//        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
//        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime dateTime27 = dateTime26.withEarlierOffsetAtOverlap();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime26, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) 'a', locale4);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-25200000), 222090);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 222090");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(14329460161L, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1432946016100");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant4.withDurationAdded(readableDuration5, (-1));
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant4.minus(readableDuration8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        int[] intArray16 = iSOChronology9.get((org.joda.time.ReadablePartial) monthDay14, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (short) 100);
        int[] intArray24 = iSOChronology17.get((org.joda.time.ReadablePartial) monthDay22, 0L);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology17.minuteOfDay();
        org.joda.time.MonthDay monthDay26 = monthDay14.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.MonthDay monthDay28 = monthDay26.plusMonths((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        boolean boolean30 = monthDay26.isSupported(dateTimeFieldType29);
        int[] intArray32 = null;
        try {
            int[] intArray34 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) monthDay26, 0, intArray32, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        boolean boolean7 = monthDay4.equals((java.lang.Object) 10.0f);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withChronologyRetainFields(chronology8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.MonthDay monthDay12 = monthDay4.withFieldAdded(durationFieldType10, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 0, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        int int8 = delegatedDateTimeField4.getMaximumValue();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsText((long) (byte) 100, locale10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("2019W161T202414.069Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019W161T202414.069Z\" is malformed at \"19W161T202414.069Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2, 86399999, 292278993, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (short) 100);
        int[] intArray12 = iSOChronology5.get((org.joda.time.ReadablePartial) monthDay10, 0L);
        gregorianChronology1.validate((org.joda.time.ReadablePartial) monthDay4, intArray12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        org.joda.time.MonthDay monthDay21 = monthDay19.plusDays(0);
        java.lang.String str22 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) monthDay19);
        int int23 = monthDay4.compareTo((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField26.getAsShortText((int) (byte) 100, locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField26.getType();
        boolean boolean31 = monthDay4.isSupported(dateTimeFieldType30);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "����W���T������.000" + "'", str22.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 0, 22, 31, 292278993, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((-25200000));
        java.lang.Appendable appendable4 = null;
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        int int12 = skipDateTimeField6.get(14329460161L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField9, durationFieldType10, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(2019, 2000, (int) (byte) 100, (int) (byte) 1, (int) (byte) 1, 4, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.months();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int5 = dateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(14329464380L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 14329464380");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1555359865551L + "'", long6 == 1555359865551L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology2 = gJChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone3);
        int int6 = copticChronology0.getMinimumDaysInFirstWeek();
        try {
            long long14 = copticChronology0.getDateTimeMillis((int) (short) -1, (-25200000), 2, (int) (byte) -1, 222090, (int) (short) 0, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        int int6 = dateTime5.getYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("2019W161T202410.781Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019W161T202410.781Z\" is malformed at \"W161T202410.781Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        long long15 = skipDateTimeField6.add((long) 31, 0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31L + "'", long15 == 31L);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        java.lang.String str9 = property4.getName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
//        org.joda.time.MonthDay monthDay17 = monthDay15.plusDays(0);
//        java.lang.String str18 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) monthDay15);
//        boolean boolean19 = property4.equals((java.lang.Object) dateTimeFormatter10);
//        try {
//            org.joda.time.DateTime dateTime21 = property4.setCopy((-25200000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329466461L + "'", long7 == 14329466461L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "����W���T������.000" + "'", str18.equals("����W���T������.000"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: PST");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        int int13 = property9.getMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
//        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
//        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
//        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        java.util.Locale locale25 = null;
//        try {
//            org.joda.time.MonthDay monthDay26 = property9.setCopy("2019W161T202410.781Z", locale25);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019W161T202410.781Z\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = buddhistChronology1.get(readablePeriod5, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("15");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = buddhistChronology7.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField10, (-1));
        java.lang.String str13 = buddhistChronology7.toString();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(8, (int) (byte) 0, 222090, (int) (short) -1, 86399999, 2000, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str8.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str13.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        boolean boolean12 = skipDateTimeField6.isLeap((long) 9);
        int int14 = skipDateTimeField6.getMinimumValue((long) 8);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(14329457595L);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getShortName((long) 'a', locale4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
//        org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTime.Property property12 = dateTime9.weekyear();
//        int int13 = dateTime9.getHourOfDay();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime9, 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone13);
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = skipDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay14, (int) '4', locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.String str7 = dateTime5.toString(dateTimeFormatter6);
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        int[] intArray16 = iSOChronology9.get((org.joda.time.ReadablePartial) monthDay14, 0L);
        try {
            iSOChronology0.validate((org.joda.time.ReadablePartial) localDate8, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970W163T202417.595Z" + "'", str7.equals("1970W163T202417.595Z"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.DateTime dateTime5 = instant4.toDateTimeISO();
        int int6 = dateTime5.getDayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 105 + "'", int6 == 105);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
        long long7 = property4.remainder();
        int int8 = property4.get();
        java.lang.String str9 = property4.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        org.joda.time.MonthDay monthDay17 = monthDay15.plusDays(0);
        java.lang.String str18 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) monthDay15);
        boolean boolean19 = property4.equals((java.lang.Object) dateTimeFormatter10);
        java.lang.String str20 = property4.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14329457595L + "'", long7 == 14329457595L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "����W���T������.000" + "'", str18.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Property[yearOfEra]" + "'", str20.equals("Property[yearOfEra]"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) -1, (int) ' ', 4, 0, 15, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter2.parseDateTime("6/15/19 8:24 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6/15/19 8:24 PM\" is malformed at \"/15/19 8:24 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter1.parseDateTime("6/15/19 8:24 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6/15/19 8:24 PM\" is malformed at \"/15/19 8:24 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths((int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(14329457797L);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) monthDay9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 'a');
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
        int int19 = property17.get();
        org.joda.time.DateTime dateTime20 = property17.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (-1));
        org.joda.time.DateTime dateTime24 = monthDay3.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        boolean boolean27 = dateTime24.isBefore((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.DateTime dateTime4 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant3.withDurationAdded(readableDuration5, 292279024);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long8 = julianChronology0.getDateTimeMillis(292278993, (int) '#', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for year must be in the range [-292269054,292272992]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(chronology41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay45 = monthDay42.withPeriodAdded(readablePeriod43, (int) (short) 100);
        org.joda.time.MonthDay monthDay47 = monthDay45.plusDays(0);
        java.lang.String str48 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) monthDay45);
        org.joda.time.MonthDay.Property property49 = monthDay45.dayOfMonth();
        java.util.Locale locale50 = null;
        java.lang.String str51 = property49.getAsText(locale50);
        int int52 = property49.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay54 = property49.addToCopy(292278993);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay(dateTimeZone57);
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay(chronology60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.MonthDay monthDay64 = monthDay61.withPeriodAdded(readablePeriod62, (int) (short) 100);
        int[] intArray66 = iSOChronology59.get((org.joda.time.ReadablePartial) monthDay64, 0L);
        gregorianChronology55.validate((org.joda.time.ReadablePartial) monthDay58, intArray66);
        int int68 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray66);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "����W���T������.000" + "'", str48.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "15" + "'", str51.equals("15"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-292275023) + "'", int68 == (-292275023));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime26 = dateTime20.withTime(1, (-1), (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        int int7 = delegatedDateTimeField2.get(1561753456002L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        boolean boolean22 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        boolean boolean4 = instant1.isBefore((long) (byte) -1);
        boolean boolean5 = instant1.isBeforeNow();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField11.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
        int[] intArray22 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay20, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
        int[] intArray30 = iSOChronology23.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology23.minuteOfDay();
        org.joda.time.MonthDay monthDay32 = monthDay20.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTime dateTime33 = dateTime14.toDateTime((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTime.Property property34 = dateTime14.era();
        org.joda.time.DateTime dateTime36 = dateTime14.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField39.getAsShortText((int) (byte) 100, locale41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = delegatedDateTimeField39.getType();
        boolean boolean44 = dateTime36.isSupported(dateTimeFieldType43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11, dateTimeFieldType43, 31);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(chronology47);
        int int49 = monthDay48.size();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology51);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay(chronology53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = null;
        boolean boolean56 = monthDay54.isSupported(dateTimeFieldType55);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.MonthDay monthDay58 = monthDay54.minus(readablePeriod57);
        int[] intArray60 = iSOChronology51.get((org.joda.time.ReadablePartial) monthDay58, (long) (byte) 100);
        int int61 = offsetDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) monthDay48, intArray60);
        try {
            int[] intArray63 = skipDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) monthDay7, (-25200000), intArray60, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -25200000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "100" + "'", str42.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 292279024 + "'", int61 == 292279024);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
        try {
            long long13 = gJChronology6.getDateTimeMillis((int) '4', 0, 2, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant4.withDurationAdded(readableDuration5, (-1));
        long long8 = instant4.getMillis();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        boolean boolean11 = instant4.isEqual((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9059057595L + "'", long8 == 9059057595L);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (short) 100);
        int[] intArray12 = iSOChronology5.get((org.joda.time.ReadablePartial) monthDay10, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        int[] intArray20 = iSOChronology13.get((org.joda.time.ReadablePartial) monthDay18, 0L);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology13.minuteOfDay();
        org.joda.time.MonthDay monthDay22 = monthDay10.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime23 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime.Property property24 = dateTime4.era();
        org.joda.time.DateTime dateTime26 = dateTime4.withMillisOfDay((int) 'a');
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime28 = dateTime4.plus(readableDuration27);
        try {
            dateTimeFormatter1.printTo(writer2, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withDurationAdded(readableDuration5, 100);
        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes((int) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        int int41 = offsetDateTimeField37.getLeapAmount(0L);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (short) 100);
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        int int49 = offsetDateTimeField37.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology50);
        org.joda.time.DateTime dateTime53 = dateTime51.minus((long) 'a');
        org.joda.time.DateTime.Property property54 = dateTime51.yearOfEra();
        org.joda.time.DateTime dateTime56 = property54.addToCopy((long) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay57 = dateTime56.toYearMonthDay();
        org.joda.time.Chronology chronology58 = yearMonthDay57.getChronology();
        java.util.Locale locale59 = null;
        try {
            java.lang.String str60 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) yearMonthDay57, locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279024 + "'", int48 == 292279024);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 292279024 + "'", int49 == 292279024);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(yearMonthDay57);
        org.junit.Assert.assertNotNull(chronology58);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        int int11 = dateTime5.getSecondOfMinute();
        int int12 = dateTime5.getMillisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 17 + "'", int11 == 17);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 595 + "'", int12 == 595);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        try {
            long long13 = buddhistChronology1.getDateTimeMillis((int) (byte) 100, (int) (short) 100, 292278993, (int) '#', 1970, (int) (short) -1, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        int int7 = dateTime5.getYearOfEra();
        int int8 = dateTime5.getHourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        java.lang.String str7 = property4.getAsText();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "73457595" + "'", str7.equals("73457595"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        org.joda.time.MonthDay monthDay17 = monthDay15.plusDays(0);
        java.lang.String str18 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        boolean boolean26 = monthDay24.isSupported(dateTimeFieldType25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay28 = monthDay24.minus(readablePeriod27);
        int[] intArray30 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay28, (long) (byte) 100);
        try {
            int[] intArray32 = unsupportedDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) monthDay15, (int) (byte) 1, intArray30, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "����W���T������.000" + "'", str18.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = gJChronology0.get(readablePeriod1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            long long11 = unsupportedDateTimeField9.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withFieldAdded(durationFieldType8, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        long long12 = durationField8.subtract((long) 2019, (long) 8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-252201597981L) + "'", long12 == (-252201597981L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            long long11 = unsupportedDateTimeField9.remainder((long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.remainder((long) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology41);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        boolean boolean46 = monthDay44.isSupported(dateTimeFieldType45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.MonthDay monthDay48 = monthDay44.minus(readablePeriod47);
        int[] intArray50 = iSOChronology41.get((org.joda.time.ReadablePartial) monthDay48, (long) (byte) 100);
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay48, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 259200032L + "'", long39 == 259200032L);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            int int11 = unsupportedDateTimeField9.getMinimumValue((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((int) (byte) 100, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType9, 1970, 2019, (int) (byte) 1);
        long long15 = offsetDateTimeField13.roundFloor((long) (short) 1);
        long long17 = offsetDateTimeField13.roundCeiling((long) (byte) 100);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        boolean boolean21 = monthDay19.isSupported(dateTimeFieldType20);
        int[] intArray25 = new int[] { (short) 1, 292279024 };
        java.util.Locale locale27 = null;
        try {
            int[] intArray28 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay19, 292278993, intArray25, "", locale27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 345600000L + "'", long17 == 345600000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        boolean boolean7 = monthDay4.equals((java.lang.Object) 10.0f);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withChronologyRetainFields(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            boolean boolean11 = unsupportedDateTimeField9.isLeap(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(chronology39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.MonthDay monthDay43 = monthDay40.withPeriodAdded(readablePeriod41, (int) (short) 100);
        org.joda.time.MonthDay monthDay45 = monthDay43.plusDays(0);
        java.lang.String str46 = dateTimeFormatter38.print((org.joda.time.ReadablePartial) monthDay43);
        org.joda.time.MonthDay.Property property47 = monthDay43.dayOfMonth();
        java.util.Locale locale48 = null;
        java.lang.String str49 = property47.getAsText(locale48);
        int int50 = property47.getMaximumValueOverall();
        int int51 = property47.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.minusMonths(2);
        org.joda.time.DateTime dateTime57 = dateTime55.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime59 = dateTime55.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property60 = dateTime55.dayOfYear();
        int int61 = property47.compareTo((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.MonthDay monthDay63 = property47.addWrapFieldToCopy(20);
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay(chronology66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.MonthDay monthDay70 = monthDay67.withPeriodAdded(readablePeriod68, (int) (short) 100);
        int[] intArray72 = iSOChronology65.get((org.joda.time.ReadablePartial) monthDay70, 0L);
        try {
            int[] intArray74 = offsetDateTimeField37.set((org.joda.time.ReadablePartial) monthDay63, 12, intArray72, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "����W���T������.000" + "'", str46.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "15" + "'", str49.equals("15"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 30 + "'", int51 == 30);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("6/15/19 8:24 PM", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6/15/19 8:24 PM\" is malformed at \"/15/19 8:24 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("30");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
        boolean boolean21 = monthDay14.isAfter((org.joda.time.ReadablePartial) monthDay20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay29 = monthDay26.withPeriodAdded(readablePeriod27, (int) (short) 100);
        int[] intArray31 = iSOChronology24.get((org.joda.time.ReadablePartial) monthDay29, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(chronology33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.MonthDay monthDay37 = monthDay34.withPeriodAdded(readablePeriod35, (int) (short) 100);
        int[] intArray39 = iSOChronology32.get((org.joda.time.ReadablePartial) monthDay37, 0L);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology32.minuteOfDay();
        org.joda.time.MonthDay monthDay41 = monthDay29.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTime dateTime42 = dateTime23.toDateTime((org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTime.Property property43 = dateTime23.era();
        org.joda.time.DateTime dateTime45 = dateTime23.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47);
        java.util.Locale locale50 = null;
        java.lang.String str51 = delegatedDateTimeField48.getAsShortText((int) (byte) 100, locale50);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField48.getType();
        boolean boolean53 = dateTime45.isSupported(dateTimeFieldType52);
        int int54 = monthDay14.indexOf(dateTimeFieldType52);
        org.joda.time.MonthDay.Property property55 = monthDay14.monthOfYear();
        try {
            int int56 = unsupportedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "100" + "'", str51.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(property55);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 222090, (java.lang.Number) 345600000L, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
//        boolean boolean7 = dateTime6.isEqualNow();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology9 = gJChronology8.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getShortName((long) 'a', locale12);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
//        org.joda.time.DateTime dateTime15 = dateTime6.withZoneRetainFields(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(2, 9, (int) (short) 0, (int) (short) 100, (int) '4', 10, (int) (short) 10, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.remainder((long) ' ');
        int int41 = offsetDateTimeField37.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 259200032L + "'", long39 == 259200032L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292275023) + "'", int41 == (-292275023));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(chronology13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = monthDay14.isSupported(dateTimeFieldType15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay18 = monthDay14.minus(readablePeriod17);
        int[] intArray20 = iSOChronology11.get((org.joda.time.ReadablePartial) monthDay18, (long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay30 = monthDay27.withPeriodAdded(readablePeriod28, (int) (short) 100);
        int[] intArray32 = iSOChronology25.get((org.joda.time.ReadablePartial) monthDay30, 0L);
        gregorianChronology21.validate((org.joda.time.ReadablePartial) monthDay24, intArray32);
        try {
            int int34 = unsupportedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay18, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        java.util.Locale locale41 = null;
        try {
            long long42 = offsetDateTimeField37.set(0L, "BuddhistChronology[America/Los_Angeles]", locale41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[America/Los_Angeles]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((long) 8, locale4);
        boolean boolean6 = delegatedDateTimeField2.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970" + "'", str5.equals("1970"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        boolean boolean4 = julianChronology0.equals((java.lang.Object) iSOChronology2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumShortTextLength(locale10);
        java.util.Locale locale12 = null;
        java.lang.String str13 = property9.getAsShortText(locale12);
        int int14 = property9.getMaximumValueOverall();
        try {
            org.joda.time.MonthDay monthDay16 = property9.setCopy("yearOfEra");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"yearOfEra\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, (int) (short) 100);
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
        int[] intArray30 = iSOChronology23.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(chronology32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay36 = monthDay33.withPeriodAdded(readablePeriod34, (int) (short) 100);
        int[] intArray38 = iSOChronology31.get((org.joda.time.ReadablePartial) monthDay36, 0L);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology31.minuteOfDay();
        org.joda.time.MonthDay monthDay40 = monthDay28.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTime dateTime41 = dateTime22.toDateTime((org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTime.Property property42 = dateTime22.era();
        org.joda.time.DateTime dateTime44 = dateTime22.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        java.util.Locale locale49 = null;
        java.lang.String str50 = delegatedDateTimeField47.getAsShortText((int) (byte) 100, locale49);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField47.getType();
        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField19, dateTimeFieldType51, 31);
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay(chronology55);
        int int57 = monthDay56.size();
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.MonthDay monthDay62 = new org.joda.time.MonthDay(chronology61);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = null;
        boolean boolean64 = monthDay62.isSupported(dateTimeFieldType63);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.MonthDay monthDay66 = monthDay62.minus(readablePeriod65);
        int[] intArray68 = iSOChronology59.get((org.joda.time.ReadablePartial) monthDay66, (long) (byte) 100);
        int int69 = offsetDateTimeField54.getMaximumValue((org.joda.time.ReadablePartial) monthDay56, intArray68);
        java.util.Locale locale71 = null;
        try {
            int[] intArray72 = unsupportedDateTimeField9.set((org.joda.time.ReadablePartial) monthDay14, (int) '4', intArray68, "1970-04-15T20:24:17.595Z", locale71);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "100" + "'", str50.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 292279024 + "'", int69 == 292279024);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField12 = iSOChronology2.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str20 = illegalFieldValueException19.getIllegalStringValue();
        java.lang.Number number21 = illegalFieldValueException19.getLowerBound();
        boolean boolean22 = iSOChronology2.equals((java.lang.Object) number21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        boolean boolean14 = iSOChronology1.equals((java.lang.Object) 14329464380L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.DateTime dateTime4 = monthDay1.toDateTime((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant7 = instant3.withDurationAdded((-61788182399900L), (int) (short) 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant3.minus(readableDuration8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        boolean boolean7 = monthDay4.equals((java.lang.Object) 10.0f);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withChronologyRetainFields(chronology8);
        org.joda.time.Chronology chronology10 = monthDay4.getChronology();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        java.util.GregorianCalendar gregorianCalendar7 = dateTime6.toGregorianCalendar();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        int int40 = monthDay39.size();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.minus(readablePeriod48);
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) (byte) 100);
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        try {
            org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((java.lang.Object) offsetDateTimeField37, dateTimeZone53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292279024 + "'", int52 == 292279024);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
//        org.joda.time.Instant instant6 = dateTime5.toInstant();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
//        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology8.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology8.hourOfDay();
//        org.joda.time.DurationField durationField18 = iSOChronology8.eras();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology8.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology8.getZone();
//        org.joda.time.LocalDateTime localDateTime22 = null;
//        boolean boolean23 = dateTimeZone21.isLocalDateTimeGap(localDateTime22);
//        org.joda.time.MutableDateTime mutableDateTime24 = instant6.toMutableDateTime(dateTimeZone21);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone21.getShortName((long) 22, locale26);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        long long15 = skipUndoDateTimeField12.set((long) 20, (int) (byte) -1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62230291199980L) + "'", long15 == (-62230291199980L));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((int) (byte) 100, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType9, 1970, 2019, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = offsetDateTimeField13.getDurationField();
        int int15 = offsetDateTimeField13.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfSecond();
        org.joda.time.Interval interval2 = property1.toInterval();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(interval2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("73457595");
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) instant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 'a');
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
        int int19 = property17.get();
        org.joda.time.DateTime dateTime20 = property17.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (-1));
        org.joda.time.DateTime dateTime24 = monthDay3.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property25 = dateTime23.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("2019W161T202414.069Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = unsupportedDateTimeField9.getAsText((long) (-292275054), locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        boolean boolean7 = monthDay4.equals((java.lang.Object) 10.0f);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withChronologyRetainFields(chronology8);
        org.joda.time.Chronology chronology10 = monthDay9.getChronology();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(595);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(chronology4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, (int) (short) 100);
        boolean boolean9 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay8);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) monthDay8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            java.lang.String str11 = unsupportedDateTimeField9.getAsShortText((long) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.millisOfSecond();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        org.joda.time.DateTime dateTime23 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField26.getAsShortText((int) (byte) 100, locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField26.getType();
        boolean boolean31 = dateTime23.isSupported(dateTimeFieldType30);
        int int32 = dateTime23.getMinuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray12 = null;
        try {
            int[] intArray14 = unsupportedDateTimeField9.addWrapPartial(readablePartial10, 20, intArray12, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        boolean boolean17 = monthDay15.isSupported(dateTimeFieldType16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay15.minus(readablePeriod18);
        int[] intArray21 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay19, (long) (byte) 100);
        try {
            int int22 = unsupportedDateTimeField9.getMaximumValue(readablePartial10, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = monthDay11.isSupported(dateTimeFieldType12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((java.lang.Object) monthDay11);
        org.joda.time.MonthDay monthDay16 = monthDay11.minusMonths(30);
        org.joda.time.MonthDay monthDay18 = monthDay11.plusDays(2019);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay30 = monthDay27.withPeriodAdded(readablePeriod28, (int) (short) 100);
        int[] intArray32 = iSOChronology25.get((org.joda.time.ReadablePartial) monthDay30, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(chronology34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.MonthDay monthDay38 = monthDay35.withPeriodAdded(readablePeriod36, (int) (short) 100);
        int[] intArray40 = iSOChronology33.get((org.joda.time.ReadablePartial) monthDay38, 0L);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology33.minuteOfDay();
        org.joda.time.MonthDay monthDay42 = monthDay30.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTime dateTime43 = dateTime24.toDateTime((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTime.Property property44 = dateTime24.era();
        org.joda.time.DateTime dateTime46 = dateTime24.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48);
        java.util.Locale locale51 = null;
        java.lang.String str52 = delegatedDateTimeField49.getAsShortText((int) (byte) 100, locale51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = delegatedDateTimeField49.getType();
        boolean boolean54 = dateTime46.isSupported(dateTimeFieldType53);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField21, dateTimeFieldType53, 31);
        long long58 = offsetDateTimeField56.roundHalfFloor((long) 100);
        int int60 = offsetDateTimeField56.getLeapAmount(0L);
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.MonthDay monthDay62 = new org.joda.time.MonthDay(chronology61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.MonthDay monthDay65 = monthDay62.withPeriodAdded(readablePeriod63, (int) (short) 100);
        boolean boolean66 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay65);
        int int67 = offsetDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) monthDay65);
        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology68.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay(dateTimeZone70);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay(chronology73);
        org.joda.time.ReadablePeriod readablePeriod75 = null;
        org.joda.time.MonthDay monthDay77 = monthDay74.withPeriodAdded(readablePeriod75, (int) (short) 100);
        int[] intArray79 = iSOChronology72.get((org.joda.time.ReadablePartial) monthDay77, 0L);
        gregorianChronology68.validate((org.joda.time.ReadablePartial) monthDay71, intArray79);
        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology82 = null;
        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay(chronology82);
        org.joda.time.ReadablePeriod readablePeriod84 = null;
        org.joda.time.MonthDay monthDay86 = monthDay83.withPeriodAdded(readablePeriod84, (int) (short) 100);
        int[] intArray88 = iSOChronology81.get((org.joda.time.ReadablePartial) monthDay86, 0L);
        int int89 = offsetDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) monthDay71, intArray88);
        try {
            int int90 = unsupportedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay11, intArray88);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "100" + "'", str52.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-259200000L) + "'", long58 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 292279024 + "'", int67 == 292279024);
        org.junit.Assert.assertNotNull(gregorianChronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(iSOChronology81);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 292279024 + "'", int89 == 292279024);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Jan", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Jan/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, (int) (short) 100);
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(chronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (short) 100);
        boolean boolean11 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (short) 100);
        int[] intArray29 = iSOChronology22.get((org.joda.time.ReadablePartial) monthDay27, 0L);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology22.minuteOfDay();
        org.joda.time.MonthDay monthDay31 = monthDay19.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime dateTime32 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime.Property property33 = dateTime13.era();
        org.joda.time.DateTime dateTime35 = dateTime13.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField38.getAsShortText((int) (byte) 100, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField38.getType();
        boolean boolean43 = dateTime35.isSupported(dateTimeFieldType42);
        int int44 = dateTime35.getMillisOfSecond();
        org.joda.time.DateTime dateTime45 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime35.withPeriodAdded(readablePeriod46, 0);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "100" + "'", str41.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 97 + "'", int44 == 97);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withWeekyear(0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((int) (byte) 100, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType9, 1970, 2019, (int) (byte) 1);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField13.getMaximumTextLength(locale14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DurationField durationField3 = julianChronology0.months();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        boolean boolean13 = dateTimeFormatter12.isOffsetParsed();
        boolean boolean14 = dateTimeFormatter12.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 20, (org.joda.time.Chronology) copticChronology1);
        java.lang.String str4 = copticChronology1.toString();
        int int5 = copticChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str4.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 100);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560630286785L + "'", long0 == 1560630286785L);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getShortName((long) 'a', locale6);
//        org.joda.time.Chronology chronology8 = julianChronology0.withZone(dateTimeZone4);
//        org.joda.time.LocalDateTime localDateTime9 = null;
//        try {
//            boolean boolean10 = dateTimeZone4.isLocalDateTimeGap(localDateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology8);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        long long15 = dateTimeZone13.convertUTCToLocal((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28800000L) + "'", long15 == (-28800000L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute(292279024);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279024 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        try {
            long long16 = unsupportedDateTimeField9.addWrapField((long) 9, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((-292275054), 105, 22, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 105 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-292275023), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withDayOfMonth((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime5.withCenturyOfEra(4);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withDurationAdded(readableDuration5, 100);
        org.joda.time.LocalTime localTime8 = dateTime1.toLocalTime();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localTime8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths(2);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekOfWeekyear((int) '#');
        int int10 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        try {
            long long19 = zonedChronology13.getDateTimeMillis((long) 595, 24, (int) '4', (int) (byte) 10, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.get();
//        org.joda.time.DurationField durationField13 = property9.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(2019);
        org.joda.time.DateTime dateTime12 = dateTime8.minusMillis(20);
        int int13 = property4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology15 = gJChronology14.withUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.Instant instant17 = gJChronology14.getGregorianCutover();
        org.joda.time.Instant instant20 = instant17.withDurationAdded(1560630267123L, (int) (short) 10);
        long long21 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) instant20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-57L) + "'", long21 == (-57L));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (short) 100);
        int[] intArray14 = iSOChronology7.get((org.joda.time.ReadablePartial) monthDay12, 0L);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) monthDay6, intArray14);
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        long long19 = dateTimeZone1.getMillisKeepLocal(dateTimeZone16, (long) 1970);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1970L + "'", long19 == 1970L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime5.minusDays((-1));
        int int11 = dateTime10.getMillisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
        java.lang.Object obj8 = null;
        boolean boolean9 = property4.equals(obj8);
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property4.setCopy("Property[yearOfEra]", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[yearOfEra]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(24);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        java.lang.String str13 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[UTC]" + "'", str13.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis((int) (short) -1, 222090, (int) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.Instant instant6 = instant3.withDurationAdded(1560630267123L, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str8 = instant3.toString(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "15821015T000000Z" + "'", str8.equals("15821015T000000Z"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(24);
        org.joda.time.DateTime dateTime9 = dateTime1.withYear(30);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = buddhistChronology7.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = buddhistChronology7.withZone(dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(31, (int) (byte) -1, 222090, 1970, 595, 10, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str8.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime.Property property27 = dateTime7.era();
        org.joda.time.DateTime dateTime29 = dateTime7.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsShortText((int) (byte) 100, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        boolean boolean37 = dateTime29.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType36, 31);
        long long41 = offsetDateTimeField39.roundHalfFloor((long) 100);
        int int43 = offsetDateTimeField39.getLeapAmount(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
        int int45 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay4.isSupported(dateTimeFieldType5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay4.minus(readablePeriod7);
        int[] intArray10 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay8, (long) (byte) 100);
        try {
            org.joda.time.MonthDay monthDay12 = monthDay8.withMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay4.isSupported(dateTimeFieldType5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay4.minus(readablePeriod7);
        int[] intArray10 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay8, (long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"JulianChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        try {
            long long12 = unsupportedDateTimeField9.roundCeiling((long) 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((-49), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2548) + "'", int2 == (-2548));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        int int13 = property9.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = monthDay1.isSupported(dateTimeFieldType2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) monthDay1);
        try {
            int int6 = monthDay1.getValue((-49));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears((int) (byte) 1);
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        java.util.Locale locale10 = null;
        try {
            org.joda.time.DateTime dateTime11 = property4.setCopy("UTC", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField12.getType();
        int int14 = skipUndoDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275053) + "'", int14 == (-292275053));
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.get();
//        org.joda.time.MonthDay monthDay13 = property9.getMonthDay();
//        java.lang.String str14 = property9.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "15" + "'", str14.equals("15"));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[yearOfEra]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2000, 49, 1970, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        long long14 = skipDateTimeField6.roundCeiling(0L);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
        int[] intArray22 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay20, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
        int[] intArray30 = iSOChronology23.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology23.minuteOfDay();
        org.joda.time.MonthDay monthDay32 = monthDay20.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.MonthDay monthDay35 = monthDay32.withPeriodAdded(readablePeriod33, 31);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay47 = monthDay44.withPeriodAdded(readablePeriod45, (int) (short) 100);
        int[] intArray49 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay47, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay(chronology51);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.MonthDay monthDay55 = monthDay52.withPeriodAdded(readablePeriod53, (int) (short) 100);
        int[] intArray57 = iSOChronology50.get((org.joda.time.ReadablePartial) monthDay55, 0L);
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology50.minuteOfDay();
        org.joda.time.MonthDay monthDay59 = monthDay47.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology50);
        org.joda.time.DateTime dateTime60 = dateTime41.toDateTime((org.joda.time.Chronology) iSOChronology50);
        org.joda.time.DateTime.Property property61 = dateTime41.era();
        org.joda.time.DateTime dateTime63 = dateTime41.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField65);
        java.util.Locale locale68 = null;
        java.lang.String str69 = delegatedDateTimeField66.getAsShortText((int) (byte) 100, locale68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = delegatedDateTimeField66.getType();
        boolean boolean71 = dateTime63.isSupported(dateTimeFieldType70);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField38, dateTimeFieldType70, 31);
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = new org.joda.time.MonthDay(chronology74);
        int int76 = monthDay75.size();
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology78);
        org.joda.time.Chronology chronology80 = null;
        org.joda.time.MonthDay monthDay81 = new org.joda.time.MonthDay(chronology80);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = null;
        boolean boolean83 = monthDay81.isSupported(dateTimeFieldType82);
        org.joda.time.ReadablePeriod readablePeriod84 = null;
        org.joda.time.MonthDay monthDay85 = monthDay81.minus(readablePeriod84);
        int[] intArray87 = iSOChronology78.get((org.joda.time.ReadablePartial) monthDay85, (long) (byte) 100);
        int int88 = offsetDateTimeField73.getMaximumValue((org.joda.time.ReadablePartial) monthDay75, intArray87);
        int int89 = skipDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay35, intArray87);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "100" + "'", str69.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(monthDay85);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292279024 + "'", int88 == 292279024);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        int int4 = dateTime1.getSecondOfMinute();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gJChronology5.weeks();
//        boolean boolean7 = dateTime1.equals((java.lang.Object) gJChronology5);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.Instant instant9 = gJChronology5.getGregorianCutover();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 55 + "'", int4 == 55);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(instant9);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        long long15 = skipDateTimeField6.addWrapField((long) (byte) 1, (int) '#');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(chronology25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay29 = monthDay26.withPeriodAdded(readablePeriod27, (int) (short) 100);
        int[] intArray31 = iSOChronology24.get((org.joda.time.ReadablePartial) monthDay29, 0L);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology24.minuteOfDay();
        org.joda.time.MonthDay monthDay33 = monthDay21.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology24);
        int[] intArray37 = new int[] { 292279024, (-1) };
        java.util.Locale locale39 = null;
        try {
            int[] intArray40 = skipDateTimeField6.set((org.joda.time.ReadablePartial) monthDay33, 595, intArray37, "15821015T000000Z", locale39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"15821015T000000Z\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28857600001L + "'", long15 == 28857600001L);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(2000, 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2022 + "'", int2 == 2022);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField5 = gJChronology0.seconds();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        try {
            long long21 = zonedChronology13.getDateTimeMillis(86399999, 0, 17, 1970, 166, 595, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField3.getAsShortText((int) (byte) 100, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField3.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear((-25200000));
        try {
            org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("Property[yearOfEra]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[yearOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.weekyear();
        org.joda.time.MutableDateTime mutableDateTime7 = instant1.toMutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        int int10 = skipDateTimeField6.get((long) 2000);
        long long12 = skipDateTimeField6.roundHalfFloor((long) (byte) 10);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField9.getType();
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField9.getLeapDurationField();
        java.util.Locale locale17 = null;
        try {
            int int18 = unsupportedDateTimeField9.getMaximumShortTextLength(locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        int int5 = dateTime1.getHourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology6.hourOfDay();
        int int16 = dateTime1.get(dateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        int int9 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        try {
            long long12 = unsupportedDateTimeField9.roundHalfEven((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) ' ');
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withDate((int) ' ', (int) '#', 363);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology10 = gJChronology9.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(2019);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis(20);
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime17);
        try {
            long long26 = limitChronology18.getDateTimeMillis(6, 0, 30, (int) (byte) 100, 10, 222090, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(292278993, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        boolean boolean8 = delegatedDateTimeField4.isLenient();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime5.era();
        org.joda.time.DateTime dateTime12 = dateTime5.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        int[] intArray20 = iSOChronology13.get((org.joda.time.ReadablePartial) monthDay18, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(chronology22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, (int) (short) 100);
        int[] intArray28 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay26, 0L);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology21.minuteOfDay();
        org.joda.time.MonthDay monthDay30 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTime dateTime31 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTime.Property property32 = dateTime12.era();
        org.joda.time.DateTime dateTime34 = dateTime12.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = delegatedDateTimeField37.getAsShortText((int) (byte) 100, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField37.getType();
        boolean boolean42 = dateTime34.isSupported(dateTimeFieldType41);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField9, dateTimeFieldType41, 31);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(chronology45);
        int int47 = monthDay46.size();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay(chronology51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        boolean boolean54 = monthDay52.isSupported(dateTimeFieldType53);
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.MonthDay monthDay56 = monthDay52.minus(readablePeriod55);
        int[] intArray58 = iSOChronology49.get((org.joda.time.ReadablePartial) monthDay56, (long) (byte) 100);
        int int59 = offsetDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) monthDay46, intArray58);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
        int int61 = monthDay46.indexOf(dateTimeFieldType60);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(chronology62);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, (int) (short) 100);
        org.joda.time.MonthDay monthDay68 = monthDay66.plusDays(0);
        boolean boolean69 = monthDay46.isBefore((org.joda.time.ReadablePartial) monthDay66);
        int int70 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.MonthDay monthDay72 = monthDay46.withMonthOfYear(8);
        org.joda.time.ReadablePeriod readablePeriod73 = null;
        org.joda.time.MonthDay monthDay74 = monthDay46.minus(readablePeriod73);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "100" + "'", str40.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292279024 + "'", int59 == 292279024);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 292278993 + "'", int70 == 292278993);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertNotNull(monthDay74);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(55, 86399999, 2, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone9.getOffset(readableInstant10);
        org.joda.time.Chronology chronology12 = gJChronology0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        try {
//            int int14 = property9.compareTo(readablePartial13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(14329460161L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        int int10 = skipDateTimeField6.get((long) 2000);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        boolean boolean16 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        boolean boolean22 = monthDay15.isAfter((org.joda.time.ReadablePartial) monthDay21);
        org.joda.time.MonthDay monthDay24 = monthDay21.minusDays(20);
        org.joda.time.MonthDay monthDay26 = monthDay24.plusDays(4);
        int[] intArray30 = new int[] { (-292275053), 49 };
        java.util.Locale locale32 = null;
        try {
            int[] intArray33 = skipDateTimeField6.set((org.joda.time.ReadablePartial) monthDay24, 31, intArray30, "2019W161T202450.338Z", locale32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019W161T202450.338Z\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("10", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(22);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setStandardOffset((int) '#');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder0.addCutover((int) '#', '#', 31, 6, (-292275054), true, (-49));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getMaximumValue();
        int int40 = offsetDateTimeField37.getMinimumValue((-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 292279024 + "'", int38 == 292279024);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292275023) + "'", int40 == (-292275023));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("2019W161T202450.338Z", 292279024);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("15821015T000000Z", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
        int int9 = dateTime5.getYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology2 = gJChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths(2);
        org.joda.time.Instant instant6 = dateTime5.toInstant();
        org.joda.time.DateTime dateTime7 = instant6.toDateTimeISO();
        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.MonthDay monthDay5 = monthDay3.minusMonths((int) 'a');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay5);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        java.util.Locale locale8 = null;
//        int int9 = property4.getMaximumShortTextLength(locale8);
//        org.joda.time.DateTime dateTime10 = property4.roundHalfFloorCopy();
//        java.lang.String str11 = property4.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28658958771L + "'", long7 == 28658958771L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[yearOfEra]" + "'", str11.equals("Property[yearOfEra]"));
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        int int3 = dateTimeZone1.getOffset(readableInstant2);
//        java.lang.String str5 = dateTimeZone1.getName((long) (-1));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DurationField durationField8 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        try {
            long long7 = julianChronology0.getDateTimeMillis((int) (short) 10, (int) (byte) 100, (-292275053), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(20);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter2.parseDateTime("yearOfEra");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"yearOfEra\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        org.joda.time.MonthDay monthDay20 = monthDay18.plusDays(0);
        java.lang.String str21 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) monthDay18);
        int int22 = monthDay3.compareTo((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField25.getAsShortText((int) (byte) 100, locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField25.getType();
        boolean boolean30 = monthDay3.isSupported(dateTimeFieldType29);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, (-292275054), 28, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for weekyear must be in the range [28,-292275054]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "����W���T������.000" + "'", str21.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "100" + "'", str28.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        java.util.Locale locale11 = null;
        try {
            int int12 = unsupportedDateTimeField9.getMaximumTextLength(locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019W161T202421.682Z", true);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Jan", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(55, (int) (byte) 100, (-25200000), 57, (-2548), 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        int int41 = offsetDateTimeField37.getLeapAmount(0L);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (short) 100);
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        int int49 = offsetDateTimeField37.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279024 + "'", int48 == 292279024);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-292275023) + "'", int49 == (-292275023));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property21 = dateTime1.era();
        org.joda.time.DateTime dateTime23 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury((int) '4');
        org.joda.time.DateTime dateTime27 = dateTime25.plusDays((int) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399999);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(110L);
        long long10 = fixedDateTimeZone4.nextTransition(100L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        int int40 = monthDay39.size();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.minus(readablePeriod48);
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) (byte) 100);
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray51);
        long long55 = offsetDateTimeField37.add(14329457235L, 110L);
        java.util.Locale locale58 = null;
        try {
            long long59 = offsetDateTimeField37.set(100L, "PST", locale58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292279024 + "'", int52 == 292279024);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3485881457235L + "'", long55 == 3485881457235L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        int int12 = dateTimeZone8.getOffsetFromLocal((long) 12);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, 15, (int) 'a', 2, (-1), (int) (byte) -1, (-292275023), dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = buddhistChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = buddhistChronology3.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology3.withUTC();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology9 = gJChronology8.withUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology3.withZone(dateTimeZone10);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        long long18 = dateTimeZone10.getMillisKeepLocal(dateTimeZone14, (long) (-25200000));
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone10);
        try {
            org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10, 55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 55");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str4.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-25200000L) + "'", long18 == (-25200000L));
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(20);
        int int9 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399999 + "'", int9 == 86399999);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399999);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.DurationField durationField10 = julianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology7.dayOfMonth();
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField11);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(24);
        int int8 = dateTime1.getWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int7 = skipDateTimeField6.getMaximumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText(0L, locale9);
        int int12 = skipDateTimeField6.get((long) 595);
        try {
            long long15 = skipDateTimeField6.set(14329495605L, (-292275023));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275023 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology10 = gJChronology9.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(2019);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis(20);
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime17);
        try {
            long long23 = limitChronology18.getDateTimeMillis(4, 28, (int) '#', 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
        int[] intArray15 = iSOChronology8.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(chronology17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (short) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePartial) monthDay21, 0L);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology16.minuteOfDay();
        org.joda.time.MonthDay monthDay25 = monthDay13.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime26 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime.Property property27 = dateTime7.era();
        org.joda.time.DateTime dateTime29 = dateTime7.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsShortText((int) (byte) 100, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        boolean boolean37 = dateTime29.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType36, 31);
        long long41 = offsetDateTimeField39.roundHalfFloor((long) 100);
        int int43 = offsetDateTimeField39.getLeapAmount(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) offsetDateTimeField39);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(chronology45);
        int int47 = monthDay46.size();
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = skipDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) monthDay46, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200000L) + "'", long41 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("AD", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 100 + "'", number7.equals((short) 100));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        int[] intArray20 = iSOChronology13.get((org.joda.time.ReadablePartial) monthDay18, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(chronology22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, (int) (short) 100);
        int[] intArray28 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay26, 0L);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology21.minuteOfDay();
        org.joda.time.MonthDay monthDay30 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTime dateTime31 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTime.Property property32 = dateTime12.era();
        org.joda.time.DateTime dateTime34 = dateTime12.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = delegatedDateTimeField37.getAsShortText((int) (byte) 100, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField37.getType();
        boolean boolean42 = dateTime34.isSupported(dateTimeFieldType41);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField9, dateTimeFieldType41, 31);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(chronology45);
        int int47 = monthDay46.size();
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay(chronology51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        boolean boolean54 = monthDay52.isSupported(dateTimeFieldType53);
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.MonthDay monthDay56 = monthDay52.minus(readablePeriod55);
        int[] intArray58 = iSOChronology49.get((org.joda.time.ReadablePartial) monthDay56, (long) (byte) 100);
        int int59 = offsetDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) monthDay46, intArray58);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
        int int61 = monthDay46.indexOf(dateTimeFieldType60);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(chronology62);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, (int) (short) 100);
        org.joda.time.MonthDay monthDay68 = monthDay66.plusDays(0);
        boolean boolean69 = monthDay46.isBefore((org.joda.time.ReadablePartial) monthDay66);
        int int70 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.MonthDay monthDay72 = monthDay46.withMonthOfYear(8);
        org.joda.time.chrono.ISOChronology iSOChronology73 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = new org.joda.time.MonthDay(chronology74);
        org.joda.time.ReadablePeriod readablePeriod76 = null;
        org.joda.time.MonthDay monthDay78 = monthDay75.withPeriodAdded(readablePeriod76, (int) (short) 100);
        int[] intArray80 = iSOChronology73.get((org.joda.time.ReadablePartial) monthDay78, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology82 = null;
        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay(chronology82);
        org.joda.time.ReadablePeriod readablePeriod84 = null;
        org.joda.time.MonthDay monthDay86 = monthDay83.withPeriodAdded(readablePeriod84, (int) (short) 100);
        int[] intArray88 = iSOChronology81.get((org.joda.time.ReadablePartial) monthDay86, 0L);
        org.joda.time.DateTimeField dateTimeField89 = iSOChronology81.minuteOfDay();
        org.joda.time.MonthDay monthDay90 = monthDay78.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology81);
        org.joda.time.MonthDay monthDay92 = monthDay90.plusMonths((-1));
        boolean boolean93 = monthDay46.isBefore((org.joda.time.ReadablePartial) monthDay90);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "100" + "'", str40.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292279024 + "'", int59 == 292279024);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 292278993 + "'", int70 == 292278993);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertNotNull(iSOChronology73);
        org.junit.Assert.assertNotNull(monthDay78);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(iSOChronology81);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(dateTimeField89);
        org.junit.Assert.assertNotNull(monthDay90);
        org.junit.Assert.assertNotNull(monthDay92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField12.getType();
        java.lang.String str14 = skipUndoDateTimeField12.toString();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (short) 100);
        int[] intArray22 = iSOChronology15.get((org.joda.time.ReadablePartial) monthDay20, 0L);
        int int23 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay20);
        int int25 = skipUndoDateTimeField12.get(0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[weekyear]" + "'", str14.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292278993 + "'", int23 == 292278993);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1971 + "'", int25 == 1971);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 363);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(2019);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfCentury((int) (short) 0);
        int int9 = dateTime8.getMonthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(166, 222090, 595, 2000, 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime5.toYearMonthDay();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime5.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        boolean boolean15 = zonedChronology13.equals((java.lang.Object) (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsText(30, locale41);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.MonthDay monthDay48 = monthDay45.withPeriodAdded(readablePeriod46, (int) (short) 100);
        int[] intArray50 = iSOChronology43.get((org.joda.time.ReadablePartial) monthDay48, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay(chronology52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.MonthDay monthDay56 = monthDay53.withPeriodAdded(readablePeriod54, (int) (short) 100);
        int[] intArray58 = iSOChronology51.get((org.joda.time.ReadablePartial) monthDay56, 0L);
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology51.minuteOfDay();
        org.joda.time.MonthDay monthDay60 = monthDay48.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.MonthDay monthDay63 = monthDay60.withPeriodAdded(readablePeriod61, 31);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, 0);
        java.util.Locale locale67 = null;
        try {
            java.lang.String str68 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay66, locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "30" + "'", str42.equals("30"));
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay66);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology1);
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        boolean boolean12 = skipDateTimeField6.isLeap((long) 9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        int[] intArray20 = iSOChronology13.get((org.joda.time.ReadablePartial) monthDay18, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(chronology22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, (int) (short) 100);
        int[] intArray28 = iSOChronology21.get((org.joda.time.ReadablePartial) monthDay26, 0L);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology21.minuteOfDay();
        org.joda.time.MonthDay monthDay30 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MonthDay monthDay32 = monthDay30.plusMonths((-1));
        int int33 = skipDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay32);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            long long3 = dateTimeFormatter0.parseMillis("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
//        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
//        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
//        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
//        int int22 = dateTime20.getYear();
//        org.joda.time.DateTime.Property property23 = dateTime20.dayOfMonth();
//        org.joda.time.DateTime dateTime24 = property23.roundFloorCopy();
//        long long25 = property23.remainder();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 60562329L + "'", long25 == 60562329L);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 110L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField12 = iSOChronology2.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        boolean boolean41 = monthDay39.isSupported(dateTimeFieldType40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((java.lang.Object) monthDay39);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusMonths(30);
        org.joda.time.MonthDay monthDay46 = monthDay39.plusDays(2019);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 10, locale48);
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay(chronology50);
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.MonthDay monthDay54 = monthDay51.withPeriodAdded(readablePeriod52, (int) (short) 100);
        boolean boolean55 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.MonthDay monthDay57 = new org.joda.time.MonthDay(chronology56);
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.MonthDay monthDay60 = monthDay57.withPeriodAdded(readablePeriod58, (int) (short) 100);
        boolean boolean61 = monthDay54.isAfter((org.joda.time.ReadablePartial) monthDay60);
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology62);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology65 = null;
        org.joda.time.MonthDay monthDay66 = new org.joda.time.MonthDay(chronology65);
        org.joda.time.ReadablePeriod readablePeriod67 = null;
        org.joda.time.MonthDay monthDay69 = monthDay66.withPeriodAdded(readablePeriod67, (int) (short) 100);
        int[] intArray71 = iSOChronology64.get((org.joda.time.ReadablePartial) monthDay69, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay(chronology73);
        org.joda.time.ReadablePeriod readablePeriod75 = null;
        org.joda.time.MonthDay monthDay77 = monthDay74.withPeriodAdded(readablePeriod75, (int) (short) 100);
        int[] intArray79 = iSOChronology72.get((org.joda.time.ReadablePartial) monthDay77, 0L);
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology72.minuteOfDay();
        org.joda.time.MonthDay monthDay81 = monthDay69.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology72);
        org.joda.time.DateTime dateTime82 = dateTime63.toDateTime((org.joda.time.Chronology) iSOChronology72);
        org.joda.time.DateTime.Property property83 = dateTime63.era();
        org.joda.time.DateTime dateTime85 = dateTime63.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology86 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField87 = gregorianChronology86.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField88 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField87);
        java.util.Locale locale90 = null;
        java.lang.String str91 = delegatedDateTimeField88.getAsShortText((int) (byte) 100, locale90);
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = delegatedDateTimeField88.getType();
        boolean boolean93 = dateTime85.isSupported(dateTimeFieldType92);
        int int94 = monthDay54.indexOf(dateTimeFieldType92);
        java.util.Locale locale95 = null;
        try {
            java.lang.String str96 = offsetDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) monthDay54, locale95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(monthDay81);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(gregorianChronology86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "100" + "'", str91.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfSecond();
        boolean boolean2 = dateTime0.isEqualNow();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology4.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology4.hourOfDay();
        org.joda.time.DurationField durationField14 = iSOChronology4.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology4.getZone();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime0.toMutableDateTime((org.joda.time.Chronology) iSOChronology4);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(24);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.plus(readablePeriod8);
        java.lang.String str11 = dateTime1.toString("100");
        org.joda.time.DateTime dateTime13 = dateTime1.withMillis((long) 166);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(2019);
        org.joda.time.DateTime dateTime12 = dateTime8.minusMillis(20);
        int int13 = property4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        java.lang.String str14 = property4.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[yearOfEra]" + "'", str14.equals("Property[yearOfEra]"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone12);
        try {
            long long21 = zonedChronology13.getDateTimeMillis((int) (short) 100, (int) (short) -1, 292278993, 222090, 22, 105, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 222090 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int7 = skipDateTimeField6.getMaximumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText((long) (short) 1, locale9);
        int int12 = skipDateTimeField6.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField37.getAsShortText(readablePartial39, (-292275054), locale41);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay47 = monthDay44.withPeriodAdded(readablePeriod45, (int) (short) 100);
        boolean boolean48 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay47);
        boolean boolean50 = monthDay47.equals((java.lang.Object) 10.0f);
        int int51 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay47);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.minusMonths(2);
        org.joda.time.DateTime.Property property56 = dateTime53.millisOfDay();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime53.withDurationAdded(readableDuration57, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        java.util.Locale locale64 = null;
        java.lang.String str65 = delegatedDateTimeField62.getAsShortText((int) (byte) 100, locale64);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = delegatedDateTimeField62.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField68 = gregorianChronology67.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField69 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField68);
        int int70 = dateTime53.get(dateTimeFieldType66);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField37, dateTimeFieldType66, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-292275054" + "'", str42.equals("-292275054"));
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-292275023) + "'", int51 == (-292275023));
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "100" + "'", str65.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DurationField durationField7 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMonthOfYear((-292275011));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275011 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        long long42 = offsetDateTimeField37.roundHalfEven((long) 595);
        java.lang.String str43 = offsetDateTimeField37.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-259200000L) + "'", long42 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "weekyear" + "'", str43.equals("weekyear"));
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        java.lang.String str5 = dateTime1.toString(dateTimeFormatter4);
//        java.io.Writer writer6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = delegatedDateTimeField9.getAsShortText((int) (byte) 100, locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField9.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField16.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
//        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(chronology29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.MonthDay monthDay33 = monthDay30.withPeriodAdded(readablePeriod31, (int) (short) 100);
//        int[] intArray35 = iSOChronology28.get((org.joda.time.ReadablePartial) monthDay33, 0L);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology28.minuteOfDay();
//        org.joda.time.MonthDay monthDay37 = monthDay25.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.DateTime dateTime38 = dateTime19.toDateTime((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.DateTime.Property property39 = dateTime19.era();
//        org.joda.time.DateTime dateTime41 = dateTime19.withMillisOfDay((int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = delegatedDateTimeField44.getAsShortText((int) (byte) 100, locale46);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = delegatedDateTimeField44.getType();
//        boolean boolean49 = dateTime41.isSupported(dateTimeFieldType48);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType48, 31);
//        org.joda.time.Chronology chronology52 = null;
//        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay(chronology52);
//        int int54 = monthDay53.size();
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology56);
//        org.joda.time.Chronology chronology58 = null;
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay(chronology58);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
//        boolean boolean61 = monthDay59.isSupported(dateTimeFieldType60);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay59.minus(readablePeriod62);
//        int[] intArray65 = iSOChronology56.get((org.joda.time.ReadablePartial) monthDay63, (long) (byte) 100);
//        int int66 = offsetDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) monthDay53, intArray65);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = null;
//        int int68 = monthDay53.indexOf(dateTimeFieldType67);
//        org.joda.time.Chronology chronology69 = null;
//        org.joda.time.MonthDay monthDay70 = new org.joda.time.MonthDay(chronology69);
//        org.joda.time.ReadablePeriod readablePeriod71 = null;
//        org.joda.time.MonthDay monthDay73 = monthDay70.withPeriodAdded(readablePeriod71, (int) (short) 100);
//        org.joda.time.MonthDay monthDay75 = monthDay73.plusDays(0);
//        boolean boolean76 = monthDay53.isBefore((org.joda.time.ReadablePartial) monthDay73);
//        int int77 = delegatedDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay53);
//        org.joda.time.MonthDay monthDay79 = monthDay53.withMonthOfYear(8);
//        try {
//            dateTimeFormatter4.printTo(writer6, (org.joda.time.ReadablePartial) monthDay79);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "11/28/19 4:49 PM" + "'", str5.equals("11/28/19 4:49 PM"));
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "100" + "'", str47.equals("100"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 292279024 + "'", int66 == 292279024);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 292278993 + "'", int77 == 292278993);
//        org.junit.Assert.assertNotNull(monthDay79);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DurationField durationField7 = property6.getDurationField();
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("2019W161T202450.338Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019W161T202450.338Z\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField9.getType();
        org.joda.time.DurationField durationField16 = unsupportedDateTimeField9.getLeapDurationField();
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField9.getAsText((long) 4, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfMonth(10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-25200000L), (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50400000L + "'", long2 == 50400000L);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        int int11 = property9.getMaximumShortTextLength(locale10);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property9.getAsShortText(locale12);
//        int int14 = property9.getMaximumValueOverall();
//        int int15 = property9.get();
//        boolean boolean17 = property9.equals((java.lang.Object) (-292275053));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "28" + "'", str13.equals("28"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 28 + "'", int15 == 28);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-1));
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.minus(readableDuration3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        org.joda.time.DurationField durationField41 = offsetDateTimeField37.getRangeDurationField();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        boolean boolean45 = monthDay43.isSupported(dateTimeFieldType44);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((java.lang.Object) monthDay43);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay46, 22, locale48);
        java.lang.String str50 = offsetDateTimeField37.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        org.joda.time.DurationField durationField54 = delegatedDateTimeField53.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology55);
        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay(chronology58);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.MonthDay monthDay62 = monthDay59.withPeriodAdded(readablePeriod60, (int) (short) 100);
        int[] intArray64 = iSOChronology57.get((org.joda.time.ReadablePartial) monthDay62, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay(chronology66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.MonthDay monthDay70 = monthDay67.withPeriodAdded(readablePeriod68, (int) (short) 100);
        int[] intArray72 = iSOChronology65.get((org.joda.time.ReadablePartial) monthDay70, 0L);
        org.joda.time.DateTimeField dateTimeField73 = iSOChronology65.minuteOfDay();
        org.joda.time.MonthDay monthDay74 = monthDay62.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology65);
        org.joda.time.DateTime dateTime75 = dateTime56.toDateTime((org.joda.time.Chronology) iSOChronology65);
        org.joda.time.DateTime.Property property76 = dateTime56.era();
        org.joda.time.DateTime dateTime78 = dateTime56.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField80 = gregorianChronology79.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField81 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField80);
        java.util.Locale locale83 = null;
        java.lang.String str84 = delegatedDateTimeField81.getAsShortText((int) (byte) 100, locale83);
        org.joda.time.DateTimeFieldType dateTimeFieldType85 = delegatedDateTimeField81.getType();
        boolean boolean86 = dateTime78.isSupported(dateTimeFieldType85);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField53, dateTimeFieldType85, 31);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField89 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField37, dateTimeFieldType85);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "22" + "'", str49.equals("22"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DateTimeField[weekyear]" + "'", str50.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(iSOChronology57);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(gregorianChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "100" + "'", str84.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DurationField durationField7 = property6.getDurationField();
        boolean boolean8 = property6.isLeap();
        java.lang.Class<?> wildcardClass9 = property6.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        try {
            org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        long long7 = property4.remainder();
//        int int8 = property4.get();
//        org.joda.time.DurationField durationField9 = property4.getDurationField();
//        java.lang.String str10 = property4.getAsText();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28658966613L + "'", long7 == 28658966613L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
//        org.joda.time.DateTime.Property property6 = dateTime3.yearOfEra();
//        java.lang.String str7 = property6.getAsShortText();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019W396T164926.735Z" + "'", str5.equals("2019W396T164926.735Z"));
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology1.withZone(dateTimeZone8);
        long long13 = dateTimeZone8.adjustOffset(0L, true);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime3.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '#');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DurationField durationField7 = property6.getDurationField();
        boolean boolean8 = property6.isLeap();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        int[] intArray20 = iSOChronology13.get((org.joda.time.ReadablePartial) monthDay18, 0L);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) monthDay12, intArray20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(chronology23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (short) 100);
        org.joda.time.MonthDay monthDay29 = monthDay27.plusDays(0);
        java.lang.String str30 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) monthDay27);
        int int31 = monthDay12.compareTo((org.joda.time.ReadablePartial) monthDay27);
        try {
            int int32 = property6.compareTo((org.joda.time.ReadablePartial) monthDay27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "����W���T������.000" + "'", str30.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        boolean boolean14 = unsupportedDateTimeField9.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = unsupportedDateTimeField9.getType();
        try {
            long long18 = unsupportedDateTimeField9.addWrapField((long) 15, (-2548));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(monthDay6);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property9.getAsShortText(locale13);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property9.getFieldType();
//        java.lang.String str16 = property9.getAsText();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28" + "'", str11.equals("28"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "28" + "'", str14.equals("28"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "28" + "'", str16.equals("28"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int7 = skipDateTimeField6.getMaximumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText(0L, locale9);
        int int12 = skipDateTimeField6.get((long) 595);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (short) 100);
        int[] intArray24 = iSOChronology17.get((org.joda.time.ReadablePartial) monthDay22, 0L);
        gregorianChronology13.validate((org.joda.time.ReadablePartial) monthDay16, intArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay31 = monthDay28.withPeriodAdded(readablePeriod29, (int) (short) 100);
        org.joda.time.MonthDay monthDay33 = monthDay31.plusDays(0);
        java.lang.String str34 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) monthDay31);
        int int35 = monthDay16.compareTo((org.joda.time.ReadablePartial) monthDay31);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField38.getAsShortText((int) (byte) 100, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField38.getType();
        boolean boolean43 = monthDay16.isSupported(dateTimeFieldType42);
        int int44 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology45.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone47 = julianChronology45.getZone();
        try {
            org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) skipDateTimeField6, (org.joda.time.Chronology) julianChronology45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����W���T������.000" + "'", str34.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "100" + "'", str41.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
        org.junit.Assert.assertNotNull(julianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(chronology21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (short) 100);
        int[] intArray27 = iSOChronology20.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        gregorianChronology16.validate((org.joda.time.ReadablePartial) monthDay19, intArray27);
        int int29 = offsetDateTimeField14.getMaximumValue(readablePartial15, intArray27);
        try {
            long long32 = offsetDateTimeField14.set((long) (-2548), "-292275054");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for monthOfYear must be in the range [-292275022,-292275011]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275011) + "'", int29 == (-292275011));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((java.lang.Object) monthDay16);
        org.joda.time.MonthDay monthDay21 = monthDay16.minusMonths(30);
        int int22 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.DateTime dateTime26 = dateTime24.minusMonths(2);
        org.joda.time.DateTime.Property property27 = dateTime24.millisOfDay();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime24.withDurationAdded(readableDuration28, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField33.getAsShortText((int) (byte) 100, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = delegatedDateTimeField33.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField39 = gregorianChronology38.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField39);
        int int41 = dateTime24.get(dateTimeFieldType37);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType37, 0, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        org.joda.time.MonthDay monthDay20 = monthDay18.plusDays(0);
        java.lang.String str21 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) monthDay18);
        int int22 = monthDay3.compareTo((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay18.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay18.minus(readablePeriod25);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "����W���T������.000" + "'", str21.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology10 = gJChronology9.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(2019);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis(20);
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime17);
        try {
            org.joda.time.DateTime dateTime20 = dateTime11.withYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property9.getAsText(locale13);
//        java.lang.String str15 = property9.getName();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28" + "'", str11.equals("28"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "28" + "'", str14.equals("28"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField12.getType();
        int int15 = skipUndoDateTimeField12.get(0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1971 + "'", int15 == 1971);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField2.getAsText((long) 20, locale9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = buddhistChronology1.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("15");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (-292276974));
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        try {
            long long13 = unsupportedDateTimeField9.addWrapField((long) 222090, (-292275023));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        boolean boolean4 = delegatedDateTimeField2.isLeap((-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        int int21 = dateTime20.getEra();
        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getOffset();
        boolean boolean40 = offsetDateTimeField37.isLeap((long) (short) 10);
        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField37.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTimeField41);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        boolean boolean14 = dateTimeFormatter12.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        java.lang.String str14 = unsupportedDateTimeField9.toString();
        try {
            java.lang.String str16 = unsupportedDateTimeField9.getAsText(14329457797L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnsupportedDateTimeField" + "'", str14.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        long long8 = skipDateTimeField6.roundHalfFloor(0L);
        long long10 = skipDateTimeField6.roundHalfEven((long) 20);
        long long12 = skipDateTimeField6.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (-292275023));
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((java.lang.Object) monthDay16);
        org.joda.time.MonthDay monthDay21 = monthDay16.minusMonths(30);
        int int22 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = skipDateTimeField6.getAsShortText(28, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        long long7 = delegatedDateTimeField2.set(14329457797L, (int) (byte) 0);
        try {
            long long10 = delegatedDateTimeField2.set((long) (-292275053), "DateTimeField[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[monthOfYear]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152457742203L) + "'", long7 == (-62152457742203L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getLeapDurationField();
        boolean boolean6 = delegatedDateTimeField4.isLenient();
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((int) (short) 10, locale8);
        long long12 = delegatedDateTimeField4.add(31L, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, 9);
        long long17 = delegatedDateTimeField4.add(14329457797L, (long) 4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 315705600031L + "'", long12 == 315705600031L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 140732657797L + "'", long17 == 140732657797L);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        int int13 = property9.getMaximumValue();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2);
//        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTime dateTime21 = dateTime17.withDayOfYear((int) ' ');
//        org.joda.time.DateTime.Property property22 = dateTime17.dayOfYear();
//        int int23 = property9.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DurationField durationField24 = property9.getDurationField();
//        org.joda.time.DateTimeField dateTimeField25 = property9.getField();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = property9.getAsText(locale26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "28" + "'", str11.equals("28"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 30 + "'", int13 == 30);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "28" + "'", str27.equals("28"));
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        long long8 = dateTimeZone5.adjustOffset(1560630256002L, false);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560630256002L + "'", long8 == 1560630256002L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology10 = gJChronology9.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(2019);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis(20);
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime17);
        try {
            long long24 = limitChronology18.getDateTimeMillis((long) 12, (int) ' ', 6, 12, (-292275053));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2018-12-18T16:00:00.000-08:00 (JulianChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(20);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(chronology4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, (int) (short) 100);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) monthDay8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(2019);
        org.joda.time.DateTime dateTime5 = dateTime3.withEra((int) (byte) 0);
        try {
            java.lang.String str7 = dateTime5.toString("yearOfEra");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("-28800000");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((-25200000));
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths(2);
        org.joda.time.DateTime.Property property9 = dateTime6.millisOfDay();
        org.joda.time.Interval interval10 = property9.toInterval();
        int int11 = property9.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property9.addWrapFieldToCopy(20);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.minuteOfDay();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology17 = gJChronology16.withUTC();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
        org.joda.time.Chronology chronology19 = julianChronology14.withZone(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime(dateTimeZone18);
        org.joda.time.DateTime dateTime22 = dateTime13.minusSeconds(1970);
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86399999 + "'", int11 == 86399999);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 10);
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
//        boolean boolean9 = dateTime6.isAfter(0L);
//        int int10 = dateTime6.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 49 + "'", int10 == 49);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(2);
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime5.era();
        java.util.Locale locale12 = null;
        int int13 = property11.getMaximumTextLength(locale12);
        java.util.Locale locale14 = null;
        java.lang.String str15 = property11.getAsText(locale14);
        java.util.Locale locale16 = null;
        int int17 = property11.getMaximumTextLength(locale16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AD" + "'", str15.equals("AD"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        try {
            long long11 = unsupportedDateTimeField9.roundFloor((long) 595);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        int int4 = dateTime1.getSecondOfMinute();
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(chronology5);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.remainder((long) ' ');
        int int41 = offsetDateTimeField37.getMinimumValue((long) ' ');
        long long43 = offsetDateTimeField37.roundCeiling((long) 28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 259200032L + "'", long39 == 259200032L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292275023) + "'", int41 == (-292275023));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 31795200000L + "'", long43 == 31795200000L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField4, (-1));
        int int7 = skipDateTimeField6.getMaximumValue();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(chronology8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (short) 100);
        boolean boolean13 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        boolean boolean19 = monthDay12.isAfter((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.MonthDay monthDay21 = monthDay18.minusDays(20);
        org.joda.time.MonthDay monthDay23 = monthDay21.plusDays(4);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(chronology30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.MonthDay monthDay34 = monthDay31.withPeriodAdded(readablePeriod32, (int) (short) 100);
        int[] intArray36 = iSOChronology29.get((org.joda.time.ReadablePartial) monthDay34, 0L);
        gregorianChronology25.validate((org.joda.time.ReadablePartial) monthDay28, intArray36);
        java.util.Locale locale39 = null;
        try {
            int[] intArray40 = skipDateTimeField6.set((org.joda.time.ReadablePartial) monthDay21, 0, intArray36, "73457595", locale39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"73457595\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = monthDay1.isSupported(dateTimeFieldType2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) monthDay1);
        org.joda.time.MonthDay monthDay6 = monthDay1.minusMonths(30);
        org.joda.time.MonthDay monthDay8 = monthDay1.plusDays(2019);
        org.joda.time.MonthDay.Property property9 = monthDay1.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.minus((long) 'a');
        org.joda.time.DateTime.Property property14 = dateTime11.yearOfEra();
        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (short) 10);
        boolean boolean17 = property9.equals((java.lang.Object) dateTime16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear(20);
        try {
            org.joda.time.Instant instant4 = org.joda.time.Instant.parse("BuddhistChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[America/Los_A...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
//        int int4 = dateTime1.getSecondOfMinute();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gJChronology5.weeks();
//        boolean boolean7 = dateTime1.equals((java.lang.Object) gJChronology5);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology5);
//        int int9 = gJChronology5.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = buddhistChronology1.toString();
        org.joda.time.Chronology chronology3 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = buddhistChronology1.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str2.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(2);
//        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((int) (byte) 1);
//        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) (short) 10);
//        java.lang.String str8 = dateTime3.toString();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 100);
//        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay13);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
//        boolean boolean20 = monthDay13.isAfter((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(chronology24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.MonthDay monthDay28 = monthDay25.withPeriodAdded(readablePeriod26, (int) (short) 100);
//        int[] intArray30 = iSOChronology23.get((org.joda.time.ReadablePartial) monthDay28, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(chronology32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.MonthDay monthDay36 = monthDay33.withPeriodAdded(readablePeriod34, (int) (short) 100);
//        int[] intArray38 = iSOChronology31.get((org.joda.time.ReadablePartial) monthDay36, 0L);
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology31.minuteOfDay();
//        org.joda.time.MonthDay monthDay40 = monthDay28.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DateTime dateTime41 = dateTime22.toDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DateTime.Property property42 = dateTime22.era();
//        org.joda.time.DateTime dateTime44 = dateTime22.withMillisOfDay((int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = delegatedDateTimeField47.getAsShortText((int) (byte) 100, locale49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField47.getType();
//        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
//        int int53 = monthDay13.indexOf(dateTimeFieldType51);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) 110L, "10");
//        int int57 = dateTime3.get(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-09-28T16:49:32.115Z" + "'", str8.equals("2019-09-28T16:49:32.115Z"));
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "100" + "'", str50.equals("100"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "15", 31, (int) (byte) 0);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 86399999);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(110L);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str12 = fixedDateTimeZone4.getShortName((-1L));
        try {
            org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.031" + "'", str12.equals("+00:00:00.031"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        int int38 = offsetDateTimeField37.getMaximumValue();
        boolean boolean39 = offsetDateTimeField37.isLenient();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(chronology40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        boolean boolean43 = monthDay41.isSupported(dateTimeFieldType42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay45 = monthDay41.minus(readablePeriod44);
        int[] intArray47 = new int[] {};
        try {
            int[] intArray49 = offsetDateTimeField37.set((org.joda.time.ReadablePartial) monthDay41, (-292275053), intArray47, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292275053");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 292279024 + "'", int38 == 292279024);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(intArray47);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
//        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
//        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
//        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime21 = dateTime20.withEarlierOffsetAtOverlap();
//        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = dateTime20.plusMinutes(31);
//        org.joda.time.DateTime.Property property25 = dateTime24.hourOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology26);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusMonths(2);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusYears((int) (byte) 1);
//        org.joda.time.DateTime dateTime33 = dateTime29.withDayOfYear((int) (short) 10);
//        long long34 = property25.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime33);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1574959772550L + "'", long22 == 1574959772550L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 7728L + "'", long34 == 7728L);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019W161T202410.781Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 97);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays(0);
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.MonthDay.Property property9 = monthDay5.dayOfMonth();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        int int12 = property9.getMaximumValueOverall();
//        boolean boolean14 = property9.equals((java.lang.Object) "yearOfEra");
//        java.util.Locale locale15 = null;
//        int int16 = property9.getMaximumShortTextLength(locale15);
//        org.joda.time.MonthDay monthDay18 = property9.addToCopy(20);
//        int int19 = property9.get();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField37.getAsText((long) 15, locale39);
        org.joda.time.DurationField durationField41 = offsetDateTimeField37.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2001" + "'", str40.equals("2001"));
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
        int[] intArray9 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay7, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (short) 100);
        int[] intArray17 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology10.minuteOfDay();
        org.joda.time.MonthDay monthDay19 = monthDay7.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime20 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.minus(readablePeriod21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("DateTimeField[weekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[weekyear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay5, 0L);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.minuteOfDay();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology16 = gJChronology15.withUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.Chronology chronology18 = julianChronology13.withZone(dateTimeZone17);
        org.joda.time.Chronology chronology19 = gJChronology11.withZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.Chronology chronology21 = iSOChronology0.withZone(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019W161T202414.069Z", (java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (short) 100);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019W161T202414.069Z" + "'", str7.equals("2019W161T202414.069Z"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 100 + "'", number9.equals((short) 100));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology3 = gJChronology2.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        boolean boolean8 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField6, 86399999);
        int int14 = skipUndoDateTimeField12.get((long) (byte) 1);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = monthDay16.isSupported(dateTimeFieldType17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay16.minus(readablePeriod19);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = buddhistChronology23.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology23, dateTimeField26, (-1));
        long long30 = skipDateTimeField28.roundHalfFloor(0L);
        long long32 = skipDateTimeField28.roundHalfEven((long) 20);
        long long34 = skipDateTimeField28.roundHalfEven(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, (-292275023));
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay47 = monthDay44.withPeriodAdded(readablePeriod45, (int) (short) 100);
        int[] intArray49 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay47, 0L);
        gregorianChronology38.validate((org.joda.time.ReadablePartial) monthDay41, intArray49);
        int int51 = offsetDateTimeField36.getMaximumValue(readablePartial37, intArray49);
        java.util.Locale locale53 = null;
        try {
            int[] intArray54 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) monthDay20, (-28800000), intArray49, "-292275054", locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1971 + "'", int14 == 1971);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str24.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-292275011) + "'", int51 == (-292275011));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy((int) (byte) 100);
        org.joda.time.DurationField durationField7 = property4.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTimeField dateTimeField9 = property4.getField();
        int int10 = property4.getMinimumValueOverall();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property4.getAsShortText(locale11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 'a');
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        int int6 = property4.get();
        org.joda.time.DateTime dateTime7 = property4.getDateTime();
        java.lang.String str8 = property4.getAsText();
        int int9 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        long long39 = offsetDateTimeField37.roundHalfFloor((long) 100);
        int int41 = offsetDateTimeField37.getLeapAmount(0L);
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(chronology42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay46 = monthDay43.withPeriodAdded(readablePeriod44, (int) (short) 100);
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        long long50 = offsetDateTimeField37.roundHalfFloor((long) 22);
        int int51 = offsetDateTimeField37.getMaximumValue();
        java.util.Locale locale54 = null;
        try {
            long long55 = offsetDateTimeField37.set(345600000L, "dayOfMonth", locale54);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfMonth\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-259200000L) + "'", long39 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279024 + "'", int48 == 292279024);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200000L) + "'", long50 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292279024 + "'", int51 == 292279024);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
        int[] intArray13 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay11, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(chronology15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (short) 100);
        int[] intArray21 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay19, 0L);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology14.minuteOfDay();
        org.joda.time.MonthDay monthDay23 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime24 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property25 = dateTime5.era();
        org.joda.time.DateTime dateTime27 = dateTime5.withMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsShortText((int) (byte) 100, locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        boolean boolean35 = dateTime27.isSupported(dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType34, 31);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(chronology38);
        int int40 = monthDay39.size();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(chronology44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        boolean boolean47 = monthDay45.isSupported(dateTimeFieldType46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.minus(readablePeriod48);
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) (byte) 100);
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        int int54 = monthDay39.indexOf(dateTimeFieldType53);
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay(chronology55);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.MonthDay monthDay59 = monthDay56.withPeriodAdded(readablePeriod57, (int) (short) 100);
        org.joda.time.MonthDay monthDay61 = monthDay59.plusDays(0);
        boolean boolean62 = monthDay39.isBefore((org.joda.time.ReadablePartial) monthDay59);
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay(chronology64);
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.MonthDay monthDay68 = monthDay65.withPeriodAdded(readablePeriod66, (int) (short) 100);
        int[] intArray70 = iSOChronology63.get((org.joda.time.ReadablePartial) monthDay68, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology72 = null;
        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay(chronology72);
        org.joda.time.ReadablePeriod readablePeriod74 = null;
        org.joda.time.MonthDay monthDay76 = monthDay73.withPeriodAdded(readablePeriod74, (int) (short) 100);
        int[] intArray78 = iSOChronology71.get((org.joda.time.ReadablePartial) monthDay76, 0L);
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology71.minuteOfDay();
        org.joda.time.MonthDay monthDay80 = monthDay68.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology71);
        org.joda.time.ReadablePeriod readablePeriod81 = null;
        org.joda.time.MonthDay monthDay83 = monthDay80.withPeriodAdded(readablePeriod81, 31);
        int int84 = monthDay59.compareTo((org.joda.time.ReadablePartial) monthDay80);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 292279024 + "'", int52 == 292279024);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(monthDay83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsShortText((int) (byte) 100, locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = unsupportedDateTimeField9.getType();
        long long13 = unsupportedDateTimeField9.getDifferenceAsLong((long) (-28800000), 14329457235L);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay15.withPeriodAdded(readablePeriod16, (int) (short) 100);
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay18);
        boolean boolean21 = monthDay18.equals((java.lang.Object) 10.0f);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MonthDay monthDay23 = monthDay18.withChronologyRetainFields(chronology22);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(chronology26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay30 = monthDay27.withPeriodAdded(readablePeriod28, (int) (short) 100);
        int[] intArray32 = iSOChronology25.get((org.joda.time.ReadablePartial) monthDay30, 0L);
        try {
            int[] intArray34 = unsupportedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) monthDay18, 8, intArray32, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray32);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (short) 100);
//        boolean boolean6 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(chronology7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (short) 100);
//        boolean boolean12 = monthDay5.isAfter((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.MonthDay monthDay14 = monthDay5.plusDays(4);
//        java.lang.String str15 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "����-06-15T��:��" + "'", str15.equals("����-06-15T��:��"));
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (short) 100);
//        org.joda.time.MonthDay monthDay9 = monthDay7.plusDays(0);
//        java.lang.String str10 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.MonthDay.Property property11 = monthDay7.dayOfMonth();
//        long long13 = julianChronology0.set((org.joda.time.ReadablePartial) monthDay7, 1560630256002L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsShortText((int) (byte) 100, locale18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField16.getType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField22 = gregorianChronology21.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField22);
//        try {
//            int int24 = monthDay7.get(dateTimeFieldType20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "����W���T������.000" + "'", str10.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561753456002L + "'", long13 == 1561753456002L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(chronology2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, (int) (short) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology1.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter12.withPivotYear((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology10 = gJChronology9.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(2019);
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis(20);
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime17);
        try {
            long long26 = limitChronology18.getDateTimeMillis(31, (int) (short) -1, 10, 15, (-292275053), (int) 'a', 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
    }
}

