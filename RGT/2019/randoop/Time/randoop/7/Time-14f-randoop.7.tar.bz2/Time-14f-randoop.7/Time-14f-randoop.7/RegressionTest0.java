import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(1, (int) '#', (int) (short) 1, (int) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = copticChronology0.set(readablePartial1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, (int) (short) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) -1, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(0, (int) 'a', (org.joda.time.Chronology) buddhistChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            int int4 = dateTime1.get(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
//        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
//        try {
//            org.joda.time.DateTime dateTime5 = dateTimeFormatter0.parseDateTime("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T155959.999-0800" + "'", str2.equals("1969365T155959.999-0800"));
//        org.junit.Assert.assertNull(chronology3);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((int) ' ', (int) (short) 10, (org.joda.time.Chronology) copticChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 13");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
//        org.joda.time.Chronology chronology5 = dateTimeFormatter0.getChronolgy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T155959.999-0800" + "'", str2.equals("1969365T155959.999-0800"));
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNull(chronology5);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            boolean boolean5 = monthDay3.isEqual(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone10.getShortName(100L, locale12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DurationField durationField15 = buddhistChronology14.eras();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-1), (int) (short) 1, (int) (short) 10, 0, (int) (byte) 10, (int) ' ', (org.joda.time.Chronology) buddhistChronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        java.util.Locale locale6 = null;
//        try {
//            org.joda.time.DateTime dateTime7 = property4.setCopy("", locale6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 166 + "'", int3 == 166);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = julianChronology1.getDateTimeMillis(31, 10, (int) (short) 1, 12, 3569, 3569, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3569 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) property3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
//        int int4 = dateTime3.getYearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        try {
//            int int6 = dateTime3.get(dateTimeFieldType5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime5.toString("hi!", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology8);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (byte) 0, (int) (short) 10, (-1), (int) (byte) 10, 4, (int) (byte) 100, (int) (byte) 100, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        try {
            java.lang.String str5 = dateTime3.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("+00:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(2019, (int) (short) 100, (int) ' ', (int) (byte) 1, (int) (short) 100, 2019, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        int int8 = property7.getMaximumValueOverall();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withCenturyOfEra((int) '#');
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property7, (java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime14 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime18.toMutableDateTimeISO();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime18);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(4, (int) 'a', 1970, (int) '4', (-1), chronology22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) 'a', 69, 0, 3569, (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3569 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        int int11 = monthDay6.size();
//        java.lang.String str12 = monthDay6.toString();
//        org.joda.time.DurationFieldType durationFieldType13 = null;
//        try {
//            org.joda.time.MonthDay monthDay15 = monthDay6.withFieldAdded(durationFieldType13, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "--06-15" + "'", str12.equals("--06-15"));
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            int int19 = dateTime9.get(dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(12);
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+12:00" + "'", str2.equals("+12:00"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField6 = buddhistChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField7 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField6 = buddhistChronology1.months();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        int int12 = property11.getMaximumValueOverall();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime16 = dateTime14.withCenturyOfEra((int) '#');
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property11, (java.lang.Object) dateTime14);
        org.joda.time.DateTime dateTime18 = property11.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(0);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        try {
            boolean boolean22 = monthDay6.isBefore((org.joda.time.ReadablePartial) localTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        java.io.Writer writer4 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        int int8 = property7.getMaximumValueOverall();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withCenturyOfEra((int) '#');
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property7, (java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime14 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime18.toMutableDateTimeISO();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime18);
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("+12:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+12:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        try {
            long long7 = julianChronology1.getDateTimeMillis(0, 166, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getYear();
//        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
//        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
//        org.joda.time.DateTime dateTime6 = property5.roundFloorCopy();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology9 = copticChronology8.withUTC();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.clockhourOfDay();
//        int int11 = dateTime6.get(dateTimeField10);
//        int int12 = dateTime6.getMinuteOfHour();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 34 + "'", int12 == 34);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = buddhistChronology1.get(readablePeriod2, (long) 'a', (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime8 = property6.addWrapFieldToCopy((int) (short) -1);
        int int9 = dateTime8.getEra();
        boolean boolean11 = dateTime8.isEqual(0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        int int10 = monthDay6.indexOf(dateTimeFieldType9);
        int int11 = monthDay6.size();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = monthDay6.isSupported(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            long long4 = dateTimeFormatter0.parseMillis("--06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(10, 34);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("--06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        java.io.Writer writer3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+12:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+12:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        long long1 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560630866054L + "'", long1 == 1560630866054L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getYear();
//        boolean boolean6 = dateTime3.isBefore((long) (short) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime3.isSupported(dateTimeFieldType7);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTimeISO();
        int int6 = dateTime5.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField11 = buddhistChronology8.hours();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField13 = buddhistChronology8.seconds();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) '4', (int) (byte) 100, (int) (byte) 1, (int) 'a', 69, (int) ' ', 3569, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 10, 166, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        try {
            org.joda.time.MonthDay monthDay10 = monthDay6.withMonthOfYear(166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("1969365T235959.999Z", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 1969365T235959.999Z");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.util.Date date9 = dateTime5.toDate();
        boolean boolean11 = dateTime5.equals((java.lang.Object) 0L);
        int int12 = dateTime5.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1969365T155959.999-0800", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969365T155959.999-0800/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long14 = gJChronology6.getDateTimeMillis(2, (int) '4', 2019, (int) ' ', 2, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField9 = buddhistChronology8.eras();
        try {
            long long12 = durationField9.subtract((long) 4, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "31");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDateTime();
        boolean boolean2 = dateTimeFormatter1.isPrinter();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.parse("org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay6, locale7);
        org.joda.time.Chronology chronology9 = monthDay6.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.roundFloorCopy();
        int int5 = dateTime4.getWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969365T235959.999Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.withCenturyOfEra((int) '#');
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone15.getShortName(100L, locale17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime20 = dateTime9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime24 = dateTime22.withCenturyOfEra((int) '#');
        int int25 = dateTime24.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone30.getShortName(100L, locale32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        org.joda.time.DateTime dateTime35 = dateTime24.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        org.joda.time.DateTime dateTime36 = dateTime20.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        try {
            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((int) '4', (int) '4', 20, 0, (int) (short) 0, 20, (org.joda.time.DateTimeZone) fixedDateTimeZone30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsText(locale6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) '#');
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withYearOfCentury((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("January");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"January\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("+12:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: +12:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.year();
        java.lang.String str8 = dateTime3.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3570-01-01T00:00:00.100Z" + "'", str8.equals("3570-01-01T00:00:00.100Z"));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        int int10 = monthDay6.indexOf(dateTimeFieldType9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        int int13 = dateTime12.getEra();
        int int14 = dateTime12.getDayOfYear();
        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
        int int17 = property16.getMaximumValue();
        java.lang.String str18 = property16.getAsText();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField10 = property2.getField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.yearOfEra();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = monthDay17.indexOf(dateTimeFieldType18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = monthDay17.indexOf(dateTimeFieldType20);
        int int22 = monthDay17.size();
        java.lang.String str23 = monthDay17.toString();
        boolean boolean24 = fixedDateTimeZone9.equals((java.lang.Object) monthDay17);
        boolean boolean25 = fixedDateTimeZone9.isFixed();
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(9, (-1), 2, 3569, 14, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3569 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "--01-01" + "'", str23.equals("--01-01"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1970);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField12);
        java.lang.String str15 = skipDateTimeField13.getAsText((long) 4);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField13.getAsText(3569, locale17);
        int int19 = skipDateTimeField13.getMinimumValue();
        long long21 = skipDateTimeField13.roundHalfCeiling((long) 100);
        int int22 = dateTime3.get((org.joda.time.DateTimeField) skipDateTimeField13);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January" + "'", str15.equals("January"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3569" + "'", str18.equals("3569"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay6, locale7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            boolean boolean10 = monthDay6.isEqual(readablePartial9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str7 = dateTimeFormatter5.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) copticChronology8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1), 0, 0, (int) (byte) 1, (int) (short) 100, (org.joda.time.Chronology) copticChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969365T235959.999Z" + "'", str7.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(34, 18062);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18096 + "'", int2 == 18096);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 9, (java.lang.Number) 18062, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withEra(2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField6 = buddhistChronology1.years();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        int int10 = property9.getMaximumValueOverall();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra((int) '#');
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property9, (java.lang.Object) dateTime12);
        java.util.Date date16 = dateTime12.toDate();
        boolean boolean18 = dateTime12.equals((java.lang.Object) 0L);
        org.joda.time.DateTime.Property property19 = dateTime12.year();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.yearOfEra();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.DurationField durationField24 = buddhistChronology21.hours();
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.DurationField durationField26 = buddhistChronology21.years();
        org.joda.time.DateTime dateTime27 = dateTime12.toDateTime((org.joda.time.Chronology) buddhistChronology21);
        boolean boolean28 = buddhistChronology1.equals((java.lang.Object) dateTime27);
        try {
            long long33 = buddhistChronology1.getDateTimeMillis(69, 18062, (int) (byte) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18062 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.yearOfEra();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DurationField durationField6 = buddhistChronology3.hours();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology3);
        java.lang.String str9 = monthDay7.toString("3569");
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3569" + "'", str9.equals("3569"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported", (int) (byte) 0, 3569, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported must be in the range [3569,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        int int8 = dateTime5.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), 18062);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 18062");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundFloorCopy();
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        int int8 = dateMidnight7.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.yearOfEra();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology19 = copticChronology18.withUTC();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) monthDay17, chronology19);
        boolean boolean21 = dateTime11.equals((java.lang.Object) monthDay20);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType23 = monthDay20.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.util.Date date9 = dateTime5.toDate();
        boolean boolean11 = dateTime5.equals((java.lang.Object) 0L);
        org.joda.time.DateTime.Property property12 = dateTime5.year();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.yearOfEra();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DurationField durationField17 = buddhistChronology14.hours();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DurationField durationField19 = buddhistChronology14.years();
        org.joda.time.DateTime dateTime20 = dateTime5.toDateTime((org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.DateTime dateTime23 = dateTime20.withFieldAdded(durationFieldType21, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology1);
        try {
            long long8 = julianChronology1.getDateTimeMillis(2, 14, 4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone5.getName(0L, locale9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra((int) '#');
        int int15 = dateTime14.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getShortName(100L, locale22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime25 = dateTime14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, 52L);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property31 = dateTime30.dayOfMonth();
        int int32 = property31.getMaximumValueOverall();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime36 = dateTime34.withCenturyOfEra((int) '#');
        boolean boolean37 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property31, (java.lang.Object) dateTime34);
        org.joda.time.Chronology chronology38 = dateTime34.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
        boolean boolean40 = dateTime34.isSupported(dateTimeFieldType39);
        org.joda.time.DateTimeZone dateTimeZone41 = dateTime34.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, (org.joda.time.ReadableInstant) dateTime34, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeZone41);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        try {
            long long9 = copticChronology3.getDateTimeMillis((int) (short) 10, 0, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 14, 2019, 3569, 18062, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3569 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.nextTransition((long) '4');
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 31);
        long long14 = fixedDateTimeZone4.nextTransition(0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1969365T235959.999Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969365T235959.999Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute(18062);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18062 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType5, (int) (byte) 100, 4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [4,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter2.parseMutableDateTime("--01-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--01-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getName((long) 0, locale10);
        long long14 = fixedDateTimeZone4.adjustOffset((long) 52, false);
        java.lang.String str16 = fixedDateTimeZone4.getName(0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTime dateTime6 = dateTimeFormatter0.parseDateTime("1969365T155959.999-0800");
        boolean boolean7 = dateTime6.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("ISOChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "--01-01");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        int int10 = monthDay6.indexOf(dateTimeFieldType9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        int int13 = dateTime12.getEra();
        int int14 = dateTime12.getDayOfYear();
        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
        org.joda.time.ReadablePartial readablePartial17 = null;
        try {
            boolean boolean18 = monthDay6.isAfter(readablePartial17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        int int10 = monthDay6.indexOf(dateTimeFieldType9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        int int13 = dateTime12.getEra();
        int int14 = dateTime12.getDayOfYear();
        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        int int21 = dateTime20.getYear();
        boolean boolean23 = dateTime20.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property24 = dateTime20.secondOfDay();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime26 = dateTime25.withEarlierOffsetAtOverlap();
        int int27 = property24.compareTo((org.joda.time.ReadableInstant) dateTime25);
        int int28 = property16.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DurationField durationField29 = property16.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 100, 1560630866054L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560630866154L + "'", long2 == 1560630866154L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.dayOfMonth();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField(chronology17, dateTimeField19);
        org.joda.time.DurationField durationField21 = skipDateTimeField20.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipDateTimeField20.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType22);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) copticChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        try {
            long long6 = julianChronology0.getDateTimeMillis(1970, (int) (byte) 0, 31, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.plusHours(2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0, 1970, chronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone24.getShortName((long) 9, locale32);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property36 = dateTime35.dayOfMonth();
        int int37 = property36.getMaximumValueOverall();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime41 = dateTime39.withCenturyOfEra((int) '#');
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property36, (java.lang.Object) dateTime39);
        org.joda.time.Chronology chronology43 = dateTime39.getChronology();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (org.joda.time.ReadableInstant) dateTime39);
        try {
            long long49 = gJChronology44.getDateTimeMillis((int) (byte) 1, (int) (short) 100, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(gJChronology44);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.yearOfEra();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = monthDay7.indexOf(dateTimeFieldType8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = monthDay7.indexOf(dateTimeFieldType10);
        int int12 = monthDay7.size();
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "�:�� �" + "'", str13.equals("�:�� �"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime9.withWeekyear(166);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getName((long) 0, locale10);
        int int13 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField[] dateTimeFieldArray1 = monthDay0.getFields();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTimeFieldArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.hours();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone8.getShortName(100L, locale10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        long long14 = fixedDateTimeZone8.nextTransition((long) '4');
        org.joda.time.Chronology chronology15 = copticChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        long long18 = cachedDateTimeZone16.nextTransition((long) (short) 1);
        long long20 = cachedDateTimeZone16.nextTransition(0L);
        long long22 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone16, (long) (short) 1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone16, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = mutableDateTime8.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes(12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = copticChronology0.equals(obj2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay6, locale7);
        java.util.Locale locale11 = null;
        try {
            long long12 = skipDateTimeField3.set(12L, "", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6" + "'", str8.equals("6"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        long long15 = fixedDateTimeZone9.nextTransition((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime18 = instant17.toMutableDateTime();
        int int21 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime18, "�:�� �", 3569);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-3570) + "'", int21 == (-3570));
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
//        int int3 = property2.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
//        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.yearOfEra();
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
//        int int17 = monthDay15.indexOf(dateTimeFieldType16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        int int19 = monthDay15.indexOf(dateTimeFieldType18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        int int22 = dateTime21.getEra();
//        int int23 = dateTime21.getDayOfYear();
//        org.joda.time.DateTime dateTime24 = monthDay15.toDateTime((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property25 = dateTime21.secondOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime21.withYearOfCentury((int) '#');
//        long long28 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 166 + "'", int23 == 166);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-18062L) + "'", long28 == (-18062L));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getEra();
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withDate(166, 20, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getEra();
        int int3 = dateTime1.getYearOfEra();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        try {
            org.joda.time.Instant instant6 = new org.joda.time.Instant((java.lang.Object) property4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        int int31 = dateTime30.getDayOfYear();
        org.joda.time.DateTime dateTime33 = dateTime30.plusHours((-1));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        int int10 = dateTime9.getEra();
        int int11 = dateTime9.getYearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
        try {
            org.joda.time.DateTime dateTime15 = dateTime3.withField(dateTimeFieldType13, 34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 34 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 1560630866054L, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("31", 2019, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for 31 must be in the range [10,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        boolean boolean5 = julianChronology1.equals((java.lang.Object) buddhistChronology4);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        try {
            long long11 = buddhistChronology1.getDateTimeMillis(100, (int) (byte) 0, 12, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        try {
            org.joda.time.DateTimeField dateTimeField2 = monthDay0.getField((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 52");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        long long6 = durationField3.subtract((long) 'a', (int) 'a');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-255139199903L) + "'", long6 == (-255139199903L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay12 = dateTime8.toTimeOfDay();
        int int13 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay12);
        try {
            long long16 = skipDateTimeField3.set((long) 'a', "3570-01-01T00:00:00.100Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"3570-01-01T00:00:00.100Z\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(timeOfDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType5, 18062, 69, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18062 for monthOfYear must be in the range [69,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipDateTimeField3.getAsText((long) 1, locale5);
        org.joda.time.DateTimeField dateTimeField7 = skipDateTimeField3.getWrappedField();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField3.getAsText(0L, locale9);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January" + "'", str6.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January" + "'", str10.equals("January"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime1.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        int int7 = property6.getMinimumValue();
        boolean boolean8 = property6.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            long long24 = zonedChronology16.getDateTimeMillis((int) (byte) 100, 2019, 0, (int) (byte) 1, 18062, (int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.era();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay();
//        long long4 = buddhistChronology1.set((org.joda.time.ReadablePartial) monthDay2, 12L);
//        org.joda.time.LocalDate localDate6 = monthDay2.toLocalDate(20);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 14256000012L + "'", long4 == 14256000012L);
//        org.junit.Assert.assertNotNull(localDate6);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.centuryOfEra();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone21.getShortName(100L, locale23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long27 = fixedDateTimeZone21.nextTransition((long) '4');
        org.joda.time.Chronology chronology28 = copticChronology15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long31 = cachedDateTimeZone29.nextTransition((long) (short) 1);
        boolean boolean32 = gJChronology13.equals((java.lang.Object) cachedDateTimeZone29);
        try {
            org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(2, (int) (byte) 1, 0, 166, (int) (byte) -1, (int) (short) 10, 2019, (org.joda.time.DateTimeZone) cachedDateTimeZone29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long18 = gregorianChronology10.getDateTimeMillis(12, 3569, 14, 69, 3569, 20, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getYear();
//        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusSeconds(100);
//        java.lang.String str7 = dateTime6.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15T20:33:00.798Z" + "'", str7.equals("2019-06-15T20:33:00.798Z"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipDateTimeField3.getAsText((long) 4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsText(3569, locale7);
        int int10 = skipDateTimeField3.get(1735776000069L);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.yearOfEra();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DurationField durationField15 = buddhistChronology12.hours();
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology12);
        int[] intArray18 = null;
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = skipDateTimeField3.set((org.joda.time.ReadablePartial) monthDay16, 0, intArray18, "31", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3569" + "'", str8.equals("3569"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(monthDay16);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.centuryOfEra();
        try {
            long long12 = gJChronology6.getDateTimeMillis((int) (short) 1, (int) (short) 100, (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) 52);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipDateTimeField3.getAsText((long) 1, locale5);
        org.joda.time.DateTimeField dateTimeField7 = skipDateTimeField3.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.yearOfEra();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = monthDay14.indexOf(dateTimeFieldType15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        int int18 = monthDay14.indexOf(dateTimeFieldType17);
        int[] intArray24 = new int[] { 9, (byte) 10, (short) 100, '4', 69 };
        int int25 = skipDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay14, intArray24);
        long long28 = skipDateTimeField3.addWrapField(1L, (int) 'a');
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January" + "'", str6.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2678400001L + "'", long28 == 2678400001L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipDateTimeField3.getAsText((long) 1, locale5);
        org.joda.time.DateTimeField dateTimeField7 = skipDateTimeField3.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.yearOfEra();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = monthDay14.indexOf(dateTimeFieldType15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        int int18 = monthDay14.indexOf(dateTimeFieldType17);
        int[] intArray24 = new int[] { 9, (byte) 10, (short) 100, '4', 69 };
        int int25 = skipDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay14, intArray24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone30.getShortName(100L, locale32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.dayOfMonth();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField(chronology36, dateTimeField38);
        org.joda.time.DurationField durationField40 = skipDateTimeField39.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField39.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35, dateTimeFieldType41);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January" + "'", str6.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getEra();
        int int3 = dateTime1.getYearOfEra();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
        org.joda.time.DateTime dateTime6 = dateTime1.withCenturyOfEra((int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.Chronology chronology5 = dateTimeFormatter4.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("January", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: January");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("3569");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone6.getShortName(100L, locale8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long12 = fixedDateTimeZone6.nextTransition((long) '4');
        org.joda.time.Chronology chronology13 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean15 = fixedDateTimeZone6.isFixed();
        int int17 = fixedDateTimeZone6.getOffset(4492800001L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported", "3569");
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) '#');
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime4.toYearMonthDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipDateTimeField3.getAsText((long) 4);
        int int6 = skipDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.lang.String str9 = property2.getAsShortText();
        java.lang.String str10 = property2.getAsText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.yearOfEra();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology19 = copticChronology18.withUTC();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) monthDay17, chronology19);
        boolean boolean21 = dateTime11.equals((java.lang.Object) monthDay20);
        int int22 = monthDay20.size();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(18096);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-18096) + "'", int1 == (-18096));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.yearOfEra();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = monthDay7.indexOf(dateTimeFieldType8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = monthDay7.indexOf(dateTimeFieldType10);
        int int12 = monthDay7.size();
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        java.lang.StringBuffer stringBuffer14 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer14, 1735776000069L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "�:�� �" + "'", str13.equals("�:�� �"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) '#');
        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = gJChronology6.getMinimumDaysInFirstWeek();
        java.lang.String str8 = gJChronology6.toString();
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[]" + "'", str8.equals("GJChronology[]"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime3.era();
        int int7 = dateTime3.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3570 + "'", int7 == 3570);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) -1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getEra();
        int int3 = dateTime1.getYearOfEra();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.MonthDay monthDay5 = monthDay3.plusDays(9);
        org.joda.time.MonthDay monthDay7 = monthDay3.plusDays((int) (short) -1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GJChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        try {
            long long6 = julianChronology0.getDateTimeMillis((int) (byte) 0, (int) (short) 100, 0, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.weekyearOfCentury();
        java.lang.Class<?> wildcardClass8 = dateTimeField7.getClass();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField11 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType9, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.weekyearOfCentury();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, 18062, (int) 'a', 18096, 31, 0, (int) (byte) 10, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18062 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipDateTimeField3.getAsText((long) 1, locale5);
        org.joda.time.DateTimeField dateTimeField7 = skipDateTimeField3.getWrappedField();
        long long9 = skipDateTimeField3.roundHalfCeiling(100L);
        long long11 = skipDateTimeField3.roundHalfCeiling((long) (-18096));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January" + "'", str6.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        int int6 = dateTime3.getMinuteOfHour();
        org.joda.time.DateTime dateTime8 = dateTime3.withDayOfYear((int) '#');
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay6, locale7);
        long long10 = skipDateTimeField3.roundCeiling((long) (short) -1);
        long long12 = skipDateTimeField3.remainder((long) 10);
        int int14 = skipDateTimeField3.getLeapAmount(52L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6" + "'", str8.equals("6"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 32054400052L, (java.lang.Number) 9, (java.lang.Number) 1560630866054L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("+12:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+12:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.Chronology chronology9 = dateTime5.getChronology();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra((int) '#');
        int int14 = dateTime13.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale21 = null;
        java.lang.String str22 = fixedDateTimeZone19.getShortName(100L, locale21);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTime dateTime24 = dateTime13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime28 = dateTime26.withCenturyOfEra((int) '#');
        int int29 = dateTime28.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale36 = null;
        java.lang.String str37 = fixedDateTimeZone34.getShortName(100L, locale36);
        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTime dateTime39 = dateTime28.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTime dateTime40 = dateTime24.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTime dateTime42 = dateTime24.withWeekyear(0);
        org.joda.time.DateTime.Property property43 = dateTime24.weekOfWeekyear();
        long long44 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
        int int47 = dateTime46.getYear();
        boolean boolean49 = dateTime46.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property50 = dateTime46.secondOfDay();
        org.joda.time.DateTime dateTime51 = property50.roundFloorCopy();
        org.joda.time.DateMidnight dateMidnight52 = dateTime51.toDateMidnight();
        try {
            org.joda.time.chrono.LimitChronology limitChronology53 = org.joda.time.chrono.LimitChronology.getInstance(chronology9, (org.joda.time.ReadableDateTime) dateTime24, (org.joda.time.ReadableDateTime) dateTime51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 50491123200100L + "'", long44 == 50491123200100L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateMidnight52);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DurationField durationField11 = buddhistChronology8.hours();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology8.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology8.weekyearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField14);
//        int int17 = skipUndoDateTimeField15.get((long) (short) 0);
//        long long20 = skipUndoDateTimeField15.set((long) 69, 69);
//        long long23 = skipUndoDateTimeField15.set(0L, 2);
//        org.joda.time.ReadablePartial readablePartial24 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.yearOfEra();
//        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology27);
//        org.joda.time.DurationField durationField30 = buddhistChronology27.hours();
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology27);
//        org.joda.time.Chronology chronology32 = buddhistChronology27.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.yearOfEra();
//        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.MonthDay monthDay39 = monthDay36.withPeriodAdded(readablePeriod37, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
//        int int41 = monthDay39.indexOf(dateTimeFieldType40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        int int43 = monthDay39.indexOf(dateTimeFieldType42);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getEra();
//        int int47 = dateTime45.getDayOfYear();
//        org.joda.time.DateTime dateTime48 = monthDay39.toDateTime((org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.MonthDay.Property property49 = monthDay39.monthOfYear();
//        int[] intArray51 = buddhistChronology27.get((org.joda.time.ReadablePartial) monthDay39, (long) 69);
//        try {
//            int[] intArray53 = skipUndoDateTimeField15.add(readablePartial24, (int) (short) 10, intArray51, 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 14 + "'", int17 == 14);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1735776000069L + "'", long20 == 1735776000069L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-378604800000L) + "'", long23 == (-378604800000L));
//        org.junit.Assert.assertNotNull(buddhistChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 166 + "'", int47 == 166);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(intArray51);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.minus((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfMonth(18062);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18062 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(166, (-584388));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -584388");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        int int31 = dateTime30.getDayOfYear();
        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 3570);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 0);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone12.getShortName(100L, locale14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long18 = fixedDateTimeZone12.nextTransition((long) '4');
        org.joda.time.Chronology chronology19 = copticChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long22 = cachedDateTimeZone20.nextTransition((long) (short) 1);
        long long24 = cachedDateTimeZone20.nextTransition(0L);
        long long26 = dateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone20, (long) (short) 1);
        org.joda.time.DateTime dateTime27 = dateTime1.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter0.parseMutableDateTime("3569");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"3569\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime33 = dateTime31.withCenturyOfEra((int) '#');
        int int34 = dateTime33.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale41 = null;
        java.lang.String str42 = fixedDateTimeZone39.getShortName(100L, locale41);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        org.joda.time.DateTime dateTime44 = dateTime33.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        org.joda.time.DateTime dateTime45 = dateTime29.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        java.util.Locale locale47 = null;
        java.lang.String str48 = fixedDateTimeZone39.getShortName((long) 9, locale47);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property51 = dateTime50.dayOfMonth();
        int int52 = property51.getMaximumValueOverall();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime56 = dateTime54.withCenturyOfEra((int) '#');
        boolean boolean57 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property51, (java.lang.Object) dateTime54);
        org.joda.time.Chronology chronology58 = dateTime54.getChronology();
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone39, (org.joda.time.ReadableInstant) dateTime54);
        org.joda.time.DateTime dateTime61 = dateTime54.minusMonths(1970);
        org.joda.time.DateTime dateTime63 = dateTime61.plusHours(1970);
        try {
            org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9, (org.joda.time.ReadableInstant) dateTime63, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+00:00" + "'", str42.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "+00:00" + "'", str48.equals("+00:00"));
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
//        java.util.Locale locale17 = null;
//        int int18 = property16.getMaximumTextLength(locale17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getYear();
//        boolean boolean23 = dateTime20.isBefore((long) (short) 0);
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfDay();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime26 = dateTime25.withEarlierOffsetAtOverlap();
//        int int27 = property24.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        int int28 = property16.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        java.lang.String str29 = property16.getAsShortText();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "6" + "'", str29.equals("6"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfMonth();
        int int5 = property4.getMaximumValueOverall();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.withCenturyOfEra((int) '#');
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property4, (java.lang.Object) dateTime7);
        org.joda.time.DateTime dateTime11 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime13 = dateTime11.minus((long) (short) -1);
        int int14 = dateTime13.getDayOfMonth();
        boolean boolean15 = dateTime1.equals((java.lang.Object) int14);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology1, dateTimeField3);
        org.joda.time.DurationField durationField5 = skipDateTimeField4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number11 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, number11, "--06-15");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        int int4 = monthDay3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfMonth();
        int int4 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property3.withMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = copticChronology4.withUTC();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((java.lang.Object) monthDay3, chronology5);
        org.joda.time.MonthDay monthDay8 = monthDay6.plusDays(34);
        try {
            java.lang.String str10 = monthDay6.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        try {
            long long9 = copticChronology0.getDateTimeMillis(0, 3569, 9, 15, 2019, 0, 34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.Chronology chronology2 = instant0.getChronology();
        org.joda.time.Instant instant4 = instant0.withMillis((long) 15);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.lang.String str8 = property6.getName();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "millisOfDay" + "'", str8.equals("millisOfDay"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        boolean boolean18 = fixedDateTimeZone11.isStandardOffset((long) 100);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
//        int int17 = property16.getMaximumValue();
//        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) (short) -1);
//        int int20 = property16.compareTo((org.joda.time.ReadablePartial) monthDay19);
//        try {
//            org.joda.time.MonthDay monthDay22 = property16.setCopy(166);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime3.withDurationAdded(readableDuration9, 20);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        int int4 = dateTime3.getYear();
        boolean boolean5 = copticChronology0.equals((java.lang.Object) dateTime3);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.millisOfDay();
        org.joda.time.DurationField durationField7 = copticChronology0.weeks();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone11.getName(0L, locale15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime20 = dateTime18.withCenturyOfEra((int) '#');
        int int21 = dateTime20.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale28 = null;
        java.lang.String str29 = fixedDateTimeZone26.getShortName(100L, locale28);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTime dateTime31 = dateTime20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long33 = fixedDateTimeZone11.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone26, 52L);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        try {
            org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((int) (byte) 10, 166, (int) ' ', 2, (int) (byte) 100, (-584388), (org.joda.time.DateTimeZone) fixedDateTimeZone26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00" + "'", str29.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property11 = dateTime7.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime7.toMutableDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = mutableDateTime12.toDateTime(dateTimeZone13);
        int int15 = property2.getDifference((org.joda.time.ReadableInstant) mutableDateTime12);
        java.util.Locale locale16 = null;
        int int17 = property2.getMaximumShortTextLength(locale16);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-584388) + "'", int15 == (-584388));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        int int8 = dateTime6.getYear();
        int int9 = property2.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfMonth();
        int int13 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime14 = property12.roundFloorCopy();
        int int15 = property2.getDifference((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime19 = dateTime17.withCenturyOfEra((int) '#');
        int int20 = dateTime19.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale27 = null;
        java.lang.String str28 = fixedDateTimeZone25.getShortName(100L, locale27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTime dateTime30 = dateTime19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        boolean boolean31 = dateTime14.isAfter((org.joda.time.ReadableInstant) dateTime30);
        int int32 = dateTime14.getDayOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.minus((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.minus(readableDuration12);
        org.joda.time.DateTime.Property property14 = dateTime9.weekOfWeekyear();
        int int15 = property14.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("January", "--01-01");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Number number14 = illegalFieldValueException9.getUpperBound();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 10 + "'", number14.equals(10));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 0);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone13.getShortName(100L, locale15);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long19 = fixedDateTimeZone13.nextTransition((long) '4');
        org.joda.time.Chronology chronology20 = copticChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long23 = cachedDateTimeZone21.nextTransition((long) (short) 1);
        long long25 = cachedDateTimeZone21.nextTransition(0L);
        long long27 = dateTimeZone6.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone21, (long) (short) 1);
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(6, (int) (byte) 10, (-1), 52, 34, (org.joda.time.DateTimeZone) cachedDateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        int int4 = dateTime3.getYear();
        boolean boolean5 = copticChronology0.equals((java.lang.Object) dateTime3);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(9, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108 + "'", int2 == 108);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime3.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.joda.time.Instant instant4 = instant0.plus((long) 14);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 34);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property11 = dateTime7.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime7.toMutableDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = mutableDateTime12.toDateTime(dateTimeZone13);
        int int15 = property2.getDifference((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime12.toMutableDateTime();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-584388) + "'", int15 == (-584388));
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        int int6 = dateTime3.getMinuteOfHour();
        org.joda.time.DateTime dateTime8 = dateTime3.withDayOfYear((int) '#');
        java.lang.String str10 = dateTime8.toString("3569");
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3569" + "'", str10.equals("3569"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.nextTransition((long) '4');
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 31);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(copticChronology13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) (short) -1);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 0, 6, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.Chronology chronology9 = dateTime5.getChronology();
        org.joda.time.DateTime dateTime11 = dateTime5.minus(32054400052L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        int int6 = dateTime3.getMinuteOfHour();
        org.joda.time.DateTime.Property property7 = dateTime3.era();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        try {
            boolean boolean24 = unsupportedDateTimeField22.isLeap(2678400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime12.withYearOfCentury((int) '#');
//        org.joda.time.DateTime.Property property19 = dateTime12.secondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime24 = dateTime12.withTime((int) (byte) -1, 0, 34, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField11 = buddhistChronology8.hours();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology8.weekyearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField14);
        int int17 = skipUndoDateTimeField15.get((long) (short) 0);
        long long20 = skipUndoDateTimeField15.set((long) 69, 69);
        java.util.Locale locale23 = null;
        try {
            long long24 = skipUndoDateTimeField15.set((long) 9, "", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 14 + "'", int17 == 14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1735776000069L + "'", long20 == 1735776000069L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969365T155959.999-0800");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969365T155959.999-0800" + "'", str3.equals("1969365T155959.999-0800"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime15.withDayOfMonth((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 3570);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.util.Date date9 = dateTime5.toDate();
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.fromDateFields(date9);
        try {
            org.joda.time.MonthDay monthDay12 = monthDay10.withMonthOfYear((-18096));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18096 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(monthDay10);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay();
//        long long9 = buddhistChronology6.set((org.joda.time.ReadablePartial) monthDay7, 12L);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) -1, 0, (-18096), 108, (int) (short) -1, (org.joda.time.Chronology) buddhistChronology6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 14256000012L + "'", long9 == 14256000012L);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime1.isSupported(dateTimeFieldType5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.withPeriodAdded(readablePeriod7, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(3570);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3570) + "'", int1 == (-3570));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        java.lang.String str10 = property9.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException("Jan 1, 3570", "+00:00");
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) "+00:00");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DurationField durationField5 = copticChronology3.eras();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.UnsupportedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("3570-01-01T00:00:00.100Z");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"3570-01-01T00:00:00.100Z/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.lang.Object obj4 = null;
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField3, obj4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology1, dateTimeField3);
        org.joda.time.DurationField durationField5 = skipDateTimeField4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number11 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, number11, "--06-15");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsText(readablePartial23, (int) (byte) 10, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) 0, true);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone4.getName(0L, locale13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        try {
            long long24 = unsupportedDateTimeField22.roundHalfCeiling((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime12.withYearOfCentury((int) '#');
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime12.withYearOfCentury((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        java.lang.String str24 = unsupportedDateTimeField22.toString();
        java.util.Locale locale25 = null;
        try {
            int int26 = unsupportedDateTimeField22.getMaximumTextLength(locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        boolean boolean6 = dateTime3.isEqualNow();
        org.joda.time.ReadableInstant readableInstant7 = null;
        try {
            int int8 = dateTime3.compareTo(readableInstant7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        int int11 = monthDay6.size();
//        java.lang.String str12 = monthDay6.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            org.joda.time.MonthDay.Property property14 = monthDay6.property(dateTimeFieldType13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "--06-15" + "'", str12.equals("--06-15"));
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
//        int int17 = property16.getMaximumValue();
//        java.util.Locale locale19 = null;
//        try {
//            org.joda.time.MonthDay monthDay20 = property16.setCopy("", locale19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        try {
            org.joda.time.MonthDay monthDay10 = monthDay8.withMonthOfYear(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
//        java.lang.String str3 = property1.getAsText();
//        long long4 = property1.remainder();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "20" + "'", str3.equals("20"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2093352L + "'", long4 == 2093352L);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("�:�� �", "org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported", (int) '#', (int) (byte) 0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 18096);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 18096");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getName((long) 0, locale10);
        int int13 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.clockhourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField15, (int) (short) 0, (int) (byte) -1, 14);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone10.getShortName(100L, locale12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone10.getName((long) 0, locale16);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(3570, (int) (short) -1, 1970, (-1), 18062, 12, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray27 = new int[] { 3570 };
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = unsupportedDateTimeField22.set(readablePartial24, 3569, intArray27, "Jan", locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.yearOfEra();
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology24);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay29 = monthDay26.withPeriodAdded(readablePeriod27, 31);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay31 = monthDay29.plus(readablePeriod30);
        int[] intArray38 = new int[] { 1970, 3569, 6, 6, 3570 };
        java.util.Locale locale40 = null;
        try {
            int[] intArray41 = unsupportedDateTimeField22.set((org.joda.time.ReadablePartial) monthDay29, 12, intArray38, "100", locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) 0, true);
        java.lang.String str12 = fixedDateTimeZone4.getName((long) 14);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime32 = dateTime30.withCenturyOfEra(2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.withEarlierOffsetAtOverlap();
        boolean boolean3 = dateTime1.isAfter((long) 4);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.nextTransition((long) '4');
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 31);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long16 = fixedDateTimeZone4.convertUTCToLocal((long) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        illegalFieldValueException2.prependMessage("");
        java.lang.Number number6 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported"));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfYear();
        long long7 = julianChronology1.add((long) (short) 0, 50491123200100L, (int) '#');
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1767189312003500L + "'", long7 == 1767189312003500L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        java.lang.String str3 = property1.getAsText();
        org.joda.time.DurationField durationField4 = property1.getDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "20" + "'", str3.equals("20"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        try {
            int int24 = unsupportedDateTimeField22.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getEra();
//        int int5 = dateTime3.getYearOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime8.withCenturyOfEra((int) '#');
//        int int11 = property6.getDifference((org.joda.time.ReadableInstant) dateTime8);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18062 + "'", int11 == 18062);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.minus((long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withFieldAdded(durationFieldType12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.joda.time.DateTime.Property property13 = dateTime11.year();
        org.joda.time.DateTime dateTime15 = dateTime11.minus((long) (byte) -1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField11 = buddhistChronology8.hours();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology8.weekyearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField14);
        int int16 = skipUndoDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime3.era();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (-1));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, 31);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '+100:31' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.yearOfEra();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = monthDay7.indexOf(dateTimeFieldType8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = monthDay7.indexOf(dateTimeFieldType10);
        int int12 = monthDay7.size();
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        java.lang.Integer int14 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "�:�� �" + "'", str13.equals("�:�� �"));
        org.junit.Assert.assertNull(int14);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 10, 14, (int) '4', (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.DateTime dateTime2 = instant0.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant0.plus(readableDuration3);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant4);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
//        org.joda.time.DurationField durationField5 = copticChronology3.eras();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.yearOfEra();
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        int int14 = monthDay12.indexOf(dateTimeFieldType13);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        int int16 = monthDay12.indexOf(dateTimeFieldType15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getEra();
//        int int20 = dateTime18.getDayOfYear();
//        org.joda.time.DateTime dateTime21 = monthDay12.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property22 = dateTime18.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = property22.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology3, dateTimeField23, 69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 166 + "'", int20 == 166);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime8 = property6.addWrapFieldToCopy((int) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone13.getName(0L, locale17);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.withCenturyOfEra((int) '#');
        int int23 = dateTime22.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone28.getShortName(100L, locale30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.DateTime dateTime33 = dateTime22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        long long35 = fixedDateTimeZone13.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone28, 52L);
        org.joda.time.DateTime dateTime36 = dateTime8.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.util.GregorianCalendar gregorianCalendar37 = dateTime36.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianCalendar37);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsText(0L, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.nextTransition((long) '4');
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 31);
        try {
            org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 34");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone6.getShortName(100L, locale8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long12 = fixedDateTimeZone6.nextTransition((long) '4');
        org.joda.time.Chronology chronology13 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 1);
        long long18 = cachedDateTimeZone14.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone14.getUncachedZone();
        int int21 = cachedDateTimeZone14.getOffset(10L);
        long long24 = cachedDateTimeZone14.adjustOffset((long) 52, false);
        java.lang.String str26 = cachedDateTimeZone14.getShortName(1199318400100L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str17 = zonedChronology16.toString();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.monthOfYear();
        org.joda.time.DurationField durationField20 = buddhistChronology18.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale27 = null;
        java.lang.String str28 = fixedDateTimeZone25.getShortName(100L, locale27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        long long31 = fixedDateTimeZone25.nextTransition((long) '4');
        org.joda.time.Chronology chronology32 = buddhistChronology18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.Chronology chronology33 = zonedChronology16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        java.lang.String str34 = zonedChronology16.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str17.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str34.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipDateTimeField3.getAsText((long) 4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsText((-1), locale7);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-584388));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-584388) + "'", int1 == (-584388));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone6.getShortName(100L, locale8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long12 = fixedDateTimeZone6.nextTransition((long) '4');
        org.joda.time.Chronology chronology13 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.util.TimeZone timeZone14 = fixedDateTimeZone6.toTimeZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        int int6 = dateTime5.getMonthOfYear();
        int int7 = dateTime5.getYearOfEra();
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(0, 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "6");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.era();
        org.joda.time.Chronology chronology9 = dateTime5.getChronology();
        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(2019);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withDate((-18096), 52, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = gregorianChronology10.add(readablePeriod11, (long) 2019, 14);
        try {
            long long19 = gregorianChronology10.getDateTimeMillis(12, (-584388), (int) (byte) 1, 34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -584388 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipDateTimeField3.getAsText((long) 4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsText(3569, locale7);
        int int9 = skipDateTimeField3.getMinimumValue();
        long long11 = skipDateTimeField3.roundHalfCeiling((long) 100);
        long long13 = skipDateTimeField3.roundHalfCeiling((long) (short) 1);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField3.getAsShortText(1560630866154L, locale15);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3569" + "'", str8.equals("3569"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Jun" + "'", str16.equals("Jun"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours((int) ' ');
        org.joda.time.DateTime.Property property16 = dateTime11.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipDateTimeField3.getAsText((long) 4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsText(3569, locale7);
        int int9 = skipDateTimeField3.getMinimumValue();
        long long11 = skipDateTimeField3.roundHalfCeiling((long) 100);
        long long13 = skipDateTimeField3.roundHalfCeiling((long) (short) 1);
        long long16 = skipDateTimeField3.set((long) 20, "Jan");
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3569" + "'", str8.equals("3569"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 20L + "'", long16 == 20L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        boolean boolean24 = unsupportedDateTimeField22.isLenient();
        try {
            int int26 = unsupportedDateTimeField22.get((long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.yearOfEra();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, 31);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField10);
        org.joda.time.DurationField durationField12 = skipDateTimeField11.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField11.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number18 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, number18, "--06-15");
        boolean boolean21 = monthDay4.isSupported(dateTimeFieldType13);
        org.joda.time.DurationField durationField22 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField22);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = copticChronology4.withUTC();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((java.lang.Object) monthDay3, chronology5);
        try {
            org.joda.time.LocalDate localDate8 = monthDay6.toLocalDate((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone24.getShortName((long) 9, locale32);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property36 = dateTime35.dayOfMonth();
        int int37 = property36.getMaximumValueOverall();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime41 = dateTime39.withCenturyOfEra((int) '#');
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property36, (java.lang.Object) dateTime39);
        org.joda.time.Chronology chronology43 = dateTime39.getChronology();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (org.joda.time.ReadableInstant) dateTime39);
        java.lang.String str45 = gJChronology44.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "GJChronology[,cutover=1970-01-01T00:00:00.100Z]" + "'", str45.equals("GJChronology[,cutover=1970-01-01T00:00:00.100Z]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime9.plusSeconds(34);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        long long25 = unsupportedDateTimeField22.add((long) (byte) 100, 1199318400000L);
        try {
            long long28 = unsupportedDateTimeField22.set(0L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1199318400100L + "'", long25 == 1199318400100L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        try {
            org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getSecondOfMinute();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withYearOfCentury((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        boolean boolean24 = unsupportedDateTimeField22.isLenient();
        java.util.Locale locale27 = null;
        try {
            long long28 = unsupportedDateTimeField22.set((long) 100, "20", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime12.withSecondOfMinute(1);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        java.lang.String str4 = property3.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[monthOfYear]" + "'", str4.equals("Property[monthOfYear]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        int int8 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, readableDateTime3, (org.joda.time.ReadableDateTime) dateTime7);
        org.joda.time.Chronology chronology11 = limitChronology10.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.yearOfEra();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DurationField durationField16 = buddhistChronology13.hours();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.Chronology chronology18 = buddhistChronology13.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale25 = null;
        java.lang.String str26 = fixedDateTimeZone23.getShortName(100L, locale25);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        java.lang.String str29 = zonedChronology28.toString();
        java.lang.String str30 = zonedChronology28.toString();
        boolean boolean31 = limitChronology10.equals((java.lang.Object) zonedChronology28);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.Chronology chronology33 = zonedChronology28.withZone(dateTimeZone32);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str29.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str30.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology33);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
//        java.lang.String str17 = property16.getAsShortText();
//        java.lang.String str18 = property16.getAsString();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6" + "'", str17.equals("6"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        boolean boolean24 = unsupportedDateTimeField22.isLenient();
        java.util.Locale locale27 = null;
        try {
            long long28 = unsupportedDateTimeField22.set(1767189312003500L, "2019-06-15T20:33:00.798Z", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), (long) 108);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-108L) + "'", long2 == (-108L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.era();
        int int9 = dateTime5.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone7.getShortName(100L, locale9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        long long13 = fixedDateTimeZone7.nextTransition((long) '4');
        org.joda.time.Chronology chronology14 = copticChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        long long17 = cachedDateTimeZone15.nextTransition((long) (short) 1);
        long long19 = cachedDateTimeZone15.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone15.getUncachedZone();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 20, dateTimeZone20);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone28.getShortName(100L, locale30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        long long34 = fixedDateTimeZone28.nextTransition((long) '4');
        org.joda.time.Chronology chronology35 = copticChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        long long38 = cachedDateTimeZone36.nextTransition((long) (short) 1);
        long long40 = cachedDateTimeZone36.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone41 = cachedDateTimeZone36.getUncachedZone();
        int int43 = cachedDateTimeZone36.getOffset(10L);
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DateTime dateTime45 = dateTime21.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.plus(readableDuration46);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        java.io.Writer writer2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.yearOfEra();
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        int int11 = monthDay9.indexOf(dateTimeFieldType10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        int int13 = monthDay9.indexOf(dateTimeFieldType12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        int int16 = dateTime15.getEra();
//        int int17 = dateTime15.getDayOfYear();
//        org.joda.time.DateTime dateTime18 = monthDay9.toDateTime((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.MonthDay.Property property19 = monthDay9.monthOfYear();
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay9);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 166 + "'", int17 == 166);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.era();
        int int5 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) ' ', 3570, 10, 18096, 18062);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18096 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        boolean boolean24 = unsupportedDateTimeField22.isLenient();
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsText(2678400001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone5.getName(0L, locale9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra((int) '#');
        int int15 = dateTime14.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getShortName(100L, locale22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime25 = dateTime14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, 52L);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime.Property property29 = dateTime28.dayOfWeek();
        java.lang.String str30 = property29.getAsShortText();
        int int31 = property29.get();
        int int32 = property29.get();
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Thu" + "'", str30.equals("Thu"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay6, locale7);
        long long10 = skipDateTimeField3.roundCeiling((long) (short) -1);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField(chronology11, dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipDateTimeField14.getAsText((long) 1, locale16);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField(chronology18, dateTimeField20);
        org.joda.time.DurationField durationField22 = skipDateTimeField21.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField21.getType();
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) monthDay24, locale25);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField(chronology27, dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField30.getAsText((long) 1, locale32);
        org.joda.time.DateTimeField dateTimeField34 = skipDateTimeField30.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.yearOfEra();
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology36);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.MonthDay monthDay41 = monthDay38.withPeriodAdded(readablePeriod39, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        int int43 = monthDay41.indexOf(dateTimeFieldType42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        int int45 = monthDay41.indexOf(dateTimeFieldType44);
        int[] intArray51 = new int[] { 9, (byte) 10, (short) 100, '4', 69 };
        int int52 = skipDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) monthDay41, intArray51);
        int int53 = skipDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray51);
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField58 = buddhistChronology57.yearOfEra();
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology57);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.MonthDay monthDay62 = monthDay59.withPeriodAdded(readablePeriod60, 31);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.MonthDay monthDay64 = monthDay62.plus(readablePeriod63);
        org.joda.time.Chronology chronology65 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = buddhistChronology66.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField68 = new org.joda.time.field.SkipDateTimeField(chronology65, dateTimeField67);
        java.util.Locale locale70 = null;
        java.lang.String str71 = skipDateTimeField68.getAsText((long) 1, locale70);
        org.joda.time.DateTimeField dateTimeField72 = skipDateTimeField68.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology74 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone73);
        org.joda.time.DateTimeField dateTimeField75 = buddhistChronology74.yearOfEra();
        org.joda.time.MonthDay monthDay76 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology74);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.MonthDay monthDay79 = monthDay76.withPeriodAdded(readablePeriod77, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = null;
        int int81 = monthDay79.indexOf(dateTimeFieldType80);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = null;
        int int83 = monthDay79.indexOf(dateTimeFieldType82);
        int[] intArray89 = new int[] { 9, (byte) 10, (short) 100, '4', 69 };
        int int90 = skipDateTimeField68.getMaximumValue((org.joda.time.ReadablePartial) monthDay79, intArray89);
        julianChronology55.validate((org.joda.time.ReadablePartial) monthDay64, intArray89);
        try {
            int[] intArray93 = skipDateTimeField3.addWrapField((org.joda.time.ReadablePartial) monthDay24, 69, intArray89, (-584388));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 69");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6" + "'", str8.equals("6"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "January" + "'", str17.equals("January"));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "6" + "'", str26.equals("6"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "January" + "'", str33.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 12 + "'", int52 == 12);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(buddhistChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "January" + "'", str71.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(buddhistChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 12 + "'", int90 == 12);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[]" + "'", str1.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
//        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property4.getAsShortText(locale6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        java.lang.String str24 = unsupportedDateTimeField22.toString();
        try {
            long long27 = unsupportedDateTimeField22.set(10L, "1805");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology4 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone7.getShortName(100L, locale9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        long long13 = fixedDateTimeZone7.nextTransition((long) '4');
        org.joda.time.Chronology chronology14 = copticChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        long long17 = cachedDateTimeZone15.nextTransition((long) (short) 1);
        long long19 = cachedDateTimeZone15.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone15.getUncachedZone();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 20, dateTimeZone20);
        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime5 = property2.roundFloorCopy();
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMillisOfDay((-18096));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18096 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours((int) ' ');
        org.joda.time.DateTime.Property property16 = dateTime11.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.DateTime dateTime19 = dateTime17.minusHours(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime5 = property2.roundFloorCopy();
        int int6 = dateTime5.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime9 = property7.addToCopy(1767189312003500L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1767189312003500 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getYear();
        boolean boolean12 = copticChronology7.equals((java.lang.Object) dateTime10);
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) dateTime10);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTime dateTime6 = dateTimeFormatter0.parseDateTime("1969365T155959.999-0800");
        try {
            org.joda.time.LocalDateTime localDateTime8 = dateTimeFormatter0.parseLocalDateTime("+12:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+12:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        long long25 = unsupportedDateTimeField22.add((long) (byte) 100, 1199318400000L);
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField22.getAsShortText(1970, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1199318400100L + "'", long25 == 1199318400100L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        try {
            org.joda.time.MonthDay monthDay10 = monthDay6.withMonthOfYear((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int9 = gJChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime((org.joda.time.Chronology) iSOChronology7);
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime6.toCalendar(locale9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(calendar10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = zonedChronology16.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(108, (-584388), 6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getRangeDurationField();
        try {
            int int24 = unsupportedDateTimeField22.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        int int8 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, readableDateTime3, (org.joda.time.ReadableDateTime) dateTime7);
        try {
            long long16 = limitChronology10.getDateTimeMillis((long) 10, (int) (short) 100, 108, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(limitChronology10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) buddhistChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.yearOfEra();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, 31);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField(chronology11, dateTimeField13);
        org.joda.time.DurationField durationField15 = skipDateTimeField14.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number21 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, number21, "--06-15");
        boolean boolean24 = monthDay7.isSupported(dateTimeFieldType16);
        org.joda.time.DurationField durationField25 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField25);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getRangeDurationField();
        try {
            int int28 = instant0.get((org.joda.time.DateTimeField) unsupportedDateTimeField26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.yearOfEra();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        int int10 = monthDay8.indexOf(dateTimeFieldType9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = monthDay8.indexOf(dateTimeFieldType11);
        int int13 = monthDay8.size();
        java.lang.String str14 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) monthDay8);
        java.util.Locale locale15 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.parse("millisOfDay", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"millisOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "�:�� �" + "'", str14.equals("�:�� �"));
        org.junit.Assert.assertNull(locale15);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfDay();
//        java.lang.String str17 = property16.getAsText();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "74102" + "'", str17.equals("74102"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.yearOfEra();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = monthDay7.indexOf(dateTimeFieldType8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = monthDay7.indexOf(dateTimeFieldType10);
        int int12 = monthDay7.size();
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        java.util.Locale locale14 = dateTimeFormatter0.getLocale();
        int int15 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "�:�� �" + "'", str13.equals("�:�� �"));
        org.junit.Assert.assertNull(locale14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2000 + "'", int15 == 2000);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withDefaultYear(0);
//        java.lang.StringBuffer stringBuffer7 = null;
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfMonth();
//        int int17 = property16.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime21 = dateTime19.withCenturyOfEra((int) '#');
//        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property16, (java.lang.Object) dateTime19);
//        org.joda.time.DateTime dateTime23 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime25 = dateTime23.plusMinutes(0);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusMinutes((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.yearOfEra();
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology29);
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology33 = copticChronology32.withUTC();
//        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((java.lang.Object) monthDay31, chronology33);
//        boolean boolean35 = dateTime25.equals((java.lang.Object) monthDay34);
//        java.lang.String str36 = monthDay34.toString();
//        boolean boolean37 = fixedDateTimeZone12.equals((java.lang.Object) monthDay34);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer7, (org.joda.time.ReadablePartial) monthDay34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "--06-15" + "'", str36.equals("--06-15"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, 1767189312003500L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560630902907L + "'", long0 == 1560630902907L);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime32 = dateTime14.withWeekyear(0);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property35 = dateTime34.dayOfMonth();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime40 = dateTime38.withCenturyOfEra((int) '#');
        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property35, (java.lang.Object) dateTime38);
        org.joda.time.DateTime dateTime42 = property35.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime46 = dateTime44.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime48 = dateTime46.plus(readablePeriod47);
        org.joda.time.MutableDateTime mutableDateTime49 = dateTime46.toMutableDateTimeISO();
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime42, (org.joda.time.ReadableInstant) dateTime46);
        boolean boolean51 = dateTime32.isEqual((org.joda.time.ReadableInstant) dateTime42);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 31 + "'", int36 == 31);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withLocale(locale4);
        java.util.Locale locale6 = dateTimeFormatter5.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(locale6);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
//        java.util.Locale locale17 = null;
//        int int18 = property16.getMaximumTextLength(locale17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getYear();
//        boolean boolean23 = dateTime20.isBefore((long) (short) 0);
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfDay();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime26 = dateTime25.withEarlierOffsetAtOverlap();
//        int int27 = property24.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        int int28 = property16.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.MonthDay monthDay29 = property16.getMonthDay();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(monthDay29);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.lang.String str9 = property2.getAsShortText();
        org.joda.time.DateTime dateTime10 = property2.withMaximumValue();
        org.joda.time.DurationField durationField11 = property2.getDurationField();
        long long14 = durationField11.subtract((-378604800000L), (long) (short) -1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-378518400000L) + "'", long14 == (-378518400000L));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone5.getShortName(100L, locale7);
        org.joda.time.Chronology chronology9 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        int int6 = dateTime3.getYear();
        int int7 = dateTime3.getSecondOfMinute();
        try {
            java.lang.String str9 = dateTime3.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3570 + "'", int6 == 3570);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime3.toTimeOfDay();
        try {
            int int9 = timeOfDay7.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(100, (int) (byte) 100, 15, (int) (short) 0, (-1), (int) (short) -1, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone7.getShortName(100L, locale9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        long long13 = fixedDateTimeZone7.nextTransition((long) '4');
        int int15 = fixedDateTimeZone7.getOffsetFromLocal((long) 31);
        org.joda.time.DateTime dateTime16 = dateTime1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("-1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsText((long) 12, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.nextTransition((long) '4');
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 31);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale16 = null;
        java.lang.String str17 = cachedDateTimeZone14.getName((long) 31, locale16);
        boolean boolean19 = cachedDateTimeZone14.isStandardOffset(12L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) -1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withLocale(locale4);
        boolean boolean6 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T235959.999Z" + "'", str2.equals("1969365T235959.999Z"));
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.DateTime dateTime9 = dateTime1.toDateTime(dateTimeZone8);
        int int10 = dateTime1.getWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis((-1), 1970, (int) (byte) 100, (int) (byte) 1, (int) (short) 10, (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.lang.String str9 = property2.getAsShortText();
        org.joda.time.DateTime dateTime10 = property2.withMaximumValue();
        boolean boolean11 = dateTime10.isEqualNow();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
        org.joda.time.DateTime dateTime13 = property12.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) 0, true);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds(3569);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.weekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        int int18 = dateTime17.getYear();
        boolean boolean19 = copticChronology14.equals((java.lang.Object) dateTime17);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.millisOfDay();
        org.joda.time.DateTime dateTime21 = dateTime11.toDateTime((org.joda.time.Chronology) copticChronology14);
        int int22 = dateTime11.getHourOfDay();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours(18062);
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.yearOfEra();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay14.withPeriodAdded(readablePeriod15, 31);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField(chronology18, dateTimeField20);
        org.joda.time.DurationField durationField22 = skipDateTimeField21.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number28 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, number28, "--06-15");
        boolean boolean31 = monthDay14.isSupported(dateTimeFieldType23);
        try {
            org.joda.time.DateTime dateTime33 = dateTime9.withField(dateTimeFieldType23, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        java.lang.String str24 = unsupportedDateTimeField22.toString();
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getLeapDurationField();
        java.lang.String str26 = unsupportedDateTimeField22.toString();
        long long29 = unsupportedDateTimeField22.add((long) (byte) 100, (int) (byte) -1);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        try {
            java.lang.String str33 = unsupportedDateTimeField22.getAsText(readablePartial30, (-584388), locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 99L + "'", long29 == 99L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
        int int4 = dateTime3.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone24.getShortName((long) 9, locale32);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property36 = dateTime35.dayOfMonth();
        int int37 = property36.getMaximumValueOverall();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime41 = dateTime39.withCenturyOfEra((int) '#');
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property36, (java.lang.Object) dateTime39);
        org.joda.time.Chronology chronology43 = dateTime39.getChronology();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime46 = dateTime39.minusMonths(1970);
        org.joda.time.DateTime dateTime48 = dateTime46.plusHours(1970);
        org.joda.time.DateTime dateTime49 = dateTime48.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
//        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
//        java.lang.Number number17 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
//        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
//        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
//        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getLeapDurationField();
//        java.lang.String str26 = unsupportedDateTimeField22.toString();
//        long long29 = unsupportedDateTimeField22.add((long) (byte) 100, (int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.yearOfEra();
//        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology31);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.MonthDay monthDay36 = monthDay33.withPeriodAdded(readablePeriod34, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        int int38 = monthDay36.indexOf(dateTimeFieldType37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        int int40 = monthDay36.indexOf(dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
//        int int43 = dateTime42.getEra();
//        int int44 = dateTime42.getDayOfYear();
//        org.joda.time.DateTime dateTime45 = monthDay36.toDateTime((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.MonthDay.Property property46 = monthDay36.monthOfYear();
//        int int47 = property46.getMaximumValue();
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) (short) -1);
//        int int50 = property46.compareTo((org.joda.time.ReadablePartial) monthDay49);
//        org.joda.time.MonthDay monthDay52 = monthDay49.plusMonths(166);
//        int[] intArray53 = monthDay52.getValues();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology56.yearOfEra();
//        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology56);
//        org.joda.time.DurationField durationField59 = buddhistChronology56.hours();
//        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology56);
//        org.joda.time.Chronology chronology61 = buddhistChronology56.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology63.yearOfEra();
//        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology63);
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.MonthDay monthDay68 = monthDay65.withPeriodAdded(readablePeriod66, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        int int70 = monthDay68.indexOf(dateTimeFieldType69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType71 = null;
//        int int72 = monthDay68.indexOf(dateTimeFieldType71);
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
//        int int75 = dateTime74.getEra();
//        int int76 = dateTime74.getDayOfYear();
//        org.joda.time.DateTime dateTime77 = monthDay68.toDateTime((org.joda.time.ReadableInstant) dateTime74);
//        org.joda.time.MonthDay.Property property78 = monthDay68.monthOfYear();
//        int[] intArray80 = buddhistChronology56.get((org.joda.time.ReadablePartial) monthDay68, (long) 69);
//        try {
//            int[] intArray82 = unsupportedDateTimeField22.addWrapPartial((org.joda.time.ReadablePartial) monthDay52, 12, intArray80, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 99L + "'", long29 == 99L);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 166 + "'", int44 == 166);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertNotNull(chronology61);
//        org.junit.Assert.assertNotNull(buddhistChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(monthDay68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 166 + "'", int76 == 166);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(intArray80);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        int int8 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, readableDateTime3, (org.joda.time.ReadableDateTime) dateTime7);
        org.joda.time.DateTime dateTime11 = limitChronology10.getLowerLimit();
        try {
            long long16 = limitChronology10.getDateTimeMillis(12, (int) (byte) -1, 166, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNull(dateTime11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        boolean boolean24 = unsupportedDateTimeField22.isLenient();
        try {
            long long26 = unsupportedDateTimeField22.roundHalfFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getYear();
        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundFloorCopy();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime((org.joda.time.Chronology) iSOChronology7);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime6.toString("GJChronology[,cutover=1970-01-01T00:00:00.100Z]", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField6 = buddhistChronology1.seconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        java.lang.String str24 = unsupportedDateTimeField22.toString();
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getLeapDurationField();
        java.lang.String str26 = unsupportedDateTimeField22.toString();
        long long29 = unsupportedDateTimeField22.add((long) (byte) 100, (int) (byte) -1);
        java.util.Locale locale30 = null;
        try {
            int int31 = unsupportedDateTimeField22.getMaximumShortTextLength(locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDateTimeField" + "'", str26.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 99L + "'", long29 == 99L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) (short) 1);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '#');
//        int int4 = dateTime3.getMonthOfYear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = fixedDateTimeZone9.getShortName(100L, locale11);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DateTime dateTime14 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '#');
//        int int19 = dateTime18.getMonthOfYear();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = fixedDateTimeZone24.getShortName(100L, locale26);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        org.joda.time.DateTime dateTime29 = dateTime18.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = fixedDateTimeZone24.getShortName((long) 9, locale32);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfMonth();
//        int int37 = property36.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime41 = dateTime39.withCenturyOfEra((int) '#');
//        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property36, (java.lang.Object) dateTime39);
//        org.joda.time.Chronology chronology43 = dateTime39.getChronology();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime dateTime46 = dateTime39.minusMonths(1970);
//        org.joda.time.DateTime dateTime48 = dateTime46.plusHours(1970);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        java.lang.String str50 = dateTime46.toString(dateTimeFormatter49);
//        java.lang.StringBuffer stringBuffer51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone52);
//        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay();
//        long long56 = buddhistChronology53.set((org.joda.time.ReadablePartial) monthDay54, 12L);
//        try {
//            dateTimeFormatter49.printTo(stringBuffer51, (org.joda.time.ReadablePartial) monthDay54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1805" + "'", str50.equals("1805"));
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 14256000012L + "'", long56 == 14256000012L);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.withEarlierOffsetAtOverlap();
        int int2 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone6.getShortName(100L, locale8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long12 = fixedDateTimeZone6.nextTransition((long) '4');
        org.joda.time.Chronology chronology13 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 1);
        long long18 = cachedDateTimeZone14.nextTransition(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        java.lang.String str20 = gregorianChronology19.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GregorianChronology[]" + "'", str20.equals("GregorianChronology[]"));
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
//        java.lang.String str6 = property4.getAsString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours(18062);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.yearOfEra();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, 31);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField(chronology17, dateTimeField19);
        org.joda.time.DurationField durationField21 = skipDateTimeField20.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipDateTimeField20.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number27 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, number27, "--06-15");
        boolean boolean30 = monthDay13.isSupported(dateTimeFieldType22);
        org.joda.time.DateTime.Property property31 = dateTime9.property(dateTimeFieldType22);
        java.lang.Number number32 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, number32, (java.lang.Number) (short) 1, (java.lang.Number) 1199318400100L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(property31);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField6 = buddhistChronology1.seconds();
        org.joda.time.DurationField durationField7 = buddhistChronology1.hours();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.yearOfEra();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        int int10 = monthDay8.indexOf(dateTimeFieldType9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay(0);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology19, dateTimeField21);
        org.joda.time.DurationField durationField23 = skipDateTimeField22.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipDateTimeField22.getType();
        int int25 = dateTime16.get(dateTimeFieldType24);
        org.joda.time.MonthDay.Property property26 = monthDay8.property(dateTimeFieldType24);
        try {
            org.joda.time.MonthDay monthDay28 = monthDay1.withField(dateTimeFieldType24, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("--06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--06-15\" is malformed at \"-06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getDurationField();
        try {
            long long25 = unsupportedDateTimeField22.roundHalfFloor((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.yearOfEra();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField11 = buddhistChronology8.hours();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology8.weekyearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField14);
        int int17 = skipUndoDateTimeField15.get((long) (short) 0);
        long long20 = skipUndoDateTimeField15.set((long) 69, 69);
        int int22 = skipUndoDateTimeField15.get((-255139199903L));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 14 + "'", int17 == 14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1735776000069L + "'", long20 == 1735776000069L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(166, 20, (int) (byte) 1, (int) '4', (int) (short) 100, (-3570));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone5.getName(0L, locale9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra((int) '#');
        int int15 = dateTime14.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getShortName(100L, locale22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime25 = dateTime14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, 52L);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        int int30 = fixedDateTimeZone20.getOffset(1560630866054L);
        boolean boolean31 = fixedDateTimeZone20.isFixed();
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay6.withPeriodAdded(readablePeriod9, 9);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str17 = zonedChronology16.toString();
        java.lang.String str18 = zonedChronology16.toString();
        try {
            long long24 = zonedChronology16.getDateTimeMillis((long) 18096, (-18096), 2, 69, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18096 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str17.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str18.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-3570), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3470L) + "'", long2 == (-3470L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        int int16 = dateTime13.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1439 + "'", int16 == 1439);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str17 = zonedChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.yearOfEra();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.DurationField durationField22 = buddhistChronology19.hours();
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.Chronology chronology24 = buddhistChronology19.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale31 = null;
        java.lang.String str32 = fixedDateTimeZone29.getShortName(100L, locale31);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology19, (org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.Chronology chronology35 = zonedChronology16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str17.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00" + "'", str32.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.withFields(readablePartial2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withYearOfCentury((int) (short) 1);
        boolean boolean9 = dateTime7.isEqual(20L);
        long long10 = dateTime7.getMillis();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2177452799900L) + "'", long10 == (-2177452799900L));
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
//        java.lang.String str5 = property4.getAsText();
//        org.joda.time.DateTime dateTime7 = property4.addToCopy((long) (short) 10);
//        org.joda.time.DateTime dateTime8 = property4.getDateTime();
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        long long10 = property4.getDifferenceAsLong(readableInstant9);
//        int int11 = property4.getMaximumValueOverall();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "15" + "'", str5.equals("15"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone6.getShortName(100L, locale8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long12 = fixedDateTimeZone6.nextTransition((long) '4');
        org.joda.time.Chronology chronology13 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        long long16 = cachedDateTimeZone14.nextTransition((long) (short) 1);
        long long18 = cachedDateTimeZone14.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone14.getUncachedZone();
        int int21 = cachedDateTimeZone14.getOffset(10L);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology23 = julianChronology22.withUTC();
        org.joda.time.DurationField durationField24 = julianChronology22.centuries();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("+12:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+12:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        java.lang.String str7 = monthDay5.toString("3569");
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay5);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3569" + "'", str7.equals("3569"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) '#');
//        int int9 = property4.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) ' ');
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths(2);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18062 + "'", int9 == 18062);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime9 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime13);
        int int18 = dateTime9.getDayOfWeek();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology7, dateTimeField9);
        org.joda.time.DurationField durationField11 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = skipDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1735776000069L, (java.lang.Number) (short) 0, (java.lang.Number) 10);
        java.lang.Number number17 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, number17, "--06-15");
        boolean boolean20 = monthDay3.isSupported(dateTimeFieldType12);
        org.joda.time.DurationField durationField21 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField21);
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField22.getRangeDurationField();
        try {
            long long26 = unsupportedDateTimeField22.set((long) 3569, "1970-W01-4T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        org.joda.time.DurationField durationField4 = skipDateTimeField3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = skipDateTimeField3.getType();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay6, locale7);
        org.joda.time.LocalDate localDate10 = monthDay6.toLocalDate((int) '4');
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6" + "'", str8.equals("6"));
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        java.lang.Object obj2 = null;
        boolean boolean3 = copticChronology0.equals(obj2);
        int int4 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.minuteOfDay();
        org.joda.time.Chronology chronology6 = copticChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) '#');
//        int int9 = property4.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        java.lang.String str10 = property4.getAsText();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18062 + "'", int9 == 18062);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "15" + "'", str10.equals("15"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.Object obj8 = null;
        jodaTimePermission1.checkGuard(obj8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = buddhistChronology1.get(readablePeriod3, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("Thu", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Thu\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) '#');
        int int7 = dateTime4.getYearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 70 + "'", int7 == 70);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) '#');
//        int int9 = property4.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime6.withDurationAdded(readableDuration10, 0);
//        int int13 = dateTime12.getYearOfEra();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18062 + "'", int9 == 18062);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property2, (java.lang.Object) dateTime5);
        java.lang.String str9 = property2.getAsShortText();
        org.joda.time.DateTime dateTime10 = property2.withMaximumValue();
        org.joda.time.DateTime.Property property11 = dateTime10.hourOfDay();
        int int12 = dateTime10.getSecondOfMinute();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone5.getShortName(100L, locale7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long11 = fixedDateTimeZone5.nextTransition((long) '4');
        int int13 = fixedDateTimeZone5.getOffsetFromLocal((long) 31);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        java.lang.StringBuffer stringBuffer17 = null;
        try {
            dateTimeFormatter16.printTo(stringBuffer17, 2678400001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = monthDay6.indexOf(dateTimeFieldType7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withCenturyOfEra((int) '#');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField(chronology17, dateTimeField19);
        org.joda.time.DurationField durationField21 = skipDateTimeField20.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipDateTimeField20.getType();
        int int23 = dateTime14.get(dateTimeFieldType22);
        org.joda.time.MonthDay.Property property24 = monthDay6.property(dateTimeFieldType22);
        try {
            org.joda.time.MonthDay monthDay26 = property24.addToCopy(14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(100L, locale6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(1560630902907L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("+12:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+12:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipDateTimeField3.getAsText((long) 1, locale5);
        org.joda.time.DateTimeField dateTimeField7 = skipDateTimeField3.getWrappedField();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField3.getAsShortText((int) ' ', locale9);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January" + "'", str6.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DateTime dateTime3 = property2.roundFloorCopy();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        int int8 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, readableDateTime3, (org.joda.time.ReadableDateTime) dateTime7);
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(12);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0, (int) '4', 108, (int) 'a', 53, 1439, 6, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '#');
        int int8 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, readableDateTime3, (org.joda.time.ReadableDateTime) dateTime7);
        org.joda.time.DateTime dateTime11 = limitChronology10.getLowerLimit();
        try {
            long long16 = limitChronology10.getDateTimeMillis(0, 31, 1439, (-3570));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNull(dateTime11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.yearOfEra();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = copticChronology6.withUTC();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) monthDay5, chronology7);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone12.getShortName(100L, locale14);
        long long18 = fixedDateTimeZone12.convertLocalToUTC((long) 0, true);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTime dateTime20 = dateTime7.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(12, 34, (int) (short) 0, 1970, 0, (int) (byte) -1, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay3.withPeriodAdded(readablePeriod4, 31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        int int8 = monthDay6.indexOf(dateTimeFieldType7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = monthDay6.indexOf(dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        int int13 = dateTime12.getEra();
//        int int14 = dateTime12.getDayOfYear();
//        org.joda.time.DateTime dateTime15 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.MonthDay.Property property16 = monthDay6.monthOfYear();
//        java.util.Locale locale17 = null;
//        int int18 = property16.getMaximumTextLength(locale17);
//        java.lang.String str19 = property16.getAsShortText();
//        org.joda.time.DateTimeField dateTimeField20 = property16.getField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withDefaultYear((int) (short) 1);
//        org.joda.time.Chronology chronology24 = dateTimeFormatter21.getChronology();
//        boolean boolean25 = property16.equals((java.lang.Object) dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 166 + "'", int14 == 166);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "6" + "'", str19.equals("6"));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNull(chronology24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) '#');
        org.joda.time.LocalTime localTime7 = dateTime4.toLocalTime();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.era();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }
}

