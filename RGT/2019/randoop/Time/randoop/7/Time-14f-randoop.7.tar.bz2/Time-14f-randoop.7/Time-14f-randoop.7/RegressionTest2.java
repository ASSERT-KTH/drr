import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.minuteOfDay();
        try {
            long long10 = buddhistChronology1.getDateTimeMillis((long) 18062, (-18096), 35, (int) ' ', 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18096 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test2");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 0, (int) (byte) -1);
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone11.getShortName(100L, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str17 = zonedChronology16.toString();
        try {
            long long23 = zonedChronology16.getDateTimeMillis(14256000012L, 100, (-584388), (-292275054), 1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], ]" + "'", str17.equals("ZonedChronology[BuddhistChronology[UTC], ]"));
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test3");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("1969365T155959.999-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969365T155959.999-0800\" is malformed at \"T155959.999-0800\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test4() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test4");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getYear();
//        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
//        org.joda.time.DateTime.Property property5 = dateTime1.secondOfDay();
//        org.joda.time.DateTime dateTime6 = property5.roundFloorCopy();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMinuteOfHour(20);
//        org.joda.time.DateTime dateTime10 = dateTime6.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.monthOfYear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology14, dateTimeField16);
//        org.joda.time.DurationField durationField18 = skipDateTimeField17.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipDateTimeField17.getType();
//        int int20 = monthDay13.indexOf(dateTimeFieldType19);
//        org.joda.time.DateTime dateTime21 = dateTime6.withFields((org.joda.time.ReadablePartial) monthDay13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2057 + "'", int2 == 2057);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test5() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test5");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, 31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test6() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test6");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getYear();
//        boolean boolean4 = dateTime1.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusSeconds(100);
//        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfSecond(365);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2057 + "'", int2 == 2057);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }
//}

