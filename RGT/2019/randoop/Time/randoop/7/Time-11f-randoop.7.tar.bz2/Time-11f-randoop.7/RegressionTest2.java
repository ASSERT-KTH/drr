import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.plusWeeks((int) '#');
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.toString();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission8.checkGuard((java.lang.Object) "ISOChronology[hi!]");
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        java.lang.Class<?> wildcardClass12 = jodaTimePermission8.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period10.plusSeconds((int) (short) 0);
        java.lang.Object obj14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField16 = gregorianChronology15.centuries();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology15.getZone();
        org.joda.time.Chronology chronology18 = gregorianChronology15.withUTC();
        org.joda.time.Period period19 = new org.joda.time.Period(obj14, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant22, readableDuration23, periodType24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType24);
        org.joda.time.Period period27 = period26.toPeriod();
        boolean boolean28 = gregorianChronology15.equals((java.lang.Object) period26);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology15.millisOfDay();
        boolean boolean30 = period13.equals((java.lang.Object) gregorianChronology15);
        org.joda.time.Days days31 = period13.toStandardDays();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(days31);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant6, readableDuration7, periodType8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType8);
        org.joda.time.PeriodType periodType11 = periodType8.withMillisRemoved();
        java.lang.String str12 = periodType8.getName();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType8);
        org.joda.time.PeriodType periodType14 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType15 = periodType8.withYearsRemoved();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Millis" + "'", str12.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        long long12 = offsetDateTimeField3.roundFloor(1L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 262974247);
        long long17 = offsetDateTimeField3.getDifferenceAsLong((long) (-9), 30552076800000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-509201280L) + "'", long17 == (-509201280L));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.lang.String str6 = offsetDateTimeField5.getName();
        long long8 = offsetDateTimeField5.roundHalfEven(10L);
        int int9 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField5.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType10, (int) (byte) 100, (-34), (int) 'a');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean21 = fixedDateTimeZone19.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType28);
        org.joda.time.Period period31 = period30.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod32 = period31.toMutablePeriod();
        int[] intArray35 = iSOChronology22.get((org.joda.time.ReadablePeriod) mutablePeriod32, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology22.era();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology22.monthOfYear();
        org.joda.time.DurationField durationField39 = iSOChronology22.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField39);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean47 = fixedDateTimeZone45.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone45);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.ReadableDuration readableDuration53 = null;
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant52, readableDuration53, periodType54);
        org.joda.time.Period period56 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType54);
        org.joda.time.Period period57 = period56.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod58 = period57.toMutablePeriod();
        int[] intArray61 = iSOChronology48.get((org.joda.time.ReadablePeriod) mutablePeriod58, 35L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone62 = iSOChronology48.getZone();
        org.joda.time.DurationField durationField63 = iSOChronology48.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField64 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField63);
        java.lang.String str65 = unsupportedDateTimeField64.getName();
        try {
            long long67 = unsupportedDateTimeField64.roundHalfCeiling(604800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfDay" + "'", str6.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(mutablePeriod32);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField40);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(mutablePeriod58);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "minuteOfDay" + "'", str65.equals("minuteOfDay"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.getLeapAmount((-2L));
        long long12 = offsetDateTimeField3.roundHalfFloor((-58060799990L));
        long long15 = offsetDateTimeField3.add((-349199999L), (long) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58060800000L) + "'", long12 == (-58060800000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-349199999L) + "'", long15 == (-349199999L));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField22 = iSOChronology7.weekyears();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.PeriodType periodType25 = periodType24.withDaysRemoved();
        java.lang.String str26 = periodType24.getName();
        org.joda.time.PeriodType periodType27 = periodType24.withDaysRemoved();
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) (byte) 10, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType33 = period31.getFieldType(0);
        boolean boolean34 = periodType24.isSupported(durationFieldType33);
        org.joda.time.field.ScaledDurationField scaledDurationField36 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (int) 'a');
        long long39 = scaledDurationField36.add((-210865896000000L), 35);
        long long42 = scaledDurationField36.getMillis(0L, (long) (-465));
        java.lang.String str43 = scaledDurationField36.toString();
        org.joda.time.PeriodType periodType46 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period47 = new org.joda.time.Period((long) (short) -1, 10L, periodType46);
        boolean boolean48 = scaledDurationField36.equals((java.lang.Object) 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Days" + "'", str26.equals("Days"));
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-103729809600000L) + "'", long39 == (-103729809600000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DurationField[hours]" + "'", str43.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[hi!]", true);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("(\"org.joda.time.JodaTimePermission\" \"hi!\")", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
        org.joda.time.Period period3 = period1.plusWeeks(0);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType10);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        java.lang.String str14 = periodType10.getName();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType10);
        org.joda.time.PeriodType periodType16 = periodType10.withDaysRemoved();
        int int17 = periodType16.size();
        org.joda.time.Period period18 = period3.withPeriodType(periodType16);
        org.joda.time.Period period19 = period3.toPeriod();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Millis" + "'", str14.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology36.hourOfDay();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField22 = iSOChronology7.weekyears();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.PeriodType periodType25 = periodType24.withDaysRemoved();
        java.lang.String str26 = periodType24.getName();
        org.joda.time.PeriodType periodType27 = periodType24.withDaysRemoved();
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) (byte) 10, periodType29, chronology30);
        org.joda.time.DurationFieldType durationFieldType33 = period31.getFieldType(0);
        boolean boolean34 = periodType24.isSupported(durationFieldType33);
        org.joda.time.field.ScaledDurationField scaledDurationField36 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType33, (int) 'a');
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(durationFieldType33, (java.lang.Number) (-35L), (java.lang.Number) 29260799035L, (java.lang.Number) 28800001L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Days" + "'", str26.equals("Days"));
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) ' ');
        org.joda.time.Period period3 = period1.plusHours(4);
        java.lang.String str4 = period3.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "P32YT4H" + "'", str4.equals("P32YT4H"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.Period period1 = org.joda.time.Period.days(10);
        org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 10, periodType4, chronology5);
        org.joda.time.DurationFieldType durationFieldType8 = period6.getFieldType(0);
        org.joda.time.Period period10 = period1.withField(durationFieldType8, 9);
        org.joda.time.field.PreciseDurationField preciseDurationField12 = new org.joda.time.field.PreciseDurationField(durationFieldType8, (-28800000965L));
        long long15 = preciseDurationField12.add((-57847903L), (long) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(weeks2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2880057944403L) + "'", long15 == (-2880057944403L));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField24 = iSOChronology7.centuries();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology7.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 1);
        java.lang.String str32 = offsetDateTimeField31.getName();
        long long34 = offsetDateTimeField31.roundHalfEven(10L);
        int int35 = offsetDateTimeField31.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField31.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType36, (int) (byte) 100, (-34), (int) 'a');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean47 = fixedDateTimeZone45.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone45);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.ReadableDuration readableDuration53 = null;
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant52, readableDuration53, periodType54);
        org.joda.time.Period period56 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType54);
        org.joda.time.Period period57 = period56.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod58 = period57.toMutablePeriod();
        int[] intArray61 = iSOChronology48.get((org.joda.time.ReadablePeriod) mutablePeriod58, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology48.era();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology48.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology48.monthOfYear();
        org.joda.time.DurationField durationField65 = iSOChronology48.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField66 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField65);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone71 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean73 = fixedDateTimeZone71.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone71);
        org.joda.time.DateTimeField dateTimeField75 = iSOChronology74.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.ReadableDuration readableDuration79 = null;
        org.joda.time.PeriodType periodType80 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period81 = new org.joda.time.Period(readableInstant78, readableDuration79, periodType80);
        org.joda.time.Period period82 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType80);
        org.joda.time.Period period83 = period82.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod84 = period83.toMutablePeriod();
        int[] intArray87 = iSOChronology74.get((org.joda.time.ReadablePeriod) mutablePeriod84, 35L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone88 = iSOChronology74.getZone();
        org.joda.time.DurationField durationField89 = iSOChronology74.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField90 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField89);
        org.joda.time.IllegalFieldValueException illegalFieldValueException92 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "PeriodType[DayTime]");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField94 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType36, (int) '#');
        int int95 = dividedDateTimeField94.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField96 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField94);
        int int97 = remainderDateTimeField96.getMaximumValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "minuteOfDay" + "'", str32.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(mutablePeriod58);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(periodType80);
        org.junit.Assert.assertNotNull(period83);
        org.junit.Assert.assertNotNull(mutablePeriod84);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(dateTimeZone88);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField90);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 34 + "'", int97 == 34);
    }
}

