import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, (int) (byte) 1, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((int) (byte) -1, (int) '4', 0, (int) 'a', 10, (int) (short) 1, (int) (byte) 10, (int) 'a', periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        try {
            org.joda.time.Period period5 = period3.withYears((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        try {
            org.joda.time.Period period7 = period5.minusWeeks((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.Period period1 = org.joda.time.Period.millis(100);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.Period period4 = period1.withFieldAdded(durationFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0d, (java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getYears();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        try {
            org.joda.time.Period period7 = period5.minusSeconds((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        try {
            org.joda.time.Period period7 = period5.minusMinutes(35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 10, periodType2, chronology3);
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) 0L, periodType2, chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        java.lang.String str11 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = fixedDateTimeZone4.nextTransition((long) 35);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        try {
            int int9 = period7.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        try {
            org.joda.time.Period period9 = period6.plusWeeks((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.Period period5 = period4.negated();
        try {
            org.joda.time.Period period7 = period4.withYears((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray14 = new int[] { (short) -1, (short) 10, (short) 100, (short) 100 };
        try {
            iSOChronology7.validate(readablePartial9, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.Period period18 = period15.withField(durationFieldType16, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = periodType4.isSupported(durationFieldType8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560627205619L + "'", long1 == 1560627205619L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 0, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 100, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.Period period17 = period14.withFieldAdded(durationFieldType15, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = period3.getFieldTypes();
        org.joda.time.Minutes minutes7 = period3.toStandardMinutes();
        try {
            org.joda.time.Period period9 = period3.withYears((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(minutes7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.Period period5 = period4.negated();
        org.joda.time.format.PeriodFormatter periodFormatter6 = null;
        java.lang.String str7 = period5.toString(periodFormatter6);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period3.negated();
        org.joda.time.Hours hours16 = period15.toStandardHours();
        try {
            org.joda.time.Period period18 = period15.minusSeconds((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(hours16);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (byte) 10, periodType9, chronology10);
        java.lang.String str12 = periodType9.getName();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((int) (short) 100, (int) (short) 1, (int) (byte) -1, (-1), (int) (short) 10, (int) ' ', (int) (byte) 1, (-1), periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        try {
            org.joda.time.Period period9 = period7.minusMinutes((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.Period period5 = period4.negated();
        try {
            org.joda.time.Period period7 = period4.plusMonths((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        try {
            long long29 = iSOChronology7.getDateTimeMillis(1, (int) (byte) 0, 1, 100, 0, (int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        try {
            org.joda.time.Period period6 = period4.minusDays(10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, chronology10);
        java.lang.String str12 = periodType7.getName();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Millis" + "'", str12.equals("Millis"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-35) + "'", int1 == (-35));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (-35), (int) (byte) 10, (int) '#', '4', (int) (short) -1, 100, (int) (short) -1, false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((-1), 1, (-1), (int) ' ', (int) (short) -1, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", (int) (short) 100, (int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hi! must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) 0, periodType2, chronology3);
        try {
            org.joda.time.Period period6 = period4.plusMinutes((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant23, readableDuration24, periodType25);
        org.joda.time.DurationFieldType durationFieldType27 = null;
        boolean boolean28 = period26.isSupported(durationFieldType27);
        int[] intArray29 = period26.getValues();
        try {
            iSOChronology7.validate(readablePartial22, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0d, (java.lang.Number) (-1.0f), (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        try {
            org.joda.time.Period period7 = period5.minusHours((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str2, (java.lang.Object) dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField22 = iSOChronology7.weekyears();
        try {
            long long27 = iSOChronology7.getDateTimeMillis((int) (short) 100, (int) (byte) 0, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (short) 0, 100, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean7 = fixedDateTimeZone5.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType14);
        org.joda.time.Period period17 = period16.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod18 = period17.toMutablePeriod();
        int[] intArray21 = iSOChronology8.get((org.joda.time.ReadablePeriod) mutablePeriod18, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology8.era();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology8.weekOfWeekyear();
        org.joda.time.DurationField durationField24 = iSOChronology8.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean31 = fixedDateTimeZone29.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.ReadableDuration readableDuration37 = null;
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant36, readableDuration37, periodType38);
        org.joda.time.Period period40 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType38);
        org.joda.time.Period period41 = period40.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod42 = period41.toMutablePeriod();
        int[] intArray45 = iSOChronology32.get((org.joda.time.ReadablePeriod) mutablePeriod42, 35L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone46 = iSOChronology32.getZone();
        org.joda.time.DurationField durationField47 = iSOChronology32.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField48 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField24, durationField47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(mutablePeriod18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(mutablePeriod42);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(durationField47);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean7 = fixedDateTimeZone5.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType14);
        org.joda.time.Period period17 = period16.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod18 = period17.toMutablePeriod();
        int[] intArray21 = iSOChronology8.get((org.joda.time.ReadablePeriod) mutablePeriod18, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology8.era();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology8.weekOfWeekyear();
        org.joda.time.DurationField durationField24 = iSOChronology8.weeks();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(mutablePeriod18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField23 = iSOChronology7.weeks();
        org.joda.time.DurationFieldType durationFieldType24 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField23, durationFieldType24, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.Period period5 = period4.negated();
        try {
            org.joda.time.Period period7 = period5.withMinutes((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withYearsRemoved();
        int int3 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial23 = null;
        try {
            int[] intArray25 = iSOChronology7.get(readablePartial23, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.ReadableDuration readableDuration37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType40 = periodType39.withMinutesRemoved();
        org.joda.time.Period period41 = new org.joda.time.Period(readableDuration37, readableInstant38, periodType39);
        org.joda.time.PeriodType periodType42 = periodType39.withMonthsRemoved();
        try {
            org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) iSOChronology7, periodType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType42);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        long long14 = cachedDateTimeZone11.convertUTCToLocal((long) (byte) 1);
        int int16 = cachedDateTimeZone11.getOffset(1560627205619L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        boolean boolean16 = iSOChronology7.equals((java.lang.Object) periodType13);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        try {
            long long41 = zonedChronology36.getDateTimeMillis((int) (byte) 0, 0, 35, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Minutes" + "'", str1.equals("Minutes"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        java.lang.Class<?> wildcardClass3 = dateTimeField2.getClass();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant6, readableDuration7, periodType8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType8);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period10, periodType11, chronology14);
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) dateTimeField2, chronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        try {
            org.joda.time.Period period17 = period14.withYears((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType23, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(0, (int) (byte) 100, 35, (-1), 10, 5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType45, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-35));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.499999595d + "'", double1 == 2440587.499999595d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        try {
            long long16 = iSOChronology7.getDateTimeMillis((int) (short) 10, (int) ' ', (int) '#', (int) 'a', (int) (byte) 0, 1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        try {
            org.joda.time.Period period13 = period7.minusDays((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        try {
            org.joda.time.Period period10 = period3.withYears(10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        long long4 = durationField1.subtract((-2L), (long) 5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-15778454822002L) + "'", long4 == (-15778454822002L));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.toString();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission8.checkGuard((java.lang.Object) "ISOChronology[hi!]");
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        java.lang.String str12 = jodaTimePermission8.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str12.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DurationField durationField24 = iSOChronology7.weeks();
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField26 = new org.joda.time.field.DecoratedDurationField(durationField24, durationFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) 10, periodType1, chronology2);
        try {
            org.joda.time.Period period5 = period3.minusWeeks((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean11 = fixedDateTimeZone9.equals((java.lang.Object) 0);
        java.lang.String str12 = fixedDateTimeZone9.getID();
        long long15 = fixedDateTimeZone9.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = cachedDateTimeZone16.getShortName((long) (short) 0);
        int int20 = cachedDateTimeZone16.getStandardOffset(10L);
        long long22 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone16, 2L);
        int int24 = cachedDateTimeZone16.getStandardOffset((long) '#');
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2L) + "'", long15 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.001" + "'", str18.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 35 + "'", int24 == 35);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        try {
            long long44 = zonedChronology36.getDateTimeMillis((long) (short) 0, (int) (short) -1, (int) (byte) 1, 8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', 0, (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 8, (int) (short) 0, (int) (byte) 100);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(96L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DurationFieldType durationFieldType24 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField23, durationFieldType24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("Millis", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.field.FieldUtils.verifyValueBounds("", 0, (int) (byte) -1, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.Period period11 = period8.minus(readablePeriod10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DurationField durationField24 = iSOChronology7.seconds();
        java.lang.Object obj25 = null;
        boolean boolean26 = iSOChronology7.equals(obj25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 10, 10, (int) '4');
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = period11.isSupported(durationFieldType12);
        try {
            int int15 = period11.getValue((-35));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(2L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 10);
        try {
            org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = illegalInstantException2.getSuppressed();
        org.joda.time.IllegalInstantException illegalInstantException7 = new org.joda.time.IllegalInstantException((long) (byte) 0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.joda.time.IllegalInstantException illegalInstantException10 = new org.joda.time.IllegalInstantException((long) (byte) 0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        java.lang.Throwable[] throwableArray11 = illegalInstantException10.getSuppressed();
        illegalInstantException7.addSuppressed((java.lang.Throwable) illegalInstantException10);
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException10);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        int int38 = cachedDateTimeZone33.getOffset(1L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Hours hours9 = period8.toStandardHours();
        try {
            org.joda.time.Period period11 = period8.plusMonths(5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(hours9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 2L, "Minutes");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("Time", 8);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("PT0S", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        try {
            org.joda.time.Period period13 = period7.withSeconds((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = period3.getFieldTypes();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.forFields(durationFieldTypeArray6);
        try {
            org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.Period period4 = new org.joda.time.Period(10, (int) '#', (int) (short) 1, (int) '#');
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.clockhourOfHalfday();
        long long30 = iSOChronology7.getDateTimeMillis(0L, 0, (int) (short) 0, 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 99L + "'", long30 == 99L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.minuteOfDay();
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) dateTimeField4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.weeks();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) 0, periodType2, chronology3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 10, periodType6, chronology7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        int int11 = period8.size();
        try {
            org.joda.time.Period period12 = period4.withFields((org.joda.time.ReadablePeriod) period8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        try {
            long long6 = iSOChronology0.getDateTimeMillis((int) '#', (int) (byte) 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 35, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 67L + "'", long2 == 67L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 10, 67L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-57L) + "'", long2 == (-57L));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        java.lang.String str2 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("ISOChronology[hi!]", true);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType7 = periodType6.withMinutesRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration4, readableInstant5, periodType7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        boolean boolean10 = periodType7.isSupported(durationFieldType9);
        org.joda.time.PeriodType periodType11 = periodType7.withMonthsRemoved();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) "ISOChronology[hi!]", periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[hi!]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = illegalInstantException2.getSuppressed();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Period period1 = org.joda.time.Period.millis(100);
        int int2 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean9 = fixedDateTimeZone7.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType16);
        org.joda.time.Period period19 = period18.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod20 = period19.toMutablePeriod();
        int[] intArray23 = iSOChronology10.get((org.joda.time.ReadablePeriod) mutablePeriod20, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology10.era();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology10.weekOfWeekyear();
        org.joda.time.Period period26 = new org.joda.time.Period(100L, (long) 4, periodType2, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology10.hourOfDay();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(mutablePeriod20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("(\"org.joda.time.JodaTimePermission\" \"hi!\")", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"(\"org.joda.time.JodaTimePermission\" \"hi!\")/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Duration duration4 = period3.toStandardDuration();
        try {
            org.joda.time.Period period6 = period3.minusSeconds((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(duration4);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((long) (byte) 0, false);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800000L + "'", long3 == 28800000L);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.minuteOfHour();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DurationField durationField37 = zonedChronology36.weeks();
        try {
            long long43 = zonedChronology36.getDateTimeMillis(0L, (-1), (int) 'a', 4, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        try {
            org.joda.time.Period period10 = period7.minusYears((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[hi!]", 4);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("GregorianChronology[America/Los_Angeles]", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, (int) (short) 0, 1, (int) (short) -1, 100, 0, 100, (int) 'a');
        int int9 = period8.getMonths();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, chronology10);
        org.joda.time.Period period13 = period11.multipliedBy(100);
        try {
            org.joda.time.Period period15 = period13.plusHours((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long6 = dateTimeZone1.convertLocalToUTC(1L, false);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800001L + "'", long6 == 28800001L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant39, readableDuration40, periodType41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType41);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.Period period48 = new org.joda.time.Period((java.lang.Object) period43, periodType44, chronology47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getChronology(chronology47);
        boolean boolean50 = zonedChronology36.equals((java.lang.Object) chronology49);
        try {
            long long58 = zonedChronology36.getDateTimeMillis(0, 96, 1, 10, (int) '#', (int) (byte) 10, (-35));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        try {
            org.joda.time.Period period6 = period4.plusMonths((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Period period0 = new org.joda.time.Period();
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 4);
        java.lang.Class<?> wildcardClass3 = dateTimeZone2.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.Period period5 = period4.negated();
        try {
            org.joda.time.Period period7 = period5.plusDays((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[hi!]", 4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (byte) 0, (int) ' ', (-35), true, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType10);
        org.joda.time.Period period13 = period12.toPeriod();
        boolean boolean14 = gregorianChronology1.equals((java.lang.Object) period12);
        org.joda.time.Seconds seconds15 = period12.toStandardSeconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(seconds15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(67L, locale3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial40 = null;
        try {
            long long42 = zonedChronology36.set(readablePartial40, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        try {
            org.joda.time.Period period5 = period3.withMonths((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(5, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102 + "'", int2 == 102);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField24 = iSOChronology7.centuries();
        org.joda.time.ReadablePartial readablePartial25 = null;
        try {
            long long27 = iSOChronology7.set(readablePartial25, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.weekyears();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) dateTimeField1, periodType2, (org.joda.time.Chronology) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DurationField durationField37 = zonedChronology36.weeks();
        try {
            long long42 = zonedChronology36.getDateTimeMillis((int) (byte) 10, (int) 'a', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period3.negated();
        int int16 = period15.getDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period16 = period14.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.Seconds seconds18 = period14.toStandardSeconds();
        int[] intArray19 = period14.getValues();
        try {
            int[] intArray21 = offsetDateTimeField3.add(readablePartial9, (-1), intArray19, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(seconds18);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale9 = null;
        try {
            long long10 = offsetDateTimeField3.set(34L, "Time", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Time\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean8 = fixedDateTimeZone6.equals((java.lang.Object) 0);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        long long12 = fixedDateTimeZone6.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey(100L);
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) 100L);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2L) + "'", long12 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean44 = fixedDateTimeZone42.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone42);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.PeriodType periodType51 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period52 = new org.joda.time.Period(readableInstant49, readableDuration50, periodType51);
        org.joda.time.Period period53 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType51);
        org.joda.time.Period period54 = period53.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod55 = period54.toMutablePeriod();
        int[] intArray58 = iSOChronology45.get((org.joda.time.ReadablePeriod) mutablePeriod55, 35L, (long) 100);
        try {
            iSOChronology7.validate(readablePartial37, intArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(mutablePeriod55);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period3.isSupported(durationFieldType4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.get(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period3.get(durationFieldType8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField23 = iSOChronology7.weeks();
        org.joda.time.DurationFieldType durationFieldType24 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField23, durationFieldType24, 102);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 'a', 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
        org.joda.time.Period period3 = period1.minusMinutes(0);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.MutablePeriod mutablePeriod15 = period3.toMutablePeriod();
        try {
            org.joda.time.Period period17 = period3.plusMinutes((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(mutablePeriod15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-1), 34L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-34) + "'", int2 == (-34));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        try {
            long long6 = offsetDateTimeField3.set((long) (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [1,1440]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, chronology10);
        int int12 = period6.getMinutes();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.joda.time.ReadablePartial readablePartial4 = null;
//        try {
//            int[] intArray6 = gregorianChronology0.get(readablePartial4, (-57L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[hi!]" + "'", str3.equals("GregorianChronology[hi!]"));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        int int15 = period3.getMillis();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) int15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        long long26 = durationField23.subtract((long) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-349199999L) + "'", long26 == (-349199999L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str13 = cachedDateTimeZone11.getNameKey(100L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType26, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.DurationField durationField45 = iSOChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology7.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology7.dayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Hours hours9 = period8.toStandardHours();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period8.toDurationTo(readableInstant10);
        try {
            org.joda.time.Period period13 = period8.minusSeconds((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(hours9);
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        int int14 = cachedDateTimeZone11.getOffset((long) 10);
        long long17 = cachedDateTimeZone11.adjustOffset((-35L), true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-35L) + "'", long17 == (-35L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = fixedDateTimeZone4.getID();
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.weekOfWeekyear();
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period45 = new org.joda.time.Period(readableInstant42, readableDuration43, periodType44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType44);
        org.joda.time.Period period47 = period46.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod48 = period47.toMutablePeriod();
        org.joda.time.Period period50 = org.joda.time.Period.millis(100);
        org.joda.time.Period period51 = period47.withFields((org.joda.time.ReadablePeriod) period50);
        org.joda.time.DurationFieldType durationFieldType52 = null;
        boolean boolean53 = period51.isSupported(durationFieldType52);
        org.joda.time.Period period55 = period51.minusYears(0);
        boolean boolean56 = zonedChronology36.equals((java.lang.Object) period51);
        org.joda.time.Period period58 = period51.minusMillis(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(mutablePeriod48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(period58);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        long long14 = cachedDateTimeZone11.convertUTCToLocal((long) (byte) 1);
        long long16 = cachedDateTimeZone11.nextTransition((long) (-35));
        java.lang.String str17 = cachedDateTimeZone11.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean24 = fixedDateTimeZone22.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant29, readableDuration30, periodType31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType31);
        org.joda.time.Period period34 = period33.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod35 = period34.toMutablePeriod();
        int[] intArray38 = iSOChronology25.get((org.joda.time.ReadablePeriod) mutablePeriod35, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology25.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean46 = fixedDateTimeZone44.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.PeriodType periodType53 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period54 = new org.joda.time.Period(readableInstant51, readableDuration52, periodType53);
        org.joda.time.Period period55 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType53);
        org.joda.time.Period period56 = period55.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod57 = period56.toMutablePeriod();
        int[] intArray60 = iSOChronology47.get((org.joda.time.ReadablePeriod) mutablePeriod57, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology47.minuteOfHour();
        boolean boolean62 = iSOChronology25.equals((java.lang.Object) dateTimeField61);
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology25.dayOfMonth();
        boolean boolean64 = cachedDateTimeZone11.equals((java.lang.Object) dateTimeField63);
        long long66 = cachedDateTimeZone11.previousTransition(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-35L) + "'", long16 == (-35L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(mutablePeriod35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(mutablePeriod57);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.Chronology chronology9 = gregorianChronology6.withUTC();
        org.joda.time.Period period10 = new org.joda.time.Period(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Period period11 = period4.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
        org.joda.time.Period period17 = period15.minusMillis((int) (byte) 10);
        int int18 = period15.size();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        boolean boolean20 = period15.isSupported(durationFieldType19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType24 = periodType23.withMinutesRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType23);
        org.joda.time.Period period26 = period15.plus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period27 = period15.negated();
        org.joda.time.Hours hours28 = period27.toStandardHours();
        org.joda.time.Period period29 = period11.plus((org.joda.time.ReadablePeriod) period27);
        org.joda.time.DurationFieldType durationFieldType30 = null;
        try {
            org.joda.time.Period period32 = period27.withField(durationFieldType30, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(hours28);
        org.junit.Assert.assertNotNull(period29);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType5);
        org.joda.time.PeriodType periodType8 = periodType5.withMillisRemoved();
        org.joda.time.PeriodType periodType9 = periodType5.withMillisRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period((-2L), periodType5);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText((-34), locale8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
        org.joda.time.Period period17 = period15.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray18 = period15.getFieldTypes();
        org.joda.time.Seconds seconds19 = period15.toStandardSeconds();
        int[] intArray20 = period15.getValues();
        try {
            int[] intArray22 = offsetDateTimeField3.addWrapField(readablePartial10, 0, intArray20, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-34" + "'", str9.equals("-34"));
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(durationFieldTypeArray18);
        org.junit.Assert.assertNotNull(seconds19);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant39, readableDuration40, periodType41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType41);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.Period period48 = new org.joda.time.Period((java.lang.Object) period43, periodType44, chronology47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getChronology(chronology47);
        boolean boolean50 = zonedChronology36.equals((java.lang.Object) chronology49);
        try {
            long long58 = zonedChronology36.getDateTimeMillis(5, 5, (int) (byte) 1, 262974247, (int) (byte) 100, 96, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 262974247 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Period period3 = new org.joda.time.Period(1009843200000L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfHalfday();
        try {
            long long9 = gregorianChronology1.getDateTimeMillis(1440, 100, 4, 1440);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(1560627205619L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2458650.3148798496d + "'", double1 == 2458650.3148798496d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        try {
            long long44 = zonedChronology36.getDateTimeMillis(0, 8, (int) (short) 0, (-100), (int) (byte) -1, (int) (byte) 10, 1440);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        int int9 = period3.getYears();
        int int10 = period3.getYears();
        try {
            org.joda.time.Period period12 = period3.minusSeconds((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        java.lang.String str6 = offsetDateTimeField3.getAsShortText(96L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.toString();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission8.checkGuard((java.lang.Object) "ISOChronology[hi!]");
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        java.lang.String str12 = jodaTimePermission8.getActions();
        java.security.PermissionCollection permissionCollection13 = jodaTimePermission8.newPermissionCollection();
        java.lang.Object obj14 = null;
        jodaTimePermission8.checkGuard(obj14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection13);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean8 = fixedDateTimeZone6.equals((java.lang.Object) 0);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        long long12 = fixedDateTimeZone6.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey(100L);
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) 100L);
        org.joda.time.Chronology chronology17 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField19 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2L) + "'", long12 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        java.lang.String str3 = gregorianChronology0.toString();
//        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean12 = fixedDateTimeZone10.equals((java.lang.Object) 0);
//        java.lang.String str13 = fixedDateTimeZone10.getID();
//        long long16 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
//        boolean boolean18 = cachedDateTimeZone17.isFixed();
//        long long20 = cachedDateTimeZone17.convertUTCToLocal((long) (byte) 1);
//        long long22 = cachedDateTimeZone17.nextTransition((long) (-35));
//        java.lang.String str23 = cachedDateTimeZone17.toString();
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.yearDay();
//        try {
//            org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) gregorianChronology0, periodType25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[hi!]" + "'", str3.equals("GregorianChronology[hi!]"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2L) + "'", long16 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2L + "'", long20 == 2L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-35L) + "'", long22 == (-35L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(periodType25);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale9 = null;
        try {
            long long10 = offsetDateTimeField3.set((long) '4', "Millis", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Millis\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = fixedDateTimeZone4.getOffsetFromLocal((-35L));
        int int15 = fixedDateTimeZone4.getOffset((-2L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Period period9 = period8.toPeriod();
        int int10 = period9.getSeconds();
        try {
            org.joda.time.Period period12 = period9.minusDays((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 10, periodType10, chronology11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15);
        org.joda.time.Period period17 = period3.minus((org.joda.time.ReadablePeriod) period16);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.hourOfDay();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 4);
        boolean boolean4 = dateTimeZone2.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean8 = fixedDateTimeZone6.equals((java.lang.Object) 0);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        long long12 = fixedDateTimeZone6.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey(100L);
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) 100L);
        org.joda.time.Chronology chronology17 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField19 = gregorianChronology0.years();
        org.joda.time.DurationField durationField20 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2L) + "'", long12 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.getLeapAmount((-2L));
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 10, periodType14, chronology15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period16.toDurationTo(readableInstant17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant19, readableDuration20, periodType21);
        org.joda.time.Period period24 = period22.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray25 = period22.getFieldTypes();
        org.joda.time.Seconds seconds26 = period22.toStandardSeconds();
        org.joda.time.Period period27 = period16.minus((org.joda.time.ReadablePeriod) seconds26);
        int[] intArray28 = period16.getValues();
        try {
            int[] intArray30 = offsetDateTimeField3.add(readablePartial11, 10, intArray28, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldTypeArray25);
        org.junit.Assert.assertNotNull(seconds26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray28);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
//        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
//        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.secondOfMinute();
//        java.lang.String str17 = gregorianChronology14.toString();
//        org.joda.time.Period period18 = new org.joda.time.Period(2L, periodType12, (org.joda.time.Chronology) gregorianChronology14);
//        try {
//            org.joda.time.Period period19 = new org.joda.time.Period((int) ' ', 96, (int) (byte) 100, 8, (int) (short) -1, (-34), 4, (int) (byte) 10, periodType12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType11);
//        org.junit.Assert.assertNotNull(periodType12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[PT0S]" + "'", str17.equals("GregorianChronology[PT0S]"));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        long long12 = offsetDateTimeField3.roundFloor(1L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant15, readableDuration16, periodType17);
        org.joda.time.Period period20 = period18.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.Seconds seconds22 = period18.toStandardSeconds();
        int[] intArray23 = period18.getValues();
        try {
            int[] intArray25 = offsetDateTimeField3.add(readablePartial13, (int) ' ', intArray23, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(seconds22);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (-1));
        long long10 = fixedDateTimeZone4.convertLocalToUTC(35L, false, (long) ' ');
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 34L + "'", long10 == 34L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.Throwable throwable5 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("Time", 8);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("Time", false);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Days", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DurationField durationField24 = iSOChronology7.seconds();
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField26 = new org.joda.time.field.DecoratedDurationField(durationField24, durationFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(35L, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        int int3 = periodType2.size();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        java.lang.String str5 = periodType2.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[Standard]" + "'", str5.equals("PeriodType[Standard]"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        java.lang.String str4 = offsetDateTimeField3.getName();
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField3.getAsShortText((-349199999L), locale6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "minuteOfDay" + "'", str4.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1381" + "'", str7.equals("1381"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        org.joda.time.Period period7 = period3.plusMonths((int) (short) 0);
        try {
            org.joda.time.DurationFieldType durationFieldType9 = period7.getFieldType(1440);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Period period9 = period4.withFieldAdded(durationFieldType7, 102);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-35), 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.toString();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        jodaTimePermission8.checkGuard((java.lang.Object) "ISOChronology[hi!]");
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        java.lang.String str12 = jodaTimePermission8.getActions();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray19 = period16.getFieldTypes();
        org.joda.time.Minutes minutes20 = period16.toStandardMinutes();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.Period period22 = period16.plus(readablePeriod21);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant23, readableDuration24, periodType25);
        org.joda.time.Period period27 = period16.withFields((org.joda.time.ReadablePeriod) period26);
        jodaTimePermission8.checkGuard((java.lang.Object) period26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldTypeArray19);
        org.junit.Assert.assertNotNull(minutes20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(262974247);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.Period period1 = org.joda.time.Period.days(10);
        int int2 = period1.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period2 = new org.joda.time.Period((long) 102, periodType1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.Period period8 = new org.joda.time.Period(35, (int) ' ', 1, 10, (-1), (int) (byte) 10, (int) (byte) 10, (int) (byte) 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology7.dayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = period11.isSupported(durationFieldType12);
        org.joda.time.Period period15 = period11.minusYears(0);
        org.joda.time.Period period17 = period11.plusMinutes(0);
        org.joda.time.Period period19 = period11.plusMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfDay();
        try {
            long long6 = iSOChronology0.getDateTimeMillis(100, 0, 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.secondOfDay();
        try {
            long long47 = zonedChronology36.getDateTimeMillis(8, 0, (-1), 100, (int) 'a', (int) (short) 1, (-52));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) ' ', (int) ' ', 8, (int) (short) 10, 96, 10, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 96 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        java.lang.String str3 = gregorianChronology0.toString();
//        try {
//            long long11 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, 0, (int) (short) 1, 0, (-52), 0, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[PT0S]" + "'", str3.equals("GregorianChronology[PT0S]"));
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField24 = iSOChronology7.weeks();
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField27 = new org.joda.time.field.ScaledDurationField(durationField24, durationFieldType25, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.monthOfYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period3.isSupported(durationFieldType4);
        int[] intArray6 = period3.getValues();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Period period9 = period3.withFieldAdded(durationFieldType7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology7.millisOfSecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        try {
            long long44 = zonedChronology36.getDateTimeMillis(28800000L, (-1), 262974247, 96, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        long long12 = offsetDateTimeField3.roundCeiling((long) ' ');
        java.util.Locale locale15 = null;
        try {
            long long16 = offsetDateTimeField3.set((long) (byte) 10, "+00:00", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60000L + "'", long12 == 60000L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.time();
        org.joda.time.Period period2 = new org.joda.time.Period((-15778454822002L), periodType1);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DurationField durationField37 = zonedChronology36.weeks();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 10, periodType39, chronology40);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period41.toDurationTo(readableInstant42);
        boolean boolean44 = zonedChronology36.equals((java.lang.Object) duration43);
        org.joda.time.Chronology chronology45 = zonedChronology36.withUTC();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance(chronology45, dateTimeZone46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean18 = fixedDateTimeZone16.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant23, readableDuration24, periodType25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType25);
        org.joda.time.Period period28 = period27.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod29 = period28.toMutablePeriod();
        int[] intArray32 = iSOChronology19.get((org.joda.time.ReadablePeriod) mutablePeriod29, 35L, (long) 100);
        java.util.Locale locale34 = null;
        try {
            int[] intArray35 = offsetDateTimeField3.set(readablePartial10, 0, intArray32, "-34", locale34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -34 for minuteOfDay must be in the range [1,1440]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(mutablePeriod29);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        long long7 = offsetDateTimeField3.add((-210866760000000L), (long) 262974247);
        java.util.Locale locale10 = null;
        try {
            long long11 = offsetDateTimeField3.set((-15778454822002L), "(\"org.joda.time.JodaTimePermission\" \"hi!\")", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-195088305180000L) + "'", long7 == (-195088305180000L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType7);
        org.joda.time.Period period10 = period8.minusMillis((int) (byte) 10);
        org.joda.time.Period period12 = period8.plusMonths((int) (short) 0);
        int[] intArray14 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period8, 99L);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableDuration18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType19);
        org.joda.time.PeriodType periodType22 = periodType19.withMillisRemoved();
        org.joda.time.PeriodType periodType23 = periodType19.withMillisRemoved();
        org.joda.time.Period period24 = period8.normalizedStandard(periodType23);
        boolean boolean25 = gregorianChronology0.equals((java.lang.Object) period24);
        try {
            org.joda.time.Period period27 = period24.minusDays(262974247);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period4 = period3.toPeriod();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("1381");
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("GregorianChronology[hi!]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[hi!]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePartial2, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 0, 8, 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        java.lang.String str3 = periodType1.getName();
        org.joda.time.PeriodType periodType4 = periodType1.withDaysRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType6 = periodType1.getFieldType((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Days" + "'", str3.equals("Days"));
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[hi!]", 4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("America/Los_Angeles", 96, (int) (byte) 1, (int) '4', '#', 262974247, (int) (byte) 100, (int) (short) 1, false, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType12);
        org.joda.time.PeriodType periodType15 = periodType12.withMillisRemoved();
        java.lang.String str16 = periodType12.getName();
        org.joda.time.PeriodType periodType17 = periodType12.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant20, readableDuration21, periodType22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType22);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period24, periodType25, chronology28);
        boolean boolean30 = periodType17.equals((java.lang.Object) period29);
        try {
            org.joda.time.Period period31 = new org.joda.time.Period((-100), (-1), 1, 96, (int) (byte) 10, 262974247, (int) '#', (int) '4', periodType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Millis" + "'", str16.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType7);
        org.joda.time.Period period10 = period8.minusMillis((int) (byte) 10);
        org.joda.time.Period period12 = period8.plusMonths((int) (short) 0);
        int[] intArray14 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period8, 99L);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableDuration18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType19);
        org.joda.time.PeriodType periodType22 = periodType19.withMillisRemoved();
        org.joda.time.PeriodType periodType23 = periodType19.withMillisRemoved();
        org.joda.time.Period period24 = period8.normalizedStandard(periodType23);
        boolean boolean25 = gregorianChronology0.equals((java.lang.Object) period24);
        try {
            org.joda.time.Period period27 = period24.minusMinutes(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(4);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText((-34), locale8);
        int int11 = offsetDateTimeField3.getLeapAmount((long) (-100));
        int int14 = offsetDateTimeField3.getDifference((long) (-1), (long) 96);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-34" + "'", str9.equals("-34"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.get(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableDuration14, periodType15);
        org.joda.time.Period period18 = period16.minusMillis((int) (byte) 10);
        int int19 = period16.getDays();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period16.get(durationFieldType20);
        int[] intArray22 = period16.getValues();
        try {
            int[] intArray24 = offsetDateTimeField3.addWrapPartial(readablePartial11, (-100), intArray22, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (int) ' ', (int) (byte) 10, (int) (byte) 10, 9, 5, (int) (byte) 100, 102);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.getLeapAmount((-2L));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsShortText(0L, locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
        int int2 = period1.getMonths();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant39, readableDuration40, periodType41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType41);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.Period period48 = new org.joda.time.Period((java.lang.Object) period43, periodType44, chronology47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getChronology(chronology47);
        boolean boolean50 = zonedChronology36.equals((java.lang.Object) chronology49);
        try {
            long long58 = zonedChronology36.getDateTimeMillis((int) ' ', (int) (byte) 10, 100, 8, 0, 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.001", "", 0, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '+00:00:00.001' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period7.getFieldTypes();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType16 = periodType15.withMinutesRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration13, readableInstant14, periodType15);
        org.joda.time.PeriodType periodType18 = periodType15.withMonthsRemoved();
        try {
            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) durationFieldTypeArray12, periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: [Lorg.joda.time.DurationFieldType;");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, chronology10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period11.toDurationFrom(readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 10, periodType16, chronology17);
        java.lang.String str19 = periodType16.getName();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant14, periodType16);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = periodType16.indexOf(durationFieldType21);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+00:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.getYears();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DurationField durationField37 = zonedChronology36.weeks();
        org.joda.time.DurationFieldType durationFieldType38 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField39 = new org.joda.time.field.DecoratedDurationField(durationField37, durationFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        try {
            org.joda.time.Period period17 = period14.withHours((-35));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField45, (int) (short) 1, (-1), 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTimeField45);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = periodType3.isSupported(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType3.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(9, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology7.weekOfWeekyear();
        try {
            long long30 = iSOChronology7.getDateTimeMillis((-1), 9, (-100), 102);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition((long) (short) 10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = cachedDateTimeZone11.getName(3251471753L, locale15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.001" + "'", str16.equals("+00:00:00.001"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period16 = period14.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.Seconds seconds18 = period14.toStandardSeconds();
        int[] intArray19 = period14.getValues();
        int int20 = offsetDateTimeField3.getMinimumValue(readablePartial10, intArray19);
        long long22 = offsetDateTimeField3.roundCeiling(1L);
        try {
            int int25 = offsetDateTimeField3.getDifference((long) (-35), (-195088305180000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3251471752");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(seconds18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60000L + "'", long22 == 60000L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) '4', "ISOChronology[hi!]");
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        int int9 = period3.getYears();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Period period12 = period3.withField(durationFieldType10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        long long11 = offsetDateTimeField3.roundHalfEven((long) 1440);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) (byte) 10, (-34));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period2 = new org.joda.time.Period((long) 102, periodType1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) 10);
        int int9 = period6.size();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = period6.isSupported(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType15 = periodType14.withMinutesRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType14);
        org.joda.time.Period period17 = period6.plus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period18 = period6.negated();
        org.joda.time.Period period19 = period2.minus((org.joda.time.ReadablePeriod) period6);
        int int20 = period6.getHours();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period16 = period14.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.Seconds seconds18 = period14.toStandardSeconds();
        int[] intArray19 = period14.getValues();
        int int20 = offsetDateTimeField3.getMinimumValue(readablePartial10, intArray19);
        try {
            long long23 = offsetDateTimeField3.set((long) (-52), "PeriodType[Standard]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[Standard]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(seconds18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        int int12 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        boolean boolean14 = fixedDateTimeZone4.isStandardOffset((long) 10);
        java.lang.String str15 = fixedDateTimeZone4.getID();
        boolean boolean17 = fixedDateTimeZone4.isStandardOffset((long) 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
//        org.joda.time.Period period16 = period15.toPeriod();
//        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
//        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
//        java.lang.String str29 = fixedDateTimeZone26.getID();
//        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = zonedChronology36.equals(obj37);
//        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.weekOfWeekyear();
//        java.util.TimeZone timeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forTimeZone(timeZone40);
//        java.lang.String str42 = dateTimeZone41.getID();
//        org.joda.time.Chronology chronology43 = zonedChronology36.withZone(dateTimeZone41);
//        try {
//            long long51 = zonedChronology36.getDateTimeMillis(1, 0, 1, (int) (short) 100, 0, 44, (-34));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(mutablePeriod17);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "PT0S" + "'", str42.equals("PT0S"));
//        org.junit.Assert.assertNotNull(chronology43);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.weekOfWeekyear();
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period45 = new org.joda.time.Period(readableInstant42, readableDuration43, periodType44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType44);
        org.joda.time.Period period47 = period46.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod48 = period47.toMutablePeriod();
        org.joda.time.Period period50 = org.joda.time.Period.millis(100);
        org.joda.time.Period period51 = period47.withFields((org.joda.time.ReadablePeriod) period50);
        org.joda.time.DurationFieldType durationFieldType52 = null;
        boolean boolean53 = period51.isSupported(durationFieldType52);
        org.joda.time.Period period55 = period51.minusYears(0);
        boolean boolean56 = zonedChronology36.equals((java.lang.Object) period51);
        org.joda.time.DurationFieldType durationFieldType57 = null;
        boolean boolean58 = period51.isSupported(durationFieldType57);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(mutablePeriod48);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean51 = fixedDateTimeZone49.equals((java.lang.Object) 0);
        java.lang.String str52 = fixedDateTimeZone49.getID();
        long long55 = fixedDateTimeZone49.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone56 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        java.lang.String str58 = cachedDateTimeZone56.getShortName((long) (short) 0);
        org.joda.time.Chronology chronology59 = iSOChronology7.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone56);
        java.lang.String str61 = cachedDateTimeZone56.getShortName((long) ' ');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-2L) + "'", long55 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "+00:00:00.001" + "'", str58.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "+00:00:00.001" + "'", str61.equals("+00:00:00.001"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DurationField durationField24 = iSOChronology7.weeks();
        long long27 = durationField24.subtract((long) (short) 10, 96L);
        long long30 = durationField24.subtract((long) '#', (long) 'a');
        org.joda.time.DurationFieldType durationFieldType31 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField24, durationFieldType31, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-58060799990L) + "'", long27 == (-58060799990L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-58665599965L) + "'", long30 == (-58665599965L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Duration duration4 = period3.toStandardDuration();
        long long5 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Throwable throwable5 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period16 = period14.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.Seconds seconds18 = period14.toStandardSeconds();
        int[] intArray19 = period14.getValues();
        int int20 = offsetDateTimeField3.getMinimumValue(readablePartial10, intArray19);
        long long22 = offsetDateTimeField3.roundCeiling(1L);
        long long24 = offsetDateTimeField3.roundCeiling((long) 8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(seconds18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60000L + "'", long22 == 60000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 60000L + "'", long24 == 60000L);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        long long7 = dateTimeZone1.convertLocalToUTC((long) 1, false, 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) periodType4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfSecond();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[PT0S]" + "'", str3.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = fixedDateTimeZone4.convertUTCToLocal((-2L));
        long long15 = fixedDateTimeZone4.convertUTCToLocal((long) 96);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        long long11 = offsetDateTimeField3.roundHalfCeiling(10L);
        boolean boolean12 = offsetDateTimeField3.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        long long11 = offsetDateTimeField3.roundHalfEven((long) 1440);
        java.lang.String str12 = offsetDateTimeField3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str12.equals("DateTimeField[minuteOfDay]"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, (long) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("Time", 8);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("(\"org.joda.time.JodaTimePermission\" \"hi!\")", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField24 = iSOChronology7.centuries();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology7.dayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.years((int) ' ');
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration4);
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1009843200000L + "'", long8 == 1009843200000L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        java.lang.Class<?> wildcardClass3 = periodType1.getClass();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        java.lang.String str8 = periodType4.getName();
        org.joda.time.PeriodType periodType9 = periodType4.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Millis" + "'", str8.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[hi!]", 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("minuteOfDay", 262974247, (int) (short) 100, (int) 'a', '#', (-52), 8, 1, false, (int) (byte) 10);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("Minutes", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = periodType0.isSupported(durationFieldType2);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.001", "", 0, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.centuries();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        boolean boolean12 = cachedDateTimeZone6.equals((java.lang.Object) dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = period11.isSupported(durationFieldType12);
        org.joda.time.Period period15 = period11.minusYears(0);
        org.joda.time.Period period17 = period11.plusMinutes(0);
        org.joda.time.Period period18 = period11.toPeriod();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType7);
        org.joda.time.Period period10 = period8.minusMillis((int) (byte) 10);
        org.joda.time.Period period12 = period8.plusMonths((int) (short) 0);
        int[] intArray14 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period8, 99L);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableDuration18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType19);
        org.joda.time.PeriodType periodType22 = periodType19.withMillisRemoved();
        org.joda.time.PeriodType periodType23 = periodType19.withMillisRemoved();
        org.joda.time.Period period24 = period8.normalizedStandard(periodType23);
        boolean boolean25 = gregorianChronology0.equals((java.lang.Object) period24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText((-34), locale8);
        long long11 = offsetDateTimeField3.remainder((long) (short) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-34" + "'", str9.equals("-34"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.toString();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        java.lang.String str7 = jodaTimePermission1.toString();
        java.lang.String str8 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int11 = offsetDateTimeField3.getDifference(9700L, (long) 35);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 10, periodType15, chronology16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period17.toDurationTo(readableInstant18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant20, readableDuration21, periodType22);
        org.joda.time.Period period25 = period23.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray26 = period23.getFieldTypes();
        org.joda.time.Seconds seconds27 = period23.toStandardSeconds();
        org.joda.time.Period period28 = period17.minus((org.joda.time.ReadablePeriod) seconds27);
        int[] intArray29 = period17.getValues();
        try {
            int[] intArray31 = offsetDateTimeField3.addWrapPartial(readablePartial12, 96, intArray29, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 96");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(duration19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldTypeArray26);
        org.junit.Assert.assertNotNull(seconds27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean9 = fixedDateTimeZone7.equals((java.lang.Object) 0);
        java.lang.String str10 = fixedDateTimeZone7.getID();
        long long13 = fixedDateTimeZone7.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str16 = cachedDateTimeZone14.getNameKey(100L);
        boolean boolean17 = gregorianChronology1.equals((java.lang.Object) 100L);
        org.joda.time.Chronology chronology18 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField20 = gregorianChronology1.years();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2L) + "'", long13 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        long long14 = cachedDateTimeZone11.convertUTCToLocal((long) (byte) 1);
        long long16 = cachedDateTimeZone11.nextTransition((long) (-35));
        long long18 = cachedDateTimeZone11.previousTransition((long) 0);
        java.lang.String str19 = cachedDateTimeZone11.getID();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-35L) + "'", long16 == (-35L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period3.isSupported(durationFieldType4);
        int[] intArray6 = period3.getValues();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.indexOf(durationFieldType7);
        int int9 = period3.getSeconds();
        int int11 = period3.getValue(0);
        try {
            org.joda.time.Period period13 = period3.plusHours(262974247);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period6, periodType7, chronology10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period11.toDurationFrom(readableInstant12);
        try {
            org.joda.time.Period period15 = period11.withHours(1440);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(duration13);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        boolean boolean9 = offsetDateTimeField3.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = period3.getFieldTypes();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.forFields(durationFieldTypeArray6);
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = period3.getFieldTypes();
        org.joda.time.Minutes minutes7 = period3.toStandardMinutes();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Period period9 = period3.plus(readablePeriod8);
        int int10 = period9.getDays();
        try {
            org.joda.time.Period period12 = period9.withYears(262974247);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(minutes7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "(\"org.joda.time.JodaTimePermission\" \"hi!\")", (int) (byte) 0, 100);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int11 = offsetDateTimeField3.getDifference(9700L, (long) 35);
        long long13 = offsetDateTimeField3.roundHalfFloor((-58665539965L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58665540000L) + "'", long13 == (-58665540000L));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DurationField durationField22 = iSOChronology7.eras();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant25, readableDuration26, periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType27);
        org.joda.time.PeriodType periodType30 = periodType27.withMillisRemoved();
        org.joda.time.PeriodType periodType31 = periodType27.withMillisRemoved();
        try {
            org.joda.time.Period period32 = new org.joda.time.Period((java.lang.Object) durationField22, periodType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.UnsupportedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(67L, "Millis");
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean51 = fixedDateTimeZone49.equals((java.lang.Object) 0);
        java.lang.String str52 = fixedDateTimeZone49.getID();
        long long55 = fixedDateTimeZone49.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone56 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        java.lang.String str58 = cachedDateTimeZone56.getShortName((long) (short) 0);
        org.joda.time.Chronology chronology59 = iSOChronology7.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone56);
        org.joda.time.DurationField durationField60 = iSOChronology7.millis();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-2L) + "'", long55 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "+00:00:00.001" + "'", str58.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(durationField60);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        long long12 = offsetDateTimeField3.roundFloor(1L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 262974247);
        long long16 = offsetDateTimeField3.roundCeiling((-59947903L));
        try {
            long long19 = offsetDateTimeField3.set((long) (-100), (-35));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for minuteOfDay must be in the range [1,1440]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-59940000L) + "'", long16 == (-59940000L));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant4, readableDuration5, periodType6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType6);
        org.joda.time.PeriodType periodType9 = periodType6.withMillisRemoved();
        java.lang.String str10 = periodType6.getName();
        org.joda.time.PeriodType periodType11 = periodType6.withYearsRemoved();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Millis" + "'", str10.equals("Millis"));
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology36.era();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        boolean boolean11 = period3.equals((java.lang.Object) gregorianChronology9);
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            long long14 = gregorianChronology9.set(readablePartial12, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        int int12 = fixedDateTimeZone4.getStandardOffset((-2L));
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone4.getName(60000L, locale14);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant5, readableDuration6, periodType7);
        org.joda.time.Period period10 = period8.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period8.getFieldTypes();
        org.joda.time.Seconds seconds12 = period8.toStandardSeconds();
        int[] intArray13 = period8.getValues();
        int int14 = offsetDateTimeField3.getMinimumValue(readablePartial4, intArray13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant17, readableDuration18, periodType19);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        boolean boolean22 = period20.isSupported(durationFieldType21);
        int[] intArray23 = period20.getValues();
        try {
            int[] intArray25 = offsetDateTimeField3.addWrapPartial(readablePartial15, (int) '#', intArray23, 1440);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(seconds12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT0.100S", "");
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = zonedChronology36.getZone();
        long long43 = dateTimeZone40.convertLocalToUTC(59948L, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 59947L + "'", long43 == 59947L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        try {
            org.joda.time.Period period5 = period3.plusWeeks(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant39, readableDuration40, periodType41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType41);
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.Period period48 = new org.joda.time.Period((java.lang.Object) period43, periodType44, chronology47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getChronology(chronology47);
        boolean boolean50 = zonedChronology36.equals((java.lang.Object) chronology49);
        java.lang.String str51 = zonedChronology36.toString();
        try {
            long long59 = zonedChronology36.getDateTimeMillis((int) (byte) 10, 96, (int) (byte) 100, 0, (int) (byte) 0, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 96 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ZonedChronology[ISOChronology[UTC], hi!]" + "'", str51.equals("ZonedChronology[ISOChronology[UTC], hi!]"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period3.negated();
        org.joda.time.Period period17 = period15.minusHours((int) (short) 0);
        try {
            org.joda.time.Period period19 = period15.minusMonths((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 2L, (java.lang.Number) 59999L, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DurationField durationField24 = iSOChronology7.seconds();
        org.joda.time.ReadablePartial readablePartial25 = null;
        try {
            int[] intArray27 = iSOChronology7.get(readablePartial25, (-58665540000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PeriodType[Standard]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.get(0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((-210865896000000L), locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "721" + "'", str13.equals("721"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1L, (-210866760000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210866759999999L) + "'", long2 == (-210866759999999L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period8.indexOf(durationFieldType10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[hi!]", 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("minuteOfDay", 262974247, (int) (short) 100, (int) 'a', '#', (-52), 8, 1, false, (int) (byte) 10);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("ISOChronology[hi!]", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-52), (int) (short) 1, (int) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        try {
//            long long11 = gregorianChronology3.getDateTimeMillis((-35), 102, (int) '4', 1440, (-1), (-1), 44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1440 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean7 = fixedDateTimeZone5.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType14);
        org.joda.time.Period period17 = period16.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod18 = period17.toMutablePeriod();
        int[] intArray21 = iSOChronology8.get((org.joda.time.ReadablePeriod) mutablePeriod18, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology8.era();
        java.lang.String str23 = iSOChronology8.toString();
        org.joda.time.DurationField durationField24 = iSOChronology8.hours();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology8.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology8.weekOfWeekyear();
        org.joda.time.DurationField durationField27 = iSOChronology8.centuries();
        org.joda.time.DurationField durationField28 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long31 = durationField28.subtract(1560627205619L, 1560627205619L);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField32 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField27, durationField28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(mutablePeriod18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[hi!]" + "'", str23.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        java.lang.Object obj37 = null;
        boolean boolean38 = zonedChronology36.equals(obj37);
        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.secondOfDay();
        try {
            long long47 = zonedChronology36.getDateTimeMillis(1, (-52), 1440, (int) ' ', (int) (short) -1, 35, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Millis");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        long long11 = offsetDateTimeField3.roundHalfEven((long) 1440);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField3.getAsShortText((long) 96, locale13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.ReadablePartial readablePartial0 = null;
//        org.joda.time.ReadablePartial readablePartial1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
//        java.lang.String str5 = gregorianChronology2.toString();
//        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.minutes();
//        boolean boolean7 = gregorianChronology2.equals((java.lang.Object) periodType6);
//        try {
//            org.joda.time.Period period8 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[PT0S]" + "'", str5.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertNotNull(periodType6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.time();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(100, (int) 'a', (int) (byte) 10, 100, (-35), (int) '#', (int) (short) 100, 262974247, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str13 = cachedDateTimeZone11.getShortName((long) (short) 0);
        java.lang.String str15 = cachedDateTimeZone11.getShortName((-349199999L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.001" + "'", str13.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology7.weekOfWeekyear();
        try {
            long long30 = iSOChronology7.getDateTimeMillis((int) ' ', 100, (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.ReadablePartial readablePartial4 = null;
//        int[] intArray11 = new int[] { 8, 4, (byte) -1, 10, (byte) 10, (short) 10 };
//        try {
//            gregorianChronology3.validate(readablePartial4, intArray11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(59947L, "hi!");
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType16);
        org.joda.time.Period period19 = period18.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod20 = period19.toMutablePeriod();
        org.joda.time.Period period22 = org.joda.time.Period.millis(100);
        org.joda.time.Period period23 = period19.withFields((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period25 = period22.plusSeconds((int) (short) 0);
        org.joda.time.Period period27 = period25.withHours(96);
        try {
            org.joda.time.Period period28 = period11.minus((org.joda.time.ReadablePeriod) period27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(mutablePeriod20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.plusWeeks((int) '#');
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = period2.isSupported(durationFieldType5);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField7 = gregorianChronology6.centuries();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.Chronology chronology9 = gregorianChronology6.withUTC();
        org.joda.time.Period period10 = new org.joda.time.Period(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Period period11 = period4.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
        org.joda.time.Period period17 = period15.minusMillis((int) (byte) 10);
        int int18 = period15.size();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        boolean boolean20 = period15.isSupported(durationFieldType19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType24 = periodType23.withMinutesRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType23);
        org.joda.time.Period period26 = period15.plus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period27 = period15.negated();
        org.joda.time.Hours hours28 = period27.toStandardHours();
        org.joda.time.Period period29 = period11.plus((org.joda.time.ReadablePeriod) period27);
        try {
            org.joda.time.Period period31 = period27.withWeeks(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(hours28);
        org.junit.Assert.assertNotNull(period29);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (-52), (int) (byte) 100, 96, (int) (byte) 100, 0, (-100), 1440);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        long long12 = offsetDateTimeField3.roundFloor(1L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 262974247);
        int int16 = offsetDateTimeField3.getLeapAmount(0L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) (byte) 10, periodType20, chronology21);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Duration duration24 = period22.toDurationTo(readableInstant23);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant25, readableDuration26, periodType27);
        org.joda.time.Period period30 = period28.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray31 = period28.getFieldTypes();
        org.joda.time.Seconds seconds32 = period28.toStandardSeconds();
        org.joda.time.Period period33 = period22.minus((org.joda.time.ReadablePeriod) seconds32);
        int[] intArray34 = period22.getValues();
        try {
            int[] intArray36 = offsetDateTimeField3.add(readablePartial17, 35, intArray34, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldTypeArray31);
        org.junit.Assert.assertNotNull(seconds32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.Period period1 = new org.joda.time.Period(3251471753L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType5);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period7, periodType8, chronology11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationFrom(readableInstant13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 10, periodType17, chronology18);
        java.lang.String str20 = periodType17.getName();
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15, periodType17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant24, readableDuration25, periodType26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType26);
        org.joda.time.PeriodType periodType29 = periodType26.withMillisRemoved();
        java.lang.String str30 = periodType26.getName();
        java.lang.String str31 = periodType26.getName();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration14, periodType26);
        try {
            org.joda.time.Period period34 = period32.plusSeconds((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Millis" + "'", str30.equals("Millis"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Millis" + "'", str31.equals("Millis"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.PeriodType periodType8 = periodType4.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 9, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.DurationField durationField45 = iSOChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology7.halfdayOfDay();
        org.joda.time.Chronology chronology47 = iSOChronology7.withUTC();
        org.joda.time.DurationField durationField48 = iSOChronology7.weekyears();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (short) 10, 5, (int) 'a', (-35));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-100), 96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 96");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        long long12 = offsetDateTimeField3.getDifferenceAsLong((long) 1, (-195088305180000L));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField3, 0, (int) ' ', (-34));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [32,-34]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3251471753L + "'", long12 == 3251471753L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        java.lang.String str22 = iSOChronology7.toString();
        org.joda.time.DurationField durationField23 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology7.yearOfCentury();
        long long29 = iSOChronology7.add((long) (byte) 1, 0L, (int) ' ');
        org.joda.time.DurationField durationField30 = iSOChronology7.hours();
        org.joda.time.DurationFieldType durationFieldType31 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField32 = new org.joda.time.field.DecoratedDurationField(durationField30, durationFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[hi!]" + "'", str22.equals("ISOChronology[hi!]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period7 = period5.minusMillis((int) (byte) 10);
        org.joda.time.Period period9 = period5.plusMonths((int) (short) 0);
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period5, 99L);
        try {
            org.joda.time.Period period13 = period5.withSeconds((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[hi!]", 4);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("-34", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        java.lang.String str3 = gregorianChronology0.toString();
//        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean12 = fixedDateTimeZone10.equals((java.lang.Object) 0);
//        java.lang.String str13 = fixedDateTimeZone10.getID();
//        long long16 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
//        boolean boolean18 = cachedDateTimeZone17.isFixed();
//        long long20 = cachedDateTimeZone17.convertUTCToLocal((long) (byte) 1);
//        long long22 = cachedDateTimeZone17.nextTransition((long) (-35));
//        java.lang.String str23 = cachedDateTimeZone17.toString();
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology0.hourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[PT0S]" + "'", str3.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2L) + "'", long16 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2L + "'", long20 == 2L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-35L) + "'", long22 == (-35L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(100);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        org.joda.time.DurationField durationField45 = iSOChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology7.hourOfDay();
        org.joda.time.ReadablePartial readablePartial47 = null;
        try {
            long long49 = iSOChronology7.set(readablePartial47, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Period period9 = period8.toPeriod();
        int int10 = period9.getSeconds();
        int int11 = period9.getMillis();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-58060799990L), (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1857945599680");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("ISOChronology[hi!]", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("P0D", (int) '4', (-34), (int) (short) 1, ' ', (int) (byte) 100, (-100), (int) (short) 1, true, (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.getLeapAmount((-2L));
        long long12 = offsetDateTimeField3.roundHalfFloor((-58060799990L));
        int int14 = offsetDateTimeField3.getLeapAmount((long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58060800000L) + "'", long12 == (-58060800000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
//        org.joda.time.Period period16 = period15.toPeriod();
//        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
//        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology7.getZone();
//        org.joda.time.DurationField durationField24 = iSOChronology7.weeks();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.hourOfDay();
//        java.lang.String str28 = gregorianChronology25.toString();
//        int int29 = gregorianChronology25.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology25.getZone();
//        org.joda.time.Chronology chronology31 = iSOChronology7.withZone(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology7.clockhourOfHalfday();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(mutablePeriod17);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GregorianChronology[PT0S]" + "'", str28.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.Period period5 = period4.toPeriod();
        java.lang.Class<?> wildcardClass6 = period4.getClass();
        org.joda.time.PeriodType periodType7 = period4.getPeriodType();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.years();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((-34), 35, 44, 100, 44, 96, (int) (short) 1, 1440, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1560627205619L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2458650L + "'", long1 == 2458650L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.Period period5 = period3.plusDays((-52));
        org.joda.time.Period period7 = period5.minusHours(5);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj5 = null;
        boolean boolean6 = jodaTimePermission4.equals(obj5);
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("GregorianChronology[America/Los_Angeles]");
        boolean boolean10 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission9);
        java.security.PermissionCollection permissionCollection11 = jodaTimePermission4.newPermissionCollection();
        java.security.PermissionCollection permissionCollection12 = jodaTimePermission4.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(permissionCollection11);
        org.junit.Assert.assertNotNull(permissionCollection12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        illegalFieldValueException2.prependMessage("+00:00:00.001");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray16 = new int[] { 441, 9, 1, (-35) };
        try {
            int[] intArray18 = offsetDateTimeField3.add(readablePartial10, 5, intArray16, (-34));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Period period3 = new org.joda.time.Period(1009843200000L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int11 = offsetDateTimeField3.getDifference(9700L, (long) 35);
        long long13 = offsetDateTimeField3.roundHalfEven(28800000L);
        int int15 = offsetDateTimeField3.get((-59947903L));
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 1);
        int int24 = offsetDateTimeField21.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField21.getAsShortText(0L, locale26);
        long long29 = offsetDateTimeField21.roundHalfCeiling(10L);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant31, readableDuration32, periodType33);
        org.joda.time.DurationFieldType durationFieldType35 = null;
        boolean boolean36 = period34.isSupported(durationFieldType35);
        int[] intArray37 = period34.getValues();
        int int38 = offsetDateTimeField21.getMaximumValue(readablePartial30, intArray37);
        try {
            int[] intArray40 = offsetDateTimeField3.addWrapField(readablePartial16, 9, intArray37, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 441 + "'", int15 == 441);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 262974247 + "'", int24 == 262974247);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1440 + "'", int38 == 1440);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        long long6 = offsetDateTimeField3.roundFloor(0L);
        int int9 = offsetDateTimeField3.getDifference((long) (short) 1, 34L);
        java.util.Locale locale12 = null;
        try {
            long long13 = offsetDateTimeField3.set((-15778454822002L), "", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType4);
        org.joda.time.Period period7 = period6.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod8 = period7.toMutablePeriod();
        org.joda.time.Period period10 = org.joda.time.Period.millis(100);
        org.joda.time.Period period11 = period7.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = period11.isSupported(durationFieldType12);
        org.joda.time.Period period15 = period11.minusYears(0);
        try {
            org.joda.time.Period period17 = period11.withYears((-35));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean8 = fixedDateTimeZone6.equals((java.lang.Object) 0);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        long long12 = fixedDateTimeZone6.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey(100L);
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) 100L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        try {
            int[] intArray19 = gregorianChronology0.get(readablePartial17, 34L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2L) + "'", long12 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 100);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = dateTimeZone2.getOffset(readableInstant3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField3.getLeapAmount((-2L));
        org.joda.time.DurationField durationField11 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial12 = null;
        int[] intArray18 = new int[] { 102, 35, '4', (-34) };
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = offsetDateTimeField3.set(readablePartial12, (int) (byte) -1, intArray18, "Minutes", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Minutes\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(intArray18);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
//        org.joda.time.Period period16 = period15.toPeriod();
//        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
//        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
//        java.lang.String str29 = fixedDateTimeZone26.getID();
//        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = zonedChronology36.equals(obj37);
//        org.joda.time.DateTimeField dateTimeField39 = zonedChronology36.weekOfWeekyear();
//        java.util.TimeZone timeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forTimeZone(timeZone40);
//        java.lang.String str42 = dateTimeZone41.getID();
//        org.joda.time.Chronology chronology43 = zonedChronology36.withZone(dateTimeZone41);
//        org.joda.time.ReadableInterval readableInterval44 = null;
//        org.joda.time.ReadableInterval readableInterval45 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval44);
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
//        boolean boolean47 = zonedChronology36.equals((java.lang.Object) readableInterval45);
//        org.joda.time.DateTimeField dateTimeField48 = zonedChronology36.minuteOfHour();
//        try {
//            long long54 = zonedChronology36.getDateTimeMillis(0L, 9, (-1), (int) (short) 1, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(mutablePeriod17);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "PT0S" + "'", str42.equals("PT0S"));
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(readableInterval45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str13 = cachedDateTimeZone11.getShortName((long) (short) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean20 = fixedDateTimeZone18.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant25, readableDuration26, periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType27);
        org.joda.time.Period period30 = period29.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod31 = period30.toMutablePeriod();
        int[] intArray34 = iSOChronology21.get((org.joda.time.ReadablePeriod) mutablePeriod31, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology21.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean42 = fixedDateTimeZone40.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period50 = new org.joda.time.Period(readableInstant47, readableDuration48, periodType49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType49);
        org.joda.time.Period period52 = period51.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod53 = period52.toMutablePeriod();
        int[] intArray56 = iSOChronology43.get((org.joda.time.ReadablePeriod) mutablePeriod53, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology43.minuteOfHour();
        boolean boolean58 = iSOChronology21.equals((java.lang.Object) dateTimeField57);
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology21.hourOfHalfday();
        boolean boolean60 = cachedDateTimeZone11.equals((java.lang.Object) dateTimeField59);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.001" + "'", str13.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(mutablePeriod31);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(mutablePeriod53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean7 = fixedDateTimeZone5.isStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType14);
//        org.joda.time.Period period16 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType14);
//        org.joda.time.Period period17 = period16.toPeriod();
//        org.joda.time.MutablePeriod mutablePeriod18 = period17.toMutablePeriod();
//        int[] intArray21 = iSOChronology8.get((org.joda.time.ReadablePeriod) mutablePeriod18, 35L, (long) 100);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology8.minuteOfHour();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean29 = fixedDateTimeZone27.equals((java.lang.Object) 0);
//        java.lang.String str30 = fixedDateTimeZone27.getID();
//        long long33 = fixedDateTimeZone27.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
//        long long36 = cachedDateTimeZone34.previousTransition((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeZone) cachedDateTimeZone34);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = zonedChronology37.equals(obj38);
//        org.joda.time.DateTimeField dateTimeField40 = zonedChronology37.weekOfWeekyear();
//        java.util.TimeZone timeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
//        java.lang.String str43 = dateTimeZone42.getID();
//        org.joda.time.Chronology chronology44 = zonedChronology37.withZone(dateTimeZone42);
//        org.joda.time.Period period45 = new org.joda.time.Period(10L, (org.joda.time.Chronology) zonedChronology37);
//        try {
//            long long50 = zonedChronology37.getDateTimeMillis((int) (short) 0, 35, (int) 'a', 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(mutablePeriod18);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-2L) + "'", long33 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
//        org.junit.Assert.assertNotNull(zonedChronology37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PT0S" + "'", str43.equals("PT0S"));
//        org.junit.Assert.assertNotNull(chronology44);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        int int12 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        long long15 = fixedDateTimeZone4.nextTransition(1L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-59940000L), (long) (-100));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59939900L) + "'", long2 == (-59939900L));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
        org.joda.time.Period period38 = period37.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
        boolean boolean44 = iSOChronology7.equals((java.lang.Object) dateTimeField43);
        java.lang.String str45 = iSOChronology7.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ISOChronology[hi!]" + "'", str45.equals("ISOChronology[hi!]"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        boolean boolean12 = offsetDateTimeField3.isLeap((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant15, readableDuration16, periodType17);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        boolean boolean20 = period18.isSupported(durationFieldType19);
        int[] intArray21 = period18.getValues();
        try {
            int[] intArray23 = offsetDateTimeField3.addWrapField(readablePartial13, (int) '4', intArray21, 262974247);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = period3.getFieldTypes();
        org.joda.time.Minutes minutes7 = period3.toStandardMinutes();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Period period9 = period3.plus(readablePeriod8);
        try {
            org.joda.time.Period period11 = period9.plusSeconds((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
        org.junit.Assert.assertNotNull(minutes7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType10);
        org.joda.time.Period period13 = period12.toPeriod();
        boolean boolean14 = gregorianChronology1.equals((java.lang.Object) period12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType5);
        org.joda.time.PeriodType periodType8 = periodType5.withMillisRemoved();
        java.lang.String str9 = periodType5.getName();
        java.lang.String str10 = periodType5.getName();
        org.joda.time.Period period11 = new org.joda.time.Period(28800000L, periodType5);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Millis" + "'", str9.equals("Millis"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Millis" + "'", str10.equals("Millis"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.era();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField23 = iSOChronology7.months();
        org.joda.time.Chronology chronology24 = iSOChronology7.withUTC();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(chronology24);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
//        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
//        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.secondOfMinute();
//        java.lang.String str9 = gregorianChronology6.toString();
//        org.joda.time.Period period10 = new org.joda.time.Period(2L, periodType4, (org.joda.time.Chronology) gregorianChronology6);
//        int int11 = period10.getMillis();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(periodType4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[PT0S]" + "'", str9.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Minutes");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
//        org.joda.time.Period period16 = period15.toPeriod();
//        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
//        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
//        org.joda.time.DurationField durationField21 = iSOChronology7.weekyears();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean28 = fixedDateTimeZone26.isStandardOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant33 = null;
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant33, readableDuration34, periodType35);
//        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType35);
//        org.joda.time.Period period38 = period37.toPeriod();
//        org.joda.time.MutablePeriod mutablePeriod39 = period38.toMutablePeriod();
//        int[] intArray42 = iSOChronology29.get((org.joda.time.ReadablePeriod) mutablePeriod39, 35L, (long) 100);
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology29.minuteOfHour();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean50 = fixedDateTimeZone48.equals((java.lang.Object) 0);
//        java.lang.String str51 = fixedDateTimeZone48.getID();
//        long long54 = fixedDateTimeZone48.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone55 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone48);
//        long long57 = cachedDateTimeZone55.previousTransition((long) (short) 10);
//        org.joda.time.chrono.ZonedChronology zonedChronology58 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, (org.joda.time.DateTimeZone) cachedDateTimeZone55);
//        java.lang.Object obj59 = null;
//        boolean boolean60 = zonedChronology58.equals(obj59);
//        org.joda.time.DateTimeField dateTimeField61 = zonedChronology58.weekOfWeekyear();
//        java.util.TimeZone timeZone62 = null;
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forTimeZone(timeZone62);
//        java.lang.String str64 = dateTimeZone63.getID();
//        org.joda.time.Chronology chronology65 = zonedChronology58.withZone(dateTimeZone63);
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeUtils.getZone(dateTimeZone63);
//        org.joda.time.Chronology chronology67 = iSOChronology7.withZone(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(mutablePeriod17);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(periodType35);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(mutablePeriod39);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2L) + "'", long54 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertNotNull(zonedChronology58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "PT0S" + "'", str64.equals("PT0S"));
//        org.junit.Assert.assertNotNull(chronology65);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertNotNull(chronology67);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period3.negated();
        org.joda.time.Period period17 = period15.minusHours((int) (short) 0);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType19 = periodType18.withMillisRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withDaysRemoved();
        org.joda.time.Period period21 = period17.normalizedStandard(periodType19);
        java.lang.String str22 = periodType19.getName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Days" + "'", str22.equals("Days"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfDay();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Hours hours9 = period8.toStandardHours();
        org.joda.time.Period period10 = period8.normalizedStandard();
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period8.getFieldTypes();
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period8.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(hours9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(0L, locale8);
        java.lang.String str10 = offsetDateTimeField3.getName();
        boolean boolean12 = offsetDateTimeField3.isLeap((long) (short) 100);
        boolean boolean14 = offsetDateTimeField3.isLeap((-58665539965L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(262974247);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-262974247) + "'", int1 == (-262974247));
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        java.lang.String str4 = gregorianChronology1.toString();
//        org.joda.time.Period period5 = new org.joda.time.Period((-210865896000000L), (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.Chronology chronology6 = gregorianChronology1.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[PT0S]" + "'", str4.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType9 = periodType8.withMinutesRemoved();
        org.joda.time.PeriodType periodType10 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType11 = periodType8.withSecondsRemoved();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((-35), (int) (short) 1, (-34), 0, 0, 441, 102, 10, periodType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        try {
            org.joda.time.Period period8 = period4.minusWeeks((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Days", "minuteOfDay");
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.Period period1 = org.joda.time.Period.days(10);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType5 = periodType4.withMinutesRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType5);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType12);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.Period period16 = period6.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period17 = period1.plus((org.joda.time.ReadablePeriod) period13);
        int int18 = period13.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PT0S" + "'", str8.equals("PT0S"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0S" + "'", str15.equals("PT0S"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText((-34), locale8);
        int int10 = offsetDateTimeField3.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-34" + "'", str9.equals("-34"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1440 + "'", int10 == 1440);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DurationField durationField37 = zonedChronology36.weeks();
        long long41 = zonedChronology36.add((long) 1, (long) 4, (-100));
        org.joda.time.DateTimeField dateTimeField42 = zonedChronology36.weekyearOfCentury();
        try {
            org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) dateTimeField42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-399L) + "'", long41 == (-399L));
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period3.isSupported(durationFieldType7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType12 = periodType11.withMinutesRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period3.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType17 = periodType16.withMillisRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withDaysRemoved();
        org.joda.time.PeriodType periodType19 = org.joda.time.DateTimeUtils.getPeriodType(periodType17);
        org.joda.time.Period period20 = period15.normalizedStandard(periodType17);
        java.lang.String str21 = periodType17.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PeriodType[Days]" + "'", str21.equals("PeriodType[Days]"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.millisOfSecond();
        org.joda.time.DurationField durationField22 = iSOChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology7.clockhourOfHalfday();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(8, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 10);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.MutablePeriod mutablePeriod3 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(mutablePeriod3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology7.secondOfMinute();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 10);
        int int6 = period3.size();
        org.joda.time.Period period8 = period3.plusMinutes(0);
        org.joda.time.Hours hours9 = period8.toStandardHours();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period8.indexOf(durationFieldType10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(hours9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        java.lang.String str3 = gregorianChronology0.toString();
//        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
//        boolean boolean12 = fixedDateTimeZone10.equals((java.lang.Object) 0);
//        java.lang.String str13 = fixedDateTimeZone10.getID();
//        long long16 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
//        boolean boolean18 = cachedDateTimeZone17.isFixed();
//        long long20 = cachedDateTimeZone17.convertUTCToLocal((long) (byte) 1);
//        long long22 = cachedDateTimeZone17.nextTransition((long) (-35));
//        java.lang.String str23 = cachedDateTimeZone17.toString();
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology0.dayOfYear();
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.millis();
//        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType28);
//        org.joda.time.Period period31 = period29.minusMillis((int) (byte) 10);
//        int int32 = period29.size();
//        org.joda.time.DurationFieldType durationFieldType33 = null;
//        boolean boolean34 = period29.isSupported(durationFieldType33);
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.millis();
//        org.joda.time.PeriodType periodType38 = periodType37.withMinutesRemoved();
//        org.joda.time.Period period39 = new org.joda.time.Period(readableDuration35, readableInstant36, periodType37);
//        org.joda.time.Period period40 = period29.plus((org.joda.time.ReadablePeriod) period39);
//        org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) period40);
//        boolean boolean42 = gregorianChronology0.equals((java.lang.Object) period41);
//        org.joda.time.ReadablePartial readablePartial43 = null;
//        try {
//            int[] intArray45 = gregorianChronology0.get(readablePartial43, 1560627205619L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[PT0S]" + "'", str3.equals("GregorianChronology[PT0S]"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2L) + "'", long16 == (-2L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2L + "'", long20 == 2L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-35L) + "'", long22 == (-35L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertNotNull(periodType38);
//        org.junit.Assert.assertNotNull(period40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType13);
        org.joda.time.Period period16 = period15.toPeriod();
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        int[] intArray20 = iSOChronology7.get((org.joda.time.ReadablePeriod) mutablePeriod17, 35L, (long) 100);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean28 = fixedDateTimeZone26.equals((java.lang.Object) 0);
        java.lang.String str29 = fixedDateTimeZone26.getID();
        long long32 = fixedDateTimeZone26.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long35 = cachedDateTimeZone33.previousTransition((long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, (org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.DurationField durationField37 = zonedChronology36.weeks();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 10, periodType39, chronology40);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Duration duration43 = period41.toDurationTo(readableInstant42);
        boolean boolean44 = zonedChronology36.equals((java.lang.Object) duration43);
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology36);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2L) + "'", long32 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(duration43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) 100L, (java.lang.Number) 96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2458650L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.528456597d + "'", double1 == 2440587.528456597d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period2 = new org.joda.time.Period((long) 102, periodType1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) 10);
        int int9 = period6.size();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = period6.isSupported(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType15 = periodType14.withMinutesRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType14);
        org.joda.time.Period period17 = period6.plus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period18 = period6.negated();
        org.joda.time.Period period19 = period2.minus((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period20 = period2.negated();
        try {
            org.joda.time.Period period22 = period20.withHours(44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", (java.lang.Number) 262974247, (java.lang.Number) (short) 100, (java.lang.Number) 1.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period16 = period14.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.Seconds seconds18 = period14.toStandardSeconds();
        int[] intArray19 = period14.getValues();
        int int20 = offsetDateTimeField3.getMinimumValue(readablePartial10, intArray19);
        org.joda.time.DurationField durationField21 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(seconds18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType5);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period7, periodType8, chronology11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationFrom(readableInstant13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 10, periodType17, chronology18);
        java.lang.String str20 = periodType17.getName();
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15, periodType17);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant24, readableDuration25, periodType26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType26);
        org.joda.time.PeriodType periodType29 = periodType26.withMillisRemoved();
        java.lang.String str30 = periodType26.getName();
        java.lang.String str31 = periodType26.getName();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration14, periodType26);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant33);
        org.joda.time.Period period36 = period34.plusHours((-52));
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Millis" + "'", str30.equals("Millis"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Millis" + "'", str31.equals("Millis"));
        org.junit.Assert.assertNotNull(period36);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("Time", 8);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("Time", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int13 = cachedDateTimeZone11.getOffsetFromLocal(0L);
        long long15 = cachedDateTimeZone11.nextTransition((long) (byte) 10);
        long long17 = cachedDateTimeZone11.previousTransition((long) 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2L + "'", long17 == 2L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        boolean boolean6 = fixedDateTimeZone4.equals((java.lang.Object) 0);
        java.lang.String str7 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true);
        int int12 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        boolean boolean14 = fixedDateTimeZone4.isStandardOffset((long) 10);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.millisOfSecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(8);
        org.joda.time.Hours hours2 = period1.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(hours2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 1, (int) '#');
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (-1));
        int int8 = fixedDateTimeZone4.getStandardOffset(0L);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.time();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) 10, periodType1, chronology2);
        org.joda.time.PeriodType periodType4 = periodType1.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.centuries();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, (long) (short) 1, periodType10);
        org.joda.time.Period period13 = period12.toPeriod();
        boolean boolean14 = gregorianChronology1.equals((java.lang.Object) period12);
        org.joda.time.ReadablePartial readablePartial15 = null;
        try {
            long long17 = gregorianChronology1.set(readablePartial15, 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int6 = offsetDateTimeField3.getDifference((long) (short) -1, (-15778454822002L));
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        int int9 = offsetDateTimeField3.getMaximumValue(readablePartial7, intArray8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableDuration12, periodType13);
        org.joda.time.Period period16 = period14.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.Seconds seconds18 = period14.toStandardSeconds();
        int[] intArray19 = period14.getValues();
        int int20 = offsetDateTimeField3.getMinimumValue(readablePartial10, intArray19);
        long long22 = offsetDateTimeField3.roundCeiling(1L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant25, readableDuration26, periodType27);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        boolean boolean30 = period28.isSupported(durationFieldType29);
        int[] intArray31 = period28.getValues();
        try {
            int[] intArray33 = offsetDateTimeField3.addWrapPartial(readablePartial23, 1440, intArray31, 441);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1440");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 262974247 + "'", int6 == 262974247);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1440 + "'", int9 == 1440);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(seconds18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60000L + "'", long22 == 60000L);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        org.joda.time.Period period6 = period4.minusMillis((int) (byte) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period4.getFieldTypes();
        org.joda.time.Days days8 = period4.toStandardDays();
        long long11 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period4, 10L, (-100));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(days8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }
}

