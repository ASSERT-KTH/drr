import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis((int) (short) 1, 2, 25252, 0, (int) (short) 10, 163, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("2020", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2020\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) -1);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
//        org.joda.time.DateTime.Property property7 = dateTime1.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str4.equals("1970-01-01T00:00:00.100Z"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.String str2 = dateTimeFormatter0.print((long) 4);
        try {
            long long4 = dateTimeFormatter0.parseMillis("-10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-10:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2019-06-12T05:37:44.026", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T05:37:44.026" + "'", str4.equals("2019-06-12T05:37:44.026"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-12T05:37:44.026" + "'", str8.equals("2019-06-12T05:37:44.026"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 2019);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("DateTimeField[year]", "GregorianChronology[UTC]");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfHour(1969, 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.append(dateTimeParser23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder18.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        org.joda.time.DateTime dateTime12 = property7.addToCopy((-292275054));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
//        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
//        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
//        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
//        int int42 = zeroIsMaxDateTimeField40.get(0L);
//        long long44 = zeroIsMaxDateTimeField40.roundHalfCeiling(31536000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 31536000000L + "'", long44 == 31536000000L);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = cachedDateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = cachedDateTimeZone1.getUncachedZone();
        int int6 = cachedDateTimeZone1.getOffset((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        long long23 = skipUndoDateTimeField7.add((long) (byte) -1, 20257);
//        int int25 = skipUndoDateTimeField7.get((long) (byte) 100);
//        long long28 = skipUndoDateTimeField7.add((long) 3, (long) 57599);
//        boolean boolean29 = skipUndoDateTimeField7.isLenient();
//        org.joda.time.DurationField durationField30 = skipUndoDateTimeField7.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 639249148799999L + "'", long23 == 639249148799999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1971 + "'", int25 == 1971);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1817648899200003L + "'", long28 == 1817648899200003L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNull(durationField30);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
//        org.joda.time.DateTime dateTime15 = dateTime14.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime14.withPeriodAdded(readablePeriod16, (int) (byte) 10);
//        mutableDateTime10.setTime((org.joda.time.ReadableInstant) dateTime14);
//        int int20 = mutableDateTime10.getMinuteOfDay();
//        mutableDateTime10.setHourOfDay(2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime7.add(readableDuration8, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.DateTime dateTime15 = dateTime14.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) '4');
        org.joda.time.DateTime.Property property23 = dateTime19.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.DateTime dateTime26 = dateTime14.withField(dateTimeFieldType24, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        boolean boolean31 = mutableDateTime7.isSupported(dateTimeFieldType24);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType24, 0, 163, 28800);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.year();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        long long12 = dateTimeZone8.convertLocalToUTC((long) (short) 1, false, (long) 0);
        long long14 = dateTimeZone7.getMillisKeepLocal(dateTimeZone8, (long) '4');
        mutableDateTime5.setZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
//        int int7 = property4.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime10 = property4.addWrapField(1969);
//        mutableDateTime10.addMonths(1591879061);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime17 = dateTime16.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime16.withPeriodAdded(readablePeriod18, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime22 = dateTime20.withZoneRetainFields(dateTimeZone21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str24 = dateTime20.toString(dateTimeFormatter23);
//        org.joda.time.DateTime.Property property25 = dateTime20.yearOfEra();
//        boolean boolean26 = mutableDateTime10.isAfter((org.joda.time.ReadableInstant) dateTime20);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970-01-01T00:00:20.248" + "'", str24.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        try {
            mutableDateTime2.setWeekyear(1591879064);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1591879064 for weekyear must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType19, 57599, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder5.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder5.appendMinuteOfHour((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) '4');
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime18.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
//        org.joda.time.DateTime dateTime24 = dateTime23.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime23.withPeriodAdded(readablePeriod25, (int) (byte) 10);
//        mutableDateTime19.setTime((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField31 = gregorianChronology30.eras();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField34 = gregorianChronology33.eras();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField35, 2019);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime39.plus(readablePeriod40);
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.DateTime dateTime44 = dateTime41.withPeriodAdded(readablePeriod42, (int) '4');
//        org.joda.time.DateTime.Property property45 = dateTime41.secondOfMinute();
//        org.joda.time.DateTime dateTime46 = property45.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime48 = property45.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay49 = dateTime48.toYearMonthDay();
//        int int50 = skipUndoDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay49);
//        int int53 = skipUndoDateTimeField37.getDifference((long) 0, 1L);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, (org.joda.time.DateTimeField) skipUndoDateTimeField37);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone55);
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime58 = dateTime56.plus(readablePeriod57);
//        org.joda.time.ReadablePeriod readablePeriod59 = null;
//        org.joda.time.DateTime dateTime61 = dateTime58.withPeriodAdded(readablePeriod59, (int) '4');
//        org.joda.time.DateTime.Property property62 = dateTime58.secondOfMinute();
//        org.joda.time.DateTime dateTime63 = property62.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime65 = property62.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay66 = dateTime65.toYearMonthDay();
//        org.joda.time.Chronology chronology69 = null;
//        org.joda.time.Chronology chronology71 = null;
//        java.util.Locale locale72 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket75 = new org.joda.time.format.DateTimeParserBucket(100L, chronology71, locale72, (java.lang.Integer) 10, 0);
//        long long78 = dateTimeParserBucket75.computeMillis(false, "hi!");
//        java.util.Locale locale79 = dateTimeParserBucket75.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket82 = new org.joda.time.format.DateTimeParserBucket((long) ' ', chronology69, locale79, (java.lang.Integer) 10, (int) '#');
//        java.lang.String str83 = skipDateTimeField54.getAsText((org.joda.time.ReadablePartial) yearMonthDay66, 292278992, locale79);
//        int[] intArray85 = gregorianChronology2.get((org.joda.time.ReadablePartial) yearMonthDay66, 31535999999L);
//        try {
//            java.lang.String str86 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) yearMonthDay66);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(yearMonthDay49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(yearMonthDay66);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 100L + "'", long78 == 100L);
//        org.junit.Assert.assertNotNull(locale79);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "292278992" + "'", str83.equals("292278992"));
//        org.junit.Assert.assertNotNull(intArray85);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(25200);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField5 = gregorianChronology4.eras();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.millisOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, dateTimeField6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField12 = gregorianChronology11.eras();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField13, 2019);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) '4');
//        org.joda.time.DateTime.Property property23 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime24 = property23.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime26 = property23.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime26.toYearMonthDay();
//        int int28 = skipUndoDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.plus(readablePeriod31);
//        org.joda.time.ReadablePeriod readablePeriod33 = null;
//        org.joda.time.DateTime dateTime35 = dateTime32.withPeriodAdded(readablePeriod33, (int) '4');
//        org.joda.time.DateTime.Property property36 = dateTime32.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType37, (-1));
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType37);
//        int int45 = zeroIsMaxDateTimeField43.get(0L);
//        long long48 = zeroIsMaxDateTimeField43.add((long) 57599, 0);
//        long long50 = zeroIsMaxDateTimeField43.roundHalfFloor((long) (short) 1);
//        long long52 = zeroIsMaxDateTimeField43.roundHalfFloor(31536000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField55 = gregorianChronology54.eras();
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField58 = gregorianChronology57.eras();
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology57.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology54, dateTimeField59, 2019);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone62);
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.DateTime dateTime65 = dateTime63.plus(readablePeriod64);
//        org.joda.time.LocalDate localDate66 = dateTime65.toLocalDate();
//        org.joda.time.Chronology chronology69 = null;
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket73 = new org.joda.time.format.DateTimeParserBucket(100L, chronology69, locale70, (java.lang.Integer) 10, 0);
//        long long76 = dateTimeParserBucket73.computeMillis(false, "hi!");
//        java.util.Locale locale77 = dateTimeParserBucket73.getLocale();
//        java.lang.String str78 = skipUndoDateTimeField61.getAsText((org.joda.time.ReadablePartial) localDate66, (int) 'a', locale77);
//        java.lang.String str79 = zeroIsMaxDateTimeField43.getAsShortText(59, locale77);
//        java.lang.String str80 = dateTimeZone1.getName(2440588L, locale77);
//        org.joda.time.MutableDateTime mutableDateTime81 = new org.joda.time.MutableDateTime(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-292275054) + "'", int28 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 86400000 + "'", int45 == 86400000);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 57599L + "'", long48 == 57599L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 31536000000L + "'", long52 == 31536000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 100L + "'", long76 == 100L);
//        org.junit.Assert.assertNotNull(locale77);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "97" + "'", str78.equals("97"));
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "59" + "'", str79.equals("59"));
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "+00:00:25.200" + "'", str80.equals("+00:00:25.200"));
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        long long43 = zeroIsMaxDateTimeField40.add((long) (-10), (long) 1591858799);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1591858789L + "'", long43 == 1591858789L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        int int8 = property7.getMaximumValue();
//        org.joda.time.DateTime dateTime10 = property7.setCopy((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) 'a');
//        org.joda.time.DateTime dateTime14 = dateTime10.withWeekOfWeekyear((int) '#');
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        int int16 = dateTime14.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean5 = property3.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.add(9);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes(292278992);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = instant9.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.weekyear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.weekyear();
        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.roundHalfCeiling();
        int int15 = property12.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime16 = property12.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime18 = property12.addWrapField(1969);
        mutableDateTime18.addMonths(1591879061);
        int int21 = dateTime4.compareTo((org.joda.time.ReadableInstant) mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 292278993 + "'", int15 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        org.joda.time.DateTime.Property property12 = dateTime7.yearOfEra();
//        org.joda.time.DateTime dateTime14 = property12.addToCopy(100L);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) '4');
//        org.joda.time.DateTime.Property property22 = dateTime18.secondOfMinute();
//        org.joda.time.DateTime dateTime23 = property22.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime25 = property22.setCopy((int) '4');
//        org.joda.time.DateTime.Property property26 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = dateTime25.withMillis(0L);
//        boolean boolean29 = dateTime14.isAfter((org.joda.time.ReadableInstant) dateTime28);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:20.248" + "'", str11.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
//        mutableDateTime11.addYears((int) (byte) -1);
//        int int15 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        java.lang.String str16 = property7.getName();
//        org.joda.time.Interval interval17 = property7.toInterval();
//        int int18 = property7.get();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getSecondOfDay();
//        org.joda.time.TimeOfDay timeOfDay22 = dateTime20.toTimeOfDay();
//        int int23 = property7.compareTo((org.joda.time.ReadablePartial) timeOfDay22);
//        org.joda.time.DateTime dateTime25 = property7.setCopy(32);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31536020 + "'", int15 == 31536020);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "secondOfMinute" + "'", str16.equals("secondOfMinute"));
//        org.junit.Assert.assertNotNull(interval17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970-01-01T00:00:00.032", "1970-01-01T00:00:20.248");
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) '4');
        org.joda.time.DateTime.Property property12 = dateTime8.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
        org.joda.time.DateTime dateTime15 = dateTime3.withField(dateTimeFieldType13, (int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField19 = gregorianChronology18.eras();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology18.minuteOfHour();
        org.joda.time.DateTime dateTime24 = dateTime15.toDateTime((org.joda.time.Chronology) gregorianChronology18);
        try {
            org.joda.time.DateTime dateTime26 = dateTime15.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfMinute((-28800000), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime11 = property4.add((long) (-292275054));
        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime14 = instant13.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.weekyear();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime14.weekyear();
        org.joda.time.MutableDateTime mutableDateTime17 = property16.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime18 = property16.roundHalfCeiling();
        org.joda.time.DateTimeField dateTimeField19 = null;
        mutableDateTime18.setRounding(dateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        boolean boolean22 = mutableDateTime18.isSupported(dateTimeFieldType21);
        org.joda.time.DateTime dateTime23 = mutableDateTime18.toDateTime();
        int int24 = property4.getDifference((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292275054) + "'", int24 == (-292275054));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Instant instant25 = instant22.withDurationAdded(readableDuration23, 32);
        org.joda.time.DateTime dateTime26 = instant22.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime10 = property4.addWrapField(1969);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.Instant instant12 = mutableDateTime10.toInstant();
        org.joda.time.DateTimeField dateTimeField13 = mutableDateTime10.getRoundingField();
        try {
            mutableDateTime10.setMillisOfSecond((-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNull(dateTimeField13);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        mutableDateTime0.addWeeks(0);
//        mutableDateTime0.add(67L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
//        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
//        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
//        long long27 = skipUndoDateTimeField12.remainder((long) 24);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
//        org.joda.time.LocalDate localDate32 = dateTime31.toLocalDate();
//        int int33 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime35.plus(readablePeriod36);
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.DateTime dateTime40 = dateTime37.withPeriodAdded(readablePeriod38, (int) '4');
//        org.joda.time.DateTime.Property property41 = dateTime37.secondOfMinute();
//        org.joda.time.DateTime dateTime42 = property41.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime44 = property41.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime44.toYearMonthDay();
//        int[] intArray46 = null;
//        int int47 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay45, intArray46);
//        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField12);
//        boolean boolean50 = mutableDateTime0.isBefore((long) 25252000);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24L + "'", long27 == 24L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292278993 + "'", int33 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
//        mutableDateTime11.addYears((int) (byte) -1);
//        int int15 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DurationField durationField16 = property7.getDurationField();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31536020 + "'", int15 == 31536020);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateMidnight dateMidnight5 = dateTime3.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime14 = property13.roundFloor();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.Chronology chronology19 = null;
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket(100L, chronology19, locale20, (java.lang.Integer) 10, 0);
//        long long26 = dateTimeParserBucket23.computeMillis(false, "hi!");
//        java.util.Locale locale27 = dateTimeParserBucket23.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) ' ', chronology17, locale27, (java.lang.Integer) 10, (int) '#');
//        try {
//            org.joda.time.MutableDateTime mutableDateTime31 = property13.set("", locale27);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(locale27);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.millisOfSecond();
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) '#', 25252, 1591879060, 2, 2019, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plus((long) (-28800000));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        int int10 = dateTimeZone6.getOffsetFromLocal(99L);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(iSOChronology11);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        int int20 = dateTime19.getWeekyear();
//        boolean boolean21 = dateTime19.isEqualNow();
//        int int22 = dateTime19.getWeekyear();
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime10, (org.joda.time.ReadableInstant) dateTime19);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1970 + "'", int20 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        int int23 = skipUndoDateTimeField7.getDifference((long) 0, 1L);
//        org.joda.time.ReadablePartial readablePartial24 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.eras();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.weekOfWeekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField30 = gregorianChronology29.eras();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField33 = gregorianChronology32.eras();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField34, 2019);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.plus(readablePeriod39);
//        org.joda.time.LocalDate localDate41 = dateTime40.toLocalDate();
//        org.joda.time.Chronology chronology44 = null;
//        java.util.Locale locale45 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket(100L, chronology44, locale45, (java.lang.Integer) 10, 0);
//        long long51 = dateTimeParserBucket48.computeMillis(false, "hi!");
//        java.util.Locale locale52 = dateTimeParserBucket48.getLocale();
//        java.lang.String str53 = skipUndoDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate41, (int) 'a', locale52);
//        int[] intArray55 = gregorianChronology25.get((org.joda.time.ReadablePartial) localDate41, (long) 10);
//        int int56 = skipUndoDateTimeField7.getMaximumValue(readablePartial24, intArray55);
//        org.joda.time.Chronology chronology59 = null;
//        org.joda.time.Chronology chronology61 = null;
//        java.util.Locale locale62 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket(100L, chronology61, locale62, (java.lang.Integer) 10, 0);
//        long long68 = dateTimeParserBucket65.computeMillis(false, "hi!");
//        java.util.Locale locale69 = dateTimeParserBucket65.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket72 = new org.joda.time.format.DateTimeParserBucket((long) ' ', chronology59, locale69, (java.lang.Integer) 10, (int) '#');
//        java.lang.String str73 = skipUndoDateTimeField7.getAsShortText((-1), locale69);
//        boolean boolean75 = skipUndoDateTimeField7.isLeap(2440587L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
//        org.junit.Assert.assertNotNull(locale52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "97" + "'", str53.equals("97"));
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292278993 + "'", int56 == 292278993);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 100L + "'", long68 == 100L);
//        org.junit.Assert.assertNotNull(locale69);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "-1" + "'", str73.equals("-1"));
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
//        int int4 = mutableDateTime2.getEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        org.joda.time.Chronology chronology20 = null;
//        java.util.Locale locale21 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket(100L, chronology20, locale21, (java.lang.Integer) 10, 0);
//        long long27 = dateTimeParserBucket24.computeMillis(false, "hi!");
//        java.util.Locale locale28 = dateTimeParserBucket24.getLocale();
//        java.lang.String str29 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate17, (int) 'a', locale28);
//        mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField12, 3);
//        long long34 = skipUndoDateTimeField12.addWrapField(1008001120L, 1970);
//        int int36 = skipUndoDateTimeField12.getMaximumValue(29227899290L);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "97" + "'", str29.equals("97"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 62168140801120L + "'", long34 == 62168140801120L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 292278993 + "'", int36 == 292278993);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
//        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
//        java.util.Locale locale9 = dateTimeParserBucket5.getLocale();
//        java.lang.Integer int10 = dateTimeParserBucket5.getPivotYear();
//        long long11 = dateTimeParserBucket5.computeMillis();
//        java.lang.Object obj12 = dateTimeParserBucket5.saveState();
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(locale9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10.equals(10));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNotNull(obj12);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
//        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
//        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
//        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
//        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
//        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
//        java.lang.String str47 = zeroIsMaxDateTimeField40.getAsShortText((long) 292278993);
//        long long50 = zeroIsMaxDateTimeField40.addWrapField(86400003L, 1591879060);
//        long long52 = zeroIsMaxDateTimeField40.remainder((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        org.joda.time.ReadablePeriod readablePeriod55 = null;
//        org.joda.time.DateTime dateTime56 = dateTime54.plus(readablePeriod55);
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.withPeriodAdded(readablePeriod57, (int) '4');
//        org.joda.time.DateTime.Property property60 = dateTime56.secondOfMinute();
//        org.joda.time.Chronology chronology62 = null;
//        java.util.Locale locale63 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket66 = new org.joda.time.format.DateTimeParserBucket(100L, chronology62, locale63, (java.lang.Integer) 10, 0);
//        long long69 = dateTimeParserBucket66.computeMillis(false, "hi!");
//        java.util.Locale locale70 = dateTimeParserBucket66.getLocale();
//        java.lang.String str71 = property60.getAsText(locale70);
//        int int72 = zeroIsMaxDateTimeField40.getMaximumShortTextLength(locale70);
//        int int74 = zeroIsMaxDateTimeField40.getLeapAmount((long) (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "33078993" + "'", str47.equals("33078993"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 123079063L + "'", long50 == 123079063L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 100L + "'", long69 == 100L);
//        org.junit.Assert.assertNotNull(locale70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "20" + "'", str71.equals("20"));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 8 + "'", int72 == 8);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(0L, 1591879061);
        int int15 = dateTime9.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
//        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
//        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
//        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
//        int int42 = zeroIsMaxDateTimeField40.get(0L);
//        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
//        long long47 = zeroIsMaxDateTimeField40.roundHalfFloor((long) (short) 1);
//        org.joda.time.DurationField durationField48 = zeroIsMaxDateTimeField40.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
//        org.junit.Assert.assertNull(durationField48);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.secondOfDay();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
//        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
//        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType38, (-1));
//        boolean boolean44 = offsetDateTimeField43.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField47 = gregorianChronology46.eras();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField50 = gregorianChronology49.eras();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology46, dateTimeField51, 2019);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime55.plus(readablePeriod56);
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.DateTime dateTime60 = dateTime57.withPeriodAdded(readablePeriod58, (int) '4');
//        org.joda.time.DateTime.Property property61 = dateTime57.secondOfMinute();
//        org.joda.time.DateTime dateTime62 = property61.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime64 = property61.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay65 = dateTime64.toYearMonthDay();
//        int int66 = skipUndoDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay65);
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.UTC;
//        long long72 = dateTimeZone68.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long74 = dateTimeZone67.getMillisKeepLocal(dateTimeZone68, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime(dateTimeZone76);
//        org.joda.time.ReadablePeriod readablePeriod78 = null;
//        org.joda.time.DateTime dateTime79 = dateTime77.plus(readablePeriod78);
//        org.joda.time.ReadablePeriod readablePeriod80 = null;
//        org.joda.time.DateTime dateTime82 = dateTime79.withPeriodAdded(readablePeriod80, (int) '4');
//        org.joda.time.DateTime.Property property83 = dateTime79.secondOfMinute();
//        org.joda.time.Chronology chronology85 = null;
//        java.util.Locale locale86 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket89 = new org.joda.time.format.DateTimeParserBucket(100L, chronology85, locale86, (java.lang.Integer) 10, 0);
//        long long92 = dateTimeParserBucket89.computeMillis(false, "hi!");
//        java.util.Locale locale93 = dateTimeParserBucket89.getLocale();
//        java.lang.String str94 = property83.getAsText(locale93);
//        java.lang.String str95 = dateTimeZone68.getName((long) 3, locale93);
//        int int96 = skipUndoDateTimeField53.getMaximumTextLength(locale93);
//        java.lang.String str97 = offsetDateTimeField43.getAsShortText(28800032L, locale93);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime98 = property7.set("", locale93);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(yearMonthDay65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-292275054) + "'", int66 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1L + "'", long72 == 1L);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 52L + "'", long74 == 52L);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 100L + "'", long92 == 100L);
//        org.junit.Assert.assertNotNull(locale93);
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "20" + "'", str94.equals("20"));
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Coordinated Universal Time" + "'", str95.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 9 + "'", int96 == 9);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "1970" + "'", str97.equals("1970"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) -1);
//        java.lang.String str4 = dateTime1.toString();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(31564799);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str4.equals("1970-01-01T00:00:00.100Z"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2019-06-12T05:37:44.026", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T05:37:44.026" + "'", str4.equals("2019-06-12T05:37:44.026"));
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-292275054));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 292275054 + "'", int1 == 292275054);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
//        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.withPeriodAdded(readablePeriod8, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime12 = dateTime10.withZoneRetainFields(dateTimeZone11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str14 = dateTime10.toString(dateTimeFormatter13);
//        org.joda.time.DateTime.Property property15 = dateTime10.yearOfEra();
//        boolean boolean16 = gregorianChronology2.equals((java.lang.Object) property15);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:20.248" + "'", str14.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.joda.time.Interval interval7 = property5.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(interval7);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        java.lang.String str8 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.year();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.secondOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        boolean boolean4 = dateTimeZone0.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
//        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
//        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
//        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
//        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
//        long long36 = skipUndoDateTimeField16.roundHalfFloor((long) ' ');
//        org.joda.time.Instant instant38 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime39 = instant38.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime42 = property41.roundHalfEven();
//        java.lang.Class<?> wildcardClass43 = mutableDateTime42.getClass();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
//        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime60 = dateTime45.withField(dateTimeFieldType55, (int) '#');
//        boolean boolean61 = mutableDateTime42.isSupported(dateTimeFieldType55);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType55, 32);
//        long long65 = dividedDateTimeField63.remainder(86400003L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 20 + "'", int46 == 20);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 86400003L + "'", long65 == 86400003L);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
//        int int4 = mutableDateTime2.getEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        org.joda.time.Chronology chronology20 = null;
//        java.util.Locale locale21 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket(100L, chronology20, locale21, (java.lang.Integer) 10, 0);
//        long long27 = dateTimeParserBucket24.computeMillis(false, "hi!");
//        java.util.Locale locale28 = dateTimeParserBucket24.getLocale();
//        java.lang.String str29 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate17, (int) 'a', locale28);
//        mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField12, 3);
//        mutableDateTime2.setTime(639249148799999L);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "97" + "'", str29.equals("97"));
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) '4');
//        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime16 = dateTime1.withField(dateTimeFieldType11, (int) '#');
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 3, "");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks(1591879061);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) 'a');
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.secondOfMinute();
        org.joda.time.DateTime dateTime16 = dateTime13.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, 2019);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
//        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = property17.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = property17.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime20.toYearMonthDay();
//        int int22 = skipUndoDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) '4');
//        org.joda.time.DateTime.Property property30 = dateTime26.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfFloorCopy();
//        org.joda.time.Chronology chronology33 = null;
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket(100L, chronology33, locale34, (java.lang.Integer) 10, 0);
//        long long40 = dateTimeParserBucket37.computeMillis(false, "hi!");
//        java.util.Locale locale41 = dateTimeParserBucket37.getLocale();
//        java.lang.String str42 = property30.getAsShortText(locale41);
//        int int43 = skipUndoDateTimeField9.getMaximumTextLength(locale41);
//        int int44 = skipUndoDateTimeField9.getMinimumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        int int47 = skipDateTimeField45.get(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292275054) + "'", int22 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
//        org.junit.Assert.assertNotNull(locale41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "20" + "'", str42.equals("20"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292275053) + "'", int44 == (-292275053));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1971 + "'", int47 == 1971);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfMinute();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundFloor();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime6.monthOfYear();
//        int int8 = dateTime6.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime6.minus((long) 9);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType19, 57599, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder5.appendDayOfMonth((int) (short) 10);
        boolean boolean31 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long7 = dateTimeZone0.getMillisKeepLocal(dateTimeZone1, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) '4');
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
//        org.joda.time.Chronology chronology18 = null;
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket(100L, chronology18, locale19, (java.lang.Integer) 10, 0);
//        long long25 = dateTimeParserBucket22.computeMillis(false, "hi!");
//        java.util.Locale locale26 = dateTimeParserBucket22.getLocale();
//        java.lang.String str27 = property16.getAsText(locale26);
//        java.lang.String str28 = dateTimeZone1.getName((long) 3, locale26);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
//        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
//        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
//        org.joda.time.DateTime dateTime41 = dateTime39.minusMillis((-292275054));
//        try {
//            org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime41, (-292275054));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -292275054");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
//        org.junit.Assert.assertNotNull(locale26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        java.util.Locale locale9 = dateTimeParserBucket5.getLocale();
        int int10 = dateTimeParserBucket5.getOffset();
        org.joda.time.Chronology chronology12 = null;
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket(100L, chronology12, locale13, (java.lang.Integer) 10, 0);
        long long19 = dateTimeParserBucket16.computeMillis(false, "hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField21 = gregorianChronology20.eras();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField24 = gregorianChronology23.eras();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField25, 2019);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withPeriodAdded(readablePeriod32, (int) '4');
        org.joda.time.DateTime.Property property35 = dateTime31.secondOfMinute();
        org.joda.time.DateTime dateTime36 = property35.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime38 = property35.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay39 = dateTime38.toYearMonthDay();
        int int40 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay39);
        long long43 = skipUndoDateTimeField27.add((long) (byte) -1, 20257);
        dateTimeParserBucket16.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField27, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.eras();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField50 = gregorianChronology49.eras();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology46, dateTimeField51, 2019);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime57 = dateTime55.plus(readablePeriod56);
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.DateTime dateTime60 = dateTime57.withPeriodAdded(readablePeriod58, (int) '4');
        org.joda.time.DateTime.Property property61 = dateTime57.secondOfMinute();
        org.joda.time.DateTime dateTime62 = property61.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime64 = property61.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay65 = dateTime64.toYearMonthDay();
        int int66 = skipUndoDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay65);
        long long68 = skipUndoDateTimeField53.remainder((long) 24);
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        org.joda.time.DateTime dateTime72 = dateTime70.plus(readablePeriod71);
        org.joda.time.LocalDate localDate73 = dateTime72.toLocalDate();
        int int74 = skipUndoDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) localDate73);
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone75);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.DateTime dateTime78 = dateTime76.plus(readablePeriod77);
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        org.joda.time.DateTime dateTime81 = dateTime78.withPeriodAdded(readablePeriod79, (int) '4');
        org.joda.time.DateTime.Property property82 = dateTime78.secondOfMinute();
        org.joda.time.DateTime dateTime83 = property82.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime85 = property82.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay86 = dateTime85.toYearMonthDay();
        int[] intArray87 = null;
        int int88 = skipUndoDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay86, intArray87);
        int[] intArray90 = null;
        int[] intArray92 = skipUndoDateTimeField27.add((org.joda.time.ReadablePartial) yearMonthDay86, (int) (byte) 1, intArray90, 0);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField27, (int) (byte) 1);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 420);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(yearMonthDay39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292275054) + "'", int40 == (-292275054));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 639249148799999L + "'", long43 == 639249148799999L);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(yearMonthDay65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-292275054) + "'", int66 == (-292275054));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 24L + "'", long68 == 24L);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292278993 + "'", int74 == 292278993);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(property82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(yearMonthDay86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292278993 + "'", int88 == 292278993);
        org.junit.Assert.assertNull(intArray92);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime.Property property9 = dateTime4.dayOfWeek();
        int int10 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
//        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime();
//        mutableDateTime23.addWeeks(0);
//        mutableDateTime23.add(67L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField29 = gregorianChronology28.eras();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField32 = gregorianChronology31.eras();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, dateTimeField33, 2019);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime42 = dateTime39.withPeriodAdded(readablePeriod40, (int) '4');
//        org.joda.time.DateTime.Property property43 = dateTime39.secondOfMinute();
//        org.joda.time.DateTime dateTime44 = property43.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime46 = property43.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay47 = dateTime46.toYearMonthDay();
//        int int48 = skipUndoDateTimeField35.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay47);
//        long long50 = skipUndoDateTimeField35.remainder((long) 24);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone51);
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime52.plus(readablePeriod53);
//        org.joda.time.LocalDate localDate55 = dateTime54.toLocalDate();
//        int int56 = skipUndoDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate55);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        org.joda.time.ReadablePeriod readablePeriod59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime58.plus(readablePeriod59);
//        org.joda.time.ReadablePeriod readablePeriod61 = null;
//        org.joda.time.DateTime dateTime63 = dateTime60.withPeriodAdded(readablePeriod61, (int) '4');
//        org.joda.time.DateTime.Property property64 = dateTime60.secondOfMinute();
//        org.joda.time.DateTime dateTime65 = property64.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime67 = property64.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay68 = dateTime67.toYearMonthDay();
//        int[] intArray69 = null;
//        int int70 = skipUndoDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay68, intArray69);
//        mutableDateTime23.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField35);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter73.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone75);
//        org.joda.time.ReadablePeriod readablePeriod77 = null;
//        org.joda.time.DateTime dateTime78 = dateTime76.plus(readablePeriod77);
//        org.joda.time.ReadablePeriod readablePeriod79 = null;
//        org.joda.time.DateTime dateTime81 = dateTime78.withPeriodAdded(readablePeriod79, (int) '4');
//        org.joda.time.DateTime.Property property82 = dateTime78.secondOfMinute();
//        org.joda.time.Chronology chronology84 = null;
//        java.util.Locale locale85 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket88 = new org.joda.time.format.DateTimeParserBucket(100L, chronology84, locale85, (java.lang.Integer) 10, 0);
//        long long91 = dateTimeParserBucket88.computeMillis(false, "hi!");
//        java.util.Locale locale92 = dateTimeParserBucket88.getLocale();
//        java.lang.String str93 = property82.getAsText(locale92);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter94 = dateTimeFormatter74.withLocale(locale92);
//        java.lang.String str95 = skipUndoDateTimeField35.getAsText((int) (byte) 10, locale92);
//        java.lang.String str96 = skipUndoDateTimeField35.toString();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField97 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
//        int int98 = skipUndoDateTimeField35.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(yearMonthDay47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292275054) + "'", int48 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 24L + "'", long50 == 24L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292278993 + "'", int56 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(yearMonthDay68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 292278993 + "'", int70 == 292278993);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertNotNull(dateTimeFormatter74);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertNotNull(property82);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 100L + "'", long91 == 100L);
//        org.junit.Assert.assertNotNull(locale92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "20" + "'", str93.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter94);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "10" + "'", str95.equals("10"));
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "DateTimeField[year]" + "'", str96.equals("DateTimeField[year]"));
//        org.junit.Assert.assertTrue("'" + int98 + "' != '" + (-292275053) + "'", int98 == (-292275053));
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
//        long long37 = offsetDateTimeField34.add(0L, 28800);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
//        long long43 = dateTimeZone39.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long45 = dateTimeZone38.getMillisKeepLocal(dateTimeZone39, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
//        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
//        org.joda.time.Chronology chronology56 = null;
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(100L, chronology56, locale57, (java.lang.Integer) 10, 0);
//        long long63 = dateTimeParserBucket60.computeMillis(false, "hi!");
//        java.util.Locale locale64 = dateTimeParserBucket60.getLocale();
//        java.lang.String str65 = property54.getAsText(locale64);
//        java.lang.String str66 = dateTimeZone39.getName((long) 3, locale64);
//        int int67 = offsetDateTimeField34.getMaximumShortTextLength(locale64);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = offsetDateTimeField34.getType();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 908840217600000L + "'", long37 == 908840217600000L);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 52L + "'", long45 == 52L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 100L + "'", long63 == 100L);
//        org.junit.Assert.assertNotNull(locale64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "20" + "'", str65.equals("20"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Coordinated Universal Time" + "'", str66.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 1);
//        int int7 = dateTime6.getMillisOfSecond();
//        org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra(292278992);
//        org.joda.time.Chronology chronology11 = null;
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(100L, chronology11, locale12, (java.lang.Integer) 10, 0);
//        long long18 = dateTimeParserBucket15.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.eras();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField23 = gregorianChronology22.eras();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField24, 2019);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.plus(readablePeriod29);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, (int) '4');
//        org.joda.time.DateTime.Property property34 = dateTime30.secondOfMinute();
//        org.joda.time.DateTime dateTime35 = property34.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime37 = property34.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime37.toYearMonthDay();
//        int int39 = skipUndoDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay38);
//        long long42 = skipUndoDateTimeField26.add((long) (byte) -1, 20257);
//        dateTimeParserBucket15.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField26, (int) (byte) 1);
//        long long46 = skipUndoDateTimeField26.roundHalfFloor((long) ' ');
//        long long49 = skipUndoDateTimeField26.set(31L, "97");
//        int int50 = dateTime6.get((org.joda.time.DateTimeField) skipUndoDateTimeField26);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-292275054) + "'", int39 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 639249148799999L + "'", long42 == 639249148799999L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-59106067199969L) + "'", long49 == (-59106067199969L));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1970 + "'", int50 == 1970);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = property7.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay11 = dateTime10.toYearMonthDay();
//        int int12 = dateTime10.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(yearMonthDay11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int int47 = zeroIsMaxDateTimeField40.getMinimumValue(readablePartial46);
        long long49 = zeroIsMaxDateTimeField40.remainder((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfMonth();
        org.joda.time.DateTime dateTime8 = dateTime1.plus(0L);
        org.joda.time.DateTime dateTime10 = dateTime1.plusHours((int) (byte) 0);
        org.joda.time.DateTime.Property property11 = dateTime1.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime13 = property11.setCopy("DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[year]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1591879060, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 1591879060");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(25200);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType38, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField44 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType38);
        int int46 = zeroIsMaxDateTimeField44.get(0L);
        long long49 = zeroIsMaxDateTimeField44.add((long) 57599, 0);
        long long51 = zeroIsMaxDateTimeField44.roundHalfFloor((long) (short) 1);
        long long53 = zeroIsMaxDateTimeField44.roundHalfFloor(31536000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField56 = gregorianChronology55.eras();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology55.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField59 = gregorianChronology58.eras();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology58.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology55, dateTimeField60, 2019);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone63);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.DateTime dateTime66 = dateTime64.plus(readablePeriod65);
        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
        org.joda.time.Chronology chronology70 = null;
        java.util.Locale locale71 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket(100L, chronology70, locale71, (java.lang.Integer) 10, 0);
        long long77 = dateTimeParserBucket74.computeMillis(false, "hi!");
        java.util.Locale locale78 = dateTimeParserBucket74.getLocale();
        java.lang.String str79 = skipUndoDateTimeField62.getAsText((org.joda.time.ReadablePartial) localDate67, (int) 'a', locale78);
        java.lang.String str80 = zeroIsMaxDateTimeField44.getAsShortText(59, locale78);
        java.lang.String str81 = dateTimeZone2.getName(2440588L, locale78);
        try {
            java.lang.String str82 = org.joda.time.format.DateTimeFormat.patternForStyle("292278992", locale78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 292278992");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 86400000 + "'", int46 == 86400000);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 57599L + "'", long49 == 57599L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 31536000000L + "'", long53 == 31536000000L);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 100L + "'", long77 == 100L);
        org.junit.Assert.assertNotNull(locale78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "97" + "'", str79.equals("97"));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "59" + "'", str80.equals("59"));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "+00:00:25.200" + "'", str81.equals("+00:00:25.200"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime10 = property4.addWrapField(1969);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = property11.roundHalfFloor();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 20248L + "'", long0 == 20248L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1591879114, (int) (short) 100, 0, 1969, 25252000, (int) '#', 7, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = cachedDateTimeZone2.isLocalDateTimeGap(localDateTime3);
        boolean boolean5 = buddhistChronology0.equals((java.lang.Object) boolean4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        org.joda.time.DateTimeField dateTimeField7 = null;
        mutableDateTime6.setRounding(dateTimeField7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = mutableDateTime6.isSupported(dateTimeFieldType9);
        org.joda.time.DateTime dateTime11 = mutableDateTime6.toDateTime();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime6.secondOfMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = property12.set(420);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 420 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        java.lang.String str8 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime12.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime18 = dateTime16.withZoneRetainFields(dateTimeZone17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str20 = dateTime16.toString(dateTimeFormatter19);
//        org.joda.time.DateTime.Property property21 = dateTime16.yearOfEra();
//        org.joda.time.DateTime dateTime23 = property21.addToCopy(100L);
//        org.joda.time.Instant instant25 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime26 = instant25.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.weekyear();
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime26.weekyear();
//        mutableDateTime26.addWeekyears((int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime26, (org.joda.time.Chronology) gregorianChronology31);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime23, (org.joda.time.ReadableDateTime) mutableDateTime33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:20.248" + "'", str20.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime4.withMillisOfSecond(5);
        org.joda.time.DateTime.Property property15 = dateTime4.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, 2019);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
//        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = property17.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = property17.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime20.toYearMonthDay();
//        int int22 = skipUndoDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) '4');
//        org.joda.time.DateTime.Property property30 = dateTime26.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfFloorCopy();
//        org.joda.time.Chronology chronology33 = null;
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket(100L, chronology33, locale34, (java.lang.Integer) 10, 0);
//        long long40 = dateTimeParserBucket37.computeMillis(false, "hi!");
//        java.util.Locale locale41 = dateTimeParserBucket37.getLocale();
//        java.lang.String str42 = property30.getAsShortText(locale41);
//        int int43 = skipUndoDateTimeField9.getMaximumTextLength(locale41);
//        int int44 = skipUndoDateTimeField9.getMinimumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        long long47 = skipUndoDateTimeField9.remainder((-1L));
//        org.joda.time.DateTimeField dateTimeField48 = skipUndoDateTimeField9.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        org.joda.time.DateTime dateTime53 = dateTime51.plus(readablePeriod52);
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.DateTime dateTime56 = dateTime53.withPeriodAdded(readablePeriod54, (int) '4');
//        org.joda.time.DateTime.Property property57 = dateTime53.secondOfMinute();
//        org.joda.time.Chronology chronology59 = null;
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(100L, chronology59, locale60, (java.lang.Integer) 10, 0);
//        long long66 = dateTimeParserBucket63.computeMillis(false, "hi!");
//        java.util.Locale locale67 = dateTimeParserBucket63.getLocale();
//        java.lang.String str68 = property57.getAsText(locale67);
//        java.lang.String str69 = skipUndoDateTimeField9.getAsShortText(3, locale67);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292275054) + "'", int22 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
//        org.junit.Assert.assertNotNull(locale41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "20" + "'", str42.equals("20"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292275053) + "'", int44 == (-292275053));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 31535999999L + "'", long47 == 31535999999L);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
//        org.junit.Assert.assertNotNull(locale67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "20" + "'", str68.equals("20"));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "3" + "'", str69.equals("3"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime10.add(readablePeriod11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(0L, 1591879061);
        org.joda.time.DateTime.Property property15 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime17 = dateTime9.plusSeconds(25252000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("0");
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = instant5.toDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusMinutes(0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusYears((-292275053));
        org.joda.time.DateTime dateTime14 = dateTime12.minusWeeks((int) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField16 = gregorianChronology15.eras();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField19 = gregorianChronology18.eras();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField20, 2019);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) '4');
        org.joda.time.DateTime.Property property30 = dateTime26.secondOfMinute();
        org.joda.time.DateTime dateTime31 = property30.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime33 = property30.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
        int int35 = skipUndoDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay34);
        org.joda.time.DateTime dateTime36 = dateTime14.withFields((org.joda.time.ReadablePartial) yearMonthDay34);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) yearMonthDay34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-292275054) + "'", int35 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 1);
        int int7 = dateTime6.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(57599);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str5 = dateTimeZone4.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField9 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours((-1));
        org.joda.time.DateTime.Property property14 = dateTime11.year();
        org.joda.time.DateTime dateTime16 = dateTime11.plusYears(163);
        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, 2019);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
//        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = property17.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = property17.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime20.toYearMonthDay();
//        int int22 = skipUndoDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) '4');
//        org.joda.time.DateTime.Property property30 = dateTime26.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfFloorCopy();
//        org.joda.time.Chronology chronology33 = null;
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket(100L, chronology33, locale34, (java.lang.Integer) 10, 0);
//        long long40 = dateTimeParserBucket37.computeMillis(false, "hi!");
//        java.util.Locale locale41 = dateTimeParserBucket37.getLocale();
//        java.lang.String str42 = property30.getAsShortText(locale41);
//        int int43 = skipUndoDateTimeField9.getMaximumTextLength(locale41);
//        int int44 = skipUndoDateTimeField9.getMinimumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        long long47 = skipUndoDateTimeField9.remainder((-1L));
//        long long50 = skipUndoDateTimeField9.add((long) 25252000, 20257);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = skipUndoDateTimeField9.getAsText(2440588L, locale52);
//        long long56 = skipUndoDateTimeField9.set(0L, 20257);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292275054) + "'", int22 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
//        org.junit.Assert.assertNotNull(locale41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "20" + "'", str42.equals("20"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292275053) + "'", int44 == (-292275053));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 31535999999L + "'", long47 == 31535999999L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 639249174052000L + "'", long50 == 639249174052000L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1970" + "'", str53.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 577082016000000L + "'", long56 == 577082016000000L);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.eras();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.eras();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField27, 2019);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime40 = property37.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
        int int42 = skipUndoDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay41);
        int int45 = skipUndoDateTimeField29.getDifference((long) 0, 1L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField29);
        int int47 = skipUndoDateTimeField29.getMinimumValue();
        long long50 = skipUndoDateTimeField29.set(639249148799999L, (int) '#');
        int int52 = skipUndoDateTimeField29.get(576797932800031L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-292275054) + "'", int42 == (-292275054));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-292275053) + "'", int47 == (-292275053));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61062681600001L) + "'", long50 == (-61062681600001L));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20248 + "'", int52 == 20248);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField5 = gregorianChronology4.eras();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.eras();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, dateTimeField9, 2019);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withPeriodAdded(readablePeriod16, (int) '4');
//        org.joda.time.DateTime.Property property19 = dateTime15.secondOfMinute();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime22 = property19.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
//        int int24 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) '4');
//        org.joda.time.DateTime.Property property32 = dateTime28.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType33, (-1));
//        boolean boolean39 = offsetDateTimeField38.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField42 = gregorianChronology41.eras();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField45 = gregorianChronology44.eras();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology41, dateTimeField46, 2019);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime50.plus(readablePeriod51);
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, (int) '4');
//        org.joda.time.DateTime.Property property56 = dateTime52.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = property56.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime59 = property56.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay60 = dateTime59.toYearMonthDay();
//        int int61 = skipUndoDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay60);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.UTC;
//        long long67 = dateTimeZone63.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long69 = dateTimeZone62.getMillisKeepLocal(dateTimeZone63, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime(dateTimeZone71);
//        org.joda.time.ReadablePeriod readablePeriod73 = null;
//        org.joda.time.DateTime dateTime74 = dateTime72.plus(readablePeriod73);
//        org.joda.time.ReadablePeriod readablePeriod75 = null;
//        org.joda.time.DateTime dateTime77 = dateTime74.withPeriodAdded(readablePeriod75, (int) '4');
//        org.joda.time.DateTime.Property property78 = dateTime74.secondOfMinute();
//        org.joda.time.Chronology chronology80 = null;
//        java.util.Locale locale81 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket(100L, chronology80, locale81, (java.lang.Integer) 10, 0);
//        long long87 = dateTimeParserBucket84.computeMillis(false, "hi!");
//        java.util.Locale locale88 = dateTimeParserBucket84.getLocale();
//        java.lang.String str89 = property78.getAsText(locale88);
//        java.lang.String str90 = dateTimeZone63.getName((long) 3, locale88);
//        int int91 = skipUndoDateTimeField48.getMaximumTextLength(locale88);
//        java.lang.String str92 = offsetDateTimeField38.getAsShortText(28800032L, locale88);
//        java.lang.String str93 = cachedDateTimeZone2.getName((long) 1, locale88);
//        org.joda.time.DateTimeZone dateTimeZone94 = cachedDateTimeZone2.getUncachedZone();
//        boolean boolean96 = cachedDateTimeZone2.isStandardOffset(52L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(yearMonthDay23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292275054) + "'", int24 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(yearMonthDay60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-292275054) + "'", int61 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 52L + "'", long69 == 52L);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
//        org.junit.Assert.assertNotNull(locale88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "20" + "'", str89.equals("20"));
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "Coordinated Universal Time" + "'", str90.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 9 + "'", int91 == 9);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1970" + "'", str92.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "Coordinated Universal Time" + "'", str93.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone94);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(25252000, 420, 0, 99, (int) (byte) 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        int int8 = property7.getMaximumValue();
//        org.joda.time.DateTime dateTime9 = property7.withMaximumValue();
//        java.lang.String str10 = property7.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20" + "'", str10.equals("20"));
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) '4');
//        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime14 = instant13.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfMinute();
//        mutableDateTime14.addYears((int) (byte) -1);
//        int int18 = property10.getDifference((org.joda.time.ReadableInstant) mutableDateTime14);
//        boolean boolean19 = julianChronology0.equals((java.lang.Object) int18);
//        try {
//            long long24 = julianChronology0.getDateTimeMillis((int) (byte) 0, (int) '4', (int) (short) -1, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31536020 + "'", int18 == 31536020);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.Chronology chronology6 = null;
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(100L, chronology6, locale7, (java.lang.Integer) 10, 0);
//        long long13 = dateTimeParserBucket10.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.eras();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField18 = gregorianChronology17.eras();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField19, 2019);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.plus(readablePeriod24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
//        org.joda.time.DateTime.Property property29 = dateTime25.secondOfMinute();
//        org.joda.time.DateTime dateTime30 = property29.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime32 = property29.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        int int34 = skipUndoDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay33);
//        long long37 = skipUndoDateTimeField21.add((long) (byte) -1, 20257);
//        dateTimeParserBucket10.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField21, (int) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField41 = gregorianChronology40.eras();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = gregorianChronology43.eras();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology40, dateTimeField45, 2019);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone48);
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime49.plus(readablePeriod50);
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.withPeriodAdded(readablePeriod52, (int) '4');
//        org.joda.time.DateTime.Property property55 = dateTime51.secondOfMinute();
//        org.joda.time.DateTime dateTime56 = property55.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime58 = property55.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay59 = dateTime58.toYearMonthDay();
//        int int60 = skipUndoDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay59);
//        long long62 = skipUndoDateTimeField47.remainder((long) 24);
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone63);
//        org.joda.time.ReadablePeriod readablePeriod65 = null;
//        org.joda.time.DateTime dateTime66 = dateTime64.plus(readablePeriod65);
//        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
//        int int68 = skipUndoDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate67);
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
//        org.joda.time.ReadablePeriod readablePeriod71 = null;
//        org.joda.time.DateTime dateTime72 = dateTime70.plus(readablePeriod71);
//        org.joda.time.ReadablePeriod readablePeriod73 = null;
//        org.joda.time.DateTime dateTime75 = dateTime72.withPeriodAdded(readablePeriod73, (int) '4');
//        org.joda.time.DateTime.Property property76 = dateTime72.secondOfMinute();
//        org.joda.time.DateTime dateTime77 = property76.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime79 = property76.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay80 = dateTime79.toYearMonthDay();
//        int[] intArray81 = null;
//        int int82 = skipUndoDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay80, intArray81);
//        int[] intArray84 = null;
//        int[] intArray86 = skipUndoDateTimeField21.add((org.joda.time.ReadablePartial) yearMonthDay80, (int) (byte) 1, intArray84, 0);
//        long long88 = gregorianChronology0.set((org.joda.time.ReadablePartial) yearMonthDay80, 0L);
//        try {
//            long long93 = gregorianChronology0.getDateTimeMillis(0, 52, 99, 28800);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292275054) + "'", int34 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 639249148799999L + "'", long37 == 639249148799999L);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(yearMonthDay59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-292275054) + "'", int60 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 24L + "'", long62 == 24L);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(localDate67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 292278993 + "'", int68 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(yearMonthDay80);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 292278993 + "'", int82 == 292278993);
//        org.junit.Assert.assertNull(intArray86);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 0L + "'", long88 == 0L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1969-12-31T16:00:00.100-08:00");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, readableInstant2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(chronology3);
        org.joda.time.DateTime dateTime5 = mutableDateTime4.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(59L, dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes(292278992);
        org.joda.time.DateTime dateTime9 = dateTime4.plus(0L);
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withTime(1591858799, (int) (byte) -1, 2, 1971);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1591858799 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = dateTime4.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) ' ');
        org.joda.time.Chronology chronology10 = dateTime7.getChronology();
        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "000000Z" + "'", str11.equals("000000Z"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfFloor((long) 32);
        int int38 = offsetDateTimeField34.getMinimumValue();
        long long41 = offsetDateTimeField34.add((long) 0, (long) (byte) 1);
        java.lang.String str43 = offsetDateTimeField34.getAsShortText((long) 24);
        try {
            long long46 = offsetDateTimeField34.set(59L, "2019-06-12T12:38:37.466Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T12:38:37.466Z\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-292275054) + "'", int38 == (-292275054));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 31536000000L + "'", long41 == 31536000000L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970" + "'", str43.equals("1970"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 1);
        int int7 = dateTime6.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra(292278992);
        int int10 = dateTime6.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
//        java.lang.Class<?> wildcardClass6 = mutableDateTime5.getClass();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
//        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime23 = dateTime8.withField(dateTimeFieldType18, (int) '#');
//        boolean boolean24 = mutableDateTime5.isSupported(dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Thursday, January 1, 1970");
//        java.lang.Number number27 = illegalFieldValueException26.getUpperBound();
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNull(number27);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean5 = mutableDateTime2.equals((java.lang.Object) dateTimeFormatter4);
        mutableDateTime2.setDate((long) (-292275053));
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.addWeeks(0);
        mutableDateTime0.add(67L);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        long long27 = skipUndoDateTimeField12.remainder((long) 24);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
        org.joda.time.LocalDate localDate32 = dateTime31.toLocalDate();
        int int33 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime35.plus(readablePeriod36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime40 = dateTime37.withPeriodAdded(readablePeriod38, (int) '4');
        org.joda.time.DateTime.Property property41 = dateTime37.secondOfMinute();
        org.joda.time.DateTime dateTime42 = property41.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime44 = property41.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime44.toYearMonthDay();
        int[] intArray46 = null;
        int int47 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay45, intArray46);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField12);
        org.joda.time.DurationFieldType durationFieldType49 = null;
        try {
            mutableDateTime0.add(durationFieldType49, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24L + "'", long27 == 24L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292278993 + "'", int33 == 292278993);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant4 = instant1.withMillis(10L);
        org.joda.time.DateTime dateTime5 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfCeiling((long) (-28800000));
        long long39 = offsetDateTimeField34.roundHalfFloor(31507200024L);
        long long41 = offsetDateTimeField34.remainder((long) 52);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 31536000000L + "'", long39 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 52L + "'", long41 == 52L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = dateTime4.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) '4');
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.DateTime dateTime16 = dateTime4.withField(dateTimeFieldType14, (int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.plus(readablePeriod21);
        org.joda.time.DateTime dateTime23 = dateTime22.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.plus(readablePeriod26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) '4');
        org.joda.time.DateTime.Property property31 = dateTime27.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime22.withField(dateTimeFieldType32, (int) (byte) 10);
        org.joda.time.DateTime.Property property35 = dateTime18.property(dateTimeFieldType32);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.eras();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField50 = gregorianChronology49.eras();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology46, dateTimeField51, 2019);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime57 = dateTime55.plus(readablePeriod56);
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.DateTime dateTime60 = dateTime57.withPeriodAdded(readablePeriod58, (int) '4');
        org.joda.time.DateTime.Property property61 = dateTime57.secondOfMinute();
        org.joda.time.DateTime dateTime62 = property61.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime64 = property61.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay65 = dateTime64.toYearMonthDay();
        int int66 = skipUndoDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay65);
        long long68 = skipUndoDateTimeField53.remainder((long) 24);
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        org.joda.time.DateTime dateTime72 = dateTime70.plus(readablePeriod71);
        org.joda.time.LocalDate localDate73 = dateTime72.toLocalDate();
        int int74 = skipUndoDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) localDate73);
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone75);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.DateTime dateTime78 = dateTime76.plus(readablePeriod77);
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        org.joda.time.DateTime dateTime81 = dateTime78.withPeriodAdded(readablePeriod79, (int) '4');
        org.joda.time.DateTime.Property property82 = dateTime78.secondOfMinute();
        org.joda.time.DateTime dateTime83 = property82.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime85 = property82.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay86 = dateTime85.toYearMonthDay();
        int[] intArray87 = null;
        int int88 = skipUndoDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay86, intArray87);
        int int89 = zeroIsMaxDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay86);
        long long91 = zeroIsMaxDateTimeField40.roundHalfEven(86400000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(yearMonthDay65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-292275054) + "'", int66 == (-292275054));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 24L + "'", long68 == 24L);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292278993 + "'", int74 == 292278993);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(property82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(yearMonthDay86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292278993 + "'", int88 == 292278993);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 86400000L + "'", long91 == 86400000L);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long12 = dateTimeZone5.getMillisKeepLocal(dateTimeZone6, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) '4');
//        org.joda.time.DateTime.Property property21 = dateTime17.secondOfMinute();
//        org.joda.time.Chronology chronology23 = null;
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(100L, chronology23, locale24, (java.lang.Integer) 10, 0);
//        long long30 = dateTimeParserBucket27.computeMillis(false, "hi!");
//        java.util.Locale locale31 = dateTimeParserBucket27.getLocale();
//        java.lang.String str32 = property21.getAsText(locale31);
//        java.lang.String str33 = dateTimeZone6.getName((long) 3, locale31);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.weekyearOfCentury();
//        try {
//            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(99, 25252000, 0, 0, 292278993, (org.joda.time.Chronology) iSOChronology35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(locale31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "20" + "'", str32.equals("20"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Coordinated Universal Time" + "'", str33.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        org.joda.time.DurationField durationField22 = julianChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField25 = gregorianChronology24.eras();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField28 = gregorianChronology27.eras();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology24, dateTimeField29, 2019);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.plus(readablePeriod34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, (int) '4');
        org.joda.time.DateTime.Property property39 = dateTime35.secondOfMinute();
        org.joda.time.DateTime dateTime40 = property39.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime42 = property39.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime42.toYearMonthDay();
        int int44 = skipUndoDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay43);
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay43, 52, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292275054) + "'", int44 == (-292275054));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        int int6 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 70 + "'", int6 == 70);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '4', 292275054);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 52 * 292275054");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Thursday, January 1, 1970", (java.lang.Number) (short) 10, (java.lang.Number) 45512912L, (java.lang.Number) 315532800097L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime10 = property4.addWrapField(1969);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.Instant instant12 = mutableDateTime10.toInstant();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.weekyear();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant4 = instant1.plus((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant1.plus(readableDuration5);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 163, (java.lang.Number) 1591879061);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) '4');
        org.joda.time.DateTime.Property property12 = dateTime8.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
        org.joda.time.DateTime dateTime15 = dateTime3.withField(dateTimeFieldType13, (int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
        org.joda.time.DateTime dateTime22 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.withPeriodAdded(readablePeriod23, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime27 = dateTime25.withZoneRetainFields(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = dateTime15.toDateTime(dateTimeZone26);
        org.joda.time.DateMidnight dateMidnight29 = dateTime15.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight29);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfMinute((-10), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) '4');
        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 5);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
//        mutableDateTime11.addYears((int) (byte) -1);
//        int int15 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31536020 + "'", int15 == 31536020);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTime(dateTimeZone4);
//        java.util.Date date6 = mutableDateTime5.toDate();
//        mutableDateTime5.setYear(100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.dayOfMonth();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) mutableDateTime5, (org.joda.time.Chronology) gregorianChronology9);
//        java.lang.String str14 = mutableDateTime5.toString();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0100-01-01T00:00:20.248Z" + "'", str14.equals("0100-01-01T00:00:20.248Z"));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
        long long47 = zeroIsMaxDateTimeField40.roundCeiling((long) 0);
        int int49 = zeroIsMaxDateTimeField40.getMinimumValue((long) 0);
        int int51 = zeroIsMaxDateTimeField40.getLeapAmount((long) 24);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        int int8 = dateTime3.getDayOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime3.minusWeeks(31564799);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = property7.setCopy((int) '4');
//        org.joda.time.DateTime.Property property11 = dateTime10.millisOfSecond();
//        int int12 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property13 = dateTime10.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52248 + "'", int12 == 52248);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) 1591879067);
//        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
//        int int11 = dateTime9.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.setCopy("38");
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(1971, (-292275054));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendCenturyOfEra(1971, (-292275054));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withPeriodAdded(readablePeriod24, (int) '4');
        org.joda.time.DateTime.Property property27 = dateTime23.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder19.appendSignedDecimal(dateTimeFieldType28, 86400000, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType28, 45517, 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendDayOfYear(24);
        dateTimeFormatterBuilder39.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        long long23 = skipUndoDateTimeField7.add((long) (byte) -1, 20257);
        int int25 = skipUndoDateTimeField7.get((long) (byte) 100);
        long long28 = skipUndoDateTimeField7.add((long) 3, (long) 57599);
        java.lang.String str30 = skipUndoDateTimeField7.getAsShortText(31536000000L);
        boolean boolean31 = skipUndoDateTimeField7.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 639249148799999L + "'", long23 == 639249148799999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1971 + "'", int25 == 1971);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1817648899200003L + "'", long28 == 1817648899200003L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1971" + "'", str30.equals("1971"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder3.appendTimeZoneOffset("38", "", true, 1591879061, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        long long9 = skipUndoDateTimeField7.roundCeiling((-62198755200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62198755200000L) + "'", long9 == (-62198755200000L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 1970);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        java.lang.String str8 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.minus(31L);
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime15, readableDateTime18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology19);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfCeiling();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long13 = dateTimeZone6.convertLocalToUTC(52L, false, (long) ' ');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withZone(dateTimeZone10);
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(25252000, 99, 5, 2, (int) (byte) 0, (-10), (int) (byte) 10, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks(45517);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfHour(1969, 1);
        org.joda.time.Chronology chronology23 = null;
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(100L, chronology23, locale24, (java.lang.Integer) 10, 0);
        long long30 = dateTimeParserBucket27.computeMillis(false, "hi!");
        java.util.Locale locale31 = dateTimeParserBucket27.getLocale();
        java.lang.Integer int32 = dateTimeParserBucket27.getPivotYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder36.appendTimeZoneName();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime41 = dateTime39.plus(readablePeriod40);
        org.joda.time.DateTime dateTime42 = dateTime41.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.plus(readablePeriod45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) '4');
        org.joda.time.DateTime.Property property50 = dateTime46.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.DateTime dateTime53 = dateTime41.withField(dateTimeFieldType51, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder37.appendFixedDecimal(dateTimeFieldType51, 1971);
        dateTimeParserBucket27.saveField(dateTimeFieldType51, (-292275053));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder21.appendFixedDecimal(dateTimeFieldType51, 31561251);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(locale31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32.equals(10));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTime(dateTimeZone4);
        java.util.Date date6 = mutableDateTime5.toDate();
        mutableDateTime5.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths((int) (byte) 1);
        mutableDateTime5.setTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property17 = dateTime13.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) '4');
//        org.joda.time.DateTime.Property property14 = dateTime10.secondOfMinute();
//        org.joda.time.Chronology chronology16 = null;
//        java.util.Locale locale17 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket(100L, chronology16, locale17, (java.lang.Integer) 10, 0);
//        long long23 = dateTimeParserBucket20.computeMillis(false, "hi!");
//        java.util.Locale locale24 = dateTimeParserBucket20.getLocale();
//        java.lang.String str25 = property14.getAsText(locale24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter6.withLocale(locale24);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((-210866846400000L), (org.joda.time.Chronology) gregorianChronology1, locale24);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        long long33 = dateTimeZone29.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long35 = dateTimeZone28.getMillisKeepLocal(dateTimeZone29, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.plus(readablePeriod39);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime43 = dateTime40.withPeriodAdded(readablePeriod41, (int) '4');
//        org.joda.time.DateTime.Property property44 = dateTime40.secondOfMinute();
//        org.joda.time.Chronology chronology46 = null;
//        java.util.Locale locale47 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket(100L, chronology46, locale47, (java.lang.Integer) 10, 0);
//        long long53 = dateTimeParserBucket50.computeMillis(false, "hi!");
//        java.util.Locale locale54 = dateTimeParserBucket50.getLocale();
//        java.lang.String str55 = property44.getAsText(locale54);
//        java.lang.String str56 = dateTimeZone29.getName((long) 3, locale54);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone29);
//        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.Instant instant60 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime61 = instant60.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property62 = mutableDateTime61.weekyear();
//        org.joda.time.MutableDateTime.Property property63 = mutableDateTime61.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime64 = property63.roundHalfEven();
//        java.lang.Class<?> wildcardClass65 = mutableDateTime64.getClass();
//        int int66 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) mutableDateTime64);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime67 = new org.joda.time.MutableDateTime((java.lang.Object) gregorianChronology1, dateTimeZone29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//        org.junit.Assert.assertNotNull(locale24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "20" + "'", str25.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
//        org.junit.Assert.assertNotNull(locale54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "20" + "'", str55.equals("20"));
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Coordinated Universal Time" + "'", str56.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology58);
//        org.junit.Assert.assertNotNull(mutableDateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str10 = dateTimeZone9.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime8.toDateTime(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str14 = dateTimeZone13.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        long long17 = cachedDateTimeZone15.previousTransition(59L);
//        long long19 = dateTimeZone9.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, 0L);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
//        org.joda.time.DateTime dateTime29 = property28.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime30 = dateTime29.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime30.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.plus(readablePeriod34);
//        org.joda.time.DateTime dateTime36 = dateTime35.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime39 = dateTime35.withPeriodAdded(readablePeriod37, (int) (byte) 10);
//        mutableDateTime31.setTime((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) mutableDateTime31);
//        org.joda.time.Instant instant42 = gJChronology41.getGregorianCutover();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str44 = dateTimeZone43.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone43);
//        java.lang.String str47 = dateTimeZone43.getShortName((long) 57599);
//        org.joda.time.Chronology chronology48 = gJChronology41.withZone(dateTimeZone43);
//        org.joda.time.Instant instant50 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime51 = instant50.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.weekyear();
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime51.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime54 = property53.roundHalfFloor();
//        int int55 = mutableDateTime54.getYearOfEra();
//        boolean boolean57 = mutableDateTime54.isBefore(100L);
//        org.joda.time.Chronology chronology59 = null;
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(100L, chronology59, locale60, (java.lang.Integer) 10, 0);
//        org.joda.time.Chronology chronology64 = dateTimeParserBucket63.getChronology();
//        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(chronology64);
//        long long66 = dateTime65.getMillis();
//        org.joda.time.chrono.LimitChronology limitChronology67 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology41, (org.joda.time.ReadableDateTime) mutableDateTime54, (org.joda.time.ReadableDateTime) dateTime65);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime54, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 59L + "'", long17 == 59L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(instant42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UTC" + "'", str44.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology48);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1969 + "'", int55 == 1969);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(chronology64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 20248L + "'", long66 == 20248L);
//        org.junit.Assert.assertNotNull(limitChronology67);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 0, 1591879067);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        long long42 = zeroIsMaxDateTimeField40.remainder((long) (byte) 100);
        long long44 = zeroIsMaxDateTimeField40.roundHalfEven((long) ' ');
        long long46 = zeroIsMaxDateTimeField40.roundHalfFloor((long) 1);
        boolean boolean47 = zeroIsMaxDateTimeField40.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 32L + "'", long44 == 32L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
        java.lang.String str46 = zeroIsMaxDateTimeField40.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str46.equals("DateTimeField[secondOfMinute]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1591879064);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        long long7 = dateTimeZone3.convertLocalToUTC((long) (short) 1, false, (long) 0);
        long long10 = dateTimeZone3.convertLocalToUTC((long) 59, false);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone3);
        java.io.Writer writer13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        try {
            dateTimeFormatter12.printTo(writer13, (org.joda.time.ReadableInstant) mutableDateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 59L + "'", long10 == 59L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Instant instant25 = instant22.withDurationAdded(readableDuration23, 32);
        java.lang.Class<?> wildcardClass26 = instant25.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.DateTime dateTime20 = dateTime8.withField(dateTimeFieldType18, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType18, 1971);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendTwoDigitWeekyear(292273084, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime6.monthOfYear();
//        int int8 = dateTime6.getWeekOfWeekyear();
//        int int9 = dateTime6.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
        boolean boolean12 = mutableDateTime10.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
//        int int4 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) mutableDateTime3);
//        mutableDateTime3.addMillis(59);
//        org.joda.time.DateTime dateTime7 = mutableDateTime3.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTime(dateTimeZone4);
        java.util.Date date6 = mutableDateTime5.toDate();
        mutableDateTime5.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths((int) (byte) 1);
        mutableDateTime5.setTime((org.joda.time.ReadableInstant) dateTime13);
        try {
            mutableDateTime5.setDate(52248, (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
//        mutableDateTime2.addMinutes(0);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        mutableDateTime2.add(readablePeriod5, (-292275053));
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        boolean boolean17 = dateTime15.isAfter(readableInstant16);
//        boolean boolean18 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
//        mutableDateTime11.addYears((int) (byte) -1);
//        int int15 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        java.lang.String str16 = property7.getName();
//        org.joda.time.DateTime dateTime17 = property7.getDateTime();
//        long long18 = property7.remainder();
//        org.joda.time.DateTime dateTime19 = property7.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime21 = property7.addToCopy(86400000);
//        org.joda.time.DateTime dateTime22 = property7.getDateTime();
//        org.joda.time.DateTime dateTime23 = property7.withMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31536020 + "'", int15 == 31536020);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "secondOfMinute" + "'", str16.equals("secondOfMinute"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 248L + "'", long18 == 248L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) 'a');
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime17 = property15.setCopy("-1");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.Object obj4 = mutableDateTime2.clone();
        try {
            mutableDateTime2.setDate((int) (byte) 1, 163, 25252);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
        long long48 = zeroIsMaxDateTimeField40.getDifferenceAsLong((long) (byte) 0, (long) (byte) -1);
        long long51 = zeroIsMaxDateTimeField40.set((long) 25252000, 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1L + "'", long48 == 1L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(25200);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology24.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone28 = julianChronology24.getZone();
        org.joda.time.DurationField durationField29 = julianChronology24.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(0L, 1591879061);
        org.joda.time.DateTime.Property property15 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        int int8 = property7.getMaximumValue();
//        org.joda.time.DateTime dateTime9 = property7.withMaximumValue();
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        long long18 = dateTimeZone14.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long20 = dateTimeZone13.getMillisKeepLocal(dateTimeZone14, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.plus(readablePeriod24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
//        org.joda.time.DateTime.Property property29 = dateTime25.secondOfMinute();
//        org.joda.time.Chronology chronology31 = null;
//        java.util.Locale locale32 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket(100L, chronology31, locale32, (java.lang.Integer) 10, 0);
//        long long38 = dateTimeParserBucket35.computeMillis(false, "hi!");
//        java.util.Locale locale39 = dateTimeParserBucket35.getLocale();
//        java.lang.String str40 = property29.getAsText(locale39);
//        java.lang.String str41 = dateTimeZone14.getName((long) 3, locale39);
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
//        org.joda.time.ReadablePeriod readablePeriod45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime44.plus(readablePeriod45);
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) '4');
//        org.joda.time.DateTime.Property property50 = dateTime46.secondOfMinute();
//        org.joda.time.DateTime dateTime51 = property50.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime52 = dateTime51.withTimeAtStartOfDay();
//        int int53 = dateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        int int56 = dateTime55.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        org.joda.time.ReadablePeriod readablePeriod59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime58.plus(readablePeriod59);
//        org.joda.time.ReadablePeriod readablePeriod61 = null;
//        org.joda.time.DateTime dateTime63 = dateTime60.withPeriodAdded(readablePeriod61, (int) '4');
//        org.joda.time.DateTime.Property property64 = dateTime60.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property64.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType65, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime70 = dateTime55.withField(dateTimeFieldType65, (int) '#');
//        int int71 = dateTime52.get(dateTimeFieldType65);
//        int int72 = dateTime9.get(dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
//        org.junit.Assert.assertNotNull(locale39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "20" + "'", str40.equals("20"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordinated Universal Time" + "'", str41.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 20 + "'", int56 == 20);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 59 + "'", int72 == 59);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long44 = zeroIsMaxDateTimeField40.remainder((long) 292278992);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("43", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
//        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str24 = dateTimeZone23.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
//        java.lang.String str27 = dateTimeZone23.getShortName((long) 57599);
//        org.joda.time.Chronology chronology28 = gJChronology21.withZone(dateTimeZone23);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime31 = instant30.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.weekyear();
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime31.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime34 = property33.roundHalfFloor();
//        int int35 = mutableDateTime34.getYearOfEra();
//        boolean boolean37 = mutableDateTime34.isBefore(100L);
//        org.joda.time.Chronology chronology39 = null;
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket(100L, chronology39, locale40, (java.lang.Integer) 10, 0);
//        org.joda.time.Chronology chronology44 = dateTimeParserBucket43.getChronology();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(chronology44);
//        long long46 = dateTime45.getMillis();
//        org.joda.time.chrono.LimitChronology limitChronology47 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology21, (org.joda.time.ReadableDateTime) mutableDateTime34, (org.joda.time.ReadableDateTime) dateTime45);
//        org.joda.time.ReadablePeriod readablePeriod48 = null;
//        org.joda.time.DateTime dateTime49 = dateTime45.minus(readablePeriod48);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UTC" + "'", str24.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1969 + "'", int35 == 1969);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 20248L + "'", long46 == 20248L);
//        org.junit.Assert.assertNotNull(limitChronology47);
//        org.junit.Assert.assertNotNull(dateTime49);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long12 = dateTimeZone5.getMillisKeepLocal(dateTimeZone6, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) '4');
//        org.joda.time.DateTime.Property property21 = dateTime17.secondOfMinute();
//        org.joda.time.Chronology chronology23 = null;
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(100L, chronology23, locale24, (java.lang.Integer) 10, 0);
//        long long30 = dateTimeParserBucket27.computeMillis(false, "hi!");
//        java.util.Locale locale31 = dateTimeParserBucket27.getLocale();
//        java.lang.String str32 = property21.getAsText(locale31);
//        java.lang.String str33 = dateTimeZone6.getName((long) 3, locale31);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime(dateTimeZone6);
//        org.joda.time.Chronology chronology37 = julianChronology0.withZone(dateTimeZone6);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(locale31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "20" + "'", str32.equals("20"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Coordinated Universal Time" + "'", str33.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(chronology37);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
        long long47 = zeroIsMaxDateTimeField40.roundCeiling((long) 0);
        boolean boolean48 = zeroIsMaxDateTimeField40.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) (-59106067199969L));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.plus(readablePeriod11);
        org.joda.time.DateTime dateTime13 = dateTime4.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        org.joda.time.Chronology chronology6 = dateTimeParserBucket5.getChronology();
        long long7 = dateTimeParserBucket5.computeMillis();
        java.lang.Integer int8 = dateTimeParserBucket5.getOffsetInteger();
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNull(int8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.eras();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.eras();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField27, 2019);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime40 = property37.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
        int int42 = skipUndoDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay41);
        int int45 = skipUndoDateTimeField29.getDifference((long) 0, 1L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField29);
        int int47 = skipDateTimeField46.getMinimumValue();
        int int48 = skipDateTimeField46.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-292275054) + "'", int42 == (-292275054));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-292275054) + "'", int47 == (-292275054));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292275054) + "'", int48 == (-292275054));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder9.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) '4');
        org.joda.time.DateTime.Property property22 = dateTime18.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder14.appendText(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType23, 57599, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder9.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder9.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter35 = dateTimeFormatterBuilder34.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneName();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.plus(readablePeriod43);
        org.joda.time.DateTime dateTime45 = dateTime44.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.DateTime dateTime49 = dateTime47.plus(readablePeriod48);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, (int) '4');
        org.joda.time.DateTime.Property property53 = dateTime49.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.DateTime dateTime56 = dateTime44.withField(dateTimeFieldType54, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder40.appendFixedDecimal(dateTimeFieldType54, 1971);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder63.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(dateTimeZone67);
        org.joda.time.ReadablePeriod readablePeriod69 = null;
        org.joda.time.DateTime dateTime70 = dateTime68.plus(readablePeriod69);
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        org.joda.time.DateTime dateTime73 = dateTime70.withPeriodAdded(readablePeriod71, (int) '4');
        org.joda.time.DateTime.Property property74 = dateTime70.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException78 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder66.appendText(dateTimeFieldType75);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder66.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder81.appendFractionOfHour(1969, 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter85 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeParser dateTimeParser86 = dateTimeFormatter85.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder81.append(dateTimeParser86);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder62.appendOptional(dateTimeParser86);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter89 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter35, dateTimeParser86);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter90 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeParser dateTimeParser91 = dateTimeFormatter90.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray92 = new org.joda.time.format.DateTimeParser[] { dateTimeParser91 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder93 = dateTimeFormatterBuilder3.append(dateTimePrinter35, dateTimeParserArray92);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder96 = dateTimeFormatterBuilder3.appendTwoDigitYear((-28800000), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder98 = dateTimeFormatterBuilder96.appendSecondOfMinute(25252000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimePrinter35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
        org.junit.Assert.assertNotNull(dateTimeFormatter85);
        org.junit.Assert.assertNotNull(dateTimeParser86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
        org.junit.Assert.assertNotNull(dateTimeFormatter90);
        org.junit.Assert.assertNotNull(dateTimeParser91);
        org.junit.Assert.assertNotNull(dateTimeParserArray92);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder93);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder96);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder98);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Thursday, January 1, 1970", "org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45");
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
//        boolean boolean35 = offsetDateTimeField34.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = gregorianChronology37.eras();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField41 = gregorianChronology40.eras();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology37, dateTimeField42, 2019);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.plus(readablePeriod47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withPeriodAdded(readablePeriod49, (int) '4');
//        org.joda.time.DateTime.Property property52 = dateTime48.secondOfMinute();
//        org.joda.time.DateTime dateTime53 = property52.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime55 = property52.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay56 = dateTime55.toYearMonthDay();
//        int int57 = skipUndoDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay56);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.UTC;
//        long long63 = dateTimeZone59.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long65 = dateTimeZone58.getMillisKeepLocal(dateTimeZone59, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone67 = null;
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(dateTimeZone67);
//        org.joda.time.ReadablePeriod readablePeriod69 = null;
//        org.joda.time.DateTime dateTime70 = dateTime68.plus(readablePeriod69);
//        org.joda.time.ReadablePeriod readablePeriod71 = null;
//        org.joda.time.DateTime dateTime73 = dateTime70.withPeriodAdded(readablePeriod71, (int) '4');
//        org.joda.time.DateTime.Property property74 = dateTime70.secondOfMinute();
//        org.joda.time.Chronology chronology76 = null;
//        java.util.Locale locale77 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket(100L, chronology76, locale77, (java.lang.Integer) 10, 0);
//        long long83 = dateTimeParserBucket80.computeMillis(false, "hi!");
//        java.util.Locale locale84 = dateTimeParserBucket80.getLocale();
//        java.lang.String str85 = property74.getAsText(locale84);
//        java.lang.String str86 = dateTimeZone59.getName((long) 3, locale84);
//        int int87 = skipUndoDateTimeField44.getMaximumTextLength(locale84);
//        java.lang.String str88 = offsetDateTimeField34.getAsShortText(28800032L, locale84);
//        int int90 = offsetDateTimeField34.getMaximumValue((long) 1);
//        java.lang.String str92 = offsetDateTimeField34.getAsText((long) 45517);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(yearMonthDay56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-292275054) + "'", int57 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 52L + "'", long65 == 52L);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 100L + "'", long83 == 100L);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "20" + "'", str85.equals("20"));
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "Coordinated Universal Time" + "'", str86.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "1970" + "'", str88.equals("1970"));
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 292278992 + "'", int90 == 292278992);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1970" + "'", str92.equals("1970"));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        long long6 = property4.remainder();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.addWrapField(0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getLeapAmount(31535999999L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 86400000, (int) (short) 0);
        int int47 = zeroIsMaxDateTimeField40.getMinimumValue(62168140801120L);
        long long49 = zeroIsMaxDateTimeField40.roundHalfFloor((long) (-1));
        long long51 = zeroIsMaxDateTimeField40.roundHalfCeiling((long) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400000L + "'", long45 == 86400000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        org.joda.time.DateTime.Property property12 = dateTime7.weekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:20.248" + "'", str11.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) '4');
//        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime16 = dateTime1.withField(dateTimeFieldType11, (int) '#');
//        int int17 = dateTime1.getWeekyear();
//        int int18 = dateTime1.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
        long long47 = zeroIsMaxDateTimeField40.roundCeiling((long) 0);
        int int49 = zeroIsMaxDateTimeField40.getMinimumValue((long) 0);
        long long52 = zeroIsMaxDateTimeField40.add(57599L, 1L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 57600L + "'", long52 == 57600L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(23, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(1971, (-292275054));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendCenturyOfEra(1971, (-292275054));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withPeriodAdded(readablePeriod24, (int) '4');
        org.joda.time.DateTime.Property property27 = dateTime23.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder19.appendSignedDecimal(dateTimeFieldType28, 86400000, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder10.appendFraction(dateTimeFieldType28, 45517, 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendDayOfYear(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfFloor((long) 32);
        int int38 = offsetDateTimeField34.getOffset();
        long long41 = offsetDateTimeField34.set(248L, "33078993");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1043810058729600248L + "'", long41 == 1043810058729600248L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
//        boolean boolean35 = offsetDateTimeField34.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = gregorianChronology37.eras();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField41 = gregorianChronology40.eras();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology37, dateTimeField42, 2019);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.plus(readablePeriod47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withPeriodAdded(readablePeriod49, (int) '4');
//        org.joda.time.DateTime.Property property52 = dateTime48.secondOfMinute();
//        org.joda.time.DateTime dateTime53 = property52.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime55 = property52.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay56 = dateTime55.toYearMonthDay();
//        int int57 = skipUndoDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay56);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.UTC;
//        long long63 = dateTimeZone59.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long65 = dateTimeZone58.getMillisKeepLocal(dateTimeZone59, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone67 = null;
//        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(dateTimeZone67);
//        org.joda.time.ReadablePeriod readablePeriod69 = null;
//        org.joda.time.DateTime dateTime70 = dateTime68.plus(readablePeriod69);
//        org.joda.time.ReadablePeriod readablePeriod71 = null;
//        org.joda.time.DateTime dateTime73 = dateTime70.withPeriodAdded(readablePeriod71, (int) '4');
//        org.joda.time.DateTime.Property property74 = dateTime70.secondOfMinute();
//        org.joda.time.Chronology chronology76 = null;
//        java.util.Locale locale77 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket(100L, chronology76, locale77, (java.lang.Integer) 10, 0);
//        long long83 = dateTimeParserBucket80.computeMillis(false, "hi!");
//        java.util.Locale locale84 = dateTimeParserBucket80.getLocale();
//        java.lang.String str85 = property74.getAsText(locale84);
//        java.lang.String str86 = dateTimeZone59.getName((long) 3, locale84);
//        int int87 = skipUndoDateTimeField44.getMaximumTextLength(locale84);
//        java.lang.String str88 = offsetDateTimeField34.getAsShortText(28800032L, locale84);
//        long long90 = offsetDateTimeField34.roundFloor(10L);
//        boolean boolean92 = offsetDateTimeField34.isLeap(62168140801120L);
//        long long94 = offsetDateTimeField34.remainder((-1L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(yearMonthDay56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-292275054) + "'", int57 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 52L + "'", long65 == 52L);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 100L + "'", long83 == 100L);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "20" + "'", str85.equals("20"));
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "Coordinated Universal Time" + "'", str86.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "1970" + "'", str88.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 0L + "'", long90 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 31535999999L + "'", long94 == 31535999999L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        long long7 = skipUndoDateTimeField4.add((long) (byte) 100, (int) (short) -1);
        int int8 = skipUndoDateTimeField4.getMinimumValue();
        int int9 = skipUndoDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property18.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime20.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.plus(readablePeriod24);
        org.joda.time.DateTime dateTime26 = dateTime25.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.withPeriodAdded(readablePeriod27, (int) (byte) 10);
        mutableDateTime21.setTime((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime21.monthOfYear();
        mutableDateTime21.addMonths((int) (byte) 1);
        mutableDateTime21.addWeeks((int) (short) 0);
        java.lang.Object obj37 = mutableDateTime21.clone();
        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipUndoDateTimeField4, (java.lang.Object) mutableDateTime21);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 99L + "'", long7 == 99L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField47 = gregorianChronology46.eras();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField50 = gregorianChronology49.eras();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology46, dateTimeField51, 2019);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime57 = dateTime55.plus(readablePeriod56);
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.DateTime dateTime60 = dateTime57.withPeriodAdded(readablePeriod58, (int) '4');
        org.joda.time.DateTime.Property property61 = dateTime57.secondOfMinute();
        org.joda.time.DateTime dateTime62 = property61.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime64 = property61.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay65 = dateTime64.toYearMonthDay();
        int int66 = skipUndoDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay65);
        long long68 = skipUndoDateTimeField53.remainder((long) 24);
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        org.joda.time.DateTime dateTime72 = dateTime70.plus(readablePeriod71);
        org.joda.time.LocalDate localDate73 = dateTime72.toLocalDate();
        int int74 = skipUndoDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) localDate73);
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone75);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.DateTime dateTime78 = dateTime76.plus(readablePeriod77);
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        org.joda.time.DateTime dateTime81 = dateTime78.withPeriodAdded(readablePeriod79, (int) '4');
        org.joda.time.DateTime.Property property82 = dateTime78.secondOfMinute();
        org.joda.time.DateTime dateTime83 = property82.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime85 = property82.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay86 = dateTime85.toYearMonthDay();
        int[] intArray87 = null;
        int int88 = skipUndoDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay86, intArray87);
        int int89 = zeroIsMaxDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay86);
        long long91 = zeroIsMaxDateTimeField40.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(yearMonthDay65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-292275054) + "'", int66 == (-292275054));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 24L + "'", long68 == 24L);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292278993 + "'", int74 == 292278993);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(property82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(yearMonthDay86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 292278993 + "'", int88 == 292278993);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfCeiling((long) (-28800000));
        long long39 = offsetDateTimeField34.roundHalfFloor(31507200024L);
        long long41 = offsetDateTimeField34.roundHalfFloor((long) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 31536000000L + "'", long39 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-28800000), 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: -28800000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) '4');
        org.joda.time.DateTime.Property property10 = dateTime6.secondOfMinute();
        int int11 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.DateTime dateTime21 = dateTime20.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.plus(readablePeriod24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
        org.joda.time.DateTime.Property property29 = dateTime25.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.DateTime dateTime32 = dateTime20.withField(dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        int int37 = dateTime13.get(dateTimeFieldType30);
        mutableDateTime2.set(dateTimeFieldType30, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("12:00:00 AM UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12:00:00 AM UTC\" is malformed at \":00:00 AM UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, 2019);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
//        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = property17.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = property17.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime20.toYearMonthDay();
//        int int22 = skipUndoDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, (int) '4');
//        org.joda.time.DateTime.Property property30 = dateTime26.secondOfMinute();
//        org.joda.time.DateTime dateTime31 = property30.roundHalfFloorCopy();
//        org.joda.time.Chronology chronology33 = null;
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket(100L, chronology33, locale34, (java.lang.Integer) 10, 0);
//        long long40 = dateTimeParserBucket37.computeMillis(false, "hi!");
//        java.util.Locale locale41 = dateTimeParserBucket37.getLocale();
//        java.lang.String str42 = property30.getAsShortText(locale41);
//        int int43 = skipUndoDateTimeField9.getMaximumTextLength(locale41);
//        int int44 = skipUndoDateTimeField9.getMinimumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9);
//        long long47 = skipUndoDateTimeField9.remainder((-1L));
//        long long50 = skipUndoDateTimeField9.addWrapField((long) 1969, 23);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292275054) + "'", int22 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
//        org.junit.Assert.assertNotNull(locale41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "20" + "'", str42.equals("20"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292275053) + "'", int44 == (-292275053));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 31535999999L + "'", long47 == 31535999999L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 725846401969L + "'", long50 == 725846401969L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 32);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.eras();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField11 = gregorianChronology10.eras();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField12, 2019);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime19 = dateTime18.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime18.withPeriodAdded(readablePeriod20, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime24 = dateTime22.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str26 = dateTime22.toString(dateTimeFormatter25);
//        org.joda.time.DateTime.Property property27 = dateTime22.yearOfEra();
//        boolean boolean28 = gregorianChronology7.equals((java.lang.Object) property27);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime(20, 52248, 292278992, 20257, 1591858799, 35, 20, (org.joda.time.Chronology) gregorianChronology7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20257 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:20.248" + "'", str26.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
        long long47 = zeroIsMaxDateTimeField40.roundHalfFloor((long) (short) 1);
        long long49 = zeroIsMaxDateTimeField40.roundHalfFloor(31536000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField52 = gregorianChronology51.eras();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField55 = gregorianChronology54.eras();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology51, dateTimeField56, 2019);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.DateTime dateTime62 = dateTime60.plus(readablePeriod61);
        org.joda.time.LocalDate localDate63 = dateTime62.toLocalDate();
        org.joda.time.Chronology chronology66 = null;
        java.util.Locale locale67 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket70 = new org.joda.time.format.DateTimeParserBucket(100L, chronology66, locale67, (java.lang.Integer) 10, 0);
        long long73 = dateTimeParserBucket70.computeMillis(false, "hi!");
        java.util.Locale locale74 = dateTimeParserBucket70.getLocale();
        java.lang.String str75 = skipUndoDateTimeField58.getAsText((org.joda.time.ReadablePartial) localDate63, (int) 'a', locale74);
        java.lang.String str76 = zeroIsMaxDateTimeField40.getAsShortText(59, locale74);
        long long79 = zeroIsMaxDateTimeField40.set((long) (byte) 0, 45512);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 31536000000L + "'", long49 == 31536000000L);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 100L + "'", long73 == 100L);
        org.junit.Assert.assertNotNull(locale74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "97" + "'", str75.equals("97"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "59" + "'", str76.equals("59"));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 45512L + "'", long79 == 45512L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1591858799, (int) (short) 1, (int) (byte) 100, (int) 'a', (-10), 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = dateTime4.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime9.withYear(20257);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = dateTime9.isSupported(dateTimeFieldType12);
        int int14 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime9.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds(1591879067);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
//        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime17 = dateTime2.withField(dateTimeFieldType12, (int) '#');
//        try {
//            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime2, 1591858799);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1591858799");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1591879112);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime9 = instant8.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.weekyear();
        int int11 = mutableDateTime9.getEra();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
        org.joda.time.DateTime.Property property19 = dateTime14.dayOfMonth();
        org.joda.time.DateTime dateTime21 = dateTime14.plus(0L);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology6, (org.joda.time.ReadableDateTime) mutableDateTime9, (org.joda.time.ReadableDateTime) dateTime21);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime9.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        org.joda.time.DurationField durationField22 = julianChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
        boolean boolean24 = unsupportedDateTimeField23.isSupported();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfCeiling((long) (-28800000));
        java.lang.String str39 = offsetDateTimeField34.getAsShortText((long) '4');
        long long42 = offsetDateTimeField34.add(0L, 59);
        int int43 = offsetDateTimeField34.getOffset();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField45 = gregorianChronology44.eras();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField48 = gregorianChronology47.eras();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology44, dateTimeField49, 2019);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime58 = dateTime55.withPeriodAdded(readablePeriod56, (int) '4');
        org.joda.time.DateTime.Property property59 = dateTime55.secondOfMinute();
        org.joda.time.DateTime dateTime60 = property59.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime62 = property59.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay63 = dateTime62.toYearMonthDay();
        int int64 = skipUndoDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay63);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField66 = gregorianChronology65.eras();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology65.year();
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology65.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField70 = gregorianChronology69.eras();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology69.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField73 = gregorianChronology72.eras();
        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology72.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField76 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology69, dateTimeField74, 2019);
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(dateTimeZone77);
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        org.joda.time.DateTime dateTime80 = dateTime78.plus(readablePeriod79);
        org.joda.time.LocalDate localDate81 = dateTime80.toLocalDate();
        org.joda.time.Chronology chronology84 = null;
        java.util.Locale locale85 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket88 = new org.joda.time.format.DateTimeParserBucket(100L, chronology84, locale85, (java.lang.Integer) 10, 0);
        long long91 = dateTimeParserBucket88.computeMillis(false, "hi!");
        java.util.Locale locale92 = dateTimeParserBucket88.getLocale();
        java.lang.String str93 = skipUndoDateTimeField76.getAsText((org.joda.time.ReadablePartial) localDate81, (int) 'a', locale92);
        int[] intArray95 = gregorianChronology65.get((org.joda.time.ReadablePartial) localDate81, (long) 10);
        int int96 = skipUndoDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) localDate81);
        int int97 = offsetDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDate81);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970" + "'", str39.equals("1970"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1861920000000L + "'", long42 == 1861920000000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(yearMonthDay63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-292275054) + "'", int64 == (-292275054));
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(gregorianChronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(localDate81);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 100L + "'", long91 == 100L);
        org.junit.Assert.assertNotNull(locale92);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "97" + "'", str93.equals("97"));
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-292275054) + "'", int96 == (-292275054));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-292275054) + "'", int97 == (-292275054));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.parse("DateTimeField[secondOfMinute]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, (int) '4');
        org.joda.time.DateTime.Property property12 = dateTime8.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
        org.joda.time.DateTime dateTime15 = dateTime3.withField(dateTimeFieldType13, (int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
        org.joda.time.DateTime dateTime22 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.withPeriodAdded(readablePeriod23, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime27 = dateTime25.withZoneRetainFields(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = dateTime15.toDateTime(dateTimeZone26);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter14.withZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime7.withZoneRetainFields(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:20.248" + "'", str11.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
//        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str24 = dateTimeZone23.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
//        java.lang.String str27 = dateTimeZone23.getShortName((long) 57599);
//        org.joda.time.Chronology chronology28 = gJChronology21.withZone(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology21.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UTC" + "'", str24.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
        int int47 = zeroIsMaxDateTimeField40.getMaximumValue((long) 23);
        long long50 = zeroIsMaxDateTimeField40.set((long) 86400000, 35);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 86400000 + "'", int47 == 86400000);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 86400035L + "'", long50 == 86400035L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = buddhistChronology0.add(readablePeriod1, 0L, 1591879061);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        java.util.Locale locale9 = dateTimeParserBucket5.getLocale();
        java.lang.Integer int10 = dateTimeParserBucket5.getPivotYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.DateTime dateTime20 = dateTime19.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.DateTime dateTime31 = dateTime19.withField(dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder15.appendFixedDecimal(dateTimeFieldType29, 1971);
        dateTimeParserBucket5.saveField(dateTimeFieldType29, (-292275053));
        int int40 = dateTimeParserBucket5.getOffset();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10.equals(10));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 52248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52248 + "'", int1 == 52248);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime10 = property4.roundCeiling();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfCeiling((long) (-28800000));
        java.lang.String str39 = offsetDateTimeField34.getAsShortText((long) '4');
        long long41 = offsetDateTimeField34.roundHalfFloor((long) (-10));
        long long43 = offsetDateTimeField34.roundCeiling((long) 1591879067);
        try {
            long long46 = offsetDateTimeField34.add(24L, 1817649022279063L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1817649022279063");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970" + "'", str39.equals("1970"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 31536000000L + "'", long43 == 31536000000L);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long7 = dateTimeZone0.getMillisKeepLocal(dateTimeZone1, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) '4');
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
//        org.joda.time.Chronology chronology18 = null;
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket(100L, chronology18, locale19, (java.lang.Integer) 10, 0);
//        long long25 = dateTimeParserBucket22.computeMillis(false, "hi!");
//        java.util.Locale locale26 = dateTimeParserBucket22.getLocale();
//        java.lang.String str27 = property16.getAsText(locale26);
//        java.lang.String str28 = dateTimeZone1.getName((long) 3, locale26);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone29, 292275054);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 292275054");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
//        org.junit.Assert.assertNotNull(locale26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.get(0L);
        long long45 = zeroIsMaxDateTimeField40.add((long) 57599, 0);
        long long48 = zeroIsMaxDateTimeField40.getDifferenceAsLong((long) (byte) 0, (long) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.DateTime dateTime52 = dateTime50.plus(readablePeriod51);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, (int) '4');
        org.joda.time.DateTime.Property property56 = dateTime52.secondOfMinute();
        org.joda.time.DateTime dateTime57 = property56.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime59 = property56.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay60 = dateTime59.toYearMonthDay();
        int int61 = zeroIsMaxDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay60);
        long long64 = zeroIsMaxDateTimeField40.getDifferenceAsLong(1861920000000L, (long) 1);
        long long66 = zeroIsMaxDateTimeField40.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 57599L + "'", long45 == 57599L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1L + "'", long48 == 1L);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(yearMonthDay60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1861919999999L + "'", long64 == 1861919999999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant4 = instant1.plus((long) (short) -1);
        org.joda.time.Instant instant6 = instant1.withMillis(57599L);
        org.joda.time.MutableDateTime mutableDateTime7 = instant6.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis((-292275054));
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str13 = dateTimeZone12.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        long long16 = cachedDateTimeZone14.previousTransition(59L);
//        long long18 = cachedDateTimeZone14.previousTransition(0L);
//        int int20 = cachedDateTimeZone14.getStandardOffset((long) 1);
//        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone14);
//        boolean boolean22 = dateTime21.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 59L + "'", long16 == 59L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.monthOfYear();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy("2019-06-12T05:37:44.026");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:37:44.026\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
//        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
//        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
//        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
//        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
//        long long36 = skipUndoDateTimeField16.roundHalfFloor((long) ' ');
//        org.joda.time.Instant instant38 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime39 = instant38.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime42 = property41.roundHalfEven();
//        java.lang.Class<?> wildcardClass43 = mutableDateTime42.getClass();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
//        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime60 = dateTime45.withField(dateTimeFieldType55, (int) '#');
//        boolean boolean61 = mutableDateTime42.isSupported(dateTimeFieldType55);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType55, 32);
//        int int64 = dividedDateTimeField63.getDivisor();
//        long long66 = dividedDateTimeField63.remainder(67L);
//        long long69 = dividedDateTimeField63.set((long) 20248, 20257);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 20 + "'", int46 == 20);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 32 + "'", int64 == 32);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 67L + "'", long66 == 67L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 20394406022420248L + "'", long69 == 20394406022420248L);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 1, "45");
        java.lang.String str12 = illegalFieldValueException11.getIllegalValueAsString();
        java.lang.String str13 = illegalFieldValueException11.toString();
        java.lang.Number number14 = illegalFieldValueException11.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException11.getDurationFieldType();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45" + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1 + "'", number14.equals(1));
        org.junit.Assert.assertNull(durationFieldType15);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(23, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfDay((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
//        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
//        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
//        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
//        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
//        long long45 = zeroIsMaxDateTimeField40.set((long) 86400000, 3);
//        java.lang.String str47 = zeroIsMaxDateTimeField40.getAsShortText((long) 292278993);
//        long long50 = zeroIsMaxDateTimeField40.addWrapField(86400003L, 1591879060);
//        long long52 = zeroIsMaxDateTimeField40.remainder((long) 2019);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        org.joda.time.ReadablePeriod readablePeriod55 = null;
//        org.joda.time.DateTime dateTime56 = dateTime54.plus(readablePeriod55);
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.withPeriodAdded(readablePeriod57, (int) '4');
//        org.joda.time.DateTime.Property property60 = dateTime56.secondOfMinute();
//        org.joda.time.Chronology chronology62 = null;
//        java.util.Locale locale63 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket66 = new org.joda.time.format.DateTimeParserBucket(100L, chronology62, locale63, (java.lang.Integer) 10, 0);
//        long long69 = dateTimeParserBucket66.computeMillis(false, "hi!");
//        java.util.Locale locale70 = dateTimeParserBucket66.getLocale();
//        java.lang.String str71 = property60.getAsText(locale70);
//        int int72 = zeroIsMaxDateTimeField40.getMaximumShortTextLength(locale70);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = zeroIsMaxDateTimeField40.getType();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 86400003L + "'", long45 == 86400003L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "33078993" + "'", str47.equals("33078993"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 123079063L + "'", long50 == 123079063L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 100L + "'", long69 == 100L);
//        org.junit.Assert.assertNotNull(locale70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "20" + "'", str71.equals("20"));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 8 + "'", int72 == 8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTime(dateTimeZone4);
        java.util.Date date6 = mutableDateTime5.toDate();
        mutableDateTime5.setYear(100);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        org.joda.time.DateTimeField dateTimeField6 = null;
        dateTimeParserBucket5.saveField(dateTimeField6, 0);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeParserBucket5.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        org.joda.time.DurationField durationField22 = julianChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
        try {
            java.lang.String str25 = unsupportedDateTimeField23.getAsText((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        int int44 = zeroIsMaxDateTimeField40.getMinimumValue((long) (byte) -1);
        long long46 = zeroIsMaxDateTimeField40.roundCeiling((long) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1L) + "'", long46 == (-1L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(25200);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 25200 + "'", int3 == 25200);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendCenturyOfEra(0, 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        int int6 = mutableDateTime5.getYearOfEra();
        mutableDateTime5.addSeconds((-292275053));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.dayOfMonth();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.clockhourOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(29227899290L, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        long long9 = dateTimeZone5.convertLocalToUTC((long) (short) 1, false, (long) 0);
        long long12 = dateTimeZone5.convertLocalToUTC((long) 59, false);
        org.joda.time.Chronology chronology13 = julianChronology1.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 59L + "'", long12 == 59L);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        org.joda.time.DateTimeField dateTimeField7 = null;
        mutableDateTime6.setRounding(dateTimeField7);
        java.util.Date date9 = mutableDateTime6.toDate();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.yearOfCentury();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = cachedDateTimeZone1.getUncachedZone();
        int int4 = cachedDateTimeZone1.getStandardOffset(59L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = instant1.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMinutes(0);
        org.joda.time.DateTime dateTime8 = dateTime4.plusYears((-292275053));
        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks((int) (byte) -1);
        int int11 = dateTime8.getYearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        org.joda.time.Chronology chronology14 = null;
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(100L, chronology14, locale15, (java.lang.Integer) 10, 0);
        long long21 = dateTimeParserBucket18.computeMillis(false, "hi!");
        java.util.Locale locale22 = dateTimeParserBucket18.getLocale();
        int int23 = property12.getMaximumTextLength(locale22);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292273084 + "'", int11 == 292273084);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        long long23 = skipUndoDateTimeField7.add((long) (byte) -1, 20257);
        int int25 = skipUndoDateTimeField7.get((long) (byte) 100);
        java.lang.String str27 = skipUndoDateTimeField7.getAsText((-61062681600001L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 639249148799999L + "'", long23 == 639249148799999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1971 + "'", int25 == 1971);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "34" + "'", str27.equals("34"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        java.util.Locale locale9 = dateTimeParserBucket5.getLocale();
        long long11 = dateTimeParserBucket5.computeMillis(true);
        long long13 = dateTimeParserBucket5.computeMillis(true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long7 = dateTimeZone0.getMillisKeepLocal(dateTimeZone1, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) '4');
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
//        org.joda.time.Chronology chronology18 = null;
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket(100L, chronology18, locale19, (java.lang.Integer) 10, 0);
//        long long25 = dateTimeParserBucket22.computeMillis(false, "hi!");
//        java.util.Locale locale26 = dateTimeParserBucket22.getLocale();
//        java.lang.String str27 = property16.getAsText(locale26);
//        java.lang.String str28 = dateTimeZone1.getName((long) 3, locale26);
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.hourOfHalfday();
//        try {
//            long long38 = julianChronology29.getDateTimeMillis(3, 2019, (int) (byte) 0, 0, 31564799, (-1), 1591879064);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31564799 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
//        org.junit.Assert.assertNotNull(locale26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        org.joda.time.DurationField durationField22 = julianChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField23.getRangeDurationField();
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField23.getDurationField();
        try {
            int int27 = unsupportedDateTimeField23.get((long) 292273084);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        int int8 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime9 = property7.withMaximumValue();
        org.joda.time.DateTime dateTime11 = property7.setCopy(4);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(59);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = property10.addWrapFieldToCopy(99);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime12.withDurationAdded((long) 1591879112, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime4.withMillisOfSecond(5);
        try {
            java.lang.String str16 = dateTime14.toString("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.withChronology(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
        java.lang.Class<?> wildcardClass10 = dateTime8.getClass();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        int int9 = dateTimeParserBucket5.getOffset();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 1, "45");
        java.lang.String str12 = illegalFieldValueException11.getIllegalValueAsString();
        java.lang.String str13 = illegalFieldValueException11.toString();
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException11.getSuppressed();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45" + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45"));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField10, 2019);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (int) '4');
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime21 = property20.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime23 = property20.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int int25 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.withPeriodAdded(readablePeriod30, (int) '4');
        org.joda.time.DateTime.Property property33 = dateTime29.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType34, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType34);
        int int42 = zeroIsMaxDateTimeField40.getMaximumValue((long) (byte) 1);
        int int43 = zeroIsMaxDateTimeField40.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275054) + "'", int25 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86400000 + "'", int42 == 86400000);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400000 + "'", int43 == 86400000);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime9 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime11 = property4.add((long) (-292275054));
        org.joda.time.MutableDateTime mutableDateTime12 = property4.roundCeiling();
        org.joda.time.DateTimeField dateTimeField13 = property4.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = property4.addWrapField(7);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.year();
        mutableDateTime15.addWeeks(45512);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology3 = null;
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(100L, chronology3, locale4, (java.lang.Integer) 10, 0);
        long long10 = dateTimeParserBucket7.computeMillis(false, "hi!");
        java.util.Locale locale11 = dateTimeParserBucket7.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) ' ', chronology1, locale11, (java.lang.Integer) 10, (int) '#');
        long long16 = dateTimeParserBucket14.computeMillis(true);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField19 = gregorianChronology18.eras();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.eras();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.eras();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField27, 2019);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime40 = property37.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
        int int42 = skipUndoDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.plus(readablePeriod45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) '4');
        org.joda.time.DateTime.Property property50 = dateTime46.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField29, dateTimeFieldType51, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField57 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType51);
        int int59 = zeroIsMaxDateTimeField57.get(0L);
        dateTimeParserBucket14.saveField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField57, 1969);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-292275054) + "'", int42 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 86400000 + "'", int59 == 86400000);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        org.joda.time.DurationField durationField22 = julianChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField23.getRangeDurationField();
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField23.getDurationField();
        boolean boolean26 = unsupportedDateTimeField23.isSupported();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundHalfCeiling();
        int int7 = property4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime10 = property4.addWrapField(1969);
        mutableDateTime10.addWeeks(25252);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
//        mutableDateTime11.addYears((int) (byte) -1);
//        int int15 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        java.lang.String str16 = property7.getName();
//        org.joda.time.DateTime dateTime17 = property7.getDateTime();
//        long long18 = property7.remainder();
//        org.joda.time.DateTime dateTime19 = property7.roundHalfCeilingCopy();
//        int int20 = dateTime19.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31536020 + "'", int15 == 31536020);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "secondOfMinute" + "'", str16.equals("secondOfMinute"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 248L + "'", long18 == 248L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1970 + "'", int20 == 1970);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.eras();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.eras();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField27, 2019);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime40 = property37.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
        int int42 = skipUndoDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay41);
        int int45 = skipUndoDateTimeField29.getDifference((long) 0, 1L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField29);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
        org.joda.time.DateTime dateTime55 = property54.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime57 = property54.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay58 = dateTime57.toYearMonthDay();
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.Chronology chronology63 = null;
        java.util.Locale locale64 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket67 = new org.joda.time.format.DateTimeParserBucket(100L, chronology63, locale64, (java.lang.Integer) 10, 0);
        long long70 = dateTimeParserBucket67.computeMillis(false, "hi!");
        java.util.Locale locale71 = dateTimeParserBucket67.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) ' ', chronology61, locale71, (java.lang.Integer) 10, (int) '#');
        java.lang.String str75 = skipDateTimeField46.getAsText((org.joda.time.ReadablePartial) yearMonthDay58, 292278992, locale71);
        long long78 = skipDateTimeField46.set((-59106067199969L), 20248);
        try {
            long long81 = skipDateTimeField46.set((long) (byte) -1, "DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[year]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-292275054) + "'", int42 == (-292275054));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(yearMonthDay58);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
        org.junit.Assert.assertNotNull(locale71);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "292278992" + "'", str75.equals("292278992"));
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 576797932800031L + "'", long78 == 576797932800031L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.roundCeiling();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField12 = gregorianChronology11.eras();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField13, 2019);
        org.joda.time.DateTime dateTime16 = dateTime7.withChronology((org.joda.time.Chronology) gregorianChronology8);
        try {
            org.joda.time.DateTime dateTime18 = dateTime7.withCenturyOfEra(292278992);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278992 for centuryOfEra must be in the range [1,2922790]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("0100-01-01T00:00:20.248Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 0100-01-01T00:00:20.248Z");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType19, 57599, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField30 = gregorianChronology29.eras();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField33 = gregorianChronology32.eras();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField34, 2019);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime38.plus(readablePeriod39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime43 = dateTime40.withPeriodAdded(readablePeriod41, (int) '4');
        org.joda.time.DateTime.Property property44 = dateTime40.secondOfMinute();
        org.joda.time.DateTime dateTime45 = property44.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime47 = property44.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime47.toYearMonthDay();
        int int49 = skipUndoDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay48);
        long long52 = skipUndoDateTimeField36.add((long) (byte) -1, 20257);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipUndoDateTimeField36.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-292275054) + "'", int49 == (-292275054));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 639249148799999L + "'", long52 == 639249148799999L);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) '4');
        org.joda.time.DateTime.Property property17 = dateTime13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.DateTime dateTime20 = dateTime8.withField(dateTimeFieldType18, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType18, 1971);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        long long7 = gregorianChronology0.add(1560322800000L, (-7014601272L), 31564799);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-221412918893024328L) + "'", long7 == (-221412918893024328L));
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
//        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
//        org.joda.time.DurationField durationField22 = julianChronology17.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField23.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.eras();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.dayOfMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter31.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.withPeriodAdded(readablePeriod37, (int) '4');
//        org.joda.time.DateTime.Property property40 = dateTime36.secondOfMinute();
//        org.joda.time.Chronology chronology42 = null;
//        java.util.Locale locale43 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(100L, chronology42, locale43, (java.lang.Integer) 10, 0);
//        long long49 = dateTimeParserBucket46.computeMillis(false, "hi!");
//        java.util.Locale locale50 = dateTimeParserBucket46.getLocale();
//        java.lang.String str51 = property40.getAsText(locale50);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter32.withLocale(locale50);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket((-210866846400000L), (org.joda.time.Chronology) gregorianChronology27, locale50);
//        try {
//            java.lang.String str54 = unsupportedDateTimeField23.getAsText(1591858799, locale50);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertNotNull(locale50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "20" + "'", str51.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1970-01-01T00:00:20.248");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970-01-01T00:00:20.248/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.minusHours((int) (short) -1);
        java.lang.String str6 = dateTime3.toString();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readableDuration7);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str6.equals("1970-01-01T00:00:00.100Z"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildFormatter();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        int int2 = gJChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.Object obj4 = mutableDateTime2.clone();
        mutableDateTime2.setSecondOfMinute(4);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.millisOfSecond();
        java.lang.Object obj8 = mutableDateTime2.clone();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) 'a');
//        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
//        int int15 = dateTime13.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 18 + "'", int15 == 18);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime7.toYearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.String str12 = dateTime7.toString(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:20Z" + "'", str12.equals("1970-01-01T00:00:20Z"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatterBuilder20.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitYear(86400000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) 1591879067);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withDate(0, (-1), 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatterBuilder20.toFormatter();
        org.joda.time.Chronology chronology23 = null;
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(100L, chronology23, locale24, (java.lang.Integer) 10, 0);
        org.joda.time.Chronology chronology28 = dateTimeParserBucket27.getChronology();
        try {
            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter21, chronology28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(chronology28);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
//        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
//        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology23 = gJChronology21.withZone(dateTimeZone22);
//        java.lang.String str24 = gJChronology21.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "GJChronology[UTC,cutover=1970-01-01T00:00:20.248Z]" + "'", str24.equals("GJChronology[UTC,cutover=1970-01-01T00:00:20.248Z]"));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 28800032L, (java.lang.Number) 24, (java.lang.Number) 62168140801120L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(1591879067, 420, 24, 1591879064);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1591879064 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType19, 57599, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder5.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder5.appendHourOfHalfday(1591879114);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime4 = instant1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = instant1.toDateTime();
        org.joda.time.Chronology chronology6 = instant1.getChronology();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        mutableDateTime1.addWeeks((int) (byte) -1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        java.lang.String str8 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField7 = gregorianChronology6.eras();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField8, 2019);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
//        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
//        org.joda.time.DateTime dateTime19 = property18.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime21 = property18.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        int int23 = skipUndoDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay22);
//        long long25 = skipUndoDateTimeField10.remainder((long) 24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        int int31 = skipUndoDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.plus(readablePeriod34);
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, (int) '4');
//        org.joda.time.DateTime.Property property39 = dateTime35.secondOfMinute();
//        org.joda.time.DateTime dateTime40 = property39.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime42 = property39.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay43 = dateTime42.toYearMonthDay();
//        int[] intArray44 = null;
//        int int45 = skipUndoDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay43, intArray44);
//        long long47 = gregorianChronology0.set((org.joda.time.ReadablePartial) yearMonthDay43, 1817649022279063L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292275054) + "'", int23 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24L + "'", long25 == 24L);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292278993 + "'", int31 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(yearMonthDay43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292278993 + "'", int45 == 292278993);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 36679063L + "'", long47 == 36679063L);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        java.lang.Appendable appendable12 = null;
//        try {
//            dateTimeFormatter10.printTo(appendable12, 57600L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:20.248" + "'", str11.equals("1970-01-01T00:00:20.248"));
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.DateTime dateTime9 = property7.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(1971, (-292275054));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendFractionOfSecond(1591858799, 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendDayOfWeek((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = cachedDateTimeZone2.isLocalDateTimeGap(localDateTime3);
        boolean boolean5 = buddhistChronology0.equals((java.lang.Object) boolean4);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.hourOfDay();
        org.joda.time.Chronology chronology7 = buddhistChronology0.withUTC();
        try {
            long long12 = buddhistChronology0.getDateTimeMillis(57599, (-292275054), (int) (byte) 10, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.dayOfMonth();
        int int14 = property13.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
//        mutableDateTime11.addYears((int) (byte) -1);
//        int int15 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        java.lang.String str16 = property7.getName();
//        org.joda.time.DateTime dateTime17 = property7.getDateTime();
//        long long18 = property7.remainder();
//        org.joda.time.DateTime dateTime19 = property7.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime21 = property7.addToCopy(86400000);
//        org.joda.time.DateTime dateTime22 = property7.getDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.plusHours(1591879061);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31536020 + "'", int15 == 31536020);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "secondOfMinute" + "'", str16.equals("secondOfMinute"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 248L + "'", long18 == 248L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) '4');
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        int int14 = property13.getMaximumValue();
        org.joda.time.DateTime dateTime16 = property13.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property19 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.DateTime dateTime24 = dateTime23.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) '4');
        org.joda.time.DateTime.Property property32 = dateTime28.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.DateTime dateTime35 = dateTime23.withField(dateTimeFieldType33, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        int int40 = dateTime16.get(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime2 = property1.roundHalfCeiling();
//        boolean boolean3 = mutableDateTime2.isBeforeNow();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(23, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfMonth(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute(20, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        long long26 = dateTimeZone22.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long28 = dateTimeZone21.getMillisKeepLocal(dateTimeZone22, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
//        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
//        org.joda.time.Chronology chronology39 = null;
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket(100L, chronology39, locale40, (java.lang.Integer) 10, 0);
//        long long46 = dateTimeParserBucket43.computeMillis(false, "hi!");
//        java.util.Locale locale47 = dateTimeParserBucket43.getLocale();
//        java.lang.String str48 = property37.getAsText(locale47);
//        java.lang.String str49 = dateTimeZone22.getName((long) 3, locale47);
//        int int50 = skipUndoDateTimeField7.getMaximumTextLength(locale47);
//        int int52 = skipUndoDateTimeField7.get((long) (byte) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
//        org.junit.Assert.assertNotNull(locale47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "20" + "'", str48.equals("20"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 9 + "'", int50 == 9);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1971 + "'", int52 == 1971);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
        int int12 = mutableDateTime10.getDayOfWeek();
        try {
            mutableDateTime10.setTime(4, 59, 20257, 292273084);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20257 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
//        long long12 = mutableDateTime10.getMillis();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant4 = instant1.plus((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant1.minus(readableDuration5);
        org.joda.time.MutableDateTime mutableDateTime7 = instant6.toMutableDateTime();
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime7.add(readableDuration8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.weekOfWeekyear();
        java.lang.Object obj11 = mutableDateTime7.clone();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime7.minuteOfDay();
        mutableDateTime7.addMillis(70);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime7.minuteOfHour();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
//        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
//        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
//        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
//        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
//        long long36 = skipUndoDateTimeField16.roundHalfFloor((long) ' ');
//        org.joda.time.Instant instant38 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime39 = instant38.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime42 = property41.roundHalfEven();
//        java.lang.Class<?> wildcardClass43 = mutableDateTime42.getClass();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
//        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime60 = dateTime45.withField(dateTimeFieldType55, (int) '#');
//        boolean boolean61 = mutableDateTime42.isSupported(dateTimeFieldType55);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType55, 32);
//        int int64 = dividedDateTimeField63.getDivisor();
//        long long67 = dividedDateTimeField63.addWrapField((long) 20248, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 20 + "'", int46 == 20);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 32 + "'", int64 == 32);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 20248L + "'", long67 == 20248L);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) '4');
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        int int14 = property13.getMaximumValue();
        org.joda.time.DateTime dateTime16 = property13.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property19 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.DateTime dateTime24 = dateTime23.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) '4');
        org.joda.time.DateTime.Property property32 = dateTime28.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.DateTime dateTime35 = dateTime23.withField(dateTimeFieldType33, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        int int40 = dateTime16.get(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusHours((int) (short) -1);
        java.lang.String str4 = dateTime1.toString();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        boolean boolean7 = dateTime6.isAfterNow();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withDayOfYear(1591858799);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1591858799 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str4.equals("1970-01-01T00:00:00.100Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = cachedDateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = cachedDateTimeZone1.getUncachedZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
        org.joda.time.Chronology chronology36 = null;
        java.util.Locale locale37 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket(100L, chronology36, locale37, (java.lang.Integer) 10, 0);
        long long43 = dateTimeParserBucket40.computeMillis(false, "hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField45 = gregorianChronology44.eras();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField48 = gregorianChronology47.eras();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology44, dateTimeField49, 2019);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime58 = dateTime55.withPeriodAdded(readablePeriod56, (int) '4');
        org.joda.time.DateTime.Property property59 = dateTime55.secondOfMinute();
        org.joda.time.DateTime dateTime60 = property59.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime62 = property59.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay63 = dateTime62.toYearMonthDay();
        int int64 = skipUndoDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay63);
        long long67 = skipUndoDateTimeField51.add((long) (byte) -1, 20257);
        dateTimeParserBucket40.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField51, (int) (byte) 1);
        long long71 = skipUndoDateTimeField51.roundHalfFloor((long) ' ');
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField51, 0);
        java.lang.String str74 = skipUndoDateTimeField51.getName();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(yearMonthDay63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-292275054) + "'", int64 == (-292275054));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 639249148799999L + "'", long67 == 639249148799999L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "year" + "'", str74.equals("year"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(0, 1591858799, (int) ' ', 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1591858799 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType19, 57599, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder5.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder5.appendHourOfHalfday(1591879114);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter34 = dateTimeFormatterBuilder33.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimePrinter34);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(1971, (-292275054));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder5.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 1, "45");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException("2019-06-12T05:37:44.026", "");
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException14.getSuppressed();
        java.lang.String str16 = illegalFieldValueException14.getFieldName();
        illegalFieldValueException14.prependMessage("43");
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-12T05:37:44.026" + "'", str16.equals("2019-06-12T05:37:44.026"));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long7 = dateTimeZone0.getMillisKeepLocal(dateTimeZone1, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) '4');
//        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
//        org.joda.time.Chronology chronology18 = null;
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket(100L, chronology18, locale19, (java.lang.Integer) 10, 0);
//        long long25 = dateTimeParserBucket22.computeMillis(false, "hi!");
//        java.util.Locale locale26 = dateTimeParserBucket22.getLocale();
//        java.lang.String str27 = property16.getAsText(locale26);
//        java.lang.String str28 = dateTimeZone1.getName((long) 3, locale26);
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        long long36 = dateTimeZone32.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long38 = dateTimeZone31.getMillisKeepLocal(dateTimeZone32, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.ReadablePeriod readablePeriod42 = null;
//        org.joda.time.DateTime dateTime43 = dateTime41.plus(readablePeriod42);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withPeriodAdded(readablePeriod44, (int) '4');
//        org.joda.time.DateTime.Property property47 = dateTime43.secondOfMinute();
//        org.joda.time.Chronology chronology49 = null;
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(100L, chronology49, locale50, (java.lang.Integer) 10, 0);
//        long long56 = dateTimeParserBucket53.computeMillis(false, "hi!");
//        java.util.Locale locale57 = dateTimeParserBucket53.getLocale();
//        java.lang.String str58 = property47.getAsText(locale57);
//        java.lang.String str59 = dateTimeZone32.getName((long) 3, locale57);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone32);
//        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.Instant instant63 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime64 = instant63.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property65 = mutableDateTime64.weekyear();
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime64.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime67 = property66.roundHalfEven();
//        java.lang.Class<?> wildcardClass68 = mutableDateTime67.getClass();
//        int int69 = dateTimeZone32.getOffset((org.joda.time.ReadableInstant) mutableDateTime67);
//        org.joda.time.Chronology chronology70 = julianChronology29.withZone(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
//        org.junit.Assert.assertNotNull(locale26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 52L + "'", long38 == 52L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "20" + "'", str58.equals("20"));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Coordinated Universal Time" + "'", str59.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology61);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(mutableDateTime67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(chronology70);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        org.joda.time.tz.NameProvider nameProvider8 = org.joda.time.DateTimeZone.getNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider(nameProvider8);
//        boolean boolean10 = property7.equals((java.lang.Object) nameProvider8);
//        java.lang.String str11 = property7.getAsString();
//        java.lang.String str12 = property7.toString();
//        int int13 = property7.getMaximumValue();
//        org.joda.time.DateTime dateTime15 = property7.addToCopy((long) (byte) 0);
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime15.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(nameProvider8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfMinute]" + "'", str12.equals("Property[secondOfMinute]"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) 'a');
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendClockhourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendTimeZoneOffset("org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45", true, 8, 23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        dateTimeFormatterBuilder5.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) '4');
        org.joda.time.DateTime.Property property18 = dateTime14.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType19, 57599, (int) (byte) 100);
        boolean boolean27 = dateTimeFormatterBuilder26.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendYearOfEra(99, (-292275053));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.String str2 = dateTimeFormatter0.print((long) 4);
        org.joda.time.Instant instant4 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime5 = instant4.toMutableDateTimeISO();
        int int6 = mutableDateTime5.getMinuteOfHour();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "2019-06-12T12:38:37.466Z", 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.Instant instant4 = instant2.withMillis((-59106067199969L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime12 = dateTime7.toDateTimeISO();
//        org.joda.time.DateTime dateTime14 = dateTime7.plusHours(420);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:20.248" + "'", str11.equals("1970-01-01T00:00:20.248"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField36 = gregorianChronology35.eras();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField39 = gregorianChronology38.eras();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology35, dateTimeField40, 2019);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.plus(readablePeriod45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) '4');
        org.joda.time.DateTime.Property property50 = dateTime46.secondOfMinute();
        org.joda.time.DateTime dateTime51 = property50.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime53 = property50.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime53.toYearMonthDay();
        int int55 = skipUndoDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay54);
        long long57 = skipUndoDateTimeField42.remainder((long) 24);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(dateTimeZone58);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.DateTime dateTime61 = dateTime59.plus(readablePeriod60);
        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
        int int63 = skipUndoDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localDate62);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(dateTimeZone64);
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.DateTime dateTime67 = dateTime65.plus(readablePeriod66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.DateTime dateTime70 = dateTime67.withPeriodAdded(readablePeriod68, (int) '4');
        org.joda.time.DateTime.Property property71 = dateTime67.secondOfMinute();
        org.joda.time.DateTime dateTime72 = property71.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime74 = property71.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay75 = dateTime74.toYearMonthDay();
        int[] intArray76 = null;
        int int77 = skipUndoDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay75, intArray76);
        int[] intArray79 = null;
        int[] intArray81 = skipUndoDateTimeField16.add((org.joda.time.ReadablePartial) yearMonthDay75, (int) (byte) 1, intArray79, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField83 = gregorianChronology82.eras();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology82.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology85 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField86 = gregorianChronology85.eras();
        org.joda.time.DateTimeField dateTimeField87 = gregorianChronology85.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField89 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology82, dateTimeField87, 2019);
        java.lang.String str90 = gregorianChronology82.toString();
        org.joda.time.DateTimeField dateTimeField91 = gregorianChronology82.monthOfYear();
        org.joda.time.DateTimeField dateTimeField92 = gregorianChronology82.year();
        org.joda.time.MutableDateTime mutableDateTime93 = new org.joda.time.MutableDateTime((java.lang.Object) intArray79, (org.joda.time.Chronology) gregorianChronology82);
        mutableDateTime93.setDayOfMonth(4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-292275054) + "'", int55 == (-292275054));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 24L + "'", long57 == 24L);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292278993 + "'", int63 == 292278993);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(yearMonthDay75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 292278993 + "'", int77 == 292278993);
        org.junit.Assert.assertNull(intArray81);
        org.junit.Assert.assertNotNull(gregorianChronology82);
        org.junit.Assert.assertNotNull(durationField83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(gregorianChronology85);
        org.junit.Assert.assertNotNull(durationField86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "GregorianChronology[UTC]" + "'", str90.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField91);
        org.junit.Assert.assertNotNull(dateTimeField92);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekyear();
        java.lang.Object obj4 = mutableDateTime2.clone();
        mutableDateTime2.setSecondOfMinute(4);
        org.joda.time.Chronology chronology7 = mutableDateTime2.getChronology();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        java.lang.String str8 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("45", false, 4, 2019);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) '4');
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        int int14 = property13.getMaximumValue();
        org.joda.time.DateTime dateTime16 = property13.setCopy((int) (byte) 10);
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear((int) 'a');
        org.joda.time.DateTime.Property property19 = dateTime16.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.DateTime dateTime24 = dateTime23.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, (int) '4');
        org.joda.time.DateTime.Property property32 = dateTime28.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.DateTime dateTime35 = dateTime23.withField(dateTimeFieldType33, (int) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
        int int40 = dateTime16.get(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendYear(31561251, 31564799);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.appendClockhourOfDay(31536020);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1970-01-01T00:00:20.248");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay2 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(timeOfDay2);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) 100);
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
//        int int4 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) mutableDateTime3);
//        long long8 = dateTimeZone0.convertLocalToUTC((long) '4', false, 100L);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
//        org.joda.time.DateTime dateTime18 = dateTime13.withSecondOfMinute(2);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusYears((int) 'a');
//        org.joda.time.DateTime dateTime24 = dateTime20.minusSeconds(1591879064);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        long long3 = cachedDateTimeZone1.nextTransition((long) 20);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
        org.junit.Assert.assertNotNull(iSOChronology4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean5 = mutableDateTime2.equals((java.lang.Object) dateTimeFormatter4);
        int int6 = mutableDateTime2.getSecondOfMinute();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField5 = gregorianChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField6, 2019);
        java.lang.String str9 = gregorianChronology1.toString();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) 1591879064, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[UTC]" + "'", str9.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
        boolean boolean35 = offsetDateTimeField34.isSupported();
        long long37 = offsetDateTimeField34.roundHalfCeiling((long) (-28800000));
        java.lang.String str39 = offsetDateTimeField34.getAsShortText((long) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField34.getType();
        int int42 = offsetDateTimeField34.get((-62198755200000L));
        long long44 = offsetDateTimeField34.roundHalfFloor((-62198755199999L));
        int int47 = offsetDateTimeField34.getDifference((long) 31564799, 31507200024L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970" + "'", str39.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62198755200000L) + "'", long44 == (-62198755200000L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfSecond();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
        org.joda.time.DateTime dateTime12 = property11.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(0, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(chronology0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) '4');
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withDayOfWeek(1591858799);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1591858799 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfDay();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField5 = gregorianChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, dateTimeField6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField12 = gregorianChronology11.eras();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField13, 2019);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) '4');
        org.joda.time.DateTime.Property property23 = dateTime19.secondOfMinute();
        org.joda.time.DateTime dateTime24 = property23.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime26 = property23.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay27 = dateTime26.toYearMonthDay();
        int int28 = skipUndoDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.plus(readablePeriod31);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.withPeriodAdded(readablePeriod33, (int) '4');
        org.joda.time.DateTime.Property property36 = dateTime32.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 1, "45");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType37, (-1));
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType37);
        int int45 = zeroIsMaxDateTimeField43.get(0L);
        long long48 = zeroIsMaxDateTimeField43.add((long) 57599, 0);
        boolean boolean49 = julianChronology0.equals((java.lang.Object) long48);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(yearMonthDay27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-292275054) + "'", int28 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 86400000 + "'", int45 == 86400000);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 57599L + "'", long48 == 57599L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) '#');
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant7, readableInstant8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(chronology9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.hourOfDay();
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.millisOfSecond();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
//        org.joda.time.DateTime dateTime19 = dateTime18.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
//        org.joda.time.DateTime dateTime21 = property20.roundCeilingCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField23 = gregorianChronology22.eras();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.eras();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField27, 2019);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.withPeriodAdded(readablePeriod34, (int) '4');
//        org.joda.time.DateTime.Property property37 = dateTime33.secondOfMinute();
//        org.joda.time.DateTime dateTime38 = property37.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime40 = property37.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
//        int int42 = skipUndoDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay41);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.UTC;
//        long long48 = dateTimeZone44.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long50 = dateTimeZone43.getMillisKeepLocal(dateTimeZone44, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.DateTime dateTime58 = dateTime55.withPeriodAdded(readablePeriod56, (int) '4');
//        org.joda.time.DateTime.Property property59 = dateTime55.secondOfMinute();
//        org.joda.time.Chronology chronology61 = null;
//        java.util.Locale locale62 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket(100L, chronology61, locale62, (java.lang.Integer) 10, 0);
//        long long68 = dateTimeParserBucket65.computeMillis(false, "hi!");
//        java.util.Locale locale69 = dateTimeParserBucket65.getLocale();
//        java.lang.String str70 = property59.getAsText(locale69);
//        java.lang.String str71 = dateTimeZone44.getName((long) 3, locale69);
//        int int72 = skipUndoDateTimeField29.getMaximumTextLength(locale69);
//        java.lang.String str73 = property20.getAsShortText(locale69);
//        java.lang.String str76 = defaultNameProvider14.getShortName(locale69, "org.joda.time.IllegalFieldValueException: Value 1 for secondOfMinute is not supported: 45", "org.joda.time.IllegalInstantException: 38");
//        java.lang.String str77 = property13.getAsText(locale69);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(yearMonthDay41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-292275054) + "'", int42 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1L + "'", long48 == 1L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 52L + "'", long50 == 52L);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 100L + "'", long68 == 100L);
//        org.junit.Assert.assertNotNull(locale69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "20" + "'", str70.equals("20"));
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Coordinated Universal Time" + "'", str71.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 9 + "'", int72 == 9);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "0" + "'", str73.equals("0"));
//        org.junit.Assert.assertNull(str76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "0" + "'", str77.equals("0"));
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.Chronology chronology6 = null;
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(100L, chronology6, locale7, (java.lang.Integer) 10, 0);
//        long long13 = dateTimeParserBucket10.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.eras();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField18 = gregorianChronology17.eras();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField19, 2019);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.plus(readablePeriod24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
//        org.joda.time.DateTime.Property property29 = dateTime25.secondOfMinute();
//        org.joda.time.DateTime dateTime30 = property29.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime32 = property29.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        int int34 = skipUndoDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay33);
//        long long37 = skipUndoDateTimeField21.add((long) (byte) -1, 20257);
//        dateTimeParserBucket10.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField21, (int) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField41 = gregorianChronology40.eras();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = gregorianChronology43.eras();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology40, dateTimeField45, 2019);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone48);
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime49.plus(readablePeriod50);
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.withPeriodAdded(readablePeriod52, (int) '4');
//        org.joda.time.DateTime.Property property55 = dateTime51.secondOfMinute();
//        org.joda.time.DateTime dateTime56 = property55.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime58 = property55.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay59 = dateTime58.toYearMonthDay();
//        int int60 = skipUndoDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay59);
//        long long62 = skipUndoDateTimeField47.remainder((long) 24);
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone63);
//        org.joda.time.ReadablePeriod readablePeriod65 = null;
//        org.joda.time.DateTime dateTime66 = dateTime64.plus(readablePeriod65);
//        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
//        int int68 = skipUndoDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate67);
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
//        org.joda.time.ReadablePeriod readablePeriod71 = null;
//        org.joda.time.DateTime dateTime72 = dateTime70.plus(readablePeriod71);
//        org.joda.time.ReadablePeriod readablePeriod73 = null;
//        org.joda.time.DateTime dateTime75 = dateTime72.withPeriodAdded(readablePeriod73, (int) '4');
//        org.joda.time.DateTime.Property property76 = dateTime72.secondOfMinute();
//        org.joda.time.DateTime dateTime77 = property76.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime79 = property76.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay80 = dateTime79.toYearMonthDay();
//        int[] intArray81 = null;
//        int int82 = skipUndoDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay80, intArray81);
//        int[] intArray84 = null;
//        int[] intArray86 = skipUndoDateTimeField21.add((org.joda.time.ReadablePartial) yearMonthDay80, (int) (byte) 1, intArray84, 0);
//        long long88 = gregorianChronology0.set((org.joda.time.ReadablePartial) yearMonthDay80, 0L);
//        org.joda.time.DateTime dateTime89 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292275054) + "'", int34 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 639249148799999L + "'", long37 == 639249148799999L);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(yearMonthDay59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-292275054) + "'", int60 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 24L + "'", long62 == 24L);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(localDate67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 292278993 + "'", int68 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(yearMonthDay80);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 292278993 + "'", int82 == 292278993);
//        org.junit.Assert.assertNull(intArray86);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 0L + "'", long88 == 0L);
//        org.junit.Assert.assertNotNull(dateTime89);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.era();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 23);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210864772800000L) + "'", long1 == (-210864772800000L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) '4');
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (int) (byte) 10);
        mutableDateTime11.setTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Instant instant25 = instant22.withDurationAdded(readableDuration23, 32);
        org.joda.time.Instant instant27 = instant22.withMillis(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(instant27);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant1.plus(readableDuration3);
        org.joda.time.Chronology chronology5 = instant1.getChronology();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology3 = null;
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(100L, chronology3, locale4, (java.lang.Integer) 10, 0);
        long long10 = dateTimeParserBucket7.computeMillis(false, "hi!");
        java.util.Locale locale11 = dateTimeParserBucket7.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) ' ', chronology1, locale11, (java.lang.Integer) 10, (int) '#');
        long long16 = dateTimeParserBucket14.computeMillis(true);
        java.util.Locale locale17 = dateTimeParserBucket14.getLocale();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str19 = dateTimeZone18.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfCentury();
        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
        boolean boolean30 = cachedDateTimeZone20.isLocalDateTimeGap(localDateTime29);
        dateTimeParserBucket14.setZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 1, "45");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType12);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        org.joda.time.DurationField durationField22 = julianChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField22);
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField23.getRangeDurationField();
        boolean boolean25 = unsupportedDateTimeField23.isSupported();
        try {
            long long27 = unsupportedDateTimeField23.roundCeiling((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime4.withSecondOfMinute(2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusYears((int) 'a');
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
        int int15 = dateTime13.getSecondOfMinute();
        org.joda.time.DateTime.Property property16 = dateTime13.secondOfMinute();
        boolean boolean17 = property16.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.joda.time.Chronology chronology1 = null;
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
//        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
//        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
//        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
//        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
//        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
//        long long36 = skipUndoDateTimeField16.roundHalfFloor((long) ' ');
//        org.joda.time.Instant instant38 = new org.joda.time.Instant((long) '#');
//        org.joda.time.MutableDateTime mutableDateTime39 = instant38.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime39.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime42 = property41.roundHalfEven();
//        java.lang.Class<?> wildcardClass43 = mutableDateTime42.getClass();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
//        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 1, "45");
//        org.joda.time.DateTime dateTime60 = dateTime45.withField(dateTimeFieldType55, (int) '#');
//        boolean boolean61 = mutableDateTime42.isSupported(dateTimeFieldType55);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType55, 32);
//        org.joda.time.MutableDateTime mutableDateTime64 = new org.joda.time.MutableDateTime();
//        org.joda.time.ReadableDuration readableDuration65 = null;
//        mutableDateTime64.add(readableDuration65, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone68);
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.DateTime dateTime71 = dateTime69.plus(readablePeriod70);
//        org.joda.time.DateTime dateTime72 = dateTime71.withTimeAtStartOfDay();
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
//        org.joda.time.ReadablePeriod readablePeriod75 = null;
//        org.joda.time.DateTime dateTime76 = dateTime74.plus(readablePeriod75);
//        org.joda.time.ReadablePeriod readablePeriod77 = null;
//        org.joda.time.DateTime dateTime79 = dateTime76.withPeriodAdded(readablePeriod77, (int) '4');
//        org.joda.time.DateTime.Property property80 = dateTime76.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = property80.getFieldType();
//        org.joda.time.DateTime dateTime83 = dateTime71.withField(dateTimeFieldType81, (int) (byte) 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException87 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType81, (java.lang.Number) (-1.0f), (java.lang.Number) 31536000000L, (java.lang.Number) 31507200024L);
//        boolean boolean88 = mutableDateTime64.isSupported(dateTimeFieldType81);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField89 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField63, dateTimeFieldType81);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 20 + "'", int46 == 20);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(property80);
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withPeriodAdded(readablePeriod5, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime13 = dateTimeFormatter10.parseMutableDateTime("44");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"44\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:20.248" + "'", str11.equals("1970-01-01T00:00:20.248"));
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(100L, chronology1, locale2, (java.lang.Integer) 10, 0);
        long long8 = dateTimeParserBucket5.computeMillis(false, "hi!");
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.eras();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField14, 2019);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
        org.joda.time.DateTime.Property property24 = dateTime20.secondOfMinute();
        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime27 = property24.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
        int int29 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay28);
        long long32 = skipUndoDateTimeField16.add((long) (byte) -1, 20257);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField36 = gregorianChronology35.eras();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField39 = gregorianChronology38.eras();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology35, dateTimeField40, 2019);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.plus(readablePeriod45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.withPeriodAdded(readablePeriod47, (int) '4');
        org.joda.time.DateTime.Property property50 = dateTime46.secondOfMinute();
        org.joda.time.DateTime dateTime51 = property50.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime53 = property50.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime53.toYearMonthDay();
        int int55 = skipUndoDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay54);
        long long57 = skipUndoDateTimeField42.remainder((long) 24);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(dateTimeZone58);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.DateTime dateTime61 = dateTime59.plus(readablePeriod60);
        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
        int int63 = skipUndoDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localDate62);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(dateTimeZone64);
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.DateTime dateTime67 = dateTime65.plus(readablePeriod66);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.DateTime dateTime70 = dateTime67.withPeriodAdded(readablePeriod68, (int) '4');
        org.joda.time.DateTime.Property property71 = dateTime67.secondOfMinute();
        org.joda.time.DateTime dateTime72 = property71.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime74 = property71.setCopy((int) '4');
        org.joda.time.YearMonthDay yearMonthDay75 = dateTime74.toYearMonthDay();
        int[] intArray76 = null;
        int int77 = skipUndoDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay75, intArray76);
        int[] intArray79 = null;
        int[] intArray81 = skipUndoDateTimeField16.add((org.joda.time.ReadablePartial) yearMonthDay75, (int) (byte) 1, intArray79, 0);
        int int84 = skipUndoDateTimeField16.getDifference((long) 19, (long) 25200);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 639249148799999L + "'", long32 == 639249148799999L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-292275054) + "'", int55 == (-292275054));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 24L + "'", long57 == 24L);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292278993 + "'", int63 == 292278993);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(yearMonthDay75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 292278993 + "'", int77 == 292278993);
        org.junit.Assert.assertNull(intArray81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 1, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(1591879061, 45512);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.eras();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField5, 2019);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = property15.setCopy((int) '4');
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        int int20 = skipUndoDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withPeriodAdded(readablePeriod25, (int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 1, "45");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType29, (-1));
//        long long37 = offsetDateTimeField34.add(0L, 28800);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
//        long long43 = dateTimeZone39.convertLocalToUTC((long) (short) 1, false, (long) 0);
//        long long45 = dateTimeZone38.getMillisKeepLocal(dateTimeZone39, (long) '4');
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.plus(readablePeriod49);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, (int) '4');
//        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
//        org.joda.time.Chronology chronology56 = null;
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(100L, chronology56, locale57, (java.lang.Integer) 10, 0);
//        long long63 = dateTimeParserBucket60.computeMillis(false, "hi!");
//        java.util.Locale locale64 = dateTimeParserBucket60.getLocale();
//        java.lang.String str65 = property54.getAsText(locale64);
//        java.lang.String str66 = dateTimeZone39.getName((long) 3, locale64);
//        int int67 = offsetDateTimeField34.getMaximumShortTextLength(locale64);
//        long long69 = offsetDateTimeField34.roundFloor(639249148799999L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 908840217600000L + "'", long37 == 908840217600000L);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 52L + "'", long45 == 52L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 100L + "'", long63 == 100L);
//        org.junit.Assert.assertNotNull(locale64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "20" + "'", str65.equals("20"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Coordinated Universal Time" + "'", str66.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 639217612800000L + "'", long69 == 639217612800000L);
//    }
//}

