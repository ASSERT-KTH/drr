import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (byte) 10, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test003");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560627811576L + "'", long0 == 1560627811576L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1L), 1560627811576L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1560627811576");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        try {
            org.joda.time.Period period10 = period8.withMinutes((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-35) + "'", int1 == (-35));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) dateTimeZone1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+10:00" + "'", str2.equals("+10:00"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField3 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "+10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-25L) + "'", long2 == (-25L));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) 36000000, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', 10L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        try {
            org.joda.time.Period period11 = period3.minusSeconds(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Period period9 = period6.withField(durationFieldType7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 0L, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1560627811576L, (java.lang.Number) (short) 1, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.dayOfWeek();
        try {
            long long14 = iSOChronology2.getDateTimeMillis(0, 100, 36000000, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (-35), (int) (short) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        int int10 = period3.getSeconds();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
//        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
//        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType3, (java.lang.Object) false);
//        org.joda.time.Period period7 = new org.joda.time.Period(1560627811576L, periodType3);
//        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDay();
//        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', (long) '#', periodType10);
//        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
//        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', (long) '#', periodType14);
//        org.joda.time.Period period16 = period11.plus((org.joda.time.ReadablePeriod) period15);
//        org.joda.time.Period period17 = period7.withFields((org.joda.time.ReadablePeriod) period16);
//        int int18 = period7.getDays();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(periodType10);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = iSOChronology0.set(readablePartial1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        int int10 = period3.getMinutes();
        try {
            org.joda.time.Period period12 = period3.withHours(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT-1H" + "'", str3.equals("PT-1H"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10L, (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, (-1), 1, (int) (byte) 0, (-35), (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) -1, (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (byte) 100, (int) (byte) -1, (int) (byte) 1, '4', (int) '#', 36000000, (int) (byte) 0, false, 36000000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(0L, (int) (byte) 1, (int) 'a', (int) (byte) -1, (-35));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(10L, "+10:00");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', (long) '#', periodType7);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType7, (java.lang.Object) false);
        org.joda.time.Period period11 = new org.joda.time.Period(1560627811576L, periodType7);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) boolean3, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.dayOfWeek();
        org.joda.time.DurationField durationField10 = iSOChronology2.months();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Period period1 = new org.joda.time.Period(100L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = iSOChronology0.set(readablePartial2, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.plusHours(36000000);
        org.joda.time.Period period9 = period7.plusMillis(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period8 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray11 = iSOChronology6.get((org.joda.time.ReadablePeriod) period8, (long) (short) 10, (long) 100);
        try {
            iSOChronology0.validate(readablePartial3, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        try {
            org.joda.time.Period period12 = period8.plusHours((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType5 = periodType4.withMinutesRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.millisOfDay();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) periodType2, periodType5, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType9 = periodType8.withMinutesRemoved();
        org.joda.time.Period period10 = period5.normalizedStandard(periodType9);
        try {
            org.joda.time.Period period12 = period10.withMillis((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) (byte) 100, (int) (short) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        try {
            org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.Period period1 = org.joda.time.Period.years(36000000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        org.joda.time.PeriodType periodType11 = period8.getPeriodType();
        java.lang.String str12 = period8.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "P0D" + "'", str12.equals("P0D"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField2, (java.lang.Object) 1000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.Period period9 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray12 = iSOChronology7.get((org.joda.time.ReadablePeriod) period9, (long) (short) 10, (long) 100);
        try {
            iSOChronology0.validate(readablePartial4, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period5 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray8 = iSOChronology3.get((org.joda.time.ReadablePeriod) period5, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.secondOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology3.weeks();
        org.joda.time.DurationField durationField11 = iSOChronology3.minutes();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType9 = periodType8.withMinutesRemoved();
        org.joda.time.Period period10 = period5.normalizedStandard(periodType9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = period10.isSupported(durationFieldType11);
        try {
            org.joda.time.Period period14 = period10.plusSeconds((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        try {
            long long7 = iSOChronology0.getDateTimeMillis((long) (short) 10, (int) (short) -1, (int) (short) 1, (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        long long5 = durationField2.subtract((-1L), (long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-126000001L) + "'", long5 == (-126000001L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT-1H", (int) 'a', (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for PT-1H must be in the range [52,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(1000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) 'a', 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.Period period5 = new org.joda.time.Period((-1120L), (long) 4, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Period period7 = period5.withHours(10);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        java.lang.String str9 = period7.toString();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Period period12 = period7.withFieldAdded(durationFieldType10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "P0D" + "'", str9.equals("P0D"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        int int7 = period6.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.indexOf(durationFieldType19);
        boolean boolean21 = iSOChronology2.equals((java.lang.Object) period16);
        try {
            long long27 = iSOChronology2.getDateTimeMillis(1560627811576L, 36000000, (int) (byte) 1, (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36000000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone1.getName((long) 10, locale4);
        java.lang.String str7 = dateTimeZone1.getName((long) ' ');
        long long11 = dateTimeZone1.convertLocalToUTC(100L, true, (long) (short) 10);
        boolean boolean13 = dateTimeZone1.isStandardOffset((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+10:00" + "'", str7.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-35999900L) + "'", long11 == (-35999900L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 100);
        java.lang.String str5 = dateTimeZone1.getShortName((long) 36000000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36000000 + "'", int3 == 36000000);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.eras();
        org.joda.time.Chronology chronology10 = iSOChronology2.withUTC();
        try {
            long long18 = iSOChronology2.getDateTimeMillis((int) ' ', (int) '#', (int) ' ', (int) '#', (int) (short) -1, (int) 'a', 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        long long7 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, 10L);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, 0, 36000000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "P0D");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period3.indexOf(durationFieldType10);
        org.joda.time.Period period12 = period3.negated();
        org.joda.time.Period period14 = period12.plusWeeks(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int int3 = period2.getSeconds();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((int) (short) 0, (int) (byte) 1, 1, (int) (short) 100, 1000, 8, (-1), (int) (byte) 0, periodType8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        int int9 = period7.getWeeks();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = period7.normalizedStandard(periodType10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        long long7 = iSOChronology1.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean9 = iSOChronology1.equals((java.lang.Object) periodType8);
        org.joda.time.DurationField durationField10 = iSOChronology1.centuries();
        org.joda.time.DurationField durationField11 = iSOChronology1.minutes();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.clockhourOfDay();
        long long18 = iSOChronology12.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean20 = iSOChronology12.equals((java.lang.Object) periodType19);
        org.joda.time.DurationField durationField21 = iSOChronology12.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField22 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField11, durationField21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1120L) + "'", long7 == (-1120L));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1120L) + "'", long18 == (-1120L));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType3, (java.lang.Object) false);
        org.joda.time.Period period7 = new org.joda.time.Period(1560627811576L, periodType3);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', (long) '#', periodType10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', (long) '#', periodType14);
        org.joda.time.Period period16 = period11.plus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period7.withFields((org.joda.time.ReadablePeriod) period16);
        try {
            org.joda.time.Period period19 = period17.withSeconds(36000000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        int int7 = period3.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone1.getName((long) 10, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+10:00" + "'", str5.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        int int5 = period4.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        int int4 = period3.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        int int9 = periodType7.size();
        int int10 = periodType7.size();
        org.joda.time.PeriodType periodType11 = periodType7.withDaysRemoved();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period5 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray8 = iSOChronology3.get((org.joda.time.ReadablePeriod) period5, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.secondOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology3.eras();
        org.joda.time.Chronology chronology11 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) -1, (org.joda.time.Chronology) iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        org.joda.time.Period period11 = period9.withSeconds((-1));
        org.joda.time.PeriodType periodType12 = period11.getPeriodType();
        int[] intArray13 = period11.getValues();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        long long7 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, 10L);
        java.util.TimeZone timeZone8 = dateTimeZone4.toTimeZone();
        boolean boolean9 = period0.equals((java.lang.Object) dateTimeZone4);
        java.lang.String str10 = dateTimeZone4.toString();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+10:00" + "'", str10.equals("+10:00"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 10000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36000000 + "'", int3 == 36000000);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.indexOf(durationFieldType19);
        boolean boolean21 = iSOChronology2.equals((java.lang.Object) period16);
        java.lang.Class<?> wildcardClass22 = period16.getClass();
        org.joda.time.Period period24 = period16.withYears(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(7, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType3, (java.lang.Object) false);
        org.joda.time.Period period7 = new org.joda.time.Period(1560627811576L, periodType3);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', (long) '#', periodType10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', (long) '#', periodType14);
        org.joda.time.Period period16 = period11.plus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period7.withFields((org.joda.time.ReadablePeriod) period16);
        try {
            org.joda.time.Period period19 = period17.plusSeconds((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT-1H", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT-1H/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 100);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "PT-1H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "P0D", "+10:00");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        int int10 = period3.getWeeks();
        int int11 = period3.getHours();
        org.joda.time.Period period13 = period3.withMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology2.seconds();
        java.lang.String str5 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 0, (long) 10000, chronology7);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMillis((int) (short) 100);
        java.lang.String str6 = period3.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT-1H0.097S" + "'", str6.equals("PT-1H0.097S"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) -1, (long) (short) -1, chronology2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        int int6 = period5.getDays();
        org.joda.time.Duration duration7 = period5.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(36000000, '4', (int) (short) -1, 36000000, (int) (byte) -1, false, (int) (short) 1);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("YearMonthDayTime", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = iSOChronology1.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.yearOfEra();
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.DurationField durationField9 = iSOChronology0.centuries();
        long long12 = durationField9.subtract((-35999900L), (long) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-35999900L) + "'", long12 == (-35999900L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        int int3 = dateTimeZone1.getOffsetFromLocal(1260000000000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36000000 + "'", int3 == 36000000);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', (long) '#', periodType7);
        org.joda.time.Period period9 = period4.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationTo(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration11);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration11);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        long long10 = dateTimeZone1.convertLocalToUTC(100L, false, 1560627811576L);
        java.lang.String str11 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-35999900L) + "'", long10 == (-35999900L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+10:00" + "'", str11.equals("+10:00"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period8 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray11 = iSOChronology6.get((org.joda.time.ReadablePeriod) period8, (long) (short) 10, (long) 100);
        try {
            iSOChronology0.validate(readablePartial3, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        try {
            org.joda.time.Period period6 = period1.withPeriodType(periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-35), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3500L) + "'", long2 == (-3500L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((int) (byte) 0, 0, 10, 0, 0, (int) (byte) 1, 100, (int) (byte) -1, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.Period period13 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray16 = iSOChronology11.get((org.joda.time.ReadablePeriod) period13, (long) (short) 10, (long) 100);
        org.joda.time.Period period18 = period13.withMinutes((int) (byte) 10);
        boolean boolean19 = cachedDateTimeZone8.equals((java.lang.Object) period18);
        boolean boolean21 = cachedDateTimeZone8.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.weekOfWeekyear();
        org.joda.time.DurationField durationField5 = iSOChronology3.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(36000000, '4', (int) (short) -1, 36000000, (int) (byte) -1, false, (int) (short) 1);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (byte) -1, (java.lang.Object) 10000);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100, number2, (java.lang.Number) (-3500L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000405d + "'", double1 == 2440587.500000405d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.DurationField durationField9 = iSOChronology0.centuries();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray13 = iSOChronology0.get(readablePeriod10, (long) 11, (-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) (short) 0);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period9 = new org.joda.time.Period((long) '#', (long) '#', periodType8);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period13 = new org.joda.time.Period((long) '#', (long) '#', periodType12);
        org.joda.time.Period period14 = period9.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.days();
        org.joda.time.Period period16 = period14.withPeriodType(periodType15);
        org.joda.time.Period period17 = period5.withPeriodType(periodType15);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+10:00" + "'", str3.equals("+10:00"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        int int11 = period10.getYears();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.Period period4 = new org.joda.time.Period(0, 1, 4, (int) (short) 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(36000000, '4', (int) (short) -1, 36000000, (int) (byte) -1, false, (int) (short) 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(0, 'a', (int) 'a', 36000000, (-35), true, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.minusHours((int) (byte) 10);
        int int9 = period5.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        java.util.TimeZone timeZone8 = dateTimeZone5.toTimeZone();
        java.lang.String str9 = dateTimeZone5.toString();
        java.lang.String str10 = dateTimeZone5.getID();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+10:00" + "'", str6.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+10:00" + "'", str9.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+10:00" + "'", str10.equals("+10:00"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("P0D");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'P0D' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "+10:00");
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType5);
        org.joda.time.PeriodType periodType7 = periodType5.withHoursRemoved();
        org.joda.time.PeriodType periodType8 = periodType5.withMonthsRemoved();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 100, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.Seconds seconds11 = period8.toStandardSeconds();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(seconds11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', (long) '#', periodType7);
        org.joda.time.Period period9 = period4.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationTo(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period9.toDurationFrom(readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period21 = new org.joda.time.Period((long) '#', (long) '#', periodType20);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType20, (java.lang.Object) false);
        org.joda.time.Period period24 = new org.joda.time.Period(1560627811576L, periodType20);
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType20);
        org.joda.time.PeriodType periodType26 = periodType20.withMillisRemoved();
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant14, periodType26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant28);
        org.joda.time.PeriodType periodType30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13, periodType30);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(periodType26);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        try {
            long long21 = preciseDurationField18.add((-35999900L), (-210866760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210866760000000 * -210866760000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 1);
        org.joda.time.Period period3 = period1.plusDays(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "YearMonthDayTime");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) (short) 0);
        try {
            int int7 = period5.getValue((-35));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.ReadablePartial readablePartial13 = null;
        try {
            long long15 = iSOChronology2.set(readablePartial13, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period8 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray11 = iSOChronology6.get((org.joda.time.ReadablePeriod) period8, (long) (short) 10, (long) 100);
        org.joda.time.Period period13 = period8.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType15 = period8.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType15, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone19.getName((long) 10, locale22);
        java.lang.String str25 = dateTimeZone19.getName((long) ' ');
        boolean boolean26 = scaledDurationField17.equals((java.lang.Object) ' ');
        long long29 = scaledDurationField17.getValueAsLong(0L, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = iSOChronology30.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField33 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) scaledDurationField17, durationField32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+10:00" + "'", str23.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+10:00" + "'", str25.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        int int11 = periodType9.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 1, "GregorianChronology[UTC]");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (GregorianChronology[UTC])" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (GregorianChronology[UTC])"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period6 = period4.withMillis((int) 'a');
        org.joda.time.Period period8 = period6.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period6.indexOf(durationFieldType9);
        org.joda.time.Period period12 = period6.plusMillis(1);
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePeriod) period12, (long) '#', (long) (short) 1);
        org.joda.time.chrono.LenientChronology lenientChronology16 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        try {
            long long21 = iSOChronology0.getDateTimeMillis((int) (byte) 1, 0, 8, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(lenientChronology16);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "P0D");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long11 = iSOChronology2.add(0L, (long) (byte) 0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial13 = null;
        try {
            long long15 = iSOChronology2.set(readablePartial13, (-3500L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Period period1 = org.joda.time.Period.months((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant3, readableDuration4, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withHoursRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withDaysRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, periodType8);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        int int9 = period7.getWeeks();
        java.lang.String str10 = period7.toString();
        org.joda.time.Duration duration11 = period7.toStandardDuration();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P0D" + "'", str10.equals("P0D"));
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) -1, "");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        java.lang.Throwable[] throwableArray4 = illegalInstantException2.getSuppressed();
        java.lang.String str5 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 ()" + "'", str5.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 ()"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period12 = new org.joda.time.Period((long) '#', (long) '#', periodType11);
        org.joda.time.Period period14 = period12.withDays(1);
        org.joda.time.Period period15 = period8.plus((org.joda.time.ReadablePeriod) period12);
        try {
            org.joda.time.Period period17 = period15.withHours((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, (-360000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36000000000L) + "'", long2 == (-36000000000L));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 0, (-10L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        try {
            long long9 = zonedChronology3.getDateTimeMillis((long) 7, 1000, (int) (byte) 100, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT-1H", (int) ' ', (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for PT-1H must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.plusMillis(1);
        org.joda.time.Days days10 = period9.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(days10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField7 = iSOChronology2.millis();
        org.joda.time.DurationField durationField8 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField9 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long19 = scaledDurationField16.getMillis((int) (byte) -1, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-35000L) + "'", long19 == (-35000L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) -1, (int) 'a', (int) (byte) 100, 4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 0, (java.lang.Number) 10.0d, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(10285, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10285 + "'", int2 == 10285);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', (long) '#', periodType7);
        org.joda.time.Period period9 = period4.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.days();
        org.joda.time.Period period11 = period9.withPeriodType(periodType10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.clockhourOfDay();
        org.joda.time.Period period16 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period18 = period16.withMillis((int) 'a');
        org.joda.time.Period period20 = period18.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period18.indexOf(durationFieldType21);
        org.joda.time.Period period24 = period18.plusMillis(1);
        int[] intArray27 = iSOChronology12.get((org.joda.time.ReadablePeriod) period24, (long) '#', (long) (short) 1);
        org.joda.time.chrono.LenientChronology lenientChronology28 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        try {
            org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) periodType0, periodType10, (org.joda.time.Chronology) iSOChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(lenientChronology28);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DurationField durationField8 = iSOChronology2.centuries();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) durationField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-11) + "'", int1 == (-11));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 1, true);
        org.joda.time.Chronology chronology11 = zonedChronology3.withZone(dateTimeZone6);
        long long14 = dateTimeZone6.adjustOffset((long) 45, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-359999999L) + "'", long10 == (-359999999L));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 45L + "'", long14 == 45L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = dateTimeZone18.getName((long) 10, locale21);
        java.lang.String str24 = dateTimeZone18.getName((long) ' ');
        boolean boolean25 = scaledDurationField16.equals((java.lang.Object) ' ');
        long long28 = scaledDurationField16.getValueAsLong(0L, 0L);
        try {
            int int31 = scaledDurationField16.getValue((-210866760000000L), (-210866760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210866760000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+10:00" + "'", str22.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+10:00" + "'", str24.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, 1260000000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1259999999990L) + "'", long2 == (-1259999999990L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.era();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) (short) 0);
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) -1, (java.lang.Number) (byte) 100, (java.lang.Number) 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        java.lang.String str19 = scaledDurationField16.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DurationField[years]" + "'", str19.equals("DurationField[years]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GregorianChronology[UTC]", 8, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for GregorianChronology[UTC] must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long11 = iSOChronology2.add(0L, (long) (byte) 0, (int) (short) 1);
        try {
            long long19 = iSOChronology2.getDateTimeMillis(0, (int) (short) 1, 0, (int) (short) 10, (int) (byte) -1, 11, 45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-35999900L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-35999900) + "'", int1 == (-35999900));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = offsetDateTimeField9.getAsText(readablePartial10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 100, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.DurationFieldType[] durationFieldTypeArray9 = period3.getFieldTypes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-1L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) -1, (-35999900L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35999901L) + "'", long2 == (-35999901L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone7.getName((long) 10, locale10);
        boolean boolean12 = gregorianChronology0.equals((java.lang.Object) str11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+10:00" + "'", str11.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        long long5 = durationField2.subtract((-1L), (long) (-35));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3023999999L + "'", long5 == 3023999999L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        org.joda.time.Period period14 = period12.minusMillis(0);
        try {
            org.joda.time.Period period16 = period12.withMillis((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (byte) 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        boolean boolean11 = offsetDateTimeField9.isLeap((long) 4);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period17 = new org.joda.time.Period((long) '#', (long) '#', periodType16);
        org.joda.time.Period period19 = period17.plusMonths((int) (short) 0);
        int[] intArray20 = period19.getValues();
        try {
            int[] intArray22 = offsetDateTimeField9.addWrapPartial(readablePartial12, (int) ' ', intArray20, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.clockhourOfDay();
        long long8 = iSOChronology2.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean10 = iSOChronology2.equals((java.lang.Object) periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField14 = gregorianChronology12.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period19 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray22 = iSOChronology17.get((org.joda.time.ReadablePeriod) period19, (long) (short) 10, (long) 100);
        org.joda.time.Period period24 = period19.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType26 = period19.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField28 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType26, (int) '#');
        boolean boolean29 = periodType9.isSupported(durationFieldType26);
        int int30 = periodType1.indexOf(durationFieldType26);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1120L) + "'", long8 == (-1120L));
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "+10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 10, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 ()");
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) (byte) 100, 1000, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        org.joda.time.Duration duration11 = period10.toStandardDuration();
        try {
            org.joda.time.Period period13 = period10.plusWeeks((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "PT-1H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "hi!", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 100);
        long long6 = dateTimeZone1.convertLocalToUTC((long) 7, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36000000 + "'", int3 == 36000000);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-35999993L) + "'", long6 == (-35999993L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        int int10 = period3.getWeeks();
        int int11 = period3.getHours();
        int int12 = period3.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology13.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.Period period20 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray23 = iSOChronology18.get((org.joda.time.ReadablePeriod) period20, (long) (short) 10, (long) 100);
        org.joda.time.Period period25 = period20.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType27 = period20.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField15, durationFieldType27, (int) '#');
        boolean boolean30 = period3.isSupported(durationFieldType27);
        org.joda.time.Period period32 = period3.minusHours((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        java.lang.String str3 = periodType1.getName();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "YearDayTime" + "'", str3.equals("YearDayTime"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.Period period6 = new org.joda.time.Period(2440588L, (-210858120000000L), (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumShortTextLength(locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField9.getWrappedField();
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.clockhourOfDay();
        org.joda.time.Period period19 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period21 = period19.withMillis((int) 'a');
        org.joda.time.Period period23 = period21.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        int int25 = period21.indexOf(durationFieldType24);
        org.joda.time.Period period27 = period21.plusMillis(1);
        int[] intArray30 = iSOChronology15.get((org.joda.time.ReadablePeriod) period27, (long) '#', (long) (short) 1);
        java.util.Locale locale32 = null;
        try {
            int[] intArray33 = offsetDateTimeField9.set(readablePartial13, (int) 'a', intArray30, "DateTimeField[dayOfYear]", locale32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[dayOfYear]\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.DurationField durationField9 = iSOChronology0.centuries();
        org.joda.time.DurationField durationField10 = iSOChronology0.minutes();
        long long13 = durationField10.subtract((-360000000L), 0L);
        long long16 = durationField10.subtract((long) 8, (long) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-360000000L) + "'", long13 == (-360000000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-59992L) + "'", long16 == (-59992L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("P0D", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("PT-1H0.097S", 36000000, (int) (byte) 1, (int) (byte) -1, 'a', 8, (int) (byte) 0, (int) (short) 0, true, 1000);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.era();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.clockhourOfDay();
        org.joda.time.Period period10 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period12 = period10.withMillis((int) 'a');
        org.joda.time.Period period14 = period12.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = period12.indexOf(durationFieldType15);
        org.joda.time.Period period18 = period12.plusMillis(1);
        int[] intArray21 = iSOChronology6.get((org.joda.time.ReadablePeriod) period18, (long) '#', (long) (short) 1);
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology6);
        try {
            org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) iSOChronology1, (org.joda.time.Chronology) lenientChronology22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(lenientChronology22);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "YearMonthDayTime");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.Period period13 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray16 = iSOChronology11.get((org.joda.time.ReadablePeriod) period13, (long) (short) 10, (long) 100);
        org.joda.time.Period period18 = period13.withMinutes((int) (byte) 10);
        boolean boolean19 = cachedDateTimeZone8.equals((java.lang.Object) period18);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone8.getUncachedZone();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider21 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale22 = null;
        java.lang.String str25 = defaultNameProvider21.getShortName(locale22, "", "PT-1H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider21);
        java.util.Locale locale27 = null;
        java.lang.String str30 = defaultNameProvider21.getName(locale27, "hi!", "hi!");
        java.util.Locale locale31 = null;
        java.lang.String str34 = defaultNameProvider21.getShortName(locale31, "", "PT-1H0.097S");
        boolean boolean35 = cachedDateTimeZone8.equals((java.lang.Object) locale31);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period39 = new org.joda.time.Period((long) '#', (long) '#', periodType38);
        org.joda.time.Period period41 = period39.plusMonths((int) (short) 0);
        boolean boolean42 = cachedDateTimeZone8.equals((java.lang.Object) (short) 0);
        int int44 = cachedDateTimeZone8.getStandardOffset((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 36000000 + "'", int44 == 36000000);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "DurationField[years]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-35));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 10, 100, 0, '#', 0, (int) (byte) 1, (int) '#', true, (int) 'a');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (byte) -1, (int) (short) -1, (int) (byte) 0, 'a', 10, 1, 11, false, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period8 = period3.negated();
        int int9 = period3.getMonths();
        org.joda.time.Period period11 = period3.withMinutes((int) '4');
        org.joda.time.Period period13 = org.joda.time.Period.hours((int) (byte) 0);
        org.joda.time.Period period15 = period13.plusWeeks((int) (short) 0);
        int int16 = period15.getDays();
        org.joda.time.Period period18 = period15.plusHours((int) ' ');
        org.joda.time.Period period19 = period3.withFields((org.joda.time.ReadablePeriod) period15);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.plusHours(36000000);
        int int8 = period5.getMinutes();
        org.joda.time.Period period9 = period5.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.clockhourOfDay();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, (int) '4', (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0f, (java.lang.Number) 10L, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "32");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = iSOChronology0.set(readablePartial4, (-62142768000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-35999900L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3321258120000000L) + "'", long1 == (-3321258120000000L));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        int int11 = period8.getSeconds();
        org.joda.time.Period period12 = period8.normalizedStandard();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 1, true);
        org.joda.time.Chronology chronology11 = zonedChronology3.withZone(dateTimeZone6);
        org.joda.time.Period period13 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period15 = period13.withMillis((int) 'a');
        org.joda.time.Period period17 = period15.minusMinutes((int) (byte) 1);
        org.joda.time.Period period19 = period15.minusMinutes((int) (short) 10);
        org.joda.time.Period period21 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period23 = period21.withMillis((int) 'a');
        org.joda.time.Period period25 = period23.minusMinutes((int) (byte) 1);
        org.joda.time.Period period27 = period25.plusHours(36000000);
        org.joda.time.Period period28 = period19.minus((org.joda.time.ReadablePeriod) period25);
        boolean boolean29 = zonedChronology3.equals((java.lang.Object) period25);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-359999999L) + "'", long10 == (-359999999L));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        java.lang.String str9 = period7.toString();
        try {
            org.joda.time.Period period11 = period7.plusMillis((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "P0D" + "'", str9.equals("P0D"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withHoursRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1000, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        int int10 = period3.getWeeks();
        int int11 = period3.getHours();
        int int12 = period3.getYears();
        org.joda.time.Period period14 = period3.withDays(11);
        org.joda.time.Period period16 = period3.plusDays((int) ' ');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.field.FieldUtils.verifyValueBounds("45", 7, (int) (byte) -1, (int) 'a');
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        long long16 = offsetDateTimeField9.add(0L, (long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-86400000L) + "'", long16 == (-86400000L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long20 = preciseDurationField18.getMillis(0L);
        long long23 = preciseDurationField18.getValueAsLong((-36000000000L), 1L);
        try {
            long long25 = preciseDurationField18.getMillis(3500000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 3500000 * -210866760000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfYear();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((int) (short) 10, (-35), (int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) '#', (long) '#', periodType5);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType5, (java.lang.Object) false);
        org.joda.time.Period period9 = new org.joda.time.Period(1560627811576L, periodType5);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType5);
        org.joda.time.PeriodType periodType11 = periodType5.withMonthsRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = iSOChronology0.set(readablePartial3, (-59992L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        try {
            long long9 = zonedChronology3.getDateTimeMillis((-350035L), (-1), (int) (byte) 10, 11, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, (int) ' ', 0, (int) (byte) -1, (int) (short) 100, 0, (int) '#', (int) (byte) 0);
        org.joda.time.Period period10 = period8.withWeeks((-1));
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        int int10 = period3.getMinutes();
        org.joda.time.Period period12 = period3.minusWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.joda.time.Period period5 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period7 = period5.withMillis((int) 'a');
        org.joda.time.Period period9 = period7.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period7.indexOf(durationFieldType10);
        org.joda.time.Period period13 = period7.withMonths((int) (short) 100);
        int int14 = period7.getWeeks();
        int int15 = period7.getHours();
        int int16 = period7.getYears();
        boolean boolean17 = iSOChronology0.equals((java.lang.Object) int16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gregorianChronology10.seconds();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.Period period17 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray20 = iSOChronology15.get((org.joda.time.ReadablePeriod) period17, (long) (short) 10, (long) 100);
        org.joda.time.Period period22 = period17.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType24 = period17.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType24, (int) '#');
        boolean boolean27 = periodType7.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType24, 0L);
        try {
            int int32 = preciseDurationField29.getDifference((long) 45, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.clockhourOfDay();
        org.joda.time.Period period6 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.dayOfMonth();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 35, periodType1, (org.joda.time.Chronology) iSOChronology3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField9.getMaximumShortTextLength(locale13);
        int int17 = offsetDateTimeField9.getDifference(1000L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationFrom(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) '#', (long) '#', periodType19);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType19, (java.lang.Object) false);
        org.joda.time.Period period23 = new org.joda.time.Period(1560627811576L, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType19);
        org.joda.time.PeriodType periodType25 = periodType19.withMillisRemoved();
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType25);
        org.joda.time.Period period28 = period26.plusWeeks((int) ' ');
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        int int10 = period3.getMinutes();
        org.joda.time.Period period12 = period3.multipliedBy(4);
        try {
            org.joda.time.Period period14 = period3.minusMinutes(369);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-126000001L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-126000001) + "'", int1 == (-126000001));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationFrom(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period20 = new org.joda.time.Period((long) '#', (long) '#', periodType19);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType19, (java.lang.Object) false);
        org.joda.time.Period period23 = new org.joda.time.Period(1560627811576L, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType19);
        org.joda.time.PeriodType periodType25 = periodType19.withMillisRemoved();
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant27);
        org.joda.time.Period period30 = period28.withMinutes(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long20 = preciseDurationField18.getMillis(1000);
        long long23 = preciseDurationField18.getMillis(0, (-3321258120000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866760000000000L) + "'", long20 == (-210866760000000000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("YearMonthDayTime", (-35), 0, (-126000001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for YearMonthDayTime must be in the range [0,-126000001]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) '4', 36000000, 370);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumShortTextLength(locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField9.getWrappedField();
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1, 64000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64000 + "'", int2 == 64000);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(36000000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-36000000) + "'", int1 == (-36000000));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.seconds();
        java.lang.String str4 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 0, chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long20 = preciseDurationField18.getMillis(0L);
        long long23 = preciseDurationField18.add((-25L), (long) (short) 10);
        try {
            long long26 = preciseDurationField18.getMillis((long) 36000000, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 36000000 * -210866760000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2108667600000025L) + "'", long23 == (-2108667600000025L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText(0, locale15);
        long long18 = offsetDateTimeField9.roundCeiling((long) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText(0, locale15);
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField9.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.toString();
        int int11 = offsetDateTimeField9.getMaximumValue();
        int int13 = offsetDateTimeField9.get((-35999630L));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField9, (int) (short) 1, 35, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfYear must be in the range [35,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfYear]" + "'", str10.equals("DateTimeField[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 370 + "'", int11 == 370);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 369 + "'", int13 == 369);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType2, (java.lang.Object) false);
        org.joda.time.PeriodType periodType6 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withMinutesRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMillisRemoved();
        java.lang.String str9 = periodType8.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PeriodType[YearWeekDayNoYears]" + "'", str9.equals("PeriodType[YearWeekDayNoYears]"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        int int13 = offsetDateTimeField9.getMaximumValue(210866760000001L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.Period period20 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period22 = period20.withMillis((int) 'a');
        org.joda.time.Period period24 = period22.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        int int26 = period22.indexOf(durationFieldType25);
        org.joda.time.Period period28 = period22.plusMillis(1);
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = period22.indexOf(durationFieldType29);
        int[] intArray33 = iSOChronology16.get((org.joda.time.ReadablePeriod) period22, (long) (-1), 1L);
        try {
            int[] intArray35 = offsetDateTimeField9.add(readablePartial14, (int) ' ', intArray33, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 370 + "'", int13 == 370);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = period10.isSupported(durationFieldType11);
        org.joda.time.Period period14 = period10.minusMonths(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        long long7 = iSOChronology1.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean9 = iSOChronology1.equals((java.lang.Object) periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField13 = gregorianChronology11.seconds();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period18 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray21 = iSOChronology16.get((org.joda.time.ReadablePeriod) period18, (long) (short) 10, (long) 100);
        org.joda.time.Period period23 = period18.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period18.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField27 = new org.joda.time.field.ScaledDurationField(durationField13, durationFieldType25, (int) '#');
        boolean boolean28 = periodType8.isSupported(durationFieldType25);
        org.joda.time.field.PreciseDurationField preciseDurationField30 = new org.joda.time.field.PreciseDurationField(durationFieldType25, 0L);
        org.joda.time.DurationFieldType[] durationFieldTypeArray31 = new org.joda.time.DurationFieldType[] { durationFieldType25 };
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.forFields(durationFieldTypeArray31);
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) 1000, periodType32, chronology33);
        org.joda.time.PeriodType periodType35 = periodType32.withYearsRemoved();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1120L) + "'", long7 == (-1120L));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(durationFieldTypeArray31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType35);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withSeconds((int) (short) 1);
        int int9 = period5.size();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period13 = new org.joda.time.Period((long) '#', (long) '#', periodType12);
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType12, (java.lang.Object) false);
        org.joda.time.PeriodType periodType16 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withMinutesRemoved();
        try {
            org.joda.time.Period period18 = period5.withPeriodType(periodType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology2.minuteOfHour();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField15 = iSOChronology2.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        long long74 = scaledDurationField16.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType75 = org.joda.time.PeriodType.standard();
        boolean boolean76 = scaledDurationField16.equals((java.lang.Object) periodType75);
        int int78 = scaledDurationField16.getValue((-3500L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 350100L + "'", long74 == 350100L);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period3.minusMinutes((int) (short) 10);
        org.joda.time.Period period9 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period11 = period9.withMillis((int) 'a');
        org.joda.time.Period period13 = period11.minusMinutes((int) (byte) 1);
        org.joda.time.Period period15 = period13.plusHours(36000000);
        org.joda.time.Period period16 = period7.minus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType18 = periodType17.withDaysRemoved();
        try {
            org.joda.time.Period period19 = period13.withPeriodType(periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        int int10 = period3.getWeeks();
        int int11 = period3.getHours();
        int int12 = period3.getYears();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.Period period15 = period3.withFieldAdded(durationFieldType13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        org.joda.time.Period period11 = period8.toPeriod();
        int int12 = period8.getMonths();
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.Period period20 = period18.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Duration duration22 = period20.toDurationTo(readableInstant21);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration22, readableInstant23, periodType24);
        org.joda.time.Period period27 = period25.minusMillis(0);
        org.joda.time.Period period28 = period8.withFields((org.joda.time.ReadablePeriod) period25);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(duration22);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getValueAsLong((long) (-35));
        long long21 = scaledDurationField16.add((-10L), 1L);
        int int22 = scaledDurationField16.getScalar();
        long long25 = scaledDurationField16.add(0L, 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 34990L + "'", long21 == 34990L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 175000L + "'", long25 == 175000L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.clockhourOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField7 = iSOChronology2.millis();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.clockhourOfDay();
        org.joda.time.DurationField durationField11 = iSOChronology8.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField12 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) '#', (long) '#', periodType5);
        long long9 = iSOChronology0.add((org.joda.time.ReadablePeriod) period6, (long) 45, 370);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.millisOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.dayOfWeek();
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.indexOf(durationFieldType19);
        org.joda.time.Period period22 = period16.plusMillis(1);
        org.joda.time.DurationFieldType durationFieldType23 = null;
        int int24 = period16.indexOf(durationFieldType23);
        int[] intArray27 = iSOChronology10.get((org.joda.time.ReadablePeriod) period16, (long) (-1), 1L);
        try {
            org.joda.time.Period period28 = period6.minus((org.joda.time.ReadablePeriod) period16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 45L + "'", long9 == 45L);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "PT-1H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "hi!", "hi!");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "PT-1H0.097S", "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 ()");
        java.util.Locale locale14 = null;
        java.lang.String str17 = defaultNameProvider0.getShortName(locale14, "DateTimeField[dayOfYear]", "LenientChronology[ISOChronology[UTC]]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DurationField durationField7 = iSOChronology0.eras();
        try {
            long long10 = durationField7.subtract(0L, (-62142768000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant12, readableDuration13, periodType15);
        org.joda.time.PeriodType periodType17 = periodType15.withHoursRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.Period period23 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray26 = iSOChronology21.get((org.joda.time.ReadablePeriod) period23, (long) (short) 10, (long) 100);
        org.joda.time.Period period28 = period23.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType30 = period23.getFieldType(0);
        int int31 = period18.get(durationFieldType30);
        int int32 = period3.get(durationFieldType30);
        org.joda.time.Period period34 = period3.withMonths(64000);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        int int74 = scaledDurationField16.getDifference((long) (short) 0, (-360000000L));
        long long77 = scaledDurationField16.getValueAsLong(0L, (long) (-35999900));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10285 + "'", int74 == 10285);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        int int13 = offsetDateTimeField9.getMaximumValue(210866760000001L);
        int int14 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 370 + "'", int13 == 370);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant12, periodType13);
        org.joda.time.Seconds seconds15 = period14.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(seconds15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 1, true);
        org.joda.time.Chronology chronology11 = zonedChronology3.withZone(dateTimeZone6);
        long long15 = zonedChronology3.add((long) 1, (-350035L), 10000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-359999999L) + "'", long10 == (-359999999L));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3500349999L) + "'", long15 == (-3500349999L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) -1, 0, (int) (byte) 1, 100);
        int int5 = period4.getWeeks();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText(0, locale15);
        java.lang.String str17 = offsetDateTimeField9.getName();
        java.util.Locale locale20 = null;
        try {
            long long21 = offsetDateTimeField9.set((long) (-35), "YearDayTime", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"YearDayTime\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dayOfYear" + "'", str17.equals("dayOfYear"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        boolean boolean11 = offsetDateTimeField9.isLeap((long) 4);
        long long13 = offsetDateTimeField9.roundHalfFloor((-210858120000000L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((long) 4, locale15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-210858163200000L) + "'", long13 == (-210858163200000L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5" + "'", str16.equals("5"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        org.joda.time.PeriodType periodType11 = period8.getPeriodType();
        org.joda.time.Period period13 = period8.plusWeeks(4);
        org.joda.time.Weeks weeks14 = period13.toStandardWeeks();
        org.joda.time.Period period16 = period13.withWeeks((int) (byte) 10);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LenientChronology[ISOChronology[UTC]]", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        int int74 = scaledDurationField16.getDifference((long) (short) 0, (-360000000L));
        int int77 = scaledDurationField16.getDifference((long) 'a', 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10285 + "'", int74 == 10285);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Weeks weeks5 = period4.toStandardWeeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(weeks5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LenientChronology[ISOChronology[UTC]]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str3.equals("LenientChronology[ISOChronology[UTC]]"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 1);
        org.joda.time.Period period3 = period1.withMinutes((-35));
        org.joda.time.Minutes minutes4 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.eras();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone12);
        try {
            long long21 = zonedChronology13.getDateTimeMillis((-36000000), (int) (short) 100, 1, 3, 8, (int) (short) 1, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC(0L, true, (long) (short) 10);
        long long8 = dateTimeZone1.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-360000000L) + "'", long6 == (-360000000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 360000000L + "'", long8 == 360000000L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType5);
        org.joda.time.PeriodType periodType7 = periodType5.withHoursRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period12 = new org.joda.time.Period((long) '#', (long) '#', periodType11);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType11, (java.lang.Object) false);
        org.joda.time.PeriodType periodType15 = periodType11.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withMinutesRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withMillisRemoved();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType19 = periodType18.withHoursRemoved();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period26 = new org.joda.time.Period((long) '#', (long) '#', periodType25);
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType25, (java.lang.Object) false);
        org.joda.time.Period period29 = new org.joda.time.Period(1560627811576L, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant20, readableInstant21, periodType25);
        int int31 = period30.getHours();
        org.joda.time.Period period33 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period35 = period33.withMillis((int) 'a');
        org.joda.time.Period period37 = period35.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType38 = null;
        int int39 = period35.indexOf(durationFieldType38);
        org.joda.time.Period period41 = period35.withMonths((int) (short) 100);
        int int42 = period35.getWeeks();
        int int43 = period35.getHours();
        int int44 = period35.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int46 = gregorianChronology45.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField47 = gregorianChronology45.seconds();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.Period period52 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray55 = iSOChronology50.get((org.joda.time.ReadablePeriod) period52, (long) (short) 10, (long) 100);
        org.joda.time.Period period57 = period52.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType59 = period52.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField61 = new org.joda.time.field.ScaledDurationField(durationField47, durationFieldType59, (int) '#');
        boolean boolean62 = period35.isSupported(durationFieldType59);
        org.joda.time.Period period64 = period30.withField(durationFieldType59, 11);
        boolean boolean65 = periodType19.isSupported(durationFieldType59);
        int int66 = periodType16.indexOf(durationFieldType59);
        int int67 = periodType7.indexOf(durationFieldType59);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(durationFieldType59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, 8, 3, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, (int) '4', 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        java.lang.String str1 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[Years]" + "'", str1.equals("PeriodType[Years]"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LenientChronology[ISOChronology[UTC]]", "");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Period period4 = new org.joda.time.Period(35, (int) (byte) 10, 1000, 64000);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long20 = preciseDurationField18.getMillis(0L);
        long long23 = preciseDurationField18.getValueAsLong((-36000000000L), 1L);
        try {
            long long26 = preciseDurationField18.add(210866760000001L, (-2108667600000025L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -2108667600000025 * -210866760000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.DurationField durationField9 = iSOChronology0.centuries();
        org.joda.time.DurationField durationField10 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.year();
        org.joda.time.DurationField durationField12 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(370);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 370");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 0L, periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 0, 369, (int) '#', (int) (short) 10, 0, (int) (byte) 1, 5, (int) '4', periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        int int2 = period1.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.Period period13 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray16 = iSOChronology11.get((org.joda.time.ReadablePeriod) period13, (long) (short) 10, (long) 100);
        org.joda.time.Period period18 = period13.withMinutes((int) (byte) 10);
        boolean boolean19 = cachedDateTimeZone8.equals((java.lang.Object) period18);
        int int21 = cachedDateTimeZone8.getOffsetFromLocal((-350035L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 36000000 + "'", int21 == 36000000);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType9 = periodType8.withMinutesRemoved();
        org.joda.time.Period period10 = period5.normalizedStandard(periodType9);
        org.joda.time.Minutes minutes11 = period5.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(minutes11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, 64000, (int) (byte) 10, 370);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 104 + "'", int4 == 104);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period3.minusYears((int) (byte) 1);
        try {
            org.joda.time.Period period12 = period10.plusSeconds(100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 1, true);
        org.joda.time.Chronology chronology11 = zonedChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-359999999L) + "'", long10 == (-359999999L));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        java.lang.String str13 = periodType11.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PeriodType[Weeks]" + "'", str13.equals("PeriodType[Weeks]"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PT-1H");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.plusMillis(1);
        org.joda.time.Period period11 = period9.withMonths((int) (byte) 10);
        org.joda.time.Period period13 = period9.withMinutes(36000000);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        long long15 = offsetDateTimeField9.roundFloor(0L);
        java.util.Locale locale18 = null;
        try {
            long long19 = offsetDateTimeField9.set((long) 10, "", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType3, (java.lang.Object) false);
        org.joda.time.Period period7 = new org.joda.time.Period(1560627811576L, periodType3);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', (long) '#', periodType10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', (long) '#', periodType14);
        org.joda.time.Period period16 = period11.plus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period7.withFields((org.joda.time.ReadablePeriod) period16);
        int int18 = period7.getHours();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getValueAsLong((long) (-35));
        long long21 = scaledDurationField16.add((-10L), 1L);
        int int22 = scaledDurationField16.getScalar();
        long long25 = scaledDurationField16.getDifferenceAsLong(0L, (long) 8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 34990L + "'", long21 == 34990L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, (int) (short) 1, 10285, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        long long74 = scaledDurationField16.subtract((long) (-35), (int) (short) 10);
        long long77 = scaledDurationField16.getDifferenceAsLong((-3500L), 45L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-350035L) + "'", long74 == (-350035L));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone8);
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        long long16 = dateTimeZone12.convertLocalToUTC((long) (byte) 1, true);
        org.joda.time.Chronology chronology17 = zonedChronology9.withZone(dateTimeZone12);
        org.joda.time.Period period18 = new org.joda.time.Period((long) 3, periodType4, chronology17);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-359999999L) + "'", long16 == (-359999999L));
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology2.getZone();
        org.joda.time.PeriodType periodType9 = null;
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) iSOChronology2, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        int int13 = offsetDateTimeField9.getMaximumValue(210866760000001L);
        int int14 = offsetDateTimeField9.getMaximumValue();
        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 370 + "'", int13 == 370);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 370 + "'", int14 == 370);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', (long) '#', periodType7);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType7, (java.lang.Object) false);
        org.joda.time.Period period11 = new org.joda.time.Period(1560627811576L, periodType7);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType7);
        org.joda.time.PeriodType periodType13 = periodType7.withMonthsRemoved();
        try {
            org.joda.time.Period period14 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-35));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 10, 100, 0, '#', 0, (int) (byte) 1, (int) '#', true, (int) 'a');
        java.io.OutputStream outputStream15 = null;
        try {
            dateTimeZoneBuilder13.writeTo("YearMonthDayTime", outputStream15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        long long7 = iSOChronology1.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean9 = iSOChronology1.equals((java.lang.Object) periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField13 = gregorianChronology11.seconds();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period18 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray21 = iSOChronology16.get((org.joda.time.ReadablePeriod) period18, (long) (short) 10, (long) 100);
        org.joda.time.Period period23 = period18.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType25 = period18.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField27 = new org.joda.time.field.ScaledDurationField(durationField13, durationFieldType25, (int) '#');
        boolean boolean28 = periodType8.isSupported(durationFieldType25);
        org.joda.time.field.PreciseDurationField preciseDurationField30 = new org.joda.time.field.PreciseDurationField(durationFieldType25, 0L);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField31 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1120L) + "'", long7 == (-1120L));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period7 = period5.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant12, periodType13);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) 0, (long) 36000000, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField10 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfMinute();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (-11), (-35), 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((-36000000), 35, 64000, 45, (int) '4', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("P0D", 1);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("PeriodType[Weeks]", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(10, 0, 369, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = mutablePeriod4.isSupported(durationFieldType5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.indexOf(durationFieldType19);
        boolean boolean21 = iSOChronology2.equals((java.lang.Object) period16);
        java.lang.Class<?> wildcardClass22 = period16.getClass();
        int int23 = period16.getWeeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        int int6 = period3.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText(0, locale15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = offsetDateTimeField9.getMinimumValue(readablePartial17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean9 = cachedDateTimeZone8.isFixed();
        long long11 = cachedDateTimeZone8.nextTransition((long) (byte) 100);
        int int13 = cachedDateTimeZone8.getOffset((long) (byte) 10);
        int int15 = cachedDateTimeZone8.getOffsetFromLocal((long) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(10);
        java.lang.String str18 = dateTimeZone17.toString();
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone17.isLocalDateTimeGap(localDateTime19);
        long long22 = cachedDateTimeZone8.getMillisKeepLocal(dateTimeZone17, (long) 35);
        org.joda.time.DateTimeZone dateTimeZone23 = cachedDateTimeZone8.getUncachedZone();
        java.lang.String str25 = dateTimeZone23.getName((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36000000 + "'", int13 == 36000000);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 36000000 + "'", int15 == 36000000);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+10:00" + "'", str18.equals("+10:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+10:00" + "'", str25.equals("+10:00"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.toString();
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(64000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField16 = gregorianChronology14.seconds();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period21 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray24 = iSOChronology19.get((org.joda.time.ReadablePeriod) period21, (long) (short) 10, (long) 100);
        org.joda.time.Period period26 = period21.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType28 = period21.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField30 = new org.joda.time.field.ScaledDurationField(durationField16, durationFieldType28, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField32 = new org.joda.time.field.PreciseDurationField(durationFieldType28, (-210866760000000L));
        long long35 = preciseDurationField32.add(1L, (-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int37 = gregorianChronology36.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField38 = gregorianChronology36.seconds();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.Period period43 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray46 = iSOChronology41.get((org.joda.time.ReadablePeriod) period43, (long) (short) 10, (long) 100);
        org.joda.time.Period period48 = period43.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType50 = period43.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField52 = new org.joda.time.field.ScaledDurationField(durationField38, durationFieldType50, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField54 = new org.joda.time.field.PreciseDurationField(durationFieldType50, (-210866760000000L));
        org.joda.time.field.DecoratedDurationField decoratedDurationField55 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField32, durationFieldType50);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int57 = gregorianChronology56.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField58 = gregorianChronology56.seconds();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
        org.joda.time.Period period63 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray66 = iSOChronology61.get((org.joda.time.ReadablePeriod) period63, (long) (short) 10, (long) 100);
        org.joda.time.Period period68 = period63.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType70 = period63.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField72 = new org.joda.time.field.ScaledDurationField(durationField58, durationFieldType70, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField74 = new org.joda.time.field.PreciseDurationField(durationFieldType70, (-210866760000000L));
        long long77 = preciseDurationField74.add(10L, 0L);
        boolean boolean78 = preciseDurationField74.isPrecise();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField79 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType13, (org.joda.time.DurationField) decoratedDurationField55, (org.joda.time.DurationField) preciseDurationField74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The unit milliseconds must be at least 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfYear]" + "'", str10.equals("DateTimeField[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 210866760000001L + "'", long35 == 210866760000001L);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(durationFieldType50);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(durationFieldType70);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        boolean boolean11 = offsetDateTimeField9.isLeap(35000L);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField9.getWrappedField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (-35999900), (int) ' ', 10285);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35999900 for dayOfYear must be in the range [32,10285]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText(0, locale15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) 'a');
        int int19 = offsetDateTimeField9.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.eras();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period14 = new org.joda.time.Period((long) '#', (long) '#', periodType13);
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType13, (java.lang.Object) false);
        org.joda.time.Period period17 = new org.joda.time.Period(1560627811576L, periodType13);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period21 = new org.joda.time.Period((long) '#', (long) '#', periodType20);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period25 = new org.joda.time.Period((long) '#', (long) '#', periodType24);
        org.joda.time.Period period26 = period21.plus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period27 = period17.withFields((org.joda.time.ReadablePeriod) period26);
        boolean boolean28 = iSOChronology2.equals((java.lang.Object) period17);
        try {
            org.joda.time.Period period30 = period17.plusSeconds((-126000001));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period4 = period2.withMillis((int) 'a');
        org.joda.time.Period period6 = period4.minusMinutes((int) (byte) 1);
        int int7 = period6.getDays();
        org.joda.time.Period period9 = period6.withSeconds((int) (short) 1);
        int int10 = period6.size();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration12);
        org.joda.time.Period period15 = period13.plusWeeks(5);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.indexOf(durationFieldType19);
        boolean boolean21 = iSOChronology2.equals((java.lang.Object) period16);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology2.dayOfMonth();
        org.joda.time.Chronology chronology23 = iSOChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long14 = offsetDateTimeField9.getDifferenceAsLong(64000L, (long) 3);
        java.lang.String str15 = offsetDateTimeField9.getName();
        long long18 = offsetDateTimeField9.add((long) (byte) 0, (int) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfYear" + "'", str15.equals("dayOfYear"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2764800000L + "'", long18 == 2764800000L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        java.lang.String str9 = period8.toString();
        try {
            org.joda.time.Period period11 = period8.withMonths((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "P0D" + "'", str9.equals("P0D"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long13 = offsetDateTimeField9.roundHalfCeiling((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText(0, locale15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, (int) 'a');
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField18.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.clockhourOfDay();
        long long15 = iSOChronology9.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology9.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 4);
        java.lang.String str19 = offsetDateTimeField18.toString();
        java.lang.String str21 = offsetDateTimeField18.getAsShortText(64000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType22);
        try {
            int int26 = zeroIsMaxDateTimeField23.getDifference((-10L), 210866760000001L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210866760000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1120L) + "'", long15 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[dayOfYear]" + "'", str19.equals("DateTimeField[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        long long74 = scaledDurationField70.getMillis(8, 1260000000000L);
        int int77 = scaledDurationField70.getValue(2764800000L, (-1259999999990L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 64000L + "'", long74 == 64000L);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 345600 + "'", int77 == 345600);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        int int19 = offsetDateTimeField9.getMaximumValue(35L);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 370 + "'", int19 == 370);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getValueAsLong((long) (-35));
        long long21 = scaledDurationField16.getDifferenceAsLong((long) (byte) 10, 0L);
        long long24 = scaledDurationField16.getMillis(1L, 10L);
        long long27 = scaledDurationField16.getValueAsLong((-35999900L), (-59992L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 35000L + "'", long24 == 35000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1028L) + "'", long27 == (-1028L));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.toString();
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(64000L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfYear]" + "'", str10.equals("DateTimeField[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-35));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("hi!", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("-1", (-1));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.eras();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        long long21 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, 10L);
        java.util.TimeZone timeZone22 = dateTimeZone18.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.Chronology chronology24 = gregorianChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long19 = preciseDurationField18.getUnitMillis();
        try {
            long long22 = preciseDurationField18.add((long) (byte) 1, (-31312800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -31312800000 * -210866760000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-210866760000000L) + "'", long19 == (-210866760000000L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        boolean boolean11 = offsetDateTimeField9.isLeap((long) 4);
        try {
            long long14 = offsetDateTimeField9.set((long) (-35), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [5,370]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period5 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray8 = iSOChronology3.get((org.joda.time.ReadablePeriod) period5, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.secondOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.clockhourOfDay();
        long long16 = iSOChronology10.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology10.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 4);
        java.lang.String str20 = offsetDateTimeField19.toString();
        java.lang.String str22 = offsetDateTimeField19.getAsShortText(64000L);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField19.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType23);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1120L) + "'", long16 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[dayOfYear]" + "'", str20.equals("DateTimeField[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "5" + "'", str22.equals("5"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        boolean boolean19 = scaledDurationField16.isPrecise();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long21 = preciseDurationField18.add(10L, 0L);
        boolean boolean22 = preciseDurationField18.isPrecise();
        long long25 = preciseDurationField18.getDifferenceAsLong((long) 'a', (long) 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        org.joda.time.ReadablePartial readablePartial96 = null;
        java.util.Locale locale98 = null;
        try {
            java.lang.String str99 = unsupportedDateTimeField95.getAsText(readablePartial96, (-1), locale98);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        try {
            long long97 = unsupportedDateTimeField95.roundHalfCeiling((long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gregorianChronology10.seconds();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.Period period17 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray20 = iSOChronology15.get((org.joda.time.ReadablePeriod) period17, (long) (short) 10, (long) 100);
        org.joda.time.Period period22 = period17.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType24 = period17.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType24, (int) '#');
        boolean boolean27 = periodType7.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType24, 0L);
        org.joda.time.DurationFieldType[] durationFieldTypeArray30 = new org.joda.time.DurationFieldType[] { durationFieldType24 };
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.forFields(durationFieldTypeArray30);
        org.joda.time.PeriodType periodType32 = periodType31.withWeeksRemoved();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(durationFieldTypeArray30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(2764800000L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.Period period5 = period3.plusMonths((int) (short) 0);
        int[] intArray6 = period5.getValues();
        boolean boolean8 = period5.equals((java.lang.Object) (-36000000));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "45");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str10 = offsetDateTimeField9.toString();
        java.lang.String str11 = offsetDateTimeField9.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfYear]" + "'", str10.equals("DateTimeField[dayOfYear]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "dayOfYear" + "'", str11.equals("dayOfYear"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = gregorianChronology10.seconds();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.Period period17 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray20 = iSOChronology15.get((org.joda.time.ReadablePeriod) period17, (long) (short) 10, (long) 100);
        org.joda.time.Period period22 = period17.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType24 = period17.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField26 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType24, (int) '#');
        boolean boolean27 = periodType7.isSupported(durationFieldType24);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType24, 0L);
        org.joda.time.Period period31 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period33 = period31.withMillis((int) 'a');
        org.joda.time.Period period35 = period33.minusMinutes((int) (byte) 1);
        org.joda.time.Period period37 = period35.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Duration duration39 = period37.toDurationTo(readableInstant38);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period42 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration39, readableInstant40, periodType41);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.secondOfMinute();
        java.lang.String str47 = iSOChronology43.toString();
        try {
            org.joda.time.Period period48 = new org.joda.time.Period((java.lang.Object) durationFieldType24, periodType41, (org.joda.time.Chronology) iSOChronology43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.DurationFieldType$StandardDurationFieldType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationFieldType24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(duration39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[UTC]" + "'", str47.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = period3.withMonths((int) (short) 100);
        int int10 = period3.getWeeks();
        int int11 = period3.getHours();
        int int12 = period3.getYears();
        org.joda.time.Period period14 = period3.withDays(11);
        org.joda.time.Period period16 = period14.plusSeconds(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        long long14 = offsetDateTimeField9.getDifferenceAsLong(64000L, (long) 3);
        boolean boolean16 = offsetDateTimeField9.isLeap((long) (-36000000));
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.clockhourOfDay();
        org.joda.time.Period period23 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period25 = period23.withMillis((int) 'a');
        org.joda.time.Period period27 = period25.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType28 = null;
        int int29 = period25.indexOf(durationFieldType28);
        org.joda.time.Period period31 = period25.plusMillis(1);
        int[] intArray34 = iSOChronology19.get((org.joda.time.ReadablePeriod) period31, (long) '#', (long) (short) 1);
        java.util.Locale locale36 = null;
        try {
            int[] intArray37 = offsetDateTimeField9.set(readablePartial17, (int) (byte) 10, intArray34, "", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        java.util.Locale locale97 = null;
        try {
            java.lang.String str98 = unsupportedDateTimeField95.getAsShortText(0, locale97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        long long74 = scaledDurationField16.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType75 = org.joda.time.PeriodType.standard();
        boolean boolean76 = scaledDurationField16.equals((java.lang.Object) periodType75);
        long long79 = scaledDurationField16.add(0L, 345600);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 350100L + "'", long74 == 350100L);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 12096000000L + "'", long79 == 12096000000L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.eras();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone12);
        try {
            long long19 = zonedChronology13.getDateTimeMillis(3L, 45, (int) (short) -1, 45, (-10285));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException99 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 864000000L, (java.lang.Number) (-359999999L), (java.lang.Number) 3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long20 = preciseDurationField18.getMillis(0L);
        long long22 = preciseDurationField18.getValueAsLong((long) 8);
        long long25 = preciseDurationField18.getMillis((long) 35, 3500000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-7380336600000000L) + "'", long25 == (-7380336600000000L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) '#', (long) '#', periodType5);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType5, (java.lang.Object) false);
        org.joda.time.Period period9 = new org.joda.time.Period(1560627811576L, periodType5);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType5);
        org.joda.time.PeriodType periodType11 = periodType5.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period16 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray19 = iSOChronology14.get((org.joda.time.ReadablePeriod) period16, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.secondOfDay();
        org.joda.time.DurationField durationField21 = iSOChronology14.eras();
        org.joda.time.Chronology chronology22 = iSOChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology14.clockhourOfHalfday();
        boolean boolean24 = periodType11.equals((java.lang.Object) dateTimeField23);
        org.joda.time.PeriodType periodType25 = periodType11.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(periodType25);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(7);
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.secondOfDay();
        org.joda.time.DurationField durationField12 = iSOChronology5.eras();
        org.joda.time.Chronology chronology13 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology5.clockhourOfHalfday();
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology5);
        boolean boolean16 = periodType2.equals((java.lang.Object) chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(64000L, (long) 3, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        java.lang.String str4 = periodType2.getName();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Minutes" + "'", str4.equals("Minutes"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Period period4 = new org.joda.time.Period(0, (-35), 8, (int) (short) 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("+10:00");
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone2);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 1, true);
        org.joda.time.Chronology chronology11 = zonedChronology3.withZone(dateTimeZone6);
        try {
            long long19 = zonedChronology3.getDateTimeMillis(4, 0, 0, (int) (byte) 10, (-1), 4, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-359999999L) + "'", long10 == (-359999999L));
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-35));
        boolean boolean3 = dateTimeZone1.isStandardOffset(8000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = iSOChronology0.set(readablePartial7, 377999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType3, (java.lang.Object) false);
        org.joda.time.Period period7 = new org.joda.time.Period(1560627811576L, periodType3);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', (long) '#', periodType10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', (long) '#', periodType14);
        org.joda.time.Period period16 = period11.plus((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period7.withFields((org.joda.time.ReadablePeriod) period16);
        int[] intArray18 = period7.getValues();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        org.joda.time.Period period3 = period1.plusWeeks((int) (short) 0);
        org.joda.time.Period period5 = period3.withMonths(11);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DurationField durationField9 = iSOChronology2.eras();
        org.joda.time.Chronology chronology10 = iSOChronology2.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance(chronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period16 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray19 = iSOChronology14.get((org.joda.time.ReadablePeriod) period16, (long) (short) 10, (long) 100);
        org.joda.time.Period period21 = period16.withMinutes((int) (byte) 10);
        boolean boolean22 = lenientChronology11.equals((java.lang.Object) period16);
        java.lang.String str23 = lenientChronology11.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        long long30 = dateTimeZone25.getMillisKeepLocal(dateTimeZone27, 10L);
        java.util.TimeZone timeZone31 = dateTimeZone27.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone27);
        boolean boolean33 = cachedDateTimeZone32.isFixed();
        long long35 = cachedDateTimeZone32.nextTransition((long) (byte) 100);
        int int37 = cachedDateTimeZone32.getStandardOffset((-210858120000000L));
        org.joda.time.Chronology chronology38 = lenientChronology11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone32);
        java.lang.String str39 = lenientChronology11.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str23.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 36000000 + "'", int37 == 36000000);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str39.equals("LenientChronology[ISOChronology[UTC]]"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long21 = preciseDurationField18.add(10L, 0L);
        boolean boolean22 = preciseDurationField18.isPrecise();
        boolean boolean23 = preciseDurationField18.isPrecise();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 0);
        org.joda.time.Period period3 = period1.plusWeeks((int) (short) 0);
        int int4 = period3.getDays();
        java.lang.String str5 = period3.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("YearMonthDayTime");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"YearMonthDayTime\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        int int13 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0f, (java.lang.Number) 10L, (java.lang.Number) 100L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10L + "'", number5.equals(10L));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.withSeconds((int) (short) 1);
        int int9 = period5.size();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period5.toDurationTo(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period5.toDurationFrom(readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration13, readableInstant14);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(duration13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period(1560627811576L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.yearOfEra();
        org.joda.time.DurationField durationField6 = iSOChronology1.millis();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Period period1 = org.joda.time.Period.months(10000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        try {
            long long98 = unsupportedDateTimeField95.addWrapField((-25L), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumShortTextLength(locale10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField9.getAsShortText((long) 4, locale13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5" + "'", str14.equals("5"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(35);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        boolean boolean96 = unsupportedDateTimeField95.isLenient();
        try {
            java.lang.String str98 = unsupportedDateTimeField95.getAsShortText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getValueAsLong((long) (-35));
        long long21 = scaledDurationField16.getDifferenceAsLong((long) (byte) 10, 0L);
        long long24 = scaledDurationField16.getMillis(1L, 10L);
        long long27 = scaledDurationField16.getDifferenceAsLong((long) 369, 1259971200000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 35000L + "'", long24 == 35000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-35999177L) + "'", long27 == (-35999177L));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.Period period2 = new org.joda.time.Period((-9489004200000000L), (long) (short) 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        java.lang.String str3 = gregorianChronology0.toString();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((-126000001), 36000000, 100, 0, 8, (-126000001), 369);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -126000001 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(36000000, '4', (int) (short) -1, 36000000, (int) (byte) -1, false, (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("YearMonthDayTime", 35, (int) (byte) 100, 0, '4', 1, 8, (int) (byte) -1, false, 10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.Period period25 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray28 = iSOChronology23.get((org.joda.time.ReadablePeriod) period25, (long) (short) 10, (long) 100);
        org.joda.time.Period period30 = period25.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType32 = period25.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType32, (int) '#');
        long long36 = scaledDurationField34.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField39 = gregorianChronology37.seconds();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period44 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray47 = iSOChronology42.get((org.joda.time.ReadablePeriod) period44, (long) (short) 10, (long) 100);
        org.joda.time.Period period49 = period44.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType51 = period44.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType51, (int) '#');
        org.joda.time.Period period55 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period57 = period55.withMillis((int) 'a');
        org.joda.time.Period period59 = period57.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType60 = null;
        int int61 = period57.indexOf(durationFieldType60);
        org.joda.time.Period period63 = period57.withMonths((int) (short) 100);
        int int64 = period57.getWeeks();
        int int65 = period57.getHours();
        int int66 = period57.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int68 = gregorianChronology67.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField69 = gregorianChronology67.seconds();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period74 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray77 = iSOChronology72.get((org.joda.time.ReadablePeriod) period74, (long) (short) 10, (long) 100);
        org.joda.time.Period period79 = period74.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType81 = period74.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField83 = new org.joda.time.field.ScaledDurationField(durationField69, durationFieldType81, (int) '#');
        boolean boolean84 = period57.isSupported(durationFieldType81);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType81, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField88 = new org.joda.time.field.ScaledDurationField(durationField39, durationFieldType81, 8);
        int int89 = scaledDurationField34.compareTo((org.joda.time.DurationField) scaledDurationField88);
        long long92 = scaledDurationField34.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType93 = org.joda.time.PeriodType.standard();
        boolean boolean94 = scaledDurationField34.equals((java.lang.Object) periodType93);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField34);
        org.joda.time.ReadablePartial readablePartial96 = null;
        try {
            int int97 = unsupportedDateTimeField95.getMinimumValue(readablePartial96);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1260000000000L + "'", long36 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 350100L + "'", long92 == 350100L);
        org.junit.Assert.assertNotNull(periodType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "PT-1H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "hi!", "hi!");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "PT-1H0.097S", "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 ()");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale15 = null;
        java.lang.String str18 = defaultNameProvider0.getShortName(locale15, "GregorianChronology[UTC]", "5");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType5);
        org.joda.time.PeriodType periodType7 = periodType5.withHoursRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType7);
        org.joda.time.Period period10 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period12 = period10.withMillis((int) 'a');
        org.joda.time.Period period14 = period12.minusMinutes((int) (byte) 1);
        org.joda.time.Period period16 = period14.minusSeconds(100);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period16.toDurationTo(readableInstant17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant19, periodType20);
        org.joda.time.Period period22 = period8.normalizedStandard(periodType20);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        int int6 = period5.getDays();
        org.joda.time.Period period8 = period5.minusHours((int) (byte) 10);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period12 = new org.joda.time.Period((long) '#', (long) '#', periodType11);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period16 = new org.joda.time.Period((long) '#', (long) '#', periodType15);
        org.joda.time.Period period17 = period12.plus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.days();
        org.joda.time.Period period19 = period17.withPeriodType(periodType18);
        org.joda.time.Period period20 = period5.normalizedStandard(periodType18);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3) + "'", int1 == (-3));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-35));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("hi!", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder5.setStandardOffset((int) ' ');
        java.io.DataOutput dataOutput9 = null;
        try {
            dateTimeZoneBuilder7.writeTo("PeriodType[Weeks]", dataOutput9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
        java.lang.String str9 = dateTimeZone3.getName(1259971200000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+10:00" + "'", str9.equals("+10:00"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period3 = period1.withMillis((int) 'a');
        org.joda.time.Period period5 = period3.minusMinutes((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        org.joda.time.Period period7 = period3.normalizedStandard();
        try {
            org.joda.time.DurationFieldType durationFieldType9 = period3.getFieldType((-10285));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        org.joda.time.DurationField durationField9 = iSOChronology0.centuries();
        org.joda.time.DurationField durationField10 = iSOChronology0.minutes();
        long long13 = durationField10.subtract((-360000000L), 0L);
        org.joda.time.Period period15 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period17 = period15.withMillis((int) 'a');
        org.joda.time.Period period19 = period17.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period17.indexOf(durationFieldType20);
        org.joda.time.Period period23 = period17.withMonths((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType29 = periodType28.withWeeksRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant26, readableDuration27, periodType29);
        org.joda.time.PeriodType periodType31 = periodType29.withHoursRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant24, readableDuration25, periodType31);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray40 = iSOChronology35.get((org.joda.time.ReadablePeriod) period37, (long) (short) 10, (long) 100);
        org.joda.time.Period period42 = period37.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType44 = period37.getFieldType(0);
        int int45 = period32.get(durationFieldType44);
        int int46 = period17.get(durationFieldType44);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType44, (-126000001));
        long long50 = scaledDurationField48.getValueAsLong((long) 10285);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-360000000L) + "'", long13 == (-360000000L));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) '#', (long) '#', periodType6);
        org.joda.time.Period period8 = period3.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Period period10 = period8.withPeriodType(periodType9);
        org.joda.time.Period period11 = period8.toPeriod();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period11.plus(readablePeriod12);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, 10L);
        long long10 = dateTimeZone1.convertLocalToUTC(100L, false, 1560627811576L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone1.getName((long) 7, locale12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        long long20 = dateTimeZone15.getMillisKeepLocal(dateTimeZone17, 10L);
        java.util.TimeZone timeZone21 = dateTimeZone17.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period27 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray30 = iSOChronology25.get((org.joda.time.ReadablePeriod) period27, (long) (short) 10, (long) 100);
        org.joda.time.Period period32 = period27.withMinutes((int) (byte) 10);
        boolean boolean33 = cachedDateTimeZone22.equals((java.lang.Object) period32);
        org.joda.time.DateTimeZone dateTimeZone34 = cachedDateTimeZone22.getUncachedZone();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider35 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale36 = null;
        java.lang.String str39 = defaultNameProvider35.getShortName(locale36, "", "PT-1H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider35);
        java.util.Locale locale41 = null;
        java.lang.String str44 = defaultNameProvider35.getName(locale41, "hi!", "hi!");
        java.util.Locale locale45 = null;
        java.lang.String str48 = defaultNameProvider35.getShortName(locale45, "", "PT-1H0.097S");
        boolean boolean49 = cachedDateTimeZone22.equals((java.lang.Object) locale45);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period53 = new org.joda.time.Period((long) '#', (long) '#', periodType52);
        org.joda.time.Period period55 = period53.plusMonths((int) (short) 0);
        boolean boolean56 = cachedDateTimeZone22.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        int int59 = cachedDateTimeZone22.getStandardOffset(2440588L);
        long long61 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone22, 518400010L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-35999900L) + "'", long10 == (-35999900L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+10:00" + "'", str13.equals("+10:00"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 36000000 + "'", int59 == 36000000);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 518400010L + "'", long61 == 518400010L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', (long) '#', periodType2);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType2, (java.lang.Object) false);
        org.joda.time.PeriodType periodType6 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withMinutesRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMillisRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.Period period11 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period13 = period11.withMillis((int) 'a');
        org.joda.time.Period period15 = period13.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        int int17 = period13.indexOf(durationFieldType16);
        org.joda.time.Period period19 = period13.withMonths((int) (short) 100);
        int int20 = period13.getWeeks();
        int int21 = period13.getHours();
        int int22 = period13.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int24 = gregorianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField25 = gregorianChronology23.seconds();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.Period period30 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray33 = iSOChronology28.get((org.joda.time.ReadablePeriod) period30, (long) (short) 10, (long) 100);
        org.joda.time.Period period35 = period30.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType37 = period30.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField39 = new org.joda.time.field.ScaledDurationField(durationField25, durationFieldType37, (int) '#');
        boolean boolean40 = period13.isSupported(durationFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(durationFieldType37, "+10:00");
        boolean boolean43 = periodType8.isSupported(durationFieldType37);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-35));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 10, 100, 0, '#', 0, (int) (byte) 1, (int) '#', true, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[UTC]", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(5, 35);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        int int13 = offsetDateTimeField9.getMaximumValue(210866760000001L);
        long long16 = offsetDateTimeField9.addWrapField(3023999999L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        boolean boolean19 = offsetDateTimeField9.isLeap((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField9.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 370 + "'", int13 == 370);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3023999999L + "'", long16 == 3023999999L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', (long) '#', periodType3);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', (long) '#', periodType7);
        org.joda.time.Period period9 = period4.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationTo(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant13);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((-1), (int) (short) 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        long long18 = scaledDurationField16.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology19.seconds();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period26 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray29 = iSOChronology24.get((org.joda.time.ReadablePeriod) period26, (long) (short) 10, (long) 100);
        org.joda.time.Period period31 = period26.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType33 = period26.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType33, (int) '#');
        org.joda.time.Period period37 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period39 = period37.withMillis((int) 'a');
        org.joda.time.Period period41 = period39.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = period39.indexOf(durationFieldType42);
        org.joda.time.Period period45 = period39.withMonths((int) (short) 100);
        int int46 = period39.getWeeks();
        int int47 = period39.getHours();
        int int48 = period39.getYears();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField51 = gregorianChronology49.seconds();
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period56 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray59 = iSOChronology54.get((org.joda.time.ReadablePeriod) period56, (long) (short) 10, (long) 100);
        org.joda.time.Period period61 = period56.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType63 = period56.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField65 = new org.joda.time.field.ScaledDurationField(durationField51, durationFieldType63, (int) '#');
        boolean boolean66 = period39.isSupported(durationFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(durationFieldType63, "+10:00");
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType63, 8);
        int int71 = scaledDurationField16.compareTo((org.joda.time.DurationField) scaledDurationField70);
        long long74 = scaledDurationField16.add(100L, (long) (byte) 10);
        org.joda.time.PeriodType periodType75 = org.joda.time.PeriodType.standard();
        boolean boolean76 = scaledDurationField16.equals((java.lang.Object) periodType75);
        org.joda.time.PeriodType periodType77 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean78 = scaledDurationField16.equals((java.lang.Object) periodType77);
        java.lang.Object obj79 = null;
        boolean boolean80 = scaledDurationField16.equals(obj79);
        long long83 = scaledDurationField16.getValueAsLong((long) 3, (-210866760000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260000000000L + "'", long18 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(durationFieldType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 350100L + "'", long74 == 350100L);
        org.junit.Assert.assertNotNull(periodType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(periodType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfDay();
        long long7 = iSOChronology1.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean9 = iSOChronology1.equals((java.lang.Object) periodType8);
        org.joda.time.DurationField durationField10 = iSOChronology1.centuries();
        org.joda.time.DurationField durationField11 = iSOChronology1.minutes();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1000, (org.joda.time.Chronology) iSOChronology1);
        try {
            long long17 = iSOChronology1.getDateTimeMillis(8, 370, (-11), 370);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 370 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1120L) + "'", long7 == (-1120L));
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 10285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10295 + "'", int2 == 10295);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 3500000L, (java.lang.Number) 8, (java.lang.Number) 3L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int23 = gregorianChronology22.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField24 = gregorianChronology22.seconds();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.Period period29 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray32 = iSOChronology27.get((org.joda.time.ReadablePeriod) period29, (long) (short) 10, (long) 100);
        org.joda.time.Period period34 = period29.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType36 = period29.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField38 = new org.joda.time.field.ScaledDurationField(durationField24, durationFieldType36, (int) '#');
        long long40 = scaledDurationField38.getMillis(36000000);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int42 = gregorianChronology41.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField43 = gregorianChronology41.seconds();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period48 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray51 = iSOChronology46.get((org.joda.time.ReadablePeriod) period48, (long) (short) 10, (long) 100);
        org.joda.time.Period period53 = period48.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType55 = period48.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField57 = new org.joda.time.field.ScaledDurationField(durationField43, durationFieldType55, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField59 = new org.joda.time.field.PreciseDurationField(durationFieldType55, (-210866760000000L));
        long long62 = preciseDurationField59.add(1L, (-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int64 = gregorianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField65 = gregorianChronology63.seconds();
        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone67);
        org.joda.time.Period period70 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray73 = iSOChronology68.get((org.joda.time.ReadablePeriod) period70, (long) (short) 10, (long) 100);
        org.joda.time.Period period75 = period70.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType77 = period70.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField79 = new org.joda.time.field.ScaledDurationField(durationField65, durationFieldType77, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField81 = new org.joda.time.field.PreciseDurationField(durationFieldType77, (-210866760000000L));
        org.joda.time.field.DecoratedDurationField decoratedDurationField82 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) preciseDurationField59, durationFieldType77);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField83 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType17, (org.joda.time.DurationField) scaledDurationField38, (org.joda.time.DurationField) decoratedDurationField82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1260000000000L + "'", long40 == 1260000000000L);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(durationFieldType55);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 210866760000001L + "'", long62 == 210866760000001L);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertNotNull(iSOChronology68);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(period75);
        org.junit.Assert.assertNotNull(durationFieldType77);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("DateTimeField[dayOfYear]");
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText(45, locale11);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField9.getAsText((int) (short) -1, locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 3500000L, (java.lang.Number) 8, (java.lang.Number) 3L);
        java.lang.String str22 = illegalFieldValueException21.getFieldName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "45" + "'", str12.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "dayOfYear" + "'", str22.equals("dayOfYear"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) periodType7);
        java.lang.String str9 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        long long6 = iSOChronology0.add(0L, (long) ' ', (-35));
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 4);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 10);
        int int13 = offsetDateTimeField9.getMaximumValue(210866760000001L);
        org.joda.time.DurationField durationField14 = offsetDateTimeField9.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1120L) + "'", long6 == (-1120L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 370 + "'", int13 == 370);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Period period4 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray7 = iSOChronology2.get((org.joda.time.ReadablePeriod) period4, (long) (short) 10, (long) 100);
        long long12 = iSOChronology2.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 10, 36000000);
        org.joda.time.Period period14 = org.joda.time.Period.hours((int) (byte) -1);
        org.joda.time.Period period16 = period14.withMillis((int) 'a');
        org.joda.time.Period period18 = period16.minusMinutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period16.indexOf(durationFieldType19);
        boolean boolean21 = iSOChronology2.equals((java.lang.Object) period16);
        org.joda.time.DateTimeZone dateTimeZone22 = iSOChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology2.getZone();
        org.joda.time.DurationField durationField24 = iSOChronology2.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62142768000000L) + "'", long12 == (-62142768000000L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.Period period7 = org.joda.time.Period.hours((int) (byte) -1);
        int[] intArray10 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, (long) (short) 10, (long) 100);
        org.joda.time.Period period12 = period7.withMinutes((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType14, (int) '#');
        org.joda.time.field.PreciseDurationField preciseDurationField18 = new org.joda.time.field.PreciseDurationField(durationFieldType14, (-210866760000000L));
        long long20 = preciseDurationField18.getMillis(0L);
        long long23 = preciseDurationField18.getValueAsLong((-36000000000L), 1L);
        long long26 = preciseDurationField18.getMillis(10L, 518400010L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2108667600000000L) + "'", long26 == (-2108667600000000L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 36000000, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withHoursRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }
}

